#V 1.0.14
import xbmc , xbmcaddon , xbmcgui , xbmcplugin , requests , urllib , urllib2 , json , os , re , sys , datetime , urlresolver , random , liveresolver , base64 , pyxbmct
from resources . lib . common_addon import Addon
from HTMLParser import HTMLParser
from metahandler import metahandlers
import nanscrapers
import requests
import downloader as Get_Files
import extract
import time
if 64 - 64: i11iIiiIii
VVeve = 'plugin.video.picasso'
VeevVee = Addon ( VVeve , sys . argv )
VevVevVVevVevVev = xbmcaddon . Addon ( id = VVeve )
iiiii = xbmcaddon . Addon ( ) . getAddonInfo
eeeevVV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'fanart.png' ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'fanart.png' ) )
Veveveeeeeevev = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'icon.png' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + '/resources/art' , 'next.png' ) )
IIi1IiiiI1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + '/resources' , 'rd.txt' ) )
I11i11Ii = 'http://matsbuilds.uk/pin'
eVeveveVe = xbmcaddon . Addon ( ) . getSetting ( 'password' )
VVVeev = xbmcaddon . Addon ( ) . getSetting ( 'enable_meta' )
Veeeeveveve = base64 . b64decode ( 'aHR0cHM6Ly94aGFtc3Rlci5jb20v' )
IiIi11iIIi1Ii = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
VeevV = requests . session ( )
IiI = base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvYW5ld0V2b2x2ZW1lbnUvaW5mby50eHQ=' )
eeVe = xbmc . translatePath ( 'special://home/userdata/addon_data/' + VVeve )
Ve = xbmc . translatePath ( os . path . join ( 'special://home/userdata/Database' , 'picasso.db' ) )
eevV = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'repository.Goliath' ) )
IiiIII111iI = '[COLOR cyan]Picasso[/COLOR]'
IiII = open ( Ve , 'a' )
IiII . close ( )
if 28 - 28: Ii11111i * iiI1i1
if 46 - 46: VeeevVVeveVV * Ii * Veeve
if not os . path . exists ( eevV ) :
 VVVeveeve = xbmcgui . Dialog ( ) . yesno ( IiiIII111iI , 'This Add-on requires [COLOR cyan]Goliaths Repo[/COLOR] to be installed to work correctly would you like to install it now?' , '' , yeslabel = '[B][COLOR white]YES[/COLOR][/B]' , nolabel = '[B][COLOR grey]NO[/COLOR][/B]' )
 if VVVeveeve == 1 :
  Ii1iI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  if not os . path . exists ( Ii1iI ) :
   os . makedirs ( Ii1iI )
  VeI1Ii11I1Ii1i = base64 . b64decode ( b'aHR0cDovL21hdHNidWlsZHMudWsvZ29saWF0aC9yZXBvc2l0b3J5LkdvbGlhdGgtMS40LnppcA==' )
  Vee = xbmcgui . DialogProgress ( )
  Vee . create ( IiiIII111iI , "" , "" , "Downloading [COLOR cyan]Goliaths Repo[/COLOR]" )
  eeveVeVeveve = os . path . join ( Ii1iI , 'repo.zip' )
  if 43 - 43: VevVVe . II1Iiii1111i
  try :
   os . remove ( eeveVeVeveve )
  except :
   pass
   if 25 - 25: VVeevevev
  Get_Files . download ( VeI1Ii11I1Ii1i , eeveVeVeveve , Vee )
  Vev = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
  time . sleep ( 2 )
  Vee . update ( 0 , "" , "Installing [COLOR red]Golitaths Repo[/COLOR] Please Wait" , "" )
  extract . all ( eeveVeVeveve , Vev , Vee )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  xbmc . executebuiltin ( "UpdateLocalAddons" )
  if 34 - 34: Veveevev % eeveee / VVVevV / I1ii * eVVVeeveevV + VVeVeeevevee
  if 41 - 41: i11IiIiiIIIII / IiiIII111ii / i1iIIi1
def ii11iIi1I ( st ) :
 import re
 st = re . sub ( '\[.+\]' , '' , st )
 import string
 iI111I11I1I1 = 0
 for VeevV in st :
  if VeevV in 'lij|\' ' : iI111I11I1I1 += 37
  elif VeevV in '![]fI.,:;/\\t' : iI111I11I1I1 += 50
  elif VeevV in '`-(){}r"' : iI111I11I1I1 += 60
  elif VeevV in '*^zcsJkvxy' : iI111I11I1I1 += 85
  elif VeevV in 'aebdhnopqug#$L+<>=?_~FZT' + string . digits : iI111I11I1I1 += 95
  elif VeevV in 'BSPEAKVXY&UwNRCHD' : iI111I11I1I1 += 112
  elif VeevV in 'QGOMm%W@' : iI111I11I1I1 += 135
  else : iI111I11I1I1 += 50
 return int ( iI111I11I1I1 * 6.5 / 100 )
 if 55 - 55: iI1I % iiiIi - eVVVeeveevV / Ii11111i % eeveee + VVeevevev
def iI111IiI111I ( Heading = xbmcaddon . Addon ( ) . getAddonInfo ( 'name' ) ) :
 VeeVeVevVe = xbmc . Keyboard ( '' , Heading )
 VeeVeVevVe . doModal ( )
 if ( VeeVeVevVe . isConfirmed ( ) ) :
  return VeeVeVevVe . getText ( )
  if 47 - 47: I1ii
def iiIiIiIi ( url ) :
 if 33 - 33: i11IiIiiIIIII + Veeve % i11iIiiIii . iiiIi - VevVVe
 import webbrowser
 if 66 - 66: i11IiIiiIIIII - VeeevVVeveVV * VeeevVVeveVV . eVVVeeveevV . VVVevV
 IiI1i11iii1 = webbrowser . open
 eeevVeevevVeev = xbmc . executebuiltin
 eVVVeveve = lambda VevVeveveevVVVev : xbmc . getCondVisibility ( str ( VevVeveveevVVVev ) )
 Ii1iIIIi1ii = lambda VevVeveveevVVVev : eeevVeevevVeev ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( VevVeveveevVVVev ) )
 if 80 - 80: VVeVeeevevee * i11iIiiIii / iI1I
 I11II1i = 'System.Platform.Android'
 if 23 - 23: VVVevV / eeveee + VVeVeeevevee + VVeVeeevevee / Veeve
 if eVVVeveve ( I11II1i ) : Ii1iIIIi1ii ( base64 . b64decode ( url ) )
 else : IiI1i11iii1 ( base64 . b64decode ( url ) )
 if 26 - 26: VeeevVVeveVV
 if 12 - 12: VeeevVVeveVV % Veveevev / iiiIi % eeveee
def iiii ( ) :
 if 54 - 54: VVVevV * eVVVeeveevV
 if 13 - 13: i1iIIi1 + Veveevev - VeeevVVeveVV + iI1I . IiiIII111ii + VVeevevev
 import sys
 if 8 - 8: iiI1i1 . VevVVe - iiI1i1 * i11IiIiiIIIII
 VVVV = 'aHR0cDovL29mZnNob3JlcGx1Z2lucy5jb20vcG9ydGFsL2FwcGxpY2F0aW9uLnBocD9pZD1wbHVnaW4udmlkZW8ucGljYXNzbw=='
 VVVevev = 'YzFkZmYwYzYxZjQ3MDY0'
 iiiiiIIii = base64 . b64decode ( 'aHR0cDovL29mZnNob3JlcGx1Z2lucy5jb20vcG9ydGFsL2FwaS5waHA/cGluPSVzJmtleT0=' ) + base64 . b64decode ( VVVevev )
 VevevevVVev = 'W0NPTE9SIGN5YW5dSW4gb3JkZXIgdG8gY29udGludWUgcGxlYXNlWy9DT0xPUl0gW0NPTE9SIHdoaXRlXVtCXVZFUklGWVsvQl1bL0NPTE9SXSBbQ09MT1IgY3lhbl15b3VyIGRldmljZSBieSBnZXR0aW5nIGFbL0NPTE9SXVtDT0xPUiB3aGl0ZV1bQl0gRlJFRSBQSU5bL0JdWy9DT0xPUl1bQ09MT1IgY3lhbl0gZnJvbSBvdXIgd2Vic2l0ZSBhbmQgZW50ZXJpbmcgdGhlIHBpbiBvbiB0aGUgbmV4dCBwcm9tdC4gIFsvQ09MT1JdW0NPTE9SIHdoaXRlXVtCXXwgICB3d3cubWF0c2J1aWxkcy51ay9waW5bL0JdWy9DT0xPUl0='
 if 43 - 43: iI1I - Ii11111i % VevVVe . VVeVeeevevee
 eevev = base64 . b64decode ( VevevevVVev )
 VeeVeee = xbmcaddon . Addon ( ) . getAddonInfo
 VeveveveeevV = xbmcaddon . Addon ( ) . getSetting ( 'pin' )
 VVVVi11i1 = lambda VevVeveveevVVVev : base64 . b64decode ( str ( VevVeveveevVVVev ) )
 IIIii1II1II = lambda VevVeveveevVVVev : requests . get ( iiiiiIIii % ( VevVeveveevVVVev ) ) . text . strip ( )
 i1I1iI = lambda VevVeveveevVVVev : xbmcaddon . Addon ( ) . setSetting ( base64 . b64decode ( 'cGlu' ) , VevVeveveevVVVev )
 eeevVeeVVeev = lambda VevVeveveevVVVev : xbmcgui . Dialog ( ) . yesno ( VeeVeee ( 'name' ) , VevVeveveevVVVev , yeslabel = "Get A Pin" , nolabel = 'Cancel' )
 eevVVeveveV = bool ( IIIii1II1II ( VeveveveeevV ) == base64 . b64decode ( 'UGluIFZlcmlmaWVk' ) )
 if 39 - 39: i1iIIi1 - Veeve * VVeevevev % eeveee * Veeve % Veeve
 if eevVVeveveV : return
 else :
  if 59 - 59: iiI1i1 + VevVVe - eeveee - VevVVe + eVVVeeveevV / VVVevV
  if eeevVeeVVeev ( eevev ) :
   iiIiIiIi ( VVVV )
   I1 = iI111IiI111I ( 'Type Your Pin Here' )
   i1I1iI ( I1 )
   iiii ( )
  else : sys . exit ( )
  if 71 - 71: eVVVeeveevV + iiiIi % i11iIiiIii + VVVevV - i1iIIi1
  if 88 - 88: Veveevev - VVeevevev % eVVVeeveevV
  if 16 - 16: VevVVe * I1ii % i1iIIi1
def Veeveveve ( ) :
 if not os . path . exists ( eeVe ) :
  os . mkdir ( eeVe )
 I11IiI1I11i1i ( IiI , 'GlobalCompare' )
 iI1ii1Ii ( '[B][COLOR yellow]Keep Safe[/COLOR][/B]' , 'url' , 22 , 'http://i.imgur.com/cR0cP8f.png' , II1 )
 iI1ii1Ii ( '[B][COLOR yellow]Find It...[/COLOR][/B]' , 'url' , 5 , 'http://i.imgur.com/ZQYQyHG.png' , II1 )
 iI1ii1Ii ( '[B][COLOR cyan]Movie Madness[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvTW92aWVzL01haW5tZW51LnhtbA==' ) , 26 , 'http://i.imgur.com/Y2rejnc.png' , II1 )
 iI1ii1Ii ( '[B][COLOR cyan]Telly Box[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvVHZTaG93cy9NYWlubWVudS54bWw=' ) , 27 , 'http://i.imgur.com/63LrHYW.png' , II1 )
 eeeeevevev = iIIIi1 ( iiII1i1 )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in eeveveVVeve :
  VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVVevevV )
  for VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV in VVeVVeveeeveeV :
   iI1ii1Ii ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , 1 , VevevVeveVVevevVevev , eeeevVV )
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 11 - 11: i1iIIi1 . VVVevV
def eev ( name , url , iconimage , fanart ) :
 iI1ii1Ii ( '[B][COLOR yellow]MOVIE SEARCH[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvTW92aWVzL1NlYXJjaC9TZWFyY2gudHh0' ) , 5 , 'http://i.imgur.com/QArRVYb.png' , II1 )
 iI1ii1Ii ( '[B][COLOR yellow]UK CINEMA RELEASE DATES[/COLOR][/B]' , 'http://www.empireonline.com/movies/features/upcoming-movies/' , 34 , 'http://i.imgur.com/aKQgDR7.png' , II1 )
 eeeeevevev = iIIIi1 ( url )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 eeeveVe = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in eeveveVVeve :
  VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVVevevV )
 for VVVevevV in eeeveVe :
  eevevevVeve = re . compile ( '<title>(.+?)</title>.+?lbscraper>(.+?)</lbscraper>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVVevevV )
  for name , url , iconimage , fanart in VVeVVeveeeveeV :
   iI1iII1 ( name , url , iconimage , fanart , VVVevevV )
   if 86 - 86: eVVVeeveevV
def VVeeevV ( name , url , iconimage , fanarts ) :
 iI1ii1Ii ( '[B][COLOR yellow]TV SEARCH[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvYW5ld0V2b2x2ZW1lbnUvc2VhcmNoLnhtbA==' ) , 33 , 'http://i.imgur.com/he5RFkL.png' , fanarts )
 iI1ii1Ii ( '[B][COLOR yellow]TV SCHEDULE[/COLOR][/B]' , 'http://www.tvwise.co.uk/uk-premiere-dates/' , 32 , 'http://i.imgur.com/XKAapZH.png' , fanarts )
 iI1ii1Ii ( '[B][COLOR yellow]Latest Episodes[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL3d3dy53YXRjaGVwaXNvZGVzNC5jb20=' ) , 28 , 'http://i.imgur.com/n8itltl.png' , fanarts )
 iI1ii1Ii ( '[B][COLOR yellow]Popular Shows[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL3d3dy53YXRjaGVwaXNvZGVzNC5jb20vaG9tZS9wb3B1bGFyLXNlcmllcw==' ) , 29 , 'http://i.imgur.com/ury75ui.png' , fanarts )
 iI1ii1Ii ( '[B][COLOR yellow]New Shows[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL3d3dy53YXRjaGVwaXNvZGVzNC5jb20vaG9tZS9uZXctc2VyaWVz' ) , 30 , 'http://i.imgur.com/UPWjTLw.png' , fanarts )
 if 67 - 67: i11iIiiIii - Ii % VVVevV . Ii11111i
 eevee = eeeeeVeeeveee ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , eevee )
 eeeeevevev = iIIIi1 ( url )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in eeveveVVeve :
  VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVVevevV )
  for name , url , iconimage , eeeevVV in VVeVVeveeeveeV :
   iI1iII1 ( name , url , iconimage , eeeevVV , VVVevevV )
   if 6 - 6: VVeVeeevevee - i11IiIiiIIIII + iiI1i1 - iI1I - i11iIiiIii
def VVeveVVevV ( name , url , iconimage , fanart ) :
 eevee = eeeeeVeeeveee ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , eevee )
 eeeeevevev = iIIIi1 ( url )
 eV ( eeeeevevev )
 if '<message>' in eeeeevevev :
  IiI = re . compile ( '<message>(.+?)</message>' ) . findall ( eeeeevevev ) [ 0 ]
  I11IiI1I11i1i ( IiI , eevee )
 if '<intro>' in eeeeevevev :
  iIi1IIIi1 = re . compile ( '<intro>(.+?)</intro>' ) . findall ( eeeeevevev ) [ 0 ]
  VeveVeVVVeVV ( iIi1IIIi1 )
 if 'XXX>yes</XXX' in eeeeevevev : ii1ii11IIIiiI ( eeeeevevev )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in eeveveVVeve :
  iI1iII1 ( name , url , iconimage , fanart , VVVevevV )
  if 67 - 67: VVeVeeevevee * I1ii * VVVevV + eVVVeeveevV / Ii
def iI1iII1 ( name , url , iconimage , fanart , item ) :
 try :
  if '<sportsdevil>' in item : I1I111 ( name , url , iconimage , fanart , item )
  elif '<iplayer>' in item : VeeveveeeveV ( name , url , iconimage , fanart , item )
  elif '<folder>' in item : IIiIi1iI ( name , url , iconimage , fanart , item )
  elif '<iptv>' in item : i1IiiiI1iI ( name , url , iconimage , fanart , item )
  elif '<image>' in item : i1iIi ( name , url , iconimage , fanart , item )
  elif '<text>' in item : eeVVeeeeee ( name , url , iconimage , fanart , item )
  elif '<scraper>' in item : II1I ( name , url , iconimage , fanart , item )
  elif '<lbscraper>' in item : Vevi1II1Iiii1I11 ( name , url , iconimage , fanart , item )
  elif '<redirect>' in item : IIII ( name , url , iconimage , fanart , item )
  elif '<oktitle>' in item : iiIiI ( name , url , iconimage , fanart , item )
  elif '<nan>' in item : eeveveeeVevVe ( name , url , iconimage , fanart , item )
  elif '<adult>' in item : eevVevVVVevVee ( name , url , iconimage , fanart , item )
  else : iiIiII1 ( name , url , iconimage , fanart , item )
 except : pass
 if 86 - 86: Veveevev - i11IiIiiIIIII - VVeevevev * IiiIII111ii
def VeeveveeeveV ( name , url , iconimage , fanart , item ) :
 url = re . compile ( '<iplayer>(.+?)</iplayer>' ) . findall ( item ) [ 0 ]
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 url = 'plugin://plugin.video.iplayerwww/?url=%s&mode=202&name=%s&iconimage=%s&description=&subtitles_url=&logged_in=False' % ( url , name , iconimage )
 eeeeevVev ( name , url , 16 , iconimage , fanart )
 if 51 - 51: VVeevevev / VVeevevev
def eeveveeeVevVe ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 eeVVVev = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 eeve = re . compile ( '<nan>(.+?)</nan>' ) . findall ( item ) [ 0 ]
 VevVVeVevevVVeve = re . compile ( '<imdb>(.+?)</imdb>' ) . findall ( item ) [ 0 ]
 if eeve == 'movie' :
  VevVVeVevevVVeve = VevVVeVevevVVeve + '<>movie'
 elif eeve == 'tvshow' :
  I1111IIIIIi = re . compile ( '<showname>(.+?)</showname>' ) . findall ( item ) [ 0 ]
  Iiii1i1 = re . compile ( '<season>(.+?)</season>' ) . findall ( item ) [ 0 ]
  VV = re . compile ( '<episode>(.+?)</episode>' ) . findall ( item ) [ 0 ]
  eeeveveve = re . compile ( '<showyear>(.+?)</showyear>' ) . findall ( item ) [ 0 ]
  iiIi1IIi1I = re . compile ( '<episodeyear>(.+?)</episodeyear>' ) . findall ( item ) [ 0 ]
  VevVVeVevevVVeve = VevVVeVevevVVeve + '<>' + I1111IIIIIi + '<>' + Iiii1i1 + '<>' + VV + '<>' + eeeveveve + '<>' + iiIi1IIi1I
  eeve = "tvep"
 eevVeVVeveveveeVev ( name , VevVVeVevevVVeve , 19 , iconimage , 1 , eeve , isFolder = True )
 if 56 - 56: IiiIII111ii
def eeeveVeveVVee ( name , imdb , iconimage , fanart ) :
 IIi1IiiiI1Ii = ''
 eVeevevVeveeeveveev = name
 eevee = eeeeeVeeeveee ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , eevee )
 if 'movie' in imdb :
  imdb = imdb . split ( '<>' ) [ 0 ]
  ii = [ ]
  VVeeeeVevVe = [ ]
  VViIiIIi1 = name . partition ( '(' )
  I1IIII1i = VViIiIIi1 [ 0 ]
  I1IIII1i = eeeeeVeeeveee ( I1IIII1i )
  I1I11i = VViIiIIi1 [ 2 ] . partition ( ')' ) [ 0 ]
  Ii1I1I1i1Ii = nanscrapers . scrape_movie ( I1IIII1i , I1I11i , imdb , timeout = 800 )
 else :
  I1111IIIIIi = imdb . split ( '<>' ) [ 1 ]
  i1 = imdb . split ( '<>' ) [ 0 ]
  Iiii1i1 = imdb . split ( '<>' ) [ 2 ]
  VV = imdb . split ( '<>' ) [ 3 ]
  eeeveveve = imdb . split ( '<>' ) [ 4 ]
  iiIi1IIi1I = imdb . split ( '<>' ) [ 5 ]
  Ii1I1I1i1Ii = nanscrapers . scrape_episode ( I1111IIIIIi , eeeveveve , iiIi1IIi1I , Iiii1i1 , VV , i1 , None )
 VeeveVeveve = 1
 for i11I1II1I11i in list ( Ii1I1I1i1Ii ( ) ) :
  for VeeVeVVev in i11I1II1I11i :
   if urlresolver . HostedMediaFile ( VeeVeVVev [ 'url' ] ) . valid_url ( ) :
    IIi1IiiiI1Ii = iI1i11iII111 ( VeeVeVVev [ 'url' ] )
    name = "Link " + str ( VeeveVeveve ) + ' | ' + VeeVeVVev [ 'source' ] + IIi1IiiiI1Ii
    VeeveVeveve = VeeveVeveve + 1
    Iii1IIII11I ( name , VeeVeVVev [ 'url' ] , 2 , iconimage , fanart , description = VevVevVVevVevVev . getSetting ( 'tv' ) )
    if 77 - 77: II1Iiii1111i - Ii - VVeVeeevevee . Veveevev
    if 39 - 39: Veeve / iiiIi + iI1I / Veveevev
def eevVevVVVevVee ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<adult>(.+?)</adult>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 iI1ii1Ii ( name , url , 36 , iconimage , fanart )
 if 13 - 13: i1iIIi1 + Ii11111i + IiiIII111ii % VevVVe / eeveee . i1iIIi1
def VVevVeeeeveVVevV ( ) :
 iI1ii1Ii ( '[B][COLOR yellow]Main Categories[/COLOR][/B]' , Veeeeveveve , 39 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]All Categories Alpha[/COLOR][/B]' , Veeeeveveve + 'categories' , 38 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Latest[/COLOR][/B]' , Veeeeveveve + 'videos/latest' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Best[/COLOR][/B]' , Veeeeveveve + 'best' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Top Rated[/COLOR][/B]' , Veeeeveveve + 'best/weekly' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Top Viewed[/COLOR][/B]' , Veeeeveveve + 'most-viewed' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]HD[/COLOR][/B]' , Veeeeveveve + 'categories/hd-videos' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Most Commented[/COLOR][/B]' , Veeeeveveve + 'most-commented/weekly' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Best of 2016[/COLOR][/B]' , Veeeeveveve + 'videos/top/year/2016' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Search[/COLOR][/B]' , 'url' , 40 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 62 - 62: VevVVe
def VeveveevVVev ( url ) :
 IIi1I1iiiii = eeveveVVeeVVeeve ( url )
 VevVeveeVVV = re . compile ( '<div class="video"><a href="(.+?)" class=".+?"><div class=".+?"  data-previewvideo=".+?"><img src=\'(.+?)\' class=\'.+?\' alt="(.+?)"/><img class=\'.+?\' src=\'.+?\'' , re . DOTALL ) . findall ( IIi1I1iiiii )
 for url , Veveveeeeeevev , VeveevVevevVeeveev in VevVeveeVVV :
  VeveevVevevVeeveev = VeveevVevevVeeveev . replace ( '&#039;' , '\'' ) . replace ( '&amp;' , ' & ' )
  eVVeevVeveve ( '[B][COLOR yellow]%s[/COLOR][/B]' % VeveevVevevVeeveev , url , 41 , Veveveeeeeevev , eeeevVV , '' )
 iIiIi11 = re . compile ( '<link rel="next" href="(.+?)"' , re . DOTALL ) . findall ( IIi1I1iiiii )
 for url in iIiIi11 :
  eVVeevVeveve ( '[B][COLOR cyan]Next Page>>>[/COLOR][/B]' , url , 37 , 'http://i.imgur.com/Uqrznbf.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 87 - 87: II1Iiii1111i . VevVVe - Veeve + Ii11111i / II1Iiii1111i / I1ii
def IiIIIIii1I ( url ) :
 IIi1I1iiiii = eeveveVVeeVVeeve ( url )
 VevVeveeVVV = re . compile ( '<div class="list">(.+?)<div class="head"' , re . DOTALL ) . findall ( IIi1I1iiiii ) [ 1 ]
 eeVevVV = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( str ( VevVeveeVVV ) )
 for url in eeVevVV :
  VeveevVevevVeeveev = url . split ( 'xhamster.com/' ) [ 1 ]
  try :
   VeveevVevevVeeveev = VeveevVevevVeeveev . replace ( '-1.html' , '' )
   VeveevVevevVeeveev = VeveevVevevVeeveev . split ( '/' ) [ 1 ] . title ( )
  except : pass
  if 'categories' not in VeveevVevevVeeveev :
   eVVeevVeveve ( '[B][COLOR yellow]%s[/COLOR][/B]' % VeveevVevevVeeveev , url , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 54 - 54: i1iIIi1 + i11IiIiiIIIII % VVeevevev + VeeevVVeveVV - Ii11111i - eeveee
def eeveevVevVeveveVVe ( url ) :
 IIi1I1iiiii = eeveveVVeeVVeeve ( url )
 VevVeveeVVV = re . compile ( 'ul class="alphabet-block".+?<a class=""(.+?)</ul>' , re . DOTALL ) . findall ( IIi1I1iiiii )
 eeVevVV = re . compile ( 'href="(.+?)">(.+?)<' , re . DOTALL ) . findall ( str ( VevVeveeVVV ) )
 for url , VeveevVevevVeeveev in eeVevVV :
  eVVeevVeveve ( '[B][COLOR yellow]%s[/COLOR][/B]' % VeveevVevevVeeveev , url , 42 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 14 - 14: Veveevev + I1ii
def eeeveveVevVev ( url ) :
 IIi1I1iiiii = eeveveVVeeVVeeve ( url )
 VevVeveeVVV = re . compile ( '<div class="letter-categories">(.+?)</ul>' , re . DOTALL ) . findall ( IIi1I1iiiii )
 eeVevVV = re . compile ( 'href="(.+?)"><span >(.+?)<' , re . DOTALL ) . findall ( str ( VevVeveeVVV ) )
 for url , VeveevVevevVeeveev in eeVevVV :
  eVVeevVeveve ( '[B][COLOR yellow]%s[/COLOR][/B]' % VeveevVevevVeeveev , url , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 30 - 30: eVVVeeveevV + VVVevV * VVeVeeevevee % i11iIiiIii % Veveevev
def VVevVeVVeveeve ( ) :
 ee = xbmc . Keyboard ( '' , 'Search For Your Porn!' )
 ee . doModal ( )
 if ( ee . isConfirmed ( ) ) :
  I1111i = ee . getText ( ) . replace ( ' ' , '+' )
  VeI1Ii11I1Ii1i = Veeeeveveve + 'search.php?from=&q=' + I1111i + '&qcat=video'
  VeveveevVVev ( VeI1Ii11I1Ii1i )
  if 14 - 14: eVVVeeveevV / eeveee
def eeveveVVeeVVeeve ( url ) :
 iII11I1IiiIi = { }
 iII11I1IiiIi [ 'User-Agent' ] = IiIi11iIIi1Ii
 eeeeevevev = VeevV . get ( url , headers = iII11I1IiiIi ) . text
 eeeeevevev = eeeeevevev . encode ( 'ascii' , 'ignore' )
 return eeeeevevev
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 98 - 98: Ii / VVeVeeevevee
def i1ii1I1111ii1 ( url ) :
 iIiI1 = [ ]
 eVeevVVeVev = [ ]
 II = ''
 IIi1I1iiiii = eeveveVVeeVVeeve ( url )
 eeveveVVeve = re . compile ( 'sources(.+?)debug":false' , re . DOTALL ) . findall ( IIi1I1iiiii )
 eevVeeveVeveVVevev = re . compile ( '"url":"(.+?)".+?quality":"(.+?)"' , re . DOTALL ) . findall ( str ( eeveveVVeve ) )
 for eeeeevevev , eeevevVVeveveveveV in eevVeeveVeveVVevev :
  II = '[B][COLOR cyan]%s[/COLOR][/B]' % eeevevVVeveveveveV
  iIiI1 . append ( II )
  eVeevVVeVev . append ( eeeeevevev )
 if len ( eevVeeveVeveVVevev ) > 1 :
  I1II1 = xbmcgui . Dialog ( )
  eeeV = I1II1 . select ( 'Please Select Quality' , iIiI1 )
  if eeeV == - 1 :
   return
  elif eeeV > - 1 :
   url = eVeevVVeVev [ eeeV ]
 else :
  url = re . compile ( 'sources.+?"url":"(.+?)"' ) . findall ( IIi1I1iiiii ) [ 0 ]
 url = url . replace ( '\\' , '' )
 print 'THIS> ' + url
 i1I1i111Ii = xbmcgui . ListItem ( VeveevVevevVeeveev , iconImage = 'DefaultVideo.png' , thumbnailImage = VevevVeveVVevevVevev )
 i1I1i111Ii . setInfo ( type = 'Video' , infoLabels = { "Title" : VeveevVevevVeeveev } )
 i1I1i111Ii . setProperty ( "IsPlayable" , "true" )
 i1I1i111Ii . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1I1i111Ii )
 if 67 - 67: VevVVe . Ii
def eVVeevVeveve ( name , url , mode , iconimage , fanart , description ) :
 i1i1iI1iiiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 VeeeveVeeeev = True
 i1I1i111Ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1I1i111Ii . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1I1i111Ii . setProperty ( 'fanart_image' , fanart )
 if mode == 41 :
  i1I1i111Ii . setProperty ( "IsPlayable" , "true" )
  VeeeveVeeeev = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = i1i1iI1iiiI , listitem = i1I1i111Ii , isFolder = False )
 else :
  VeeeveVeeeev = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = i1i1iI1iiiI , listitem = i1I1i111Ii , isFolder = True )
 return VeeeveVeeeev
 if 61 - 61: Veveevev - eVVVeeveevV - Ii
 if 25 - 25: Ii11111i * VVeVeeevevee + VVVevV . eeveee . eeveee
 if 58 - 58: VevVVe
def II1I ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<scraper>(.+?)</scraper>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 iI1ii1Ii ( name , url , 18 , iconimage , fanart )
 if 53 - 53: Ii
def eevVVVeVev ( name , url , iconimage , fanart ) :
 eevVeVeeveveeve = url
 if eevVeVeeveveeve == 'latestmovies' :
  I1II1I11I1I = 15
  VeVVeve = MOVIESINDEXER ( )
  i1II1 = re . compile ( '<item>(.+?)</item>' ) . findall ( VeVVeve )
  for VVVevevV in i1II1 :
   VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVVevevV )
   i11i1 = len ( i1II1 )
   for name , url , iconimage , fanart in VVeVVeveeeveeV :
    if '<meta>' in VVVevevV :
     IiiiiI1i1Iii = re . compile ( '<meta>(.+?)</meta>' ) . findall ( VVVevevV ) [ 0 ]
     eevVeVVeveveveeVev ( name , url , I1II1I11I1I , iconimage , i11i1 , IiiiiI1i1Iii , isFolder = False )
    else : Iii1IIII11I ( name , url , 15 , iconimage , fanart )
    if 87 - 87: eeveee
    if 29 - 29: VevVVe % eVVVeeveevV - VevVVe / eVVVeeveevV . Ii
def i11III1111iIi ( name , url , iconimage , fanarts ) :
 eeeeevevev = I1i111I ( 'http://www.watchepisodes4.com' )
 VeeVeeveeevVeveevevV = re . compile ( '<a title=".+?" .+? style="background-image: url(.+?)"></a>.+?<div class="hb-right">.+?<a title=".+?" href="(.+?)" class="episode">(.+?)</a>' , re . DOTALL ) . findall ( eeeeevevev )
 for iconimage , url , name in VeeVeeveeevVeveevevV :
  iconimage = iconimage . replace ( "('" , "" ) . replace ( "')" , "" )
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  name = name . split ( '  ' ) [ 0 ]
  iI1ii1Ii ( name , url , 24 , iconimage , iconimage )
  if 48 - 48: iiiIi / iI1I . iiI1i1 * Veveevev * I1ii / Ii
def VVVVeVVeevVev ( name , url , iconimage , fanart ) :
 eeeeevevev = I1i111I ( url )
 VeeVeeveeevVeveevevV = re . compile ( '<div class="cb-first">.+?<a href="(.+?)" class="c-image"><img alt=".+?" title="(.+?)" src="(.+?)"></a>' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in VeeVeeveeevVeveevevV :
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  iI1ii1Ii ( name , url , 31 , iconimage , iconimage )
  if 92 - 92: VVVevV + iiI1i1 / Veeve
def VeeVevVV ( name , url , iconimage , fanart ) :
 eeeeevevev = I1i111I ( url )
 VeeVeeveeevVeveevevV = re . compile ( '<div class="cb-first">.+?<a href="(.+?)" class="c-image"><img alt=".+?" title="(.+?)" src="(.+?)"></a>' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in VeeVeeveeevVeveevevV :
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  iI1ii1Ii ( name , url , 31 , iconimage , iconimage )
  if 69 - 69: iiiIi % I1ii
def ii1I1IIii11 ( name , url , iconimage , fanart ) :
 eeeeevevev = VeveeveV ( url )
 IIIIiIiIi1 = re . compile ( '<div class="std-cts">.+?<div class="sdt-content tnContent">.+?<h2>(.+?)</h2>' , re . DOTALL ) . findall ( eeeeevevev ) [ 0 ] . replace ( ' Episodes' , '' ) . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
 eeveveVVeve = re . compile ( '<a title=".+?" href="(.+?)">.+?<div class="season">(.+?) </div>.+?<div class="episode">(.+?)</div>.+?<div class="e-name">(.+?)</div>' , re . DOTALL ) . findall ( eeeeevevev )
 for url , Iiii1i1 , VV , I11iiiiI1i in eeveveVVeve :
  I11iiiiI1i = I11iiiiI1i . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  if '</div>' in name : name = 'TBA'
  iI1ii1Ii ( '%s ' % IIIIiIiIi1 + '(%s ' % Iiii1i1 + '%s)' % VV , url , 24 , iconimage , iconimage )
  if 40 - 40: VVVevV + Ii * eVVVeeveevV
def VeveVVeeeVVevV ( name , url , iconimage , fanart ) :
 eVeevevVeveeeveveev = name
 eeeeevevev = VeveeveV ( url )
 eeeevevVee = re . compile ( '<a target="_blank" href=".+?" data-episodeid=".+?" data-linkid=".+?" data-hostname=".+?" class="watch-button" data-actuallink="(.+?)">Watch Now!</a>' ) . findall ( eeeeevevev )
 VeeveVeveve = 1
 ii = [ ]
 VVeeeeVevVe = [ ]
 for VeeveevVevev in eeeevevVee :
  IIi1IiiiI1Ii = iI1i11iII111 ( VeeveevVevev )
  if 'http' in VeeveevVevev : ii1 = VeeveevVevev . split ( '/' ) [ 2 ] . split ( '.' ) [ 0 ]
  else : ii1 = VeeveevVevev
  name = "Link " + str ( VeeveVeveve ) + ' | ' + ii1 + IIi1IiiiI1Ii
  if ii1 != 'www' :
   Iii1IIII11I ( ii1 , VeeveevVevev , 2 , iconimage , fanart , description = '' )
   if 39 - 39: i11IiIiiIIIII / iiiIi . eeveee % Ii11111i * IiiIII111ii + VevVVe
def VeveeevV ( name , url , iconimage , fanart ) :
 eeeeevevev = VeveeveV ( url )
 VeeVeeveeevVeveevevV = re . compile ( '<td height="20">(.+?)</td>.+?<td>(.+?)</td>.+?<td><a href=".+?">(.+?)</a></td>.+?<td><a href=".+?">(.+?)</a></td>.+?</tr>' , re . DOTALL ) . findall ( eeeeevevev )
 for I1IiI11 , name , iI1iiiiIii , time in VeeVeeveeevVeveevevV :
  name = name . replace ( "&#8217;" , "'" ) . replace ( '&amp;' , ' & ' )
  iI1ii1Ii ( '[COLOR yellow]%s[/COLOR] - ' % iI1iiiiIii + '[COLOR yellow]%s[/COLOR] ' % name + '- [COLOR white]%s[/COLOR]' % I1IiI11 , url , 28 , iconimage , fanart )
  if 19 - 19: VVeevevev - II1Iiii1111i . Ii11111i
def eeVeevev ( url ) :
 VVee = ''
 iIIiiiI = xbmc . Keyboard ( VVee , '[B][COLOR cyan]What Would You Like Me To Find?[/COLOR][/B]' )
 iIIiiiI . doModal ( )
 if iIIiiiI . isConfirmed ( ) :
  VVee = iIIiiiI . getText ( ) . replace ( ' ' , '+' ) . replace ( '+and+' , '+%26+' )
 if len ( VVee ) > 1 :
  url = 'http://www.watchepisodes4.com/search/ajax_search?q=' + VVee
  eeeeevevev = VeveeveV ( url )
  VVeVVeveeeveeV = json . loads ( eeeeevevev )
  VVeVVeveeeveeV = VVeVVeveeeveeV [ 'series' ]
  for VVVevevV in VVeVVeveeeveeV :
   VeveevVevevVeeveev = VVVevevV [ 'value' ]
   eeev = VVVevevV [ 'seo' ]
   url = 'http://www.watchepisodes4.com/' + eeev
   VevevVeveVVevevVevev = 'http://www.watchepisodes4.com/movie_images/' + eeev + '.jpg'
   iI1ii1Ii ( VeveevVevevVeeveev , url , 31 , VevevVeveVVevevVevev , eeeevVV )
  VVee = VVee [ : - 1 ]
  eeeeevevev = iIIIi1 ( 'http://matsbuilds.uk/anewEvolvemenu/search.xml' )
  IiI111ii1ii = re . compile ( '<link>(.+?)</link>' ) . findall ( eeeeevevev )
  for url in IiI111ii1ii :
   try :
    eeeeevevev = iIIIi1 ( url )
    VevVVeIiIII1 = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
    for VVVevevV in VevVVeIiIII1 :
     eeveveVVeve = re . compile ( '<title>(.+?)</title>' ) . findall ( VVVevevV )
     for eVeevevVeveeeveveev in eeveveVVeve :
      eVeevevVeveeeveveev = eeeeeVeeeveee ( eVeevevVeveeeveveev . upper ( ) )
      VVee = VVee . upper ( )
      if VVee in eVeevevVeveeeveveev :
       iI1iII1 ( VeveevVevevVeeveev , url , VevevVeveVVevevVevev , eeeevVV , VVVevevV )
   except : pass
   if 56 - 56: VVeVeeevevee + Veeve + IiiIII111ii % VVeevevev % I1ii + Ii
def VeevVVVevevVevV ( name , url , iconimage , fanart ) :
 eeeeevevev = VeveeveV ( url )
 eeveveVVeve = re . compile ( '</div>.+?<a href="(.+?)" class="list cf">.+?<div class="serie-poster">.+?<img src="(.+?)" alt="(.+?)"/>.+?<span class="date">.+?</span>' , re . DOTALL ) . findall ( eeeeevevev )
 for url , iconimage , name in eeveveVVeve :
  url = 'http://www.cinemixtv.ga/' + url
  Iii1IIII11I ( '[B][COLOR yellow]%s[/COLOR][/B]' % name , url , 52 , iconimage , fanart )
 try :
  iIiIi11 = re . compile ( '<li class="active"><a href=".+?">.+?</a></li><li class="noactive"><a href="(.+?)">(.+?)</a></li>' , re . DOTALL ) . findall ( eeeeevevev )
  for url , VeevVVVeevev in iIiIi11 :
   iI1ii1Ii ( '[COLOR cyan]Next Page >> %s[/COLOR]' % VeevVVVeevev , url , IIiiIIIIII1II , '' , '' )
 except : pass
 if 35 - 35: iiI1i1
 if 42 - 42: iI1I . VevVVe . Ii + Veveevev + eVVVeeveevV + VevVVe
def I1I ( name , url , iconimage ) :
 eeeeevevev = VeveeveV ( url )
 eeveveVVeve = re . compile ( '<iframe width=".+?" height=".+?" src="(.+?)" allowfullscreen></iframe>' ) . findall ( eeeeevevev )
 for url in eeveveVVeve :
  eeeeevevev = VeveeveV ( url )
  eVeevVVeVev = 'http:' + re . compile ( '<iframe width="100%" height="100%" src="(.+?)" allowfullscreen></iframe>' ) . findall ( eeeeevevev ) [ 0 ]
  eVeevVVeVev = urlresolver . HostedMediaFile ( eVeevVVeVev ) . resolve ( )
  i1I1i111Ii = xbmcgui . ListItem ( name , iconImage = 'DefaultVideo.png' , thumbnailImage = iconimage )
  i1I1i111Ii . setPath ( eVeevVVeVev )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1I1i111Ii )
  if 68 - 68: iiiIi
  if 25 - 25: VVVevV . iiiIi
def iIIi ( name , url , iconimage , fanart ) :
 eeeeevevev = VeveeveV ( url )
 VeeVeeveeevVeveevevV = re . compile ( '<h2 id=".+?">(.+?)</h2>.+?<p><span class="article__image article__image--undefined"><img src="(.+?)" alt=".+?"></span> </p>.+?<p><strong>(.+?)</strong>(.+?)<' , re . DOTALL ) . findall ( eeeeevevev )
 for eVeevevVeveeeveveev , iconimage , eVeveeveveeev , iI1iiiiIii in VeeVeeveeevVeveevevV :
  name = name . replace ( "&#8217;" , "'" ) . replace ( '&amp;' , ' & ' )
  iI1ii1Ii ( '[COLOR yellow]%s [/COLOR] ' % eVeevevVeveeeveveev + '[COLOR yellow]%s[/COLOR]' % eVeveeveveeev + '[COLOR white]%s[/COLOR]' % iI1iiiiIii , url , 35 , iconimage , fanart )
def ii1IIII ( name , url , iconimage , fanart ) :
 eeeeevevev = iIIIi1 ( 'http://matsbuilds.uk/Menus/Movies/EvolveLatest/mainmenu.xml' )
 VeeVeeveeevVeveevevV = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in VeeVeeveeevVeveevevV :
  iI1iII1 ( name , url , iconimage , fanart , VVVevevV )
  if 59 - 59: I1ii * VVeVeeevevee % Veeve
  if 62 - 62: iiI1i1
  if 12 - 12: eVVVeeveevV / eeveee
  if 42 - 42: II1Iiii1111i
  if 19 - 19: I1ii % VVVevV * iiI1i1 + VevVVe
def iii11I ( name , url , iconimage , fanarts ) :
 eeeeevevev = I1i111I ( url )
 VeeVeeveeevVeveevevV = re . compile ( '<div class="thumb" id="post-.+?">.+?<a href="(.+?)" title="Watch (.+?) Online"><img width=".+?" height=".+?" src="(.+?)" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt=".+?" />' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in VeeVeeveeevVeveevevV :
  iI1ii1Ii ( name , url , 46 , iconimage , iconimage )
  if 50 - 50: IiiIII111ii + Ii11111i + i11IiIiiIIIII . Veeve / eeveee
def i1Iii11I1i ( name , url , iconimage , fanarts ) :
 eeeeevevev = I1i111I ( url )
 VeeVeeveeevVeveevevV = re . compile ( '<div class="thumb" id="post-.+?">.+?<a href="(.+?)" title="Watch (.+?) Online"><img width=".+?" height=".+?" src="(.+?)" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt=".+?" />' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in VeeVeeveeevVeveevevV :
  iI1ii1Ii ( name , url , 46 , iconimage , iconimage )
  if 72 - 72: iiI1i1 * i11IiIiiIIIII % iiiIi / VVeevevev
def I11i1II ( name , url , iconimage , fanarts ) :
 eeeeevevev = I1i111I ( url )
 VeeVeeveeevVeveevevV = re . compile ( '<div class="thumb">.+?<a href="(.+?)" title="Watch (.+?) Online"><img width=".+?" height=".+?" src="(.+?)" class="attachment-post-thumbnail size-post-thumbnail wp-post-image"' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in VeeVeeveeevVeveevevV :
  iI1ii1Ii ( name , url , 46 , iconimage , iconimage )
  if 72 - 72: iiI1i1 . Ii / II1Iiii1111i . Veeve
def eeeeveveveevevev ( name , url , iconimage , fanarts ) :
 ii = [ ]
 VVeeeeVevVe = [ ]
 Veve = [ ]
 eeeeevevev = VeveeveV ( url )
 eeeevevVee = re . compile ( '<a href="(.+?)" title=".+?" rel="nofollow" target="blank">.+?</a><br/>' ) . findall ( eeeeevevev )
 VeeveVeveve = 1
 ii = [ ]
 VVeeeeVevVe = [ ]
 for VeeveevVevev in eeeevevVee :
  IIi1IiiiI1Ii = iI1i11iII111 ( VeeveevVevev )
  if '//' in VeeveevVevev : ii1 = VeeveevVevev . split ( '/' ) [ 2 ] . split ( '.' ) [ 0 ]
  else : ii1 = VeeveevVevev
  name = "Link " + str ( VeeveVeveve ) + ' | ' + ii1 + IIi1IiiiI1Ii
  if ii1 != 'www' :
   Iii1IIII11I ( ii1 , VeeveevVevev , 2 , iconimage , eeeevVV , description = '' )
   if 72 - 72: eVVVeeveevV % VVVevV + VVeevevev / I1ii + i1iIIi1
   if 10 - 10: iI1I / iiiIi + i11iIiiIii / i11IiIiiIIIII
def Vevi1II1Iiii1I11 ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<lbscraper>(.+?)</lbscraper>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 iI1ii1Ii ( name , url , 10 , iconimage , fanart )
 if 74 - 74: eVVVeeveevV + Ii11111i + Ii - Ii + Veeve
def eVVVeveeev ( name , url , iconimage , fanart ) :
 Ii1I1I1i1Ii = iIi1i1iIi1iI ( name , url , iconimage )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( Ii1I1I1i1Ii )
 for VVVevevV in eeveveVVeve :
  iI1iII1 ( name , url , iconimage , fanart , VVVevevV )
  if 26 - 26: VeeevVVeveVV * VevVVe + eVVVeeveevV
def iIi1i1iIi1iI ( name , url , iconimage ) :
 eevVeVeeveveeve = url
 string = ''
 if url == 'mamahd' :
  eeeeevevev = I1i111I ( "http://mamahd.com" ) . replace ( '\n' , '' ) . replace ( '\t' , '' )
  IiIii1i111 = re . compile ( '<a href="(.+?)">.+?<img src="(.+?)"></div>.+?<div class="home cell">.+?<span>(.+?)</span>.+?<span>(.+?)</span>.+?</a>' ) . findall ( eeeeevevev )
  for url , iconimage , iI , eeveevev in IiIii1i111 :
   string = string + '<item>\n<title>%s vs %s</title>\n<sportsdevil>%s</sportsdevil>\n<thumbnail>%s</thumbnail>\n<fanart>fanart</fanart>\n</item>\n\n' % ( iI , eeveevev , url , iconimage )
  return string
  if 14 - 14: eeveee . eVVVeeveevV . VVeVeeevevee + VeeevVVeveVV - eVVVeeveevV + i1iIIi1
 elif url == 'cricfree' :
  eeeeevevev = I1i111I ( "http://cricfree.sc/football-live-stream" )
  iII1iiiiIII = re . compile ( '<td><span class="sport-icon(.+?)</tr>' , re . DOTALL ) . findall ( eeeeevevev )
  for VVeVVeveeevevVe in iII1iiiiIII :
   I111i1II = re . compile ( '<td>(.+?)<br(.+?)</td>' ) . findall ( VVeVVeveeevevVe )
   for VeveeeeeevVVVVev , iI1iiiiIii in I111i1II :
    VeveeeeeevVVVVev = '[COLOR yellow]' + VeveeeeeevVVVVev + '[/COLOR]'
    iI1iiiiIii = iI1iiiiIii . replace ( '>' , '' )
   time = re . compile ( '<td class="matchtime" style="color:#545454;font-weight:bold;font-size: 9px">(.+?)</td>' ) . findall ( VVeVVeveeevevVe ) [ 0 ]
   time = '[COLOR white](' + time + ')[/COLOR]'
   IiiIi1III = re . compile ( '<a style="text-decoration:none !important;color:#545454;" href="(.+?)" target="_blank">(.+?)</a></td>' ) . findall ( VVeVVeveeevevVe )
   for url , VevVe in IiiIi1III :
    url = url
    VevVe = VevVe
   string = string + '\n<item>\n<title>%s</title>\n<sportsdevil>%s</sportsdevil>\n' % ( VeveeeeeevVVVVev + ' ' + time + ' - ' + VevVe , url )
   string = string + '<thumbnail>iconimage</thumbnail>\n<fanart>fanart</fanart>\n</item>\n'
  return string
  if 44 - 44: VevVVe - VVeVeeevevee % iiI1i1
 elif url == 'bigsports' :
  eeeeevevev = I1i111I ( "http://www.bigsports.me/cat/4/football-live-stream.html" )
  IiIii1i111 = re . compile ( '<td>.+?<td>(.+?)\-(.+?)\-(.+?)</td>.+?<td>(.+?)\:(.+?)</td>.+?<td>Football</td>.+?<td><strong>(.+?)</strong></td>.+?<a target=.+? href=(.+?) class=.+?' , re . DOTALL ) . findall ( eeeeevevev )
  for VeveeeeeevVVVVev , VevV , VeeveVev , iIiIIIIIii , VVeev , name , url in IiIii1i111 :
   if not '</td>' in VeveeeeeevVVVVev :
    url = url . replace ( '"' , '' )
    iI1iiiiIii = VeveeeeeevVVVVev + ' ' + VevV + ' ' + VeeveVev
    time = iIiIIIIIii + ':' + VVeev
    iI1iiiiIii = '[COLOR yellow]' + iI1iiiiIii + '[/COLOR]'
    time = '[COLOR cyan](' + time + ')[/COLOR]'
    string = string + '\n<item>\n<title>%s</title>\n<sportsdevil>%s</sportsdevil>\n' % ( iI1iiiiIii + ' ' + time + ' ' + name , url )
    string = string + '<thumbnail>iconimage</thumbnail>\n<fanart>fanart</fanart>\n</item>\n'
  return string
  if 25 - 25: VeeevVVeveVV + i1iIIi1 * VVVevV
  if 92 - 92: VevVVe + VVeVeeevevee + Ii11111i / eeveee + iI1I
def iiIiI ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 I1iIi1iIiiIiI = re . compile ( '<oktitle>(.+?)</oktitle>' ) . findall ( item ) [ 0 ]
 I1i11ii = re . compile ( '<line1>(.+?)</line1>' ) . findall ( item ) [ 0 ]
 i111iI = re . compile ( '<line2>(.+?)</line2>' ) . findall ( item ) [ 0 ]
 VVe = re . compile ( '<line3>(.+?)</line3>' ) . findall ( item ) [ 0 ]
 i1i11I1I1iii1 = '##' + I1iIi1iIiiIiI + '#' + I1i11ii + '#' + i111iI + '#' + VVe + '##'
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 eeeeevVev ( name , i1i11I1I1iii1 , 17 , iconimage , fanart )
 if 8 - 8: iiiIi + Veeve / IiiIII111ii / VVeVeeevevee
def eeeevV ( name , url ) :
 iII1iii = re . compile ( '##(.+?)##' ) . findall ( url ) [ 0 ] . split ( '#' )
 I1II1 = xbmcgui . Dialog ( )
 I1II1 . ok ( iII1iii [ 0 ] , iII1iii [ 1 ] , iII1iii [ 2 ] , iII1iii [ 3 ] )
 if 12 - 12: eVVVeeveevV
def IIII ( name , url , iconimage , fanart , item ) :
 url = re . compile ( '<redirect>(.+?)</redirect>' ) . findall ( item ) [ 0 ]
 VVeveVVevV ( 'name' , url , 'iconimage' , 'fanart' )
 if 83 - 83: IiiIII111ii . Ii11111i / II1Iiii1111i / eVVVeeveevV - Veeve
def eeVVeeeeee ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 i1i11I1I1iii1 = re . compile ( '<text>(.+?)</text>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 eeeeevVev ( name , i1i11I1I1iii1 , 9 , iconimage , fanart )
 if 100 - 100: VVeevevev
def II1i ( name , url ) :
 Ii1IIIIi1ii1I = VeveeveV ( url )
 IiiIiI1Ii1i ( name , Ii1IIIIi1ii1I )
 if 22 - 22: i1iIIi1 / i11iIiiIii
def i1iIi ( name , url , iconimage , fanart , item ) :
 eVVee = re . compile ( '<image>(.+?)</image>' ) . findall ( item )
 if len ( eVVee ) == 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  iII1111III1I = re . compile ( '<image>(.+?)</image>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  eeeeevVev ( name , iII1111III1I , 7 , iconimage , fanart )
 elif len ( eVVee ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  ii11i = ''
  for iII1111III1I in eVVee : ii11i = ii11i + '<image>' + iII1111III1I + '</image>'
  Ii1iI = eeVe
  name = eeeeeVeeeveee ( name )
  VeveveVeeveveeve = os . path . join ( os . path . join ( Ii1iI , '' ) , name + '.txt' )
  if not os . path . exists ( VeveveVeeveveeve ) : file ( VeveveVeeveveeve , 'w' ) . close ( )
  VeveveVev = open ( VeveveVeeveveeve , "w" )
  VeveveVev . write ( ii11i )
  VeveveVev . close ( )
  eeeeevVev ( name , 'image' , 8 , iconimage , fanart )
  if 70 - 70: VVeVeeevevee . VVVevV * VeeevVVeveVV - i1iIIi1 * VevVVe + Veveevev
def i1IiiiI1iI ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<iptv>(.+?)</iptv>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 iI1ii1Ii ( name , url , 6 , iconimage , fanart )
 if 10 - 10: eeveee / i11iIiiIii
def eeveveV ( url , iconimage ) :
 eeeeevevev = VeveeveV ( url )
 VevevVevVeeeeevev = re . compile ( '^#.+?:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( eeeeevevev )
 Vevevev = [ ]
 for eeeeveevevevV , VeveevVevevVeeveev , url in VevevVevVeeeeevev :
  VVVVeve = { "params" : eeeeveevevevV , "name" : VeveevVevevVeeveev , "url" : url }
  Vevevev . append ( VVVVeve )
 list = [ ]
 for I1IiI11 in Vevevev :
  VVVVeve = { "name" : I1IiI11 [ "name" ] , "url" : I1IiI11 [ "url" ] }
  VevevVevVeeeeevev = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1IiI11 [ "params" ] )
  for eeeveevVevVeeeee , i11IIIiI1I in VevevVevVeeeeevev :
   VVVVeve [ eeeveevVevVeeeee . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = i11IIIiI1I . strip ( )
  list . append ( VVVVeve )
 for I1IiI11 in list :
  if '.ts' in I1IiI11 [ "url" ] : eeeeevVev ( I1IiI11 [ "name" ] , I1IiI11 [ "url" ] , 2 , iconimage , eeeevVV )
  else : Iii1IIII11I ( I1IiI11 [ "name" ] , I1IiI11 [ "url" ] , 2 , iconimage , eeeevVV )
  if 69 - 69: Ii11111i
def iiIiII1 ( name , url , iconimage , fanart , item ) :
 IIi1IiiiI1Ii = ''
 eeveeV = re . compile ( '<link>(.+?)</link>' ) . findall ( item )
 VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
 for name , VeVVVeeveeveee , iconimage , fanart in VVeVVeveeeveeV :
  if 'youtube.com/playlist?' in VeVVVeeveeveee :
   VVee = VeVVVeeveeveee . split ( 'list=' ) [ 1 ]
   iI1ii1Ii ( name , VeVVVeeveeveee , IIiiIIIIII1II , iconimage , fanart , description = VVee )
 if len ( eeveeV ) == 1 :
  VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
  for name , url , iconimage , fanart in VVeVVeveeeveeV :
   try :
    IIi1IiiiI1Ii = iI1i11iII111 ( url )
    I1iiiiI1iI = url . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
    if 'SportsDevil' in url : I1iiiiI1iI = ''
   except : pass
   if '.ts' in url : Iii1IIII11I ( name , url , 16 , iconimage , fanart , description = '' )
   if '<meta>' in item :
    IiiiiI1i1Iii = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
    eevVeVVeveveveeVev ( name + IIi1IiiiI1Ii , url , 2 , iconimage , 10 , IiiiiI1i1Iii , isFolder = False )
   else :
    Iii1IIII11I ( name + IIi1IiiiI1Ii , url , 2 , iconimage , fanart )
 elif len ( eeveeV ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  if '.ts' in url : Iii1IIII11I ( name , url , 16 , iconimage , fanart , description = '' )
  if '<meta>' in item :
   IiiiiI1i1Iii = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
   eevVeVVeveveveeVev ( name , url , 3 , iconimage , len ( eeveeV ) , IiiiiI1i1Iii , isFolder = True )
  else :
   iI1ii1Ii ( name , url , 3 , iconimage , fanart )
   if 43 - 43: I1ii - VeeevVVeveVV
   if 3 - 3: Ii11111i / IiiIII111ii
def I1I111 ( name , url , iconimage , fanart , item ) :
 eeveeV = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( item )
 iIiIi1I = re . compile ( '<link>(.+?)</link>' ) . findall ( item )
 if len ( eeveeV ) + len ( iIiIi1I ) == 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( item ) [ 0 ]
  url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url
  eeeeevVev ( name , url , 16 , iconimage , fanart )
 elif len ( eeveeV ) + len ( iIiIi1I ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  iI1ii1Ii ( name , url , 3 , iconimage , fanart )
  if 45 - 45: Ii + Veeve
def ii1ii11IIIiiI ( link ) :
 if eVeveveVe == '' :
  I1II1 = xbmcgui . Dialog ( )
  eeeV = I1II1 . yesno ( 'Adult Content' , 'You have found the goodies ;)' , '' , 'Please set a password to prevent accidental access' , 'Cancel' , 'OK' )
  if eeeV == 1 :
   ee = xbmc . Keyboard ( '' , 'Set Password' )
   ee . doModal ( )
   if ( ee . isConfirmed ( ) ) :
    IiII1II11I = ee . getText ( )
    VevVevVVevVevVev . setSetting ( 'password' , IiII1II11I )
  else : quit ( )
 elif eVeveveVe <> '' :
  I1II1 = xbmcgui . Dialog ( )
  eeeV = I1II1 . yesno ( 'Adult Content' , 'Please enter the password you set!' , 'to continue' , 'dirty git' , 'Cancel' , 'OK' )
  if eeeV == 1 :
   ee = xbmc . Keyboard ( '' , 'Enter Password' )
   ee . doModal ( )
   if ( ee . isConfirmed ( ) ) :
    IiII1II11I = ee . getText ( )
   if IiII1II11I <> eVeveveVe :
    quit ( )
  else : quit ( )
  if 54 - 54: i1iIIi1 + Ii11111i + VVeVeeevevee * iI1I - eVVVeeveevV % I1ii
def I111 ( name , url , iconimage ) :
 iI1I1i11iIIii = ''
 eevee = eeeeeVeeeveee ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , eevee )
 eeeeevevev = iIIIi1 ( url )
 IIIIIiI111I = re . compile ( '<title>.*?' + re . escape ( name ) + '.*?</title>(.+?)</item>' , re . DOTALL ) . findall ( eeeeevevev ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIIIIiI111I ) [ 0 ]
 eeveeV = [ ]
 if '<link>' in IIIIIiI111I :
  iIIIIIii = re . compile ( '<link>(.+?)</link>' ) . findall ( IIIIIiI111I )
  for Ii1ii111i1 in iIIIIIii :
   eeveeV . append ( Ii1ii111i1 )
 if '<sportsdevil>' in IIIIIiI111I :
  i1i1i1I = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( IIIIIiI111I )
  for eVeeevevev in i1i1i1I :
   eVeeevevev = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + eVeeevevev
   eeveeV . append ( eVeeevevev )
 VeeveVeveve = 1
 for eeeeevevev in eeveeV :
  if '(' in eeeeevevev :
   eeeeevevev = eeeeevevev . split ( '(' )
   iI1I1i11iIIii = eeeeevevev [ 1 ] . replace ( ')' , '' )
   eeeeevevev = eeeeevevev [ 0 ]
  IIi1IiiiI1Ii = iI1i11iII111 ( eeeeevevev )
  I1iiiiI1iI = eeeeevevev . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
  if iI1I1i11iIIii <> '' : name = "Link " + str ( VeeveVeveve ) + ' | ' + iI1I1i11iIIii + IIi1IiiiI1Ii
  else : name = "Link " + str ( VeeveVeveve ) + ' | ' + I1iiiiI1iI + IIi1IiiiI1Ii
  VeeveVeveve = VeeveVeveve + 1
  eevVeVVeveveveeVev ( name , eeeeevevev , 2 , iconimage , 10 , '' , isFolder = False , description = VevVevVVevVevVev . getSetting ( 'tv' ) )
  if 87 - 87: VeeevVVeveVV - eeveee / i1iIIi1 . i11iIiiIii * VeeevVVeveVV
def IIiIi1iI ( name , url , iconimage , fanart , item ) :
 VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
 for name , url , iconimage , fanart in VVeVVeveeeveeV :
  if 'youtube.com/channel/' in url :
   VVee = url . split ( 'channel/' ) [ 1 ]
   iI1ii1Ii ( name , url , IIiiIIIIII1II , iconimage , fanart , description = VVee )
  elif 'youtube.com/user/' in url :
   VVee = url . split ( 'user/' ) [ 1 ]
   iI1ii1Ii ( name , url , IIiiIIIIII1II , iconimage , fanart , description = VVee )
  elif 'youtube.com/playlist?' in url :
   VVee = url . split ( 'list=' ) [ 1 ]
   iI1ii1Ii ( name , url , IIiiIIIIII1II , iconimage , fanart , description = VVee )
  elif 'plugin://' in url :
   VVevev = HTMLParser ( )
   url = VVevev . unescape ( url )
   iI1ii1Ii ( name , url , IIiiIIIIII1II , iconimage , fanart )
  else :
   iI1ii1Ii ( name , url , 1 , iconimage , fanart )
   if 28 - 28: I1ii - i11iIiiIii . VVVevV + i1iIIi1 / VVVevV
def i11iIiI11I1i ( ) :
 ee = xbmc . Keyboard ( '' , '[B][COLOR cyan]What Would You Like Me To Find?[/COLOR][/B]' )
 ee . doModal ( )
 if ( ee . isConfirmed ( ) ) :
  VVee = ee . getText ( )
  VVee = VVee . upper ( )
 else : quit ( )
 eeeeevevev = iIIIi1 ( 'http://matsbuilds.uk/Menus/anewEvolvemenu/search.xml' )
 IiI111ii1ii = re . compile ( '<link>(.+?)</link>' ) . findall ( eeeeevevev )
 for VeI1Ii11I1Ii1i in IiI111ii1ii :
  try :
   eeeeevevev = iIIIi1 ( VeI1Ii11I1Ii1i )
   VevVVeIiIII1 = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
   for VVVevevV in VevVVeIiIII1 :
    eeveveVVeve = re . compile ( '<title>(.+?)</title>' ) . findall ( VVVevevV )
    for eVeevevVeveeeveveev in eeveveVVeve :
     eVeevevVeveeeveveev = eVeevevVeveeeveveev . upper ( )
     if VVee in eVeevevVeveeeveveev :
      iI1iII1 ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV , VVVevevV )
  except : pass
  if 41 - 41: i11IiIiiIIIII
def eVVeeeveevVVVV ( url ) :
 string = "ShowPicture(%s)" % url
 xbmc . executebuiltin ( string )
 if 26 - 26: IiiIII111ii % iiI1i1 + eeveee
def VVVeee ( name , url , iconimage , description ) :
 if description : name = description
 try :
  if 'plugin://plugin.video.SportsDevil/' in url :
   VeeveveeevevevevVV ( name , url , iconimage )
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url
   url = url . replace ( '|' , '' )
   VeeveveeevevevevVV ( name , url , iconimage )
  elif urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
   url = urlresolver . HostedMediaFile ( url ) . resolve ( )
   VeveVVeevVe ( name , url , iconimage )
  elif liveresolver . isValid ( url ) == True :
   url = liveresolver . resolve ( url )
   VeveVVeevVe ( name , url , iconimage )
  else : VeveVVeevVe ( name , url , iconimage )
 except :
  eevevevVevevev ( ii1eVeVeveeveee ( 'Picasso' ) , 'Stream Unavailable' , '3000' , Veveveeeeeevev )
  if 86 - 86: VVVevV * Ii11111i * i1iIIi1
def VeveVeVVVeVV ( url ) :
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  url = urlresolver . HostedMediaFile ( url ) . resolve ( )
 xbmc . Player ( ) . play ( url )
 if 51 - 51: Veeve + i1iIIi1 . Ii . VVVevV + Veveevev * VevVVe
def VeveVVeevVe ( name , url , iconimage ) :
 VeeeveVeeeev = True
 i1I1i111Ii = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage ) ; i1I1i111Ii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 VeeeveVeeeev = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = i1I1i111Ii )
 i1I1i111Ii . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1I1i111Ii )
 if 72 - 72: I1ii + I1ii / Veeve . VeeevVVeveVV % i11IiIiiIIIII
def VeeveveeevevevevVV ( name , url , iconimage ) :
 xbmc . executebuiltin ( 'Dialog.Close(all,True)' )
 VeeeveVeeeev = True
 i1I1i111Ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage ) ; i1I1i111Ii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 VeeeveVeeeev = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = i1I1i111Ii )
 xbmc . Player ( ) . play ( url , i1I1i111Ii , False )
 if 49 - 49: I1ii . VVeevevev - II1Iiii1111i * VeeevVVeveVV . II1Iiii1111i
def ii1Ii1IiIIi ( url ) :
 xbmc . executebuiltin ( "PlayMedia(%s)" % url )
 if 83 - 83: VVeVeeevevee / VVVevV
def iIIIi1 ( url ) :
 II1Ii11Ii1i1I = urllib2 . Request ( url )
 II1Ii11Ii1i1I . add_header ( base64 . b64decode ( 'VXNlci1BZ2VudA==' ) , base64 . b64decode ( 'dTM0ODczZWpyZGU4dTkyM2pxdzlkaXUy' ) )
 ii1iIi1II = urllib2 . urlopen ( II1Ii11Ii1i1I )
 eeeeevevev = ii1iIi1II . read ( )
 ii1iIi1II . close ( )
 eeeeevevev = eeeeevevev . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 if '{' in eeeeevevev :
  string = eeeeevevev [ : : - 1 ]
  string = string . replace ( '}' , '' ) . replace ( '{' , '' ) . replace ( ',' , '' ) . replace ( ']' , '' ) . replace ( '[' , '' )
  string = string + '=='
  eeeeevevev = string . decode ( 'base64' )
 if url <> IiI : eeeeevevev = eeeeevevev . replace ( '\n' , '' ) . replace ( '\r' , '' )
 print eeeeevevev
 return eeeeevevev
 if 2 - 2: II1Iiii1111i + Veveevev - eVVVeeveevV . VevVVe - eVVVeeveevV
def VeveeveV ( url ) :
 II1Ii11Ii1i1I = urllib2 . Request ( url )
 II1Ii11Ii1i1I . add_header ( base64 . b64decode ( 'VXNlci1BZ2VudA==' ) , base64 . b64decode ( 'dTM0ODczZWpyZGU4dTkyM2pxdzlkaXUy' ) )
 ii1iIi1II = urllib2 . urlopen ( II1Ii11Ii1i1I )
 eeeeevevev = ii1iIi1II . read ( )
 ii1iIi1II . close ( )
 return eeeeevevev
 if 67 - 67: iiI1i1 - IiiIII111ii
def I1i111I ( url ) :
 II1Ii11Ii1i1I = urllib2 . Request ( url )
 II1Ii11Ii1i1I . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 ii1iIi1II = urllib2 . urlopen ( II1Ii11Ii1i1I )
 eeeeevevev = ii1iIi1II . read ( )
 ii1iIi1II . close ( )
 eeeeevevev = eeeeevevev . replace ( '\n' , '' ) . replace ( '\r' , '' )
 return eeeeevevev
 if 11 - 11: iiI1i1 . VeeevVVeveVV . Veeve / Ii - VVeVeeevevee
 if 30 - 30: Veveevev
def Ii111 ( ) :
 iiii ( )
 eVev = [ ]
 i1iI = sys . argv [ 2 ]
 if len ( i1iI ) >= 2 :
  eeeeveevevevV = sys . argv [ 2 ]
  iieeeveevVeVVV = eeeeveevevevV . replace ( '?' , '' )
  if ( eeeeveevevevV [ len ( eeeeveevevevV ) - 1 ] == '/' ) :
   eeeeveevevevV = eeeeveevevevV [ 0 : len ( eeeeveevevevV ) - 2 ]
  eeVeveVevevVeve = iieeeveevVeVVV . split ( '&' )
  eVev = { }
  for VeeveVeveve in range ( len ( eeVeveVevevVeve ) ) :
   eeVVeveveVVeevevev = { }
   eeVVeveveVVeevevev = eeVeveVevevVeve [ VeeveVeveve ] . split ( '=' )
   if ( len ( eeVVeveveVVeevevev ) ) == 2 :
    eVev [ eeVVeveveVVeevevev [ 0 ] ] = eeVVeveveVVeevevev [ 1 ]
 return eVev
 if 14 - 14: VVeevevev . Veeve . VVeVeeevevee / i11IiIiiIIIII % VVVevV - iiiIi
def eevevevVevevev ( title , message , ms , nart ) :
 xbmc . executebuiltin ( "XBMC.notification(" + title + "," + message + "," + ms + "," + nart + ")" )
 if 67 - 67: VVeVeeevevee - eVVVeeveevV . Ii
def eeeeeVeeeveee ( string ) :
 I1I1iI = re . compile ( '(\[.+?\])' ) . findall ( string )
 for I1iIi1iiIIiI in I1I1iI : string = string . replace ( I1iIi1iiIIiI , '' )
 return string
 if 81 - 81: VVeevevev * Veveevev . eVVVeeveevV
def ii1eVeVeveeveee ( string ) :
 string = string . split ( ' ' )
 iiiIIiIi = ''
 for VeeVVV in string :
  Ii1iI11iI1 = '[B][COLOR yellow]' + VeeVVV [ 0 ] . upper ( ) + '[/COLOR][COLOR white]' + VeeVVV [ 1 : ] + '[/COLOR][/B] '
  iiiIIiIi = iiiIIiIi + Ii1iI11iI1
 return iiiIIiIi
 if 5 - 5: iiI1i1
def eevVeVVeveveveeVev ( name , url , mode , iconimage , itemcount , metatype , isFolder = False , description = '' ) :
 if isFolder == True : VevVevVVevVevVev . setSetting ( 'favtype' , 'folder' )
 else : VevVevVVevVevVev . setSetting ( 'favtype' , 'link' )
 if VVVeev == 'true' :
  VVeeeveveVevev = name
  name = eeeeeVeeeveee ( name )
  VVeveVVe = ""
  VVeveVeve = ""
  III111i11IiI = [ ]
  Vevevevev = eval ( base64 . b64decode ( 'bWV0YWhhbmRsZXJzLk1ldGFEYXRhKHRtZGJfYXBpX2tleT0iZDk1NWQ4ZjAyYTNmMjQ4MGE1MTg4MWZlNGM5NmYxMGUiKQ==' ) )
  eeVVVev = { }
  if metatype == 'movie' :
   VViIiIIi1 = name . partition ( '(' )
   if len ( VViIiIIi1 ) > 0 :
    VVeveVVe = VViIiIIi1 [ 0 ]
    VVeveVeve = VViIiIIi1 [ 2 ] . partition ( ')' )
   if len ( VVeveVeve ) > 0 :
    VVeveVeve = VVeveVeve [ 0 ]
   eeVVVev = Vevevevev . get_meta ( 'movie' , name = VVeveVVe , year = VVeveVeve )
   if not eeVVVev [ 'trailer' ] == '' : III111i11IiI . append ( ( ii1eVeVeveeveee ( 'Play Trailer' ) , 'XBMC.RunPlugin(%s)' % VeevVee . build_plugin_url ( { 'mode' : 11 , 'url' : eeVVVev [ 'trailer' ] } ) ) )
  elif metatype == 'tvep' :
   eVeevevVeveeeveveev = VevVevVVevVevVev . getSetting ( 'tv' )
   if '<>' in url :
    print url
    i1 = url . split ( '<>' ) [ 0 ]
    I1111IIIIIi = url . split ( '<>' ) [ 1 ]
    Iiii1i1 = url . split ( '<>' ) [ 2 ]
    VV = url . split ( '<>' ) [ 3 ]
    eeeveveve = url . split ( '<>' ) [ 4 ]
    iiIi1IIi1I = url . split ( '<>' ) [ 5 ]
    eeVVVev = Vevevevev . get_episode_meta ( I1111IIIIIi , imdb_id = i1 , season = Iiii1i1 , episode = VV , air_date = '' , episode_title = '' , overlay = '' )
   else :
    eeVevevVevVev = re . compile ( 'Season (.+?) Episode (.+?)\)' ) . findall ( name )
    for iII1I1 , eevVeeeveeveeeev in eeVevevVevVev :
     eeVVVev = Vevevevev . get_episode_meta ( eVeevevVeveeeveveev , imdb_id = '' , season = iII1I1 , episode = eevVeeeveeveeeev , air_date = '' , episode_title = '' , overlay = '' )
  try :
   if eeVVVev [ 'cover_url' ] == '' : iconimage = iconimage
   else : iconimage = eeVVVev [ 'cover_url' ]
  except : pass
  i1i1iI1iiiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( eeeevVV ) + "&iconimage=" + urllib . quote_plus ( iconimage )
  VeeeveVeeeev = True
  i1I1i111Ii = xbmcgui . ListItem ( VVeeeveveVevev , iconImage = iconimage , thumbnailImage = iconimage )
  i1I1i111Ii . setInfo ( type = "Video" , infoLabels = eeVVVev )
  i1I1i111Ii . setProperty ( "IsPlayable" , "true" )
  i1I1i111Ii . addContextMenuItems ( III111i11IiI , replaceItems = False )
  if not eeVVVev . get ( 'backdrop_url' , '' ) == '' : i1I1i111Ii . setProperty ( 'fanart_image' , eeVVVev [ 'backdrop_url' ] )
  else : i1I1i111Ii . setProperty ( 'fanart_image' , eeeevVV )
  eeeveevevevevVeev = VevVevVVevVevVev . getSetting ( 'favlist' )
  eevVeveveVee = [ ]
  eevVeveveVee . append ( ( ii1eVeVeveeveee ( 'Stream Information' ) , 'XBMC.Action(Info)' ) )
  if eeeveevevevevVeev == 'yes' : eevVeveveVee . append ( ( '[COLOR cyan]Remove From Keep Safe? [/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
  else : eevVeveveVee . append ( ( '[COLOR cyan]Add To Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
  i1I1i111Ii . addContextMenuItems ( eevVeveveVee , replaceItems = False )
  VeeeveVeeeev = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = i1i1iI1iiiI , listitem = i1I1i111Ii , isFolder = isFolder , totalItems = itemcount )
  return VeeeveVeeeev
 else :
  if isFolder :
   iI1ii1Ii ( name , url , mode , iconimage , eeeevVV , description = '' )
  else :
   Iii1IIII11I ( name , url , mode , iconimage , eeeevVV , description = '' )
   if 63 - 63: IiiIII111ii * VVeVeeevevee * i11IiIiiIIIII - I1ii - i11IiIiiIIIII
def iI1ii1Ii ( name , url , mode , iconimage , fanart , description = '' ) :
 VevVevVVevVevVev . setSetting ( 'favtype' , 'folder' )
 i1i1iI1iiiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 VeeeveVeeeev = True
 i1I1i111Ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1I1i111Ii . setInfo ( type = "Video" , infoLabels = { "Title" : name , 'plot' : description } )
 i1I1i111Ii . setProperty ( 'fanart_image' , fanart )
 if 'youtube.com/channel/' in url :
  i1i1iI1iiiI = 'plugin://plugin.video.youtube/channel/' + description + '/'
 if 'youtube.com/user/' in url :
  i1i1iI1iiiI = 'plugin://plugin.video.youtube/user/' + description + '/'
 if 'youtube.com/playlist?' in url :
  i1i1iI1iiiI = 'plugin://plugin.video.youtube/playlist/' + description + '/'
 if 'plugin://' in url :
  i1i1iI1iiiI = url
 eevVeveveVee = [ ]
 eeeveevevevevVeev = VevVevVVevVevVev . getSetting ( 'favlist' )
 if eeeveevevevevVeev == 'yes' : eevVeveveVee . append ( ( '[COLOR cyan]Remove From Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : eevVeveveVee . append ( ( '[COLOR cyan]Add To Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 i1I1i111Ii . addContextMenuItems ( eevVeveveVee , replaceItems = False )
 VeeeveVeeeev = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = i1i1iI1iiiI , listitem = i1I1i111Ii , isFolder = True )
 return VeeeveVeeeev
 if 97 - 97: eVVVeeveevV / VeeevVVeveVV
def eeeeevVev ( name , url , mode , iconimage , fanart , description = '' ) :
 VevVevVVevVevVev . setSetting ( 'favtype' , 'link' )
 i1i1iI1iiiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 VeeeveVeeeev = True
 i1I1i111Ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1I1i111Ii . setProperty ( 'fanart_image' , fanart )
 eevVeveveVee = [ ]
 eeeveevevevevVeev = VevVevVVevVevVev . getSetting ( 'favlist' )
 if eeeveevevevevVeev == 'yes' : eevVeveveVee . append ( ( '[COLOR cyan]Remove from Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : eevVeveveVee . append ( ( '[COLOR cyan]Add to Keeo Safe[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 i1I1i111Ii . addContextMenuItems ( eevVeveveVee , replaceItems = False )
 VeeeveVeeeev = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = i1i1iI1iiiI , listitem = i1I1i111Ii , isFolder = False )
 return VeeeveVeeeev
 if 18 - 18: VVeevevev + iiI1i1 - Veeve - VevVVe
def Iii1IIII11I ( name , url , mode , iconimage , fanart , description = '' ) :
 VevVevVVevVevVev . setSetting ( 'favtype' , 'link' )
 i1i1iI1iiiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 VeeeveVeeeev = True
 i1I1i111Ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1I1i111Ii . setProperty ( 'fanart_image' , fanart )
 i1I1i111Ii . setProperty ( "IsPlayable" , "true" )
 eevVeveveVee = [ ]
 eeeveevevevevVeev = VevVevVVevVevVev . getSetting ( 'favlist' )
 if eeeveevevevevVeev == 'yes' : eevVeveveVee . append ( ( '[COLOR cyan]Remove from Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : eevVeveveVee . append ( ( '[COLOR cyan]Add to Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 i1I1i111Ii . addContextMenuItems ( eevVeveveVee , replaceItems = False )
 VeeeveVeeeev = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = i1i1iI1iiiI , listitem = i1I1i111Ii , isFolder = False )
 return VeeeveVeeeev
iiII1i1 = base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvYW5ld0V2b2x2ZW1lbnUvRXZvbHZlTWFpbk1lbnUueG1s' )
def I11IiI1I11i1i ( url , name ) :
 eee = VeveeveV ( url )
 if len ( eee ) > 1 :
  Ii1iI = eeVe
  VeveveVeeveveeve = os . path . join ( os . path . join ( Ii1iI , '' ) , name + '.txt' )
  if not os . path . exists ( VeveveVeeveveeve ) :
   file ( VeveveVeeveveeve , 'w' ) . close ( )
  VVVVeveeee = open ( VeveveVeeveveeve )
  eeeeeVeev = VVVVeveeee . read ( )
  if eeeeeVeev == eee : pass
  else :
   IiiIiI1Ii1i ( '[B][COLOR yellow]PICASSO INFO[/COLOR][/B]' , eee )
   VeveveVev = open ( VeveveVeeveveeve , "w" )
   VeveveVev . write ( eee )
   VeveveVev . close ( )
   if 54 - 54: iiiIi % eVVVeeveevV . iI1I + I1ii - eVVVeeveevV * VevVVe
def IiiIiI1Ii1i ( heading , text ) :
 id = 10147
 xbmc . executebuiltin ( 'ActivateWindow(%d)' % id )
 xbmc . sleep ( 500 )
 VVeevevV = xbmcgui . Window ( id )
 eevIi1Iii111IiI1 = 50
 while ( eevIi1Iii111IiI1 > 0 ) :
  try :
   xbmc . sleep ( 10 )
   eevIi1Iii111IiI1 -= 1
   VVeevevV . getControl ( 1 ) . setLabel ( heading )
   VVeevevV . getControl ( 5 ) . setText ( text )
   return
  except :
   pass
   if 98 - 98: iI1I - VeeevVVeveVV % VevVVe + Ii11111i . i11IiIiiIIIII
def VeVV ( name ) :
 global Icon
 global Next
 global Previous
 global window
 global Quit
 global images
 VeveveVeeveveeve = os . path . join ( os . path . join ( eeVe , '' ) , name + '.txt' )
 VVVVeveeee = open ( VeveveVeeveveeve )
 eeeeeVeev = VVVVeveeee . read ( )
 images = re . compile ( '<image>(.+?)</image>' ) . findall ( eeeeeVeev )
 VevVevVVevVevVev . setSetting ( 'pos' , '0' )
 window = pyxbmct . AddonDialogWindow ( '' )
 iIII1I1i1i = '/resources/art'
 eevVIIiI1I1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + iIII1I1i1i , 'next_focus.png' ) )
 I11I1IIiiII1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + iIII1I1i1i , 'next1.png' ) )
 IIIIIii1ii11 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + iIII1I1i1i , 'previous_focus.png' ) )
 VVVeeeevVeeVeV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + iIII1I1i1i , 'previous.png' ) )
 eVeVVVe = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + iIII1I1i1i , 'close_focus.png' ) )
 ii1I = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + iIII1I1i1i , 'close.png' ) )
 eevVVeVeVevev = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + iIII1I1i1i , 'main-bg1.png' ) )
 window . setGeometry ( 1300 , 720 , 100 , 50 )
 I1iii = pyxbmct . Image ( eevVVeVeVevev )
 window . placeControl ( I1iii , - 10 , - 10 , 130 , 70 )
 i1i11I1I1iii1 = '0xFF000000'
 Previous = pyxbmct . Button ( '' , focusTexture = IIIIIii1ii11 , noFocusTexture = VVVeeeevVeeVeV , textColor = i1i11I1I1iii1 , focusedColor = i1i11I1I1iii1 )
 Next = pyxbmct . Button ( '' , focusTexture = eevVIIiI1I1 , noFocusTexture = I11I1IIiiII1 , textColor = i1i11I1I1iii1 , focusedColor = i1i11I1I1iii1 )
 Quit = pyxbmct . Button ( '' , focusTexture = eVeVVVe , noFocusTexture = ii1I , textColor = i1i11I1I1iii1 , focusedColor = i1i11I1I1iii1 )
 Icon = pyxbmct . Image ( images [ 0 ] , aspectRatio = 2 )
 window . placeControl ( Previous , 102 , 1 , 10 , 10 )
 window . placeControl ( Next , 102 , 40 , 10 , 10 )
 window . placeControl ( Quit , 102 , 21 , 10 , 10 )
 window . placeControl ( Icon , 0 , 0 , 100 , 50 )
 Previous . controlRight ( Next )
 Previous . controlUp ( Quit )
 window . connect ( Previous , eVVevVVevV )
 window . connect ( Next , eeveve )
 Previous . setVisible ( False )
 window . setFocus ( Quit )
 Previous . controlRight ( Quit )
 Quit . controlLeft ( Previous )
 Quit . controlRight ( Next )
 Next . controlLeft ( Quit )
 window . connect ( Quit , window . close )
 window . doModal ( )
 del window
 if 47 - 47: eeveee + IiiIII111ii - I1ii % VeeevVVeveVV
def eeveve ( ) :
 eevVev = int ( VevVevVVevVevVev . getSetting ( 'pos' ) )
 eeVeVe = int ( eevVev ) + 1
 VevVevVVevVevVev . setSetting ( 'pos' , str ( eeVeVe ) )
 IIIi1i = len ( images )
 Icon . setImage ( images [ int ( eeVeVe ) ] )
 Previous . setVisible ( True )
 if int ( eeVeVe ) == int ( IIIi1i ) - 1 :
  Next . setVisible ( False )
  if 71 - 71: IiiIII111ii % eeveee / eVVVeeveevV / II1Iiii1111i
def eVVevVVevV ( ) :
 eevVev = int ( VevVevVVevVevVev . getSetting ( 'pos' ) )
 VVevVVevVV = int ( eevVev ) - 1
 VevVevVVevVevVev . setSetting ( 'pos' , str ( VVevVVevVV ) )
 Icon . setImage ( images [ int ( VVevVVevVV ) ] )
 Next . setVisible ( True )
 if int ( VVevVVevVV ) == 0 :
  Previous . setVisible ( False )
  if 61 - 61: VeeevVVeveVV . I1ii . VeeevVVeveVV / II1Iiii1111i
def eevevV ( url , fanart ) :
 VevVevVVevVevVev . setSetting ( 'favlist' , 'yes' )
 i1i = None
 file = open ( Ve , 'r' )
 i1i = file . read ( ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 eeveveVVeve = re . compile ( "<item>(.+?)</item>" , re . DOTALL ) . findall ( i1i )
 for VVVevevV in eeveveVVeve :
  iI1iII1 ( VeveevVevevVeeveev , url , Veveveeeeeevev , fanart , VVVevevV )
 VevVevVVevVevVev . setSetting ( 'favlist' , 'no' )
 if 5 - 5: I1ii . VVVevV . Veeve . VeeevVVeveVV
def VeevVeeVev ( name , url , iconimage , fanart ) :
 eVeveveVeevVVV = VevVevVVevVevVev . getSetting ( 'favtype' )
 url = url . replace ( ' ' , '%20' )
 iconimage = iconimage . replace ( ' ' , '%20' )
 if '<>' in url :
  i1 = url . split ( '<>' ) [ 0 ]
  Iiii1i1 = url . split ( '<>' ) [ 1 ]
  VV = url . split ( '<>' ) [ 2 ]
  eeeveveve = url . split ( '<>' ) [ 3 ]
  iiIi1IIi1I = url . split ( '<>' ) [ 4 ]
  string = '<FAV><item>\n<title>' + name + '</title>\n<meta>tvep</meta>\n<nan>tvshow</nan>\n<showyear>' + eeeveveve + '</showyear>\n<imdb>' + i1 + '</imdb>\n<season>' + Iiii1i1 + '</season>\n<episode>' + VV + '</episode>\n<episodeyear>' + iiIi1IIi1I + '</episodeyear>\n<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 elif len ( url ) == 9 :
  string = '<FAV><item>\n<title>' + name + '</title>\n<meta>movie</meta>\n<nan>movie</nan>\n<imdb>' + url + '</imdb>\n' + '<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 else :
  string = '<FAV><item>\n<title>' + name + '</title>\n<' + eVeveveVeevVVV + '>' + url + '</' + eVeveveVeevVVV + '>\n' + '<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 IiII = open ( Ve , 'a' )
 IiII . write ( string )
 IiII . close ( )
 if 23 - 23: Ii . eeveee * VVeevevev
def iIi1IiI ( name , url , iconimage ) :
 print name
 i1i = None
 file = open ( Ve , 'r' )
 i1i = file . read ( )
 I11IIIiIi11 = ''
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( i1i )
 for VVeVVeveeeveeV in eeveveVVeve :
  string = '\n<FAV><item>\n' + VVeVVeveeeveeV + '</item>\n'
  if name in VVeVVeveeeveeV :
   print 'xxxxxxxxxxxxxxxxx'
   string = string . replace ( 'item' , ' ' )
  I11IIIiIi11 = I11IIIiIi11 + string
 file = open ( Ve , 'w' )
 file . truncate ( )
 file . write ( I11IIIiIi11 )
 file . close ( )
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 39 - 39: i11IiIiiIIIII % Ii11111i % Veveevev . Ii
def iI1i11iII111 ( url ) :
 try :
  I1iiiiI1iI = url . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
  file = open ( IIi1IiiiI1Ii , 'r' )
  eVeevevVeeVeveV = file . read ( )
  if I1iiiiI1iI in eVeevevVeeVeveV : return '[COLOR cyan] (RD)[/COLOR]'
  else : return ''
 except : return ''
 if 16 - 16: i1iIIi1 / II1Iiii1111i + eVVVeeveevV / i11IiIiiIIIII
def IIIiiI1 ( ) :
 xbmcaddon . Addon ( 'script.module.nanscrapers' ) . openSettings ( )
 if 74 - 74: VVeVeeevevee - eVVVeeveevV + Ii . VevVVe + eVVVeeveevV - VVeVeeevevee
def IiIiiiiI1 ( ) :
 xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
 if 62 - 62: VVVevV % IiiIII111ii * VVeevevev - Ii
def VeVVe ( ) :
 xbmcaddon . Addon ( 'script.module.metahandler' ) . openSettings ( )
 if 17 - 17: Ii
def eV ( link ) :
 try :
  i1IIII1iii11I = re . compile ( '<layouttype>(.+?)</layouttype>' ) . findall ( link ) [ 0 ]
  if i1IIII1iii11I == 'thumbnail' : xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
  else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 except : pass
 if 97 - 97: VeeevVVeveVV - iI1I
 if 58 - 58: iiI1i1 + Ii11111i
eeeeveevevevV = Ii111 ( ) ; VeI1Ii11I1Ii1i = None ; VeveevVevevVeeveev = None ; IIiiIIIIII1II = None ; I111I11I111 = None ; VevevVeveVVevevVevev = None ; iiiiI11ii = None
try : I111I11I111 = urllib . unquote_plus ( eeeeveevevevV [ "site" ] )
except : pass
try : VeI1Ii11I1Ii1i = urllib . unquote_plus ( eeeeveevevevV [ "url" ] )
except : pass
try : VeveevVevevVeeveev = urllib . unquote_plus ( eeeeveevevevV [ "name" ] )
except : pass
try : IIiiIIIIII1II = int ( eeeeveevevevV [ "mode" ] )
except : pass
try : VevevVeveVVevevVevev = urllib . unquote_plus ( eeeeveevevevV [ "iconimage" ] )
except : pass
try : eeeevVV = urllib . unquote_plus ( eeeeveevevevV [ "fanart" ] )
except : pass
try : iiiiI11ii = str ( eeeeveevevevV [ "description" ] )
except : pass
if 96 - 96: IiiIII111ii . Ii11111i / IiiIII111ii % Ii11111i
if IIiiIIIIII1II == None or VeI1Ii11I1Ii1i == None or len ( VeI1Ii11I1Ii1i ) < 1 : Veeveveve ( )
elif IIiiIIIIII1II == 1 : VVeveVVevV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif IIiiIIIIII1II == 2 : VVVeee ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , iiiiI11ii )
elif IIiiIIIIII1II == 3 : I111 ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif IIiiIIIIII1II == 4 : VeveVVeevVe ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif IIiiIIIIII1II == 5 : i11iIiI11I1i ( )
elif IIiiIIIIII1II == 6 : eeveveV ( VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif IIiiIIIIII1II == 7 : eVVeeeveevVVVV ( VeI1Ii11I1Ii1i )
elif IIiiIIIIII1II == 8 : VeVV ( VeveevVevevVeeveev )
elif IIiiIIIIII1II == 9 : II1i ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i )
elif IIiiIIIIII1II == 10 : eVVVeveeev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif IIiiIIIIII1II == 11 : ii1Ii1IiIIi ( VeI1Ii11I1Ii1i )
elif IIiiIIIIII1II == 12 : IiIiiiiI1 ( )
elif IIiiIIIIII1II == 13 : VeVVe ( )
elif IIiiIIIIII1II == 15 : SCRAPEMOVIE ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif IIiiIIIIII1II == 16 : VeeveveeevevevevVV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif IIiiIIIIII1II == 17 : eeeevV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i )
elif IIiiIIIIII1II == 18 : eevVVVeVev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif IIiiIIIIII1II == 19 : eeeveVeveVVee ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
if 94 - 94: i1iIIi1 + iI1I / eVVVeeveevV
elif IIiiIIIIII1II == 20 : VeevVeeVev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif IIiiIIIIII1II == 21 : iIi1IiI ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif IIiiIIIIII1II == 22 : eevevV ( VeI1Ii11I1Ii1i , eeeevVV )
elif IIiiIIIIII1II == 23 : DOIPLAYER ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif IIiiIIIIII1II == 24 : VeveVVeeeVVevV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif IIiiIIIIII1II == 25 : IIIiiI1 ( )
if 91 - 91: VVeVeeevevee / Ii * Ii
elif IIiiIIIIII1II == 26 : eev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif IIiiIIIIII1II == 27 : VVeeevV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif IIiiIIIIII1II == 28 : i11III1111iIi ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif IIiiIIIIII1II == 29 : VeeVevVV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif IIiiIIIIII1II == 30 : VVVVeVVeevVev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif IIiiIIIIII1II == 31 : ii1I1IIii11 ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif IIiiIIIIII1II == 32 : VeveeevV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif IIiiIIIIII1II == 33 : eeVeevev ( VeI1Ii11I1Ii1i )
elif IIiiIIIIII1II == 34 : iIIi ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif IIiiIIIIII1II == 35 : ii1IIII ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
if 25 - 25: iiI1i1 . eVVVeeveevV * I1ii - i11IiIiiIIIII
elif IIiiIIIIII1II == 36 : VVevVeeeeveVVevV ( )
elif IIiiIIIIII1II == 37 : VeveveevVVev ( VeI1Ii11I1Ii1i )
elif IIiiIIIIII1II == 38 : eeveevVevVeveveVVe ( VeI1Ii11I1Ii1i )
elif IIiiIIIIII1II == 39 : IiIIIIii1I ( VeI1Ii11I1Ii1i )
elif IIiiIIIIII1II == 40 : VVevVeVVeveeve ( )
elif IIiiIIIIII1II == 41 : i1ii1I1111ii1 ( VeI1Ii11I1Ii1i )
elif IIiiIIIIII1II == 42 : eeeveveVevVev ( VeI1Ii11I1Ii1i )
if 55 - 55: Veveevev
elif IIiiIIIIII1II == 43 : iii11I ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif IIiiIIIIII1II == 44 : i1Iii11I1i ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif IIiiIIIIII1II == 45 : I11i1II ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif IIiiIIIIII1II == 46 : eeeeveveveevevev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
if 63 - 63: i1iIIi1 * Veveevev * iiiIi
elif IIiiIIIIII1II == 47 : DODOCLOGMENU ( )
elif IIiiIIIIII1II == 48 : GET_DOCCONTENT ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , II1 )
elif IIiiIIIIII1II == 49 : DO_DOCCONTENT ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , II1 )
elif IIiiIIIIII1II == 50 : RESOLVE2 ( VeI1Ii11I1Ii1i )
elif IIiiIIIIII1II == 51 : VeevVVVevevVevV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif IIiiIIIIII1II == 52 : I1I ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
if 92 - 92: VVVevV / Ii11111i
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
