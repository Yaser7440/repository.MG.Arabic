# script.module.mctools
This is a library for the viewer addons.

It requires this libraries to be installed before:

    script.module.beautifulsoup4
    script.module.html5lib
    script.module.requests
    script.module.feedparser
    script.module.xbmcswift2
    script.module.simplejson
    script.module.metahandler
    script.module.httplib2
    
  You can google them and installed one by one or you can instead use this repo and you install directly the script.module.mctools 
  and it will download everything for you.
   https://offshoregit.com/pulsarunofficial/Unofficial-Quasar-Repo/repository.unofficialquasar/repository.unofficialquasar-1.0.4.zip
  
  Forum support:
  http://forums.tvaddons.ag/addon-releases/37973-torrent-rss-kickass-yts-torrentz-viewers-3.html#post314231
