import re
import json
import urllib
import urllib2
from dudehere.routines import *
from dudehere.routines import plugin
from dudehere.routines.trakt import TraktAPI
trakt = TraktAPI()

base_url = "http://%s:6544" % plugin.get_setting('mythtv_host')
		
def search(filename):
	response = _call('/Dvr/GetRecordedList')
	pattern = '\/Default\/([^\/]+)\/.*,\s(\d+_\d+)\.pvr'
	match = re.search(pattern, filename)
	if match:
		title, ts = match.groups()
	else:
		plugin.log(filename)
		return False, False, False, False
	
	year = ts[0:4]
	month = ts[4:6]
	day = ts[6:8]
	hour = ts[9:11]
	minut = ts[11:13]
	second = ts[13:15]
	
	start_time = "%s-%s-%sT%s:%s:%sZ" % (year, month, day, hour, minut, second)
	slug = False
	for r in response['ProgramList']['Programs']:
		if r['Title'] == title and r['StartTime'] == start_time:
			plugin.log(r['StartTime'])
			tvdb_id = r['Inetref']
			slug = trakt.query_slug(id_type='tvdb', id=tvdb_id)
			channel = r['Channel']['ChanId']
			break
	if slug:
		uri = '/Dvr/GetRecorded?StartTime=%s&ChanId=%s' % (start_time, channel)
		response = _call(uri)
		season = response['Program']['Season']
		episode = str(response['Program']['Episode'])
		meta = trakt.get_metadata('episode', '', '', '', slug, season, episode)
		imdb_id = meta['imdb_id']
		eps = results = trakt.get_show_episodes(imdb_id, season)
		for e in eps:
			if str(e['number']) == episode:
				trakt_id = e['ids']['trakt']
				break
		return slug, season, episode, trakt_id
	
	return False, False, False, False

def _call(uri):
	headers = {'Accept': 'application/json'}
	url = base_url + uri
	request = urllib2.Request(url, headers=headers)
	f = urllib2.urlopen(request)
	result = f.read()
	response = json.loads(result)
	return response
