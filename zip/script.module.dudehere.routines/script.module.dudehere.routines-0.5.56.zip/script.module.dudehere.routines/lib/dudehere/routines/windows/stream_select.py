#!/usr/bin/python
# -*- coding: utf-8 -*-
PYTHONIOENCODING="UTF-8"

'''*
	Copyright (C) 2016 DudeHere

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

*'''

import xbmc
import xbmcgui
from dudehere.routines import *
from dudehere.routines.windows import BaseWindow

CONTROLS = enum(
	CLOSE=82000,
	LISTS=91050,
)
table = {9: "local.png", 8: '1080.png', 7:"720.png", 6: "hd.png", 5: "hd.png", 4:"480.png", 3:"unknown.png", 2:"low.png", 1:"low.png"}

class StreamSelect(BaseWindow):
	choice = -1
	def __init__(self, *args, **kwargs):
		BaseWindow.__init__(self)

	def onInit(self):
		items = []
		for stream in self.streams:
			result = self.results[self.streams.index(stream)]
			icon = table[result.quality]
			liz = xbmcgui.ListItem(stream, iconImage='definition/' + icon)
			
			items.append(liz)
		self.getControl(CONTROLS.LISTS).addItems(items)
		self.getControl(CONTROLS.LISTS).selectItem(0)

	
	def onClick(self, controlID):
		if controlID==CONTROLS.LISTS:
			index = self.getControl(CONTROLS.LISTS).getSelectedPosition()
			self.choice = index
			self.close()
		elif controlID == CONTROLS.CLOSE:
			self.close()	