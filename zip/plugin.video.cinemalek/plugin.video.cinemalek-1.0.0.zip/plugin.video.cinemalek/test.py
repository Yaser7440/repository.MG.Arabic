s1='http://cinemalek.com/wp-content/uploads/2016/05/the-american-side-2016.jpg'
s2='http://cinemalek.com/wp-content/uploads/2016/05/The-American-Side-2016.jpg'
if s1==s2:
    print "ok"
