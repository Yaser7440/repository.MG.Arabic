# -*- coding: utf-8 -*-
# Embedded file name: /media/hdd/Extensions/TSmedia/addons/arabic/plugin.video.aflamhd/default.py




try:import sys, syspath
except:pass
import os, sys
import httplib
import time
from urllib import urlencode
import urllib, urllib2, re, sys
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse
from addon.common.net import Net
from urlresolver import resolve
import StringIO
#url='http%3A%2F%2Fvgrp1.viewstream.co.il%2Fviewstream%2F34%2F13%2F299%2F13299.flv%3Fvtraffid%3D13299%26ctraffid%3D34'
#print urllib.unquote_plus(url)
#sys.exit(0)
__settings__ = xbmcaddon.Addon(id='plugin.video.cinemalek')
__icon__ = __settings__.getAddonInfo('icon')
__fanart__ = __settings__.getAddonInfo('fanart')
__language__ = __settings__.getLocalizedString
_thisPlugin = int(sys.argv[1])
_pluginName = sys.argv[0]
baseurl = 'http://cinemalek.com/'

####functions

def read_url(url):
     
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', host)
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
        return link
    
def readnet2(url):
            
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      

              
def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        
        return query.hostname 
##########################################parsing tools
def showmenu():

                genreliste=[]
               
                #genreliste.append(("Genres", 'genre',5,'img/6.png','',1))
                #genreliste.append(("الاضافات الجديده", 'http://www.shayef.com/Mosalsalat.asp',222,'img/1.png','',1))
                genreliste.append(("Search", 'http://cinemalek.com/?s=',3,'img/search.png','',1))
   
                genreliste.append(("افلام اجنبيه", 'http://cinemalek.com/category/%D8%A3%D9%81%D9%84%D8%A7%D9%85/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/',100,'img/englishm.png','',1))
                genreliste.append(("افلام عربي", 'http://cinemalek.com/category/%D8%A3%D9%81%D9%84%D8%A7%D9%85/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%B9%D8%B1%D8%A8%D9%89/',100,'img/arabicm.png','',1))
                genreliste.append(("افلام هندي", 'http://cinemalek.com/category/%D8%A3%D9%81%D9%84%D8%A7%D9%85/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D9%87%D9%86%D8%AF%D9%89/',100,'img/hendim.png','',1))
                genreliste.append(("سلاسل افلام احنبيه", 'http://cinemalek.com/movies/category/%D8%B3%D9%84%D8%A7%D8%B3%D9%84_%D8%A7%D9%84%D8%A7%D9%81%D9%84%D8%A7%D9%85_%D8%A7%D9%84%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D9%87/',100,'img/englishs.png','',1))
                genreliste.append(("افلام انيمي وكارتون", 'http://cinemalek.com/category/kartoon/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D9%86%D9%85%D9%89-%D9%88-%D9%83%D8%A7%D8%B1%D8%AA%D9%88%D9%86/',100,'img/anime.png','',1))
                genreliste.append(("مسلسلات انيمي وكارتون", 'http://cinemalek.com/category/kartoon/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D9%83%D8%B1%D8%AA%D9%88%D9%86-%D9%88-%D8%A3%D9%86%D9%85%D9%89/',200,'img/animes.png','',1))
                genreliste.append(("عروض المصارعه", 'http://cinemalek.com/category/%D9%85%D8%B5%D8%A7%D8%B1%D8%B9%D8%A9/',100,'img/www.png','',1))
                genreliste.append(("برامج تلفزيونيه", 'http://cinemalek.com/category/%D8%A8%D8%B1%D8%A7%D9%85%D8%AC_%D8%AA%D9%84%D9%81%D8%B2%D9%8A%D9%88%D9%86%D9%8A%D8%A9/',200,'img/program.png','',1))
                genreliste.append(("مسرحيات", 'http://cinemalek.com/category/%D9%85%D8%B3%D8%B1%D8%AD%D9%8A%D8%A7%D8%AA-%D8%B9%D8%B1%D8%A8%D9%8A%D9%87/',200,'img/theatre.png','',1))
                
                genreliste.append(("مسلسلات اجنبيه", 'http://cinemalek.com/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%a7%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%a7%d8%ac%d9%86%d8%a8%d9%89/',200,'img/englishs.png','',1))
                genreliste.append(("مسلسلات عربيه", 'http://cinemalek.com/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%A7%D9%88%D9%86-%D9%84%D8%A7%D9%8A%D9%86/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%B9%D8%B1%D8%A8%D9%89/',200,'img/arabics.png','',1))
                genreliste.append((" مدبلجه مسلسلات تركيه", 'http://cinemalek.com/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%a7%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%aa%d8%b1%d9%83%d9%89/',200,'img/turkeys.png','',1))
                 
                genreliste.append(("مسلسلات هنديه", 'http://cinemalek.com/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%a7%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86/series-hendi/',200,'img/hendis.png','',1)) 
                
                
                #genreliste.append(("مسلسلات تركيه مترجمه", 'http://www.drama2.tv/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%aa%d8%b1%d9%83%d9%8a%d8%a9/',200,'img/6.png','',1))
                #genreliste.append(("مسلسلات مدبلجه", 'http://www.drama2.tv/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%aa%d8%b1%d9%83%d9%8a%d8%a9/',200,'img/6.png','',1))
                               
                

                
                
		
                for title, url, mode,pic,desc,page in genreliste:
                    addDir(title, url, mode, pic,desc,1)

###############################################tv shows
def series_a_z(mainurl):
    matches = [ ('http://www.shayef.com/Mosalsalat.asp', 'ا'),('http://www.shayef.com/Mosalsalat.asp?Leter=2', '\xd8\xa8'), ('http://www.shayef.com/Mosalsalat.asp?Leter=3', '\xd8\xaa'), ('http://www.shayef.com/Mosalsalat.asp?Leter=4', '\xd8\xab'), ('http://www.shayef.com/Mosalsalat.asp?Leter=5', '\xd8\xac'), ('http://www.shayef.com/Mosalsalat.asp?Leter=6', '\xd8\xad'), ('http://www.shayef.com/Mosalsalat.asp?Leter=7', '\xd8\xae'), ('http://www.shayef.com/Mosalsalat.asp?Leter=8', '\xd8\xaf'), ('http://www.shayef.com/Mosalsalat.asp?Leter=9', '\xd8\xb0'), ('http://www.shayef.com/Mosalsalat.asp?Leter=10', '\xd8\xb1'), ('http://www.shayef.com/Mosalsalat.asp?Leter=11', '\xd8\xb2'), ('http://www.shayef.com/Mosalsalat.asp?Leter=12', '\xd8\xb3'), ('http://www.shayef.com/Mosalsalat.asp?Leter=13', '\xd8\xb4'), ('http://www.shayef.com/Mosalsalat.asp?Leter=14', '\xd8\xb5'), ('http://www.shayef.com/Mosalsalat.asp?Leter=15', '\xd8\xb6'), ('http://www.shayef.com/Mosalsalat.asp?Leter=16', '\xd8\xb7'), ('http://www.shayef.com/Mosalsalat.asp?Leter=17', '\xd8\xb8'), ('http://www.shayef.com/Mosalsalat.asp?Leter=18', '\xd8\xb9'), ('http://www.shayef.com/Mosalsalat.asp?Leter=19', '\xd8\xba'), ('http://www.shayef.com/Mosalsalat.asp?Leter=20', '\xd9\x81'), ('http://www.shayef.com/Mosalsalat.asp?Leter=21', '\xd9\x82'), ('http://www.shayef.com/Mosalsalat.asp?Leter=22', '\xd9\x83'), ('http://www.shayef.com/Mosalsalat.asp?Leter=23', '\xd9\x84'), ('http://www.shayef.com/Mosalsalat.asp?Leter=24', '\xd9\x85'), ('http://www.shayef.com/Mosalsalat.asp?Leter=25', '\xd9\x86'), ('http://www.shayef.com/Mosalsalat.asp?Leter=26', '\xd9\x87'), ('http://www.shayef.com/Mosalsalat.asp?Leter=27', '\xd9\x88'), ('http://www.shayef.com/Mosalsalat.asp?Leter=28', '\xd9\x8a')]
    for item in matches:
        title = item[1]
        url = item[0]
        pic = ''
        try:
            mode = item[2]
        except:
            mode = 3
        print "title",title
        
        if "?" in url:
                url=url.split("?")[1]
                url=mainurl+"?"+url
        else:
                url=mainurl
        addDir(title, url, 200, pic)

def movies_a_z(mainurl):
    matches = [ ('http://www.shayef.com/Mosalsalat.asp', 'ا'),('http://www.shayef.com/Mosalsalat.asp?Leter=2', '\xd8\xa8'), ('http://www.shayef.com/Mosalsalat.asp?Leter=3', '\xd8\xaa'), ('http://www.shayef.com/Mosalsalat.asp?Leter=4', '\xd8\xab'), ('http://www.shayef.com/Mosalsalat.asp?Leter=5', '\xd8\xac'), ('http://www.shayef.com/Mosalsalat.asp?Leter=6', '\xd8\xad'), ('http://www.shayef.com/Mosalsalat.asp?Leter=7', '\xd8\xae'), ('http://www.shayef.com/Mosalsalat.asp?Leter=8', '\xd8\xaf'), ('http://www.shayef.com/Mosalsalat.asp?Leter=9', '\xd8\xb0'), ('http://www.shayef.com/Mosalsalat.asp?Leter=10', '\xd8\xb1'), ('http://www.shayef.com/Mosalsalat.asp?Leter=11', '\xd8\xb2'), ('http://www.shayef.com/Mosalsalat.asp?Leter=12', '\xd8\xb3'), ('http://www.shayef.com/Mosalsalat.asp?Leter=13', '\xd8\xb4'), ('http://www.shayef.com/Mosalsalat.asp?Leter=14', '\xd8\xb5'), ('http://www.shayef.com/Mosalsalat.asp?Leter=15', '\xd8\xb6'), ('http://www.shayef.com/Mosalsalat.asp?Leter=16', '\xd8\xb7'), ('http://www.shayef.com/Mosalsalat.asp?Leter=17', '\xd8\xb8'), ('http://www.shayef.com/Mosalsalat.asp?Leter=18', '\xd8\xb9'), ('http://www.shayef.com/Mosalsalat.asp?Leter=19', '\xd8\xba'), ('http://www.shayef.com/Mosalsalat.asp?Leter=20', '\xd9\x81'), ('http://www.shayef.com/Mosalsalat.asp?Leter=21', '\xd9\x82'), ('http://www.shayef.com/Mosalsalat.asp?Leter=22', '\xd9\x83'), ('http://www.shayef.com/Mosalsalat.asp?Leter=23', '\xd9\x84'), ('http://www.shayef.com/Mosalsalat.asp?Leter=24', '\xd9\x85'), ('http://www.shayef.com/Mosalsalat.asp?Leter=25', '\xd9\x86'), ('http://www.shayef.com/Mosalsalat.asp?Leter=26', '\xd9\x87'), ('http://www.shayef.com/Mosalsalat.asp?Leter=27', '\xd9\x88'), ('http://www.shayef.com/Mosalsalat.asp?Leter=28', '\xd9\x8a')]
    for item in matches:
        title = item[1]
        url = item[0]
        pic = ''
        try:
            mode = item[2]
        except:
            mode = 3
        print "title",title
        
        if "?" in url:
                url=url.split("?")[1]
                url=mainurl+"?"+url
        else:
                url=mainurl
        addDir(title, url, 100, pic)        
def search_series(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= '?s='+search_entered

        getseries_search("Search",url,1)
def getseries_search(tname,urlmain,page):##series
                if page>1:
                  #/page/2/
                        #http://cinemalek.com/?s=love
                  #http://cinemalek.com/page/2/?s=love     
                  url_page='http://cinemalek.com/'+"page/"+str(page)+"/"+urlmain
                  
                else:
                
                      url_page='http://cinemalek.com/'+"/"+urlmain
                 
                data=readnet2(url_page)
                
                #try:data=data.split('<ul class="modern-articles">')[1]
                #except:pass
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="block_loop">')
                i=0
                
               #http://cinemalek.com/series/wp-content/themes/series/server1.php?server=7&p=24909
                for block in blocks:
                   
                    i=i+1
                    if i==1:
                            continue
                   
                    regx='<a href="(.*?)" title="(.*?)">'
                    
                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match
                    try:href=match[0][0]
                    except:continue
                    name=match[0][1]  
                    regx='''<img.*?src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]

                   
                                             
                               
                    
                    name=name.encode("utf-8")
                    
                    try:addDir(name,href,1,img,'',1)
                    except:continue
                if len(blocks)>7:
                   addDir("next page",urlmain,300,'img/nextpage.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))   
                    
def getseasons(name,urlmain,page):##series
                if page>1:
                  #/page/2/
                  #http://www.drama2.tv/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9/page/2/      
                  url_page=urlmain+"page/"++str(page)
                  
                else:
                
                      url_page=urlmain
                 
                data=readnet(url_page)
                try:data=data.split('<div class="title6">')[1]
                except:pass
                print "url_page",url_page
              
                if data is None:
                    return

                seasons=re.findall('''<a href="(.*?)" >(.*?)</a>''',data, re.M|re.I)
                print 'seasons',seasons
                
                for href,name in seasons:
                    
                    
                    addDir(name,href,201,'','',1)
                        
               
def getseasons_search(name,urlmain,page):##series
                
                data=readnet(urlmain)
                try:data=data.split('<h2>Search results')[1]
                except:pass
               
              
                if data is None:
                    return
                regx='<a href="(.*?)"  rel="nofollow">(.*?)</a>'
                seasons=getgroups(data,regx,2)
               
                
                seasons=re.findall(regx,data, re.M|re.I)
                print 'seasons',seasons
                
                for href,name in seasons:
                    
                    
                    addDir(name,href,201,'','',1)
                                           
def getmovies(tname,urlmain,page):##series
                if page>1:
                  #/page/2/
                  #http://cinemalek.com/category/%D8%A3%D9%81%D9%84%D8%A7%D9%85/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/page/2/     
                  url_page=urlmain+"page/"+str(page)+"/"
                  
                else:
                
                      url_page=urlmain
                data=readnet2(url_page)
               #data=data.split('id="movie_list"')[1]
                
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('class="block_loop">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    regx='''<a href="(.*?)" title="(.*?)">'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match,block.encode("utf-8")
                    href=match[0][0]
                    name=match[0][1]  
                    regx='''<img.*?src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    print "img",img.strip()
                    
                   
                                             
                               
                    
                    name=name.encode("utf-8")
                    
                    try:addDir(name+"_1",href,1,img,'',1)
                    except:continue
               
                if len(blocks)>7:
                   addDir("next page",urlmain,100,'img/nextpage.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
def newseries(tname,urlmain,page):##series

                data=readnet2(urlmain)
               #data=data.split('id="movie_list"')[1]
                
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('class="vi-box-top-Home"')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                    
                    regx='''<a href="(.*?)"><img src="(.*?)" /></a>'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match,block.encode("utf-8")
                    href=match[0][0]
                    img=match[0][1]  
                    regx='''<h4>(.*?)</h4>'''
                    name=re.findall(regx,block, re.M|re.I)[0]

                   
                                             
                               
                    
                    name=name.encode("utf-8")
                    zoneid=href.split("zoneid=")[1].split("&")[0]
                    #href='http://www.shayef.com/series_page.asp?ZoneID='+zoneid
                    try:addDir(name,href,21,img,'',1)
                    except:continue
               
                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))                    
def getseries(tname,urlmain,page):##series
                if page>1:
                  #/page/2/
                  #http://www.drama2.tv/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9/page/2/      
                  url_page=urlmain+"page/"+str(page)+"/"
                  
                else:
                
                      url_page=urlmain
                 
                data=readnet2(url_page)
                
                #try:data=data.split('<ul class="modern-articles">')[1]
                #except:pass
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="block_loop">')
                i=0
                
               #http://cinemalek.com/series/wp-content/themes/series/server1.php?server=7&p=24909
                for block in blocks:
                   
                    i=i+1
                    if i==1:
                            continue
                   
                    regx='<a href="(.*?)" title="(.*?)">'
                    
                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match
                    try:href=match[0][0]
                    except:continue
                    name=match[0][1]  
                    regx='''<img.*?src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]

                   
                                             
                               
                    
                    name=name.encode("utf-8")
                    
                    try:addDir(name,href,1,img,'',1)
                    except:continue
                if len(blocks)>7:
                   addDir("next page",urlmain,200,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))               
                
                
def getepisodes21(name,urlmain,page):##series
                print "page",page
               

               
                data=readnet2(urlmain)

                if data is None:
                    return
                #try:data=data.split('<div class="keremiya_part">')[1]
                #except:data=''

               
                if data:
                   
                    block=data.split('<!-- entry content -->')[1]
                    i=0
                    if block:
                      
                                                
                       regx='''<a href='(.*?)'.*?><i class=''></i><span class='wpi_text'>(.*?)</span></a>'''
                       regx2='''<a href="(.*?)".*?>(.*?)</a>'''
                       
                       #regx='<a href="(.*?)">'
                       match=re.findall(regx,block, re.M|re.I)
                       
                       if len(match)==0:
                          match=re.findall(regx2,block, re.M|re.I)     
                    
                       for href,name in match:         
                       
                    
                    
                               
                   
                           
                                    
                            try:name=name.encode("utf-8")
                            except:pass
                            #print "href,name",href,name
                            addDir(name,href,1,'','',1)       
def getepisodes2(name,urlmain,page):##series
                print "page",page
               

               
                data=readnet2(urlmain)

                if data is None:
                    return
                #try:data=data.split('<div class="keremiya_part">')[1]
                #except:data=''

               
                if data:
                   
                    blocks=data.split('class="vi-box-top"')
                    
                    i=0
                    for block in blocks:
                       i=i+1
                       if i==1:
                                    continue
                            
                       regx='href="(.*?)"><h4>(.*?)</h4>'
                       #regx='<a href="(.*?)">'
                       match=re.findall(regx,block, re.M|re.I)
                       href=match[0][0]
                       name=match[0][1]
                       print "match",match
                       
                       regx='<a href=".*?"><img src="(.*?)" /></a>'
                       img=match=re.findall(regx,block, re.M|re.I)[0]
                    
                       if img:         
                       
                    
                    
                               
                   
                           
                                    
                            try:name=name.encode("utf-8")
                            except:pass
                            #print "href,name",href,name
                            addDir(name,href,20001,img,'',1)                                            
def getepisodes3(name,urlmain,page):##series
                print "page",page
               

               
                data=readnet2(urlmain)

                if data is None:
                    return
                #try:data=data.split('<div class="keremiya_part">')[1]
                #except:data=''

               
                if data:
                   
                    blocks=data.split('class="vi-box-top"')
                    
                    i=0
                    for block in blocks:
                       i=i+1
                       if i==1:
                                    continue
                            
                       regx='href="(.*?)"><h4>(.*?)</h4>'
                       #regx='<a href="(.*?)">'
                       match=re.findall(regx,block, re.M|re.I)
                       href=match[0][0]
                       name=match[0][1]
                       print "match",match
                       
                       regx='<a href=".*?"><img src="(.*?)" /></a>'
                       img=match=re.findall(regx,block, re.M|re.I)[0]
                    
                       if img:         
                       
                    
                    
                               
                   
                           
                                    
                            try:name=name.encode("utf-8")
                            except:pass
                            #print "href,name",href,name
                            addDir(name,href,201,img,'',1)   
def getepisodes(name,urlmain,page):##series
                print "page",page
               

               
                data=readnet2(urlmain)

                if data is None:
                    return
                #try:data=data.split('<div class="keremiya_part">')[1]
                #except:data=''

               
                if data:
                   
                    blocks=data.split('<div class="box-bottom">')
                    i=0
                    for block in blocks:
                       i=i+1
                       if i==1:
                                    continue
                            
                       regx='<a href="(.*?)"><h2>(.*?)</h2></a>'
                       #regx='<a href="(.*?)">'
                       match=re.findall(regx,block, re.M|re.I)
                       print "match",match
                
                    
                       for href,name in match:         
                       
                    
                    
                               
                   
                           
                                    
                            try:name=name.encode("utf-8")
                            except:pass
                            #print "href,name",href,name
                            addDir(name,href,21,'','',1)                        
               
                   
                


#######################################host resolving                                                    
def creatertmp(host,urlmain):
     #rtmp://streaming.hayyes.com/vod/<playpath>mp4:29/29303/29303_1_400k.mp4 <swfUrl>http://www.hayyes.com/sites/all/themes/hys/tpl/jw/jwplayer.flash.swf <pageUrl>http://www.hayyes.com/vod/aflam/7alawet-roo7
     url=host+'  swfUrl=http://www.hayyes.com/sites/all/themes/hys/tpl/jw/jwplayer.flash.swf pageUrl='+ urlmain
     return url

def gethosts(name,urlmain):##cinema and tv featured
#href="http://www.arabshow.tv/the-forest/2/">
        data=readnet2(urlmain)
        regx='''<iframe.*?src="(.*?)".*?></iframe>'''
        regx='''<a href="(.*?)" title='''
        match=re.findall(regx,data, re.M|re.I)
        href=match[1]
        
        data=readnet2(href)
        regx="data: 'server='+i+'&p=(.*?)',"
        regx='''<body class="rtl single single-post postid-(.*?) single-format-standard"'''
        #regx='<body class="rtl single single-post postid-(.*?) single-format-standard" itemscope'
        
        id=re.findall(regx,data, re.M|re.I)[0]
        print "id",id
      
        for i in range(1,11):
            server="server "+str(i)
            if '_1' in name:
               href='http://cinemalek.com/movies/wp-content/themes/movies/server1.php?server='+str(i)+'&p='+id.strip()
            else:
                    
              href='http://cinemalek.com/series/wp-content/themes/series/server1.php?server='+str(i)+'&p='+id.strip()
            addDir(server,href,11,'','',1)
        
       

		
		
                #playlink(link)
def gethosts_movies(urlmain):##cinema and tv featured

                
                data=readnet(urlmain)
                try:data=data.split("<div class='panel-container'>")[1]
                except:pass
               
                
              
                if data is None:
                    return
                
                blocks=data.split('class="tab-buttons-panel"')
               
                i=0
               
                for block in blocks:
                    i=i+1
                    
                    
                    regx1='''<iframe.*?src="(.*?)".*?></iframe>'''
                    regx2='''<iframe.*?src='(.*?)'.*?></iframe'''
                    #regx3='''<iframe width="600" height="330" scrolling="no" frameborder="0" src="http://videomega.tv/iframe.php?ref=Kjp0m2ECo44oCE2m0pjK&width=600&height=330" allowFullScreen></iframe>'''
                    match=re.findall(regx1,block, re.M|re.I)
                    match2=re.findall(regx2,block, re.M|re.I)
                   
                    
                     
                   
                    
                    for href in match:
                      
                      host=gethostname(href)
                    
                            
                   
                      addDir(host,href,1,'','',1)
                    for href in match2:
                      
                      host=gethostname(href)
                    
                            
                   
                      addDir(host,href,1,'','',1)
def get_servers(url):
    data = readnet2(url)
    regx = '<a href="(.+?)" target="_blank"><img alt'
    regx='file: "(.+?)"'
    #print "data",data
    ##http://cinemalek.com/series/wp-content/themes/series/server1.php?server=7&p=24909
    match = re.findall(regx, data, re.M | re.I)
    print 'match', match
    i = 0
    if len(match)==0:
            regx='<IFRAME src="(.+?)".+?></IFRAME>'
            href = re.findall(regx, data, re.M | re.I)[0]
            data = readnet2(href)
            regx='"url":"(.+?)"'
            match = re.findall(regx, data, re.M | re.I)
    for href in match:

        i = i + 1
        debug = True

        server = 'link' + str(i)
        if 'viewstream' in href:
            href=url=urllib.unquote_plus(href)
            playlink(href)
            return
           
        if "mp4" in href or 'm3u' in href:    
           addLink(server, href, 2, '')                      
def gethosts2(urlmain):##cinema and tv featured
                data=readnet(urlmain)
                if data is None:
                    return
               
                i=0
                regx='''<iframe.*?src="(.*?)".*?></iframe>'''
                regx='''<iframe.*?src="(.*?)".*?></iframe></p>'''
                link=re.findall(regx,data, re.M|re.I)[0]
               
                stream_url=resolve(link)
                playlink(stream_url)
	    
def resolve_host(url):#last good-used with local resolver
        if 'jacvideo' in url:
               regx='''"file":"(.*?)"'''
               data=readnet2(url)
               links=re.findall(regx,data, re.M|re.I)
               print "links",links
               
               i=0
               for link in links:
                   i=i+1
                   addDir("quality" +str(i),link,22,"")
               return     
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    listItem = xbmcgui.ListItem(path=str(stream_link))
	    xbmcplugin.setResolvedUrl(sys.argv[0], True, listItem)   
        else:
            addDir("Error,"+stream_link,"",9,"") 	    
def resolve_host2(url):#last good
        regx='''<iframe.*?src="(.*?)".*?></iframe>'''
        data=readnet2(url)
        print "data",data
        
        link=re.findall(regx,data, re.M|re.I)[0]
        print "link",link
        if link.strip()=='':
                data=readnet2(url.replace("series",'movies'))
                print "data",data
                
                link=re.findall(regx,data, re.M|re.I)[0]
                print "link",link                
        
        from urlresolver import resolve
   
        stream_link=str(resolve(link))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
   
	    playlink(stream_link)
        else:
            addDir("Error,"+stream_link,"",9,"")
def playlink(url):
            print "m2",url
            xbmc.Player().play(url)
            sys.exit(0)

            
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param



def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
def getgroups(data, pattern, grupsNum = 1, ignoreCase = False):
        tab = []
        if ignoreCase:
            match = re.search(pattern, data, re.IGNORECASE)
        else:
            match = re.search(pattern, data)
        
        for idx in range(grupsNum):
            try:
                value = match.group(idx + 1)
            except:
                value = ''

            tab.append(value)

        return tab
def getdata(data, marker1, marker2, withMarkers = True, caseSensitive = True):
        if caseSensitive:
            idx1 = data.find(marker1)
        else:
            idx1 = data.lower().find(marker1.lower())
        if -1 == idx1:
            return (False, '')
        if caseSensitive:
            idx2 = data.find(marker2, idx1 + len(marker1))
        else:
            idx2 = data.lower().find(marker2.lower(), idx1 + len(marker1))
        if -1 == idx2:
            return (False, '')
        if withMarkers:
            idx2 = idx2 + len(marker2)
        else:
            idx1 = idx1 + len(marker1)
        return  data[idx1:idx2]

params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
elif mode==1:
        print ""+url
        gethosts(name,url)
elif mode==11:
        resolve_host2(url)
elif mode==3:
        search_series(url)
elif mode==4:
        movies_a_z(url)        

elif mode==2:
        print ""+url
        playlink(url)
elif mode==21:
        print ""+url
        get_servers(url)
        
elif mode==22:
        print ""+url
        playlink(url)          
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)
elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
	print ""+url
        search(url)
        
        
elif mode==5:
	print ""+url	
        genres(url)   	
elif mode==51:
	print ""+url	
        years(url)  	
	
elif mode==104:
	print ""+url
	
	searchmovies(url)
elif mode==105:
        print ""+url
        getmovies2(name,url,page)
elif mode==300:
	print "mfaraj"+url
	
	getseries_search(name,url,page)
	#getvideopage(url,page)
        #getmovies2(name,url,page)        
elif mode==200:
	print "mfaraj"+url
	
	getseries(name,url,page)
	#getvideopage(url,page)
        #getmovies2(name,url,page)
elif mode==222:
	print "mfaraj"+url
	
	newseries(name,url,page)
	#getvideopage(url,page)
        #getmovies2(name,url,page)	
elif mode==2001:
	print "mfaraj"+url
	getepisodes2(name,url,page)
	#getvideopage(url,page)
elif mode==20011:
	print "mfaraj"+url
	getepisodes21(name,url,page)
	#getvideopage(url,page)	
elif mode==20001:
	print "mfaraj"+url
	getepisodes3(name,url,page)
	#getvideopage(url,page)		
elif mode==201:
	getepisodes21(name,url,page)
elif mode==202:
	print ""+url
	getA_Z('shows')
	
elif mode==203:
	print ""+url
        search_series(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
