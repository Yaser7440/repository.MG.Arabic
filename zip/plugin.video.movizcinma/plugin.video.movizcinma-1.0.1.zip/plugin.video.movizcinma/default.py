# -*- coding: utf-8 -*-
try:import os,sys, syspath
except:pass
import httplib
import time
from urllib import urlencode
import urllib, urllib2, re
import StringIO
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse
from addon.common.net import Net
from urlresolver import resolve
import sys
import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,os
import StringIO
import urllib2,urllib
import re
import httplib
import time,itertools


#################settings
__settings__ = xbmcaddon.Addon(id='plugin.video.movizcinma')
_thisPlugin = int(sys.argv[1])
_pluginName = sys.argv[0]
baseurl = 'http://movizcinma.com'

def read_url(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', 'movizcinma.com')
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
	return link

def patch_http_response_read(func):
    def inner(*args):
        try:
            return func(*args)
        except httplib.IncompleteRead, e:
            return e.partial

    return inner
##########################################main menu
def showmenu():
        
        addDir('Search','http://www.movizcinma.com/?s=',104,'img/0.png',1)
        addDir('••احدث الافلام و المسلسلات••','http://movizcinma.com/',10000,'img/2.png',1)
	
	addDir('••أفـــلام أجنبية••','http://movizcinma.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A-%D8%A7%D9%88%D9%86-%D9%84%D8%A7%D9%8A%D9%86',10000,'img/1.png',1)
	addDir('••أفـــلام عربية••','http://movizcinma.com/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%b9%d8%b1%d8%a8%d9%8a-%d8%a7%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86',10000,'img/3.png',1)
	addDir('••بوليود••','http://movizcinma.com/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d9%87%d9%86%d8%af%d9%8a-%d8%a7%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86',10000,'img/5.png',1)
	#addDir('••برامج-تليفزيونية••','http://movizcinma.com/category/%d8%a8%d8%b1%d8%a7%d9%85%d8%ac-%d8%aa%d9%84%d9%8a%d9%81%d8%b2%d9%8a%d9%88%d9%86%d9%8a%d8%a9',10000,'img/6.png ',1)

        #addDir('••أفــلام مصنفة••','url',5,'img/5.png ',1)
       	#addDir('••مسلسلات أون لاين••','url',55,'img/6.png ',1)

        addDir('••مسلسلات  رمضان 2016••','http://movizcinma.com/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%b1%d9%85%d8%b6%d8%a7%d9%86-%d8%a7%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86',10000,'img/4.png',1)
        #addDir('••مسلسلات عربية أون لاين••','http://movizcinma.com/online/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA/',10000,'img/6.png ',1)
        addDir('••أفلام أنمي أون لاين••','http://movizcinma.com/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d9%83%d8%a7%d8%b1%d8%aa%d9%88%d9%86-%d8%a7%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86',10000,'img/6.png',1)
                
####################movies		
               
def getyears_movies(url):
        for i in range(2002,2016):
             addDir(str(i),'http://projectfreetv.so/movies/search/'+str(i)+"/",100,'','',1)                 
                    
def getgenre_movies(url):
        #http://www.vidics.ch/Category-Movies/Genre-comedy/Letter-Any/ByPopularity/1.htm
        genrelist=[(u'/Category-FilmsAndTV/Genre-animation/Letter-Any/ByPopularity/1.htm', u'Animation'), (u'/Category-FilmsAndTV/Genre-documentary/Letter-Any/ByPopularity/1.htm', u'Documentary'), (u'/Category-FilmsAndTV/Genre-western/Letter-Any/ByPopularity/1.htm', u'Western'), (u'/Category-FilmsAndTV/Genre-family/Letter-Any/ByPopularity/1.htm', u'Family'), (u'/Category-FilmsAndTV/Genre-sci-fi/Letter-Any/ByPopularity/1.htm', u'Sci-fi'), (u'/Category-FilmsAndTV/Genre-biography/Letter-Any/ByPopularity/1.htm', u'Biography'), (u'/Category-FilmsAndTV/Genre-action/Letter-Any/ByPopularity/1.htm', u'Action'), (u'/Category-FilmsAndTV/Genre-adventure/Letter-Any/ByPopularity/1.htm', u'Adventure'), (u'/Category-FilmsAndTV/Genre-talk-show/Letter-Any/ByPopularity/1.htm', u'Talk-Show'), (u'/Category-FilmsAndTV/Genre-musical/Letter-Any/ByPopularity/1.htm', u'Musical'), (u'/Category-FilmsAndTV/Genre-reality-tv/Letter-Any/ByPopularity/1.htm', u'Reality-TV'), (u'/Category-FilmsAndTV/Genre-game-show/Letter-Any/ByPopularity/1.htm', u'Game-Show'), (u'/Category-FilmsAndTV/Genre-war/Letter-Any/ByPopularity/1.htm', u'War'), (u'/Category-FilmsAndTV/Genre-adult/Letter-Any/ByPopularity/1.htm', u'Adult')]
        for item in genrelist:
                
                 addDir(item[1],baseurl+item[0].replace('Category-FilmsAndTV','Category-Movies'),100,'http://i45.tinypic.com/2d9u26c.jpg',1)
	

                            
                    


def getA_Z_movies(name,mode):
        AZ_DIRECTORIES = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y', 'Z']
        for character in AZ_DIRECTORIES:
                #http://www.vidics.ch/Category-Movies/Genre-Any/
                addDir(character,"http://www.vidics.ch/"+name+"/Genre-Any/Letter-"+character+"/ByPopularity/1.htm",mode,"")
			
				  




                   
def getmovies(name,urlmain,page):##movies
                if page>1:
                  #/page/2/http://movizcinma.com/english-movies/2/
                  #     
                  url_page=urlmain+str(page)+"/"
                  #url_page=urlmain+"/"+"/"'+/page/'+str(page)
                  #url_page=urlmain+"page/"+str(page)
                  url_page=urlmain+'/page/'+str(page)
                  #url_page=urlmain+'"/""/"/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                data=readnet(url_page)
               #data=data.split('id="movie_list"')[1]

                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="block_loop">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    regx='''<a href="(.*?)" .*?>'''
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''<img data-src="(.*?)" src=".*?"'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                   
                    regx='''<div class="small-play">'''
                    regx='''</div><h1 class="title_loop">(.*?)</h1>'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                   
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,'',1)
                    except:continue
               
                   #addDir("next page",urlmain,100,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))



def getmovies3(name,urlmain,page):##movies
                if page>1:
                  #/page/2/http://movizcinma.com/english-movies/2/
                  #     
                  url_page=urlmain+str(page)+"/"
                  url_page=urlmain+'/page/'+str(page)
                  #url_page=urlmain+"page/"+str(page)
                  #url_page=urlmain+'/page/'+str(page)
                  #url_page=urlmain+'"/""/"/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                data=readnet(url_page)
                                  
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="Block">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    regx='''<a href="(.*?)">'''
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''<img.*?src="(.*?)".*?'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                   
                    #regx='''<div class="small-play">'''
                    regx='''<div class="movief">(.*?)</div>'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                   
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8211;"," ") 
                    try:addDir(name,href,1,img,'',1)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,10000,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))















def search(url):
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered

        getmovies3("Search",url,1)
        
        
        
        
def getmovies2(name,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  # www.vidics.ch/Category-Movies/Genre-Any/Letter-Any/LatestFirst/1.htm
                  url1=os.path.split(urlmain)[0]
                  url_page=url1+"/"+str(page)+".htm"
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                try:data=data.split(" <option value='none'")[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('<option')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<a href="(.*?)" title="(.*?)">'''
                    regx='''value='(.*?)'>(.*?)</option>'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    href=match[0][0]
                    name=match[0][1]
                    name=name.replace('Watch','').replace( 'online free.','').strip()
                    year=''
                    img=''

                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:name=str(name)+"("+year+")"
                    except:name=str(name)
                    
                    
                    try:addDir(name,href,1,img,'',1)
                    except:pass
               
                   
                
                addDir("next page",urlmain,100,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
                    
###############################################tv shows
def getyears_series(url):
        for i in range(2002,2016):
             addDir(str(i),'http://projectfreetv.so/movies/search/'+str(i)+"/",100,'','',1)                 
                    
def getgenre_series(url):
       
        genrelist=[(u'/Category-FilmsAndTV/Genre-animation/Letter-Any/ByPopularity/1.htm', u'Animation'), (u'/Category-FilmsAndTV/Genre-documentary/Letter-Any/ByPopularity/1.htm', u'Documentary'), (u'/Category-FilmsAndTV/Genre-western/Letter-Any/ByPopularity/1.htm', u'Western'), (u'/Category-FilmsAndTV/Genre-family/Letter-Any/ByPopularity/1.htm', u'Family'), (u'/Category-FilmsAndTV/Genre-sci-fi/Letter-Any/ByPopularity/1.htm', u'Sci-fi'), (u'/Category-FilmsAndTV/Genre-biography/Letter-Any/ByPopularity/1.htm', u'Biography'), (u'/Category-FilmsAndTV/Genre-action/Letter-Any/ByPopularity/1.htm', u'Action'), (u'/Category-FilmsAndTV/Genre-adventure/Letter-Any/ByPopularity/1.htm', u'Adventure'), (u'/Category-FilmsAndTV/Genre-talk-show/Letter-Any/ByPopularity/1.htm', u'Talk-Show'), (u'/Category-FilmsAndTV/Genre-musical/Letter-Any/ByPopularity/1.htm', u'Musical'), (u'/Category-FilmsAndTV/Genre-reality-tv/Letter-Any/ByPopularity/1.htm', u'Reality-TV'), (u'/Category-FilmsAndTV/Genre-game-show/Letter-Any/ByPopularity/1.htm', u'Game-Show'), (u'/Category-FilmsAndTV/Genre-war/Letter-Any/ByPopularity/1.htm', u'War'), (u'/Category-FilmsAndTV/Genre-adult/Letter-Any/ByPopularity/1.htm', u'Adult')]
        for item in genrelist:
                
      	  addDir(item[1],baseurl+item[0].replace('Category-FilmsAndTV','Category-Movies'),100,'http://i45.tinypic.com/2d9u26c.jpg',1)
	

                            
                    


def getA_Z_series(name,mode):
        AZ_DIRECTORIES = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y', 'Z']
        for character in AZ_DIRECTORIES:
                
                addDir(character,"http://www.vidics.ch/"+name+"/Genre-Any/Letter-"+character+"/ByPopularity/1.htm",mode,"")
			
				                      
def search_series(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered

        getseries_search("Search",url,0)
                    

               
                                    
def getseries(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                 
                 url_page=urlmain+"/page/"+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                try:data=data.split('</center>')[4]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="title-post">')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<img src="(.*?)">'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match
                    
                    
                    img=match[0][0]
                    #regxname='''class="attachment-col wp-post-image" alt="(.*?)"'''
                    name=re.findall(regxname,block, re.M|re.I)[0]
                    
                    name=name.replace('Watch','').replace( 'online free.','').strip()
                    regxhref='''<a href="(.*?)" title="(.*?)">'''
                    href=re.findall(regxhref,block, re.M|re.I)[0]
                    
                   
                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    
                    name=removeunicode(name)
                    try:addDir(name,href,2001,img,'',1)
                    except:pass
               
                   
                
                addDir("next page",urlmain,2001,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))

                    
def getseries_search(name,urlmain,page):##movies
                print "page",page
               
                if page>1:
                 
                  url1=os.path.split(urlmain)[0]
                  url_page=url1+"/"+str(page)+".htm"
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                try:data=data.split(" <option value='none'")[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('<option')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<a href="(.*?)" title="(.*?)">'''
                    regx='''value='(.*?)'>(.*?)</option>'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    href=match[0][0]
                    name=match[0][1]
                    name=name.replace('Watch','').replace( 'online free.','').strip()
                    year=''
                    img=''

                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:name=str(name)+"("+year+")"
                    except:name=str(name)
                    
                    
                    try:addDir(name,href,2001,img,'',1)
                    except:pass
               
                   
                
                
                                                            

def getseasons(name,urlmain,page):##series
                print "page",page
            
                if page>1:
                  
                 url_page=urlmain+"/page/"+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                print "data",data
                
                if not "<option value='none' selected>=" in data:
                        gethosts(urlmain)
                        return                   
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="moviefilm">')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<img.*?src="(.*?)"'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match
                    
                    
                    img=match[0][0]
                    regx='''<div class="movief"><a href="(.*?)">(.*?)</a></div>'''
                    match=re.findall(regx,block, re.M|re.I)
                    name=match[0][1]
                    href=match[0][0]
                    
                   
                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    
                    #name=removeunicode(name)
                    try:addDir(name,href,201,img,'',1)
                    except:pass
               
                   
                
               
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))   
                    

               
                   
                
               
                

def getepisodes(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                 
                 url_page=urlmain+"/page/"+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="moviefilm">')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    regx='''<img.*?src="(.*?)"'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match
                    
                    
                    img=match[0][0]
                    regx='''<div class="movief"><a href="(.*?)">(.*?)</a></div>'''
                    match=re.findall(regx,block, re.M|re.I)
                    name=match[0][1]
                    href=match[0][0]
                    
                   
                    
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    
                    name=removeunicode(name)
                    try:addDir(name,href,1,img,'',1)
                    except:pass
               
                   
                
               #addDir("next page",urlmain,2001,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))   
                    
                    

               
                   
                
               
               

 


#######################################host resolving                                                    
               

def gethosts(urlmain):##cinema and tv featured
                
        data=readnet(urlmain)
        #data=read_url(urlmain)
        #data=read_url(url)
        #http://www.movizcinma.com/wp-content/themes/series4watch/server1.php?server=1&p=24927
        
        regx="rel='shortlink' href='(.+?)'"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[1]
        print "id",id
        for i in range(1,7):
          url='http://movizcinma.com/wp-content/themes/yourcolor/servers/server.php?q='+id+'&i='+str(i)
          print url
          addDir('server'+str(i),url,2, 'img/server.png')
                            
                
                             
def gethosts2(urlmain):

                
                data=readnet(urlmain)
	        print data
                	
                #regx='''</span><a href='(.+?)' class='redirect_link'>'''
                #regx1='''<iframe src="(.+?)" scrolling="no" frameborder="0" width="700" height="430" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'''
                regx2='''<IFRAME SRC="(.+?)".+?></IFRAME>'''
                
                regx3='''<iframe .+? src="(.+?)" .+?></iframe>'''
                regx4='''<iframe .+? src="(.+?)" ></iframe>'''
                match2 = re.findall(regx2,data, re.M|re.I)
                match3 = re.findall(regx3,data, re.M|re.I)
                match4 = re.findall(regx4,data, re.M|re.I)
                #match5 = re.findall(regx5,data, re.M|re.I)
         
                #getmatch(match1)
                getmatch(match2)
                getmatch(match3)
                getmatch(match4)
                #getmatch(match5)
               
                return


	    
	    
def resolve_host(url):
        
        from urlresolver import resolve
        data=readnet(url)
        reurl='''<iframe.*?src="(.*?)".*?></iframe>'''
        url=re.findall(reurl,data, re.M|re.I)[0].split("=")[0]
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    listItem = xbmcgui.ListItem(path=str(stream_link))
	    xbmcplugin.setResolvedUrl(sys.argv[0], True, listItem)   
        else:
            addDir("Error,"+stream_link,"",9,"") 	    
def resolve_host2(url):#last good
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(stream_link)  
        else:
            addDir("Error,"+stream_link,"",9,"")
def playlink(stream_link):
            
            xbmc.Player().play(stream_link)
            sys.exit(0)

###functions

def readnet(url):
        import requests
        data=requests.get(url, verify=False)
        return data.content
def readnet2(url):
            
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html	    
def removeunicode(data):
             
             
            
              try:
                    type(data)
                    data=data.decode('unicode_escape').encode('ascii','replace').replace("?","").strip()
        
              except:
                    pass
              
              return data
              
def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        
        return query.hostname             
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param



def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=1):

        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
def getgroups(data, pattern, grupsNum = 1, ignoreCase = False):
        tab = []
        if ignoreCase:
            match = re.search(pattern, data, re.IGNORECASE)
        else:
            match = re.search(pattern, data)
        
        for idx in range(grupsNum):
            try:
                value = match.group(idx + 1)
            except:
                value = ''

            tab.append(value)

        return tab
def getdata(data, marker1, marker2, withMarkers = True, caseSensitive = True):
        if caseSensitive:
            idx1 = data.find(marker1)
        else:
            idx1 = data.lower().find(marker1.lower())
        if -1 == idx1:
            return (False, '')
        if caseSensitive:
            idx2 = data.find(marker2, idx1 + len(marker1))
        else:
            idx2 = data.lower().find(marker2.lower(), idx1 + len(marker1))
        if -1 == idx2:
            return (False, '')
        if withMarkers:
            idx2 = idx2 + len(marker2)
        else:
            idx1 = idx1 + len(marker1)
        return  data[idx1:idx2]

params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
##menu
if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
##parsing tools        
elif mode==1:
        print ""+url
        gethosts(url)
elif mode==2:
        print ""+url
        resolve_host(url)     
elif mode==3:
        print ""+url
        playlink(url)  
elif mode==10:
        print ""+url
        gethosts2(url)
        
elif mode==20:
        print ""+url
        resolve_host2(url)          
####movies        
elif mode==100:
        print ""+url
        getmovies(name,url,page)
elif mode==1000:
        print ""+url
        getmovies2(name,url,page)        
elif mode==10000:
        print ""+url     
        getmovies3(name,url,page) 
elif mode==101:
        print ""+url
        getgenre_movies('movies')	

elif mode==102:
	
	getA_Z_movies(name,100)

elif mode==103:
	print ""+url
	
	getyears_movies(name)	
elif mode==104:
	print ""+url
        search(url)

elif mode==105:
	print ""+url
	
	getmovies_search(url)

###series        
elif mode==200:
	
	getseries(name,url,page)
elif mode==222:	
	getseries3(name,url,page)
	
elif mode==2000:
	
	getseries2(name,url,page)
	
	
elif mode==201:
	
	getseasons(name,url,page)
	
elif mode==202:
	getepisodes(name,url,page)
elif mode==203:
	
	getA_Z_series(name,100)

elif mode==204:
	print ""+url
	
	getyears_series(name)	
elif mode==205:
	print ""+url
        search_series(url)
elif mode==500:
	print ""+url        
        years(url)

elif mode==206:
	print ""+url
	
	getseries_search(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
	
