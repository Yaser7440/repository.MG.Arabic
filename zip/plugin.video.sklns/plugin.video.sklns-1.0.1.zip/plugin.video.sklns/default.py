# -*- coding: utf8 -*-

try:import sys, syspath
except:pass
import sys
import urllib,urllib2,re,os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re



############################################

####functions

    
def readnet(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      

              
def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        
        return query.hostname 
##########################################parsing tools
def showmenu():

                menuitems=[]
                
                menuitems.append(("Last Add", 'http://sklns.com/last-videos/',100,'img/3.png','',1))
                
                menuitems.append(("Movies", 'http://sklns.com/english-movies/',100,'img/1.png','',1))
                menuitems.append(("Movies genres", 'http://sklns.com/english-movies/',101,'img/2.png','',1))
               
                
                
                
               
                
		
                for title, url, mode,pic,desc,page in menuitems:
                    addDir(title, url, mode, pic,desc,1)

def years(url):
        for i in range(1900,2017):
             #http://sklns.com/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A-2014/
             addDir(str(i),'http://sklns.com/tag/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A-'+str(i)+"/",100,'','',1)                 
                    
def genres(urlmain):

                genres=[('action', 'http://sklns.com/action/'), ('comedy', 'http://sklns.com/comedy/'), ('horror', 'http://sklns.com/horror/'), ('sci-fi', 'http://sklns.com/tag/sci-fi/'), ('adventure', 'http://sklns.com/tag/adventure/'), ('crime', 'http://sklns.com/tag/crime/'), ('mystery', 'http://sklns.com/tag/mystery/'), ('animation', 'http://sklns.com/tag/animation/'), ('thriller', 'http://sklns.com/tag/thriller/'), ('romance', 'http://sklns.com/tag/romance/'), ('drama', 'http://sklns.com/tag/drama/'), ('war', 'http://sklns.com/tag/war/'), ('history', 'http://sklns.com/tag/history/'), ('documentary', 'http://sklns.com/tag/documentary/'), ('biography', 'http://sklns.com/tag/biography/')]
                for item in genres:
                   addDir(item[0],item[1],100,'img/3.png','',1)
        
        
                            
                    


def A_Z(name='movies'):
		abc = ['#','0','1','2','3','4','5','6','7','8','9',"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'http://projectfreetv.so/watch-tv-series/#mctm-'+letter,100,'',1)
			
###################################movies
			  
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url.replace("query",search_entered)
        
          
        getmovies("Search",url,0)


                        
               
                   
                
        
def getmovies(namemain,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  # http://sklns.com/english-movies/page/2/
                  
                     url_page=urlmain+'/page'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('class="first-word"')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="item-img">')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a title="(.*?)" href="(.*?)">'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    name=match[0][0]
                    href=match[0][1]
                    regx='''src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                   
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    addDir(name,href,1,img,'',1)
                    
               
                   
                
                
                addDir("next page",urlmain,100,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))

def getmovies2(namemain,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  # http://sklns.com/english-movies/page/2/
                  
                     url_page=urlmain+'/page'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                if data is None:
                    return
               
                blocks=data.split('<div class="item-img">')
                i=0
                '''data-remote="/popup/movie_info/88784" alt="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" class="zoom" data-title="LEGO DC Comics Super Heroes: Justice League: Cosmic Clash" data-type="page"> <img src="http://www.posters.vumoo.net/300/88784.jpg" alt="" class="mov_poster" width="300" height="378"/> <span class="overlay"> <i class="fa fa-heart dvd-cover-heart" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Bookmark this"></i> <i class="fa fa-play dvd-play-icon"></i> <div class="rating-overlay dvd-cover-rating"> <div class="half-stars half-stars-video"> <i class="fa fa-star-half half-star-1"></i><i class="fa fa-star-half half-star-2 "></i><i class="fa fa-star-half half-star-3"></i><i class="fa fa-star-half half-star-4"></i><i class="fa fa-star-half half-star-5"></i> </div> <div class="full-stars full-stars-video"> <i class="fa fa-star full-star-1"></i><i class="fa fa-star full-star-2"></i><i class="fa fa-star full-star-3"></i><i class="fa fa-star full-star-4"></i><i class="fa fa-star full-star-5"></i> </div></span> <span class="cover-rating"><span class="dvd-cover-score"></span>NA</span> </div> </span> </a> </div> </div> <div class="dvd-info-container"> <h5 class="dvd-title">LEGO DC Comics Super Heroes: Justice League: Cosmic Clash</h5> <span class="dvd-year">2016</span> </div> <a href="http://www.vumoo.ch/show_browse?title=LEGO DC Comics Super Heroes: Justice League: Cosmic Clash"><div class="affiliate-cover-btn">Watch now</div></a> </article>'''
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a .*? href="(.*?)">'''
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    regx='''<img.*?src="(.*?)".*?''' 
                    #regx='''<img data-src="(.*?)".*?'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                   
                    #regx='''<div class="small-play">'''
                    regx='''<div class="post-header">
										<h3><a title="(.*?)" href=".*?">'''
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                                        
                   
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    addDir(name,href,1,img,'',1)
                    
                
                addDir("next page",urlmain,1000,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))


                    
###############################################tv shows
def search_series(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered

        getseries("Search",url,0)
def getseries(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  # http://sklns.com/english-movies/page/2/
                  
                     url_page=urlmain+'/page'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('class="first-word"')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="wpb_single_image wpb_content_element vc_align')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''href="(.*?)"'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    regx='''title="(.*?)"'''
                    
                    name=re.findall(regx,block, re.M|re.I)[0]                    
                   
                    
                    regx='''src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                   
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    addDir(name,href,201,img,'',1)
                    
               
                   
                
                
               
                                        
                    
def getseasons(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  # http://sklns.com/english-movies/page/2/
                  
                     url_page=urlmain+'/page'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('class="first-word"')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('wpb_single_image wpb_content_element vc_align')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''href="(.*?)"'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    if "imdb" in href:
                        continue
                    regx='''title="(.*?)"'''
                    
                    name=re.findall(regx,block, re.M|re.I)[0]                    
                   
                    
                    regx='''src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                   
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    addDir(name,href,1,img,'',1)
                        

                                           
                                    


def getepisodes(name,urlmain,page):##series
                if page>0:
                
                  url_page=urlmain+'&page='+str(page)
                  
                else:
                
                      url_page=urlmain
                
                data=readnet(urlmain)
                
               
                
              
                if data is None:
                    return
                '''<div id="season1-1-watch-ep" class="watch-ep-btn" data-click=" https://openload.co/embed/mb6cBGnT_ko" data-poster="http://image.tmdb.org/t/p/w1280/tVCmhoIAHMCIzNmzSBvSDja4wOY.jpg" onclick="setUpTvPlayer(this)"><i class="fa fa-play-circle"></i>Watch Episode</div> </div> </li> <li id=season1-2> <h2>Allen</h2> <span class="season-info">Season 1, Episode 2</span><br> <span class="season-info air-date">Air date: Aug-29-2005</span> <p class="synopsis-description"> Trouble is inevitable in the prison, with a race riot imminent. Michael has problems retrieving a screw from the bleachers. Veronica receives a security tape that shows Lincoln shooting Terrence Steadman. </p>'''
                blocks=data.split('<h3 class="threadtitle">')
               
                i=0
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    print "block",block
                    #block=block.lower()
                    regxhref='''<a class="title" href="(.*?)" id=".*?">(.*?)</a>'''
                    match=re.findall(regxhref,block, re.M|re.I)
                    href='http://dayt.se/forum/'+match[0][0]
                    name=match[0][1]
                               
                    regximg='''<img onerror='this.style.display = "none"' src="(.*?)" /></a>
'''
                    try:img=re.findall(regximg,block, re.M|re.I)[0]
                    except:img=''

                                             
                               
                    
                    name=name.encode("utf-8")
                    addDir(name,href,1,img,'',1)                        
               
                   
                
                                        
                   
                #if len(match)>0:
                  #addDir("next page",urlmain,200,'','',str(page+1))
                if len(match)==0:
                    addDir("Error:no results",urlmain,200,'','',str(page+1))
            

 


#######################################host resolving                                                    



def gethosts(name,urlmain):##cinema and tv featured

                
                data=readnet(urlmain)
                #regx='''<meta property="og:url" content="(.*?)" />'''
                #link1=re.findall(regx,data, re.M|re.I)[0]
                #print "link1",link1
                #sys.exit(0)
                regx='''<a href="(.*?)" data-vc-accordion data-vc-container=".vc_tta-container">'''
                regx='''href="(.*?)">لمشاهدة الفيلم اون لاين اضغط هنا</a>'''
                regx='''href="http://sklns.com/video/(.*?)/"'''
                link2=re.findall(regx,data, re.M|re.I)[0]
                link='http://sklns.com/video/'+link2+"/"
                print "link",link
                data=readnet(link)
                regx='''<link rel='shortlink' href='(.*?)' />'''
                regx="rel='shortlink' href='(.+?)'"
                id = re.findall(regx,data, re.M|re.I)[0].split("=")[1]
                print "id",id
                for i in range(1,10):
                   #url='http://sklns.com/wp-content/themes/videotube/server.php?p='+id+'&i='+str(i)

                #id=re.findall(regx,data, re.M|re.I)[0].split("=")[1]
                #print "id",id
                #i=0
                #for i in range(1,9):
                   href='http://sklns.com/wp-content/themes/videotube/server.php?p='+ id +'&i='+str(i)
                   server='server '+ str(i)
                
                    
                            
                   
                   addDir(server,href,2,'img/server.png','',1)
                                          

	    
def resolve_host(url):#last good-used with local resolver
        request2= urllib2.Request(url)

        request2.add_header("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:46.0) Gecko/20100101 Firefox/46.0")
        request2.add_header("Referer", "http://sklns.com/")

        request2.add_header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")

        request2.add_header("Accept-Language", "de,en-US;q=0.7,en;q=0.3")
        response2 = urllib2.urlopen(request2)
        data=response2.read()
        data=data.lower()
        regx='''<iframe.*?src="(.*?)".*?></iframe>'''
        url=re.findall(regx,data, re.M|re.I)[0]


        print "url",url
       
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
      
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    
        else:
            addDir("Error,"+stream_link,"",9,"") 	    

def playlink(url):
           
            xbmc.Player().play(url)
            sys.exit(0)            
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param



def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
elif mode==1:
        print ""+url
        gethosts(name,url)
elif mode==2:
        print ""+url
        resolve_host(url)        
elif mode==3:
        print ""+url
        playlink(url)
     
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)
        
elif mode==1000:
        print ""+url        
        getmovies2(name,url,page)
elif mode==101:
        print ""+url
        genres('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
	print ""+url
        search(url)    
elif mode==104:
	print ""+url
        years(url)           


elif mode==200:

	getseries(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)
	#getvideopage(url,page)	
elif mode==202:
	getepisodes(name,url,page)


xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
