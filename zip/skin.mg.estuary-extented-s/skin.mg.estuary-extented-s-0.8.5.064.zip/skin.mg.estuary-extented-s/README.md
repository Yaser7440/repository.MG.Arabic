# Estuary Extented Shortcuts - is adapted to skin Estuary for KODI 16 (jarvis).
