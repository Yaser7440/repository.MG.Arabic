# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys
import urllib,urllib2,re,os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re
from addon.common.addon import Addon
#By. MG.Arabic http://mg.esy.es/Kodi/ (04/2017)

def resolveurl(url):

            
            print "url",url
            #sys.exit(0)            
            import requests,re,time
            html=requests.get(url).text
            #<input type="hidden" name="watch" value="1">                  
            #id = re.findall('<a href="(.*?)">',html, re.M|re.I)[0]
            #fname = re.findall('<span class="timo">.*?</span>\s*<a href=".*?">(.*?)</a>',html, re.M|re.I)[0]
            #hash = re.findall('<span class="timo">.*?</span>\s*<a href=".*?">(.*?)</a>',html, re.M|re.I)[0]
            #action = re.findall('<div class="contented_local">(.*?)</div>',html, re.M|re.I)[0]
            #print "id,fname,hash,'action'",id,fname,hash,'action'
            time.sleep(10)
            #sys.exit(0)
            data= {
                'watch': "1",                               
                'referer': 'http://mp.arbcinema.com/',
                'method': 'POST'}   
                
            data=requests.post(url, data=data).text.encode("utf-8")
            return data
            


####functions

    
def readnet(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      
addon_id='plugin.video.arbcinema'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, art+'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, art+'fanart.jpg'))
show_tv = selfAddon.getSetting('enable_shows')
show_mov = addon.get_setting('enable_movies')              
baseurl = selfAddon.getSetting('base_url')
##########################################parsing tools
def showmenu():
    if show_mov == 'true':addDir('[B][COLOR white]••قوائم الافلام••[/COLOR][/B]','url',2,art+'movies.png',fanart,'')
    if show_tv == 'true':addDir('[B][COLOR white]••قوائم المسلسلات••[/COLOR][/B]','url',3,art+'tvshows.png',fanart,'')
    if show_tv == 'true':addDir('[B][COLOR white]••أغاني••[/COLOR][/B]','url',4,art+'musical.jpg',fanart,'')    
    addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')

                
def MV():	
	addDir('[B][COLOR white]••البحث[/COLOR][/B]','url',103,art+'search.png',fanart,'')
	addDir('[B][COLOR white]••السنة••[/COLOR][/B]','url',10,art+'years.png',fanart,'')	
	addDir('[B][COLOR white]••افلام اجنبيه••[/COLOR][/B]',baseurl+'/category/افلام-اجنبية-مترجمة',100,art+'latest-movies.png',fanart,'')
	addDir('[B][COLOR white]••افلام عربية••[/COLOR][/B]',baseurl+'/category/افلام-عربي',100,art+'latest-movies.png',fanart,'')	
	addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')                    

def TV():	
	#addDir('[B][COLOR white]••البحث••[/COLOR][/B]','url',103,art+'search.png',fanart,'')
	addDir('[B][COLOR white]••مسلسلات أجنبية••[/COLOR][/B]',baseurl+'/category/مسلسلات/مسلسلات-أجنبية-مترجمة',200,art+'new-tvshows.png',fanart,'')
	addDir('[B][COLOR white]••مسلسلات عربي••[/COLOR][/B]',baseurl+'/category/مسلسلات/مسلسلات-عربي',200,art+'new-tvshows.png',fanart,'')	
	addDir('[B][COLOR white]••مسلسلات رمضان 2016••[/COLOR][/B]',baseurl+'/category/مسلسلات/مسلسلات-رمضان-2016',200,art+'new-tvshows.png',fanart,'')	
	addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')

def MU():	
	#addDir('[B][COLOR white]••البحث••[/COLOR][/B]','url',103,art+'search.png',fanart,'')
	addDir('[B][COLOR white]••أغاني عربية••[/COLOR][/B]',baseurl+'/cat_song/أغاني-عربية',300,art+'musical.jpg',fanart,'')
	addDir('[B][COLOR white]••أغاني مصرية••[/COLOR][/B]',baseurl+'/cat_song/أغاني-مصريه',300,art+'musical.jpg',fanart,'')	
	addDir('[B][COLOR white]••أغاني شعبية••[/COLOR][/B]',baseurl+'/cat_song/أغاني-شعبيه',300,art+'musical.jpg',fanart,'')
	addDir('[B][COLOR white]••اغاني خليجية••[/COLOR][/B]',baseurl+'/cat_song/اغاني-خليجية',300,art+'musical.jpg',fanart,'')
	addDir('[B][COLOR white]••أغاني عراقية••[/COLOR][/B]',baseurl+'/cat_song/أغاني-عراقيه',300,art+'musical.jpg',fanart,'')	
	addDir('[B][COLOR white]••أغاني لبنانية••[/COLOR][/B]',baseurl+'/cat_song/أغاني-لبنانيه',300,art+'musical.jpg',fanart,'')	
	addDir('[B][COLOR white]••اغاني مغربية••[/COLOR][/B]',baseurl+'/cat_song/اغاني-مغربيه',300,art+'musical.jpg',fanart,'')
	addDir('[B][COLOR white]••مهرجانات شعبية••[/COLOR][/B]',baseurl+'/cat_song/مهرجانات-شعبيه',300,art+'musical.jpg',fanart,'')	
	addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')		
###################################movies
			  
def search(query,type):
	if query:
		search = query.replace(' ','+')
	else:
		keyb = xbmc.Keyboard('', 'Type in Query')
		keyb.doModal()
		if (keyb.isConfirmed()):
			search = keyb.getText().replace(' ','+')
			if search == '':
				xbmc.executebuiltin("XBMC.Notification([COLOR gold][B]Search MOVIES[/B][/COLOR],Aborting search,7000,"+icon+")")
				return
			else: pass
	url = baseurl + '/?s='+search
	print url
	link = resolveurl(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	all_videos = regex_get_all(link, '<div class="Block">', '</div>\s*</a>\s*</div>')
	for a in all_videos:
		name = regex_from_to(a, 'alt="', '"').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('&quot;','"').replace('&#39;',"'").replace('&#039;',"'")
		url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'data-lazy-src="', '"')#.replace("(","").replace("'","")
		qual = regex_from_to(a, '<div class="contented_local">\s*', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','').replace('                ','')		
		
		addDir('[B][COLOR white]%s[/COLOR][/B][B][I][COLOR red](%s)[/COLOR][/I][/B]' %(name,qual),url,1,icon,fanart,'')
	try:
		nextp=re.compile('<li><a href="(.*?)" >').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,100,art+'/next.png',fanart,'')
	except: pass
	setView('movies', 'show-view')


                        
def YEARMVEN(url):
       for i in range(2005,2018):	   
             addDir('[B][COLOR white]%s[/COLOR][/B]'%str(i), baseurl + '/category/افلام-اجنبية-مترجمة/?s='+str(i),100,art+'years.png','',1)               
              
        
def getmovies(url):##movies
	link = resolveurl(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="Block">', '</div>\s*</a>\s*</div>')
	for a in all_videos:
		name = regex_from_to(a, 'alt="', '"').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('&quot;','"').replace('&#39;',"'").replace('&#039;',"'")
		url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'data-lazy-src="', '"')#.replace("(","").replace("'","")
		qual = regex_from_to(a, '<div class="contented_local">\s*', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','').replace('                ','')		
		
		addDir('[B][COLOR white]%s[/COLOR][/B][B][I][COLOR red](%s)[/COLOR][/I][/B]' %(name,qual),url,1,icon,fanart,'')
	try:
		nextp=re.compile('<li><a href="(.*?)" >').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,100,art+'/next.png',fanart,'')
	except: pass
	setView('movies', 'show-view')

                    
###############################################tv shows

def getseries(url):##series
	link = resolveurl(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="Block">', '</div>\s*</a>\s*</div>')
	for a in all_videos:
		name = regex_from_to(a, 'alt="', '"').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('&quot;','"').replace('&#39;',"'").replace('&#039;',"'")
		url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'data-lazy-src="', '"')#.replace("(","").replace("'","")
		qual = regex_from_to(a, '<div class="contented_local">\s*', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','').replace('                ','')		
		
		addDir('[B][COLOR white]%s[/COLOR][/B][B][I][COLOR red](%s)[/COLOR][/I][/B]' %(name,qual),url,202,icon,fanart,'')
	try:
		nextp=re.compile('<li><a href="(.*?)" >').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,200,art+'/next.png',fanart,'')
	except: pass
	setView('movies', 'show-view')
                                        
                    
def getseasons(name,urlmain,page):##series
                if page>1:
                  #/page/2/
                  url_page=urlmain+"page/"++str(page)
                  
                else:
                
                      url_page=urlmain
                 
                data=readnet(url_page)
                try:data=data.split('<div class="title6">')[1]
                except:pass
                print "url_page",url_page
              
                if data is None:
                    return

                seasons=re.findall('''<a href="(.*?)" >(.*?)</a>''',data, re.M|re.I)
                print 'seasons',seasons
                
                for href,name in seasons:
                    
                    
                    addDir(name,href,202,'','',1)
                        

                                           
                                    


def getepisodes(url):##series
 	link = resolveurl(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="Blol">', '</a>')
	for a in all_videos:
		name = regex_from_to(a, '<div class="movief_title">', '</div>').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('&quot;','"').replace('&#39;',"'").replace('&#039;',"'")
		url = regex_from_to(a, 'href="', '"').replace("&amp;","&")			
		addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,1,fanart,'')
	try:
		nextp=re.compile('<li><a href="(.*?)" >').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,202,art+'/next.png',fanart,'')
	except: pass
	setView('movies', 'show-view')
               
            

 
def getsongs(url):##movies
	link = resolveurl(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="Block">', '</div>\s*</a>\s*</div>')
	for a in all_videos:
		name = regex_from_to(a, 'alt="', '"').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('&quot;','"').replace('&#39;',"'").replace('&#039;',"'")
		url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'data-lazy-src="', '"')#.replace("(","").replace("'","")
		qual = regex_from_to(a, '<div class="contented_local">\s*', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','').replace('..            ','')		
		
		addDir('[B][COLOR white]%s[/COLOR][/B][B][I][COLOR red](%s)[/COLOR][/I][/B]' %(name,qual),url,7,icon,fanart,'')
	try:
		nextp=re.compile('<li><a href="(.*?)" >').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,300,art+'/next.png',fanart,'')
	except: pass
	setView('movies', 'show-view')

#######################################host resolving                                                    




def gethosts(url):##cinema and tv featured
        from urlresolver import resolve
        data=resolveurl(url)
        #addon.log('#######################link = '+str(data))
        reurl='''<iframe.*?src="(.*?)".*?></iframe>'''
        url="http:"+re.findall(reurl,data, re.M|re.I)[0]
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    listItem = xbmcgui.ListItem(path=str(stream_link))
	    xbmcplugin.setResolvedUrl(sys.argv[0], True, listItem)   
        else:
            addDir("Error,"+stream_link,"",9,"")
                    
def playsong(urlmain):##cinema and tv featured

                data=readnet(urlmain)
                #data=readnet(urlmain)
               
               
                if data:
                   
                    regx1='''<iframe.*?src="(.*?)".*?></iframe>'''
                    regx='''<a href="(.*?)" target="_blank" class="down_toen">.*?</a>'''
                    
                    href=re.findall(regx,data, re.M|re.I)[0].split("?")[0]
                    print "href",href
                   
                    playlink(href)                   
                     	    

def playlink(url):
           
            xbmc.Player().play(url)
            sys.exit(0)            
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param

def regex_from_to(text, from_string, to_string, excluding=True):
	if excluding:
		try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
		except: r = ''
	else:
		try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
		except: r = ''
	return r


def regex_get_all(text, start_with, end_with):
	r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
	return r

def setView(content, viewType):
    ''' Why recode whats allready written and works well,
    Thanks go to Eldrado for it '''
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':

        print addon.get_setting(viewType)
        if addon.get_setting(viewType) == 'Info':
            VT = '504'
        elif addon.get_setting(viewType) == 'Info2':
            VT = '503'
        elif addon.get_setting(viewType) == 'Info3':
            VT = '515'
        elif addon.get_setting(viewType) == 'Fanart':
            VT = '508'
        elif addon.get_setting(viewType) == 'Poster Wrap':
            VT = '501'
        elif addon.get_setting(viewType) == 'Big List':
            VT = '51'
        elif addon.get_setting(viewType) == 'Low List':
            VT = '724'
        elif addon.get_setting(viewType) == 'Default View':
            VT = addon.get_setting('default-view')

        print viewType
        print VT
        
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )
	
def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

params=get_params()
url=None
name=None
mode=None
query=None
type=None
page=1

	
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try:page=int(params["page"])
except: pass
try: query=urllib.unquote_plus(params["query"])
except: pass
try: type=urllib.unquote_plus(params["type"])
except: pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1: showmenu()

#MOVIES
elif mode==2: MV()
elif mode==100: getmovies(url)


elif mode==10: YEARMVEN(url)

#TVSHOWS
elif mode==3: TV()
elif mode==200: getseries(url)
elif mode==202: getepisodes(url)
#PALY MOVIES AND TVSHOWS
elif mode==1: gethosts(url)
elif mode==103: search(query,type) 
#MUSIC
elif mode==4: MU()
elif mode==300: getsongs(url)        
elif mode==7: playsong(url)     
        
#--------N/A------------
elif mode==101: getgenre('movies')	
elif mode==201: getseasons(name,url,page)	


xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
