# -*- coding: utf8 -*-

import sys
import urllib,urllib2,re,os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re


def resolveurl(url):

            
            print "url",url
            #sys.exit(0)            
            import requests,re,time
            html=requests.get(url).text
            #<input type="hidden" name="watch" value="1">                  
            #id = re.findall('<input type="hidden" name="id" value="(.*?)">',html, re.M|re.I)[0]
            #fname = re.findall('<input type="hidden" name="fname" value="(.*?)">',html, re.M|re.I)[0]
            #hash = re.findall('<input type="hidden" name="hash" value="(.*?)">',html, re.M|re.I)[0]
            #action = re.findall('''<Form method="POST" action='(.*?)'>''',html, re.M|re.I)[0]
            #print "id,fname,hash,action",id,fname,hash,action
            time.sleep(10)
            #sys.exit(0)
            data= {
                'watch': "1",                               
                'referer': 'http://mp.arbcinema.com/',
                'method': 'POST'}   
                
            data=requests.post(url, data=data).text.encode("utf-8")
            return data
            


####functions

    
def readnet(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      

              

##########################################parsing tools
def showmenu():

                menuitems=[]
                
                menuitems.append(("Search all", 'http://mp.arbcinema.com/?s=',103,'special://home/addons/plugin.video.arbcinema/img/search.png','',1))
                menuitems.append(("افلام اجنبيه", 'http://mp.arbcinema.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9-%D9%85%D8%AA%D8%B1%D8%AC%D9%85%D8%A9',100,'special://home/addons/plugin.video.arbcinema/img/movie.jpg','',1))
                menuitems.append(("مسلسلات اجنبيه", 'http://mp.arbcinema.com/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%A3%D8%AC%D9%86%D8%A8%D9%8A%D8%A9-%D9%85%D8%AA%D8%B1%D8%AC%D9%85%D8%A9',200,'special://home/addons/plugin.video.arbcinema/img/tv.jpg','',1))
                menuitems.append(("مسلسلات رمضان 2016", 'http://mp.arbcinema.com/category/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%B1%D9%85%D8%B6%D8%A7%D9%86-2016',200,'special://home/addons/plugin.video.arbcinema/img/ramadan.jpg','',1))
                menuitems.append(("افلام عربيه", 'http://mp.arbcinema.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%B9%D8%B1%D8%A8%D9%8A',100,'special://home/addons/plugin.video.arbcinema/img/arabic1.jpg','',1))
                menuitems.append(("اغاني عربيه", 'http://mp.arbcinema.com/cat_song/%D8%A3%D8%BA%D8%A7%D9%86%D9%8A-%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9',300,'special://home/addons/plugin.video.arbcinema/img/music.jpg','',1))
				
					
               
                
                
                
                
                
               
                
		
                for title, url, mode,pic,desc,page in menuitems:
                    addDir(title, url, mode, pic,desc,1)

                
                    

			
###################################movies
			  
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered
        
          
        getmovies("Search",url,0)


                        
               
                   
                
        
def getmovies(namemain,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  #http://mp.arbcinema.com/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d8%ac%d9%86%d8%a8%d9%8a%d8%a9-%d9%85%d8%aa%d8%b1%d8%ac%d9%85%d8%a9/page/2
                  
                     url_page=urlmain+'/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('<div class="blocksFilms">')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="Block">')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)"'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    regx='''<div class="movief">(.*?)</div>'''
                    name=re.findall(regx,block, re.M|re.I)[0]
                   
                    regx='''data-lazy-src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:img=img.encode("utf-8")
                    except:img=str(img)                
                    try:addDir(name,href,1,img,'',1)
                    except:pass
               
                   
                
                if len(blocks)>15:
                   addDir("next page",urlmain,100,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))

                    
###############################################tv shows

def getseries(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  #http://mp.arbcinema.com/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d8%ac%d9%86%d8%a8%d9%8a%d8%a9-%d9%85%d8%aa%d8%b1%d8%ac%d9%85%d8%a9/page/2
                  
                     url_page=urlmain+'/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('<div class="blocksFilms">')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="Block">')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)"'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    regx='''<div class="movief">(.*?)</div>'''
                    name=re.findall(regx,block, re.M|re.I)[0]
                   
                    regx='''data-lazy-src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:str(name)
                    
                    try:img.encode("utf-8")
                    except:img=str(img)                    
                    addDir(name,href,202,'','',1)
                    
               
                   
                
                
                addDir("next page",urlmain,200,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
                                        
                    
def getseasons(name,urlmain,page):##series
                if page>1:
                  #/page/2/
                  url_page=urlmain+"page/"++str(page)
                  
                else:
                
                      url_page=urlmain
                 
                data=readnet(url_page)
                try:data=data.split('<div class="title6">')[1]
                except:pass
                print "url_page",url_page
              
                if data is None:
                    return

                seasons=re.findall('''<a href="(.*?)" >(.*?)</a>''',data, re.M|re.I)
                print 'seasons',seasons
                
                for href,name in seasons:
                    
                    
                    addDir(name,href,202,'','',1)
                        

                                           
                                    


def getepisodes(name,urlmain,page):##series
                if page>0:
                
                  url_page=urlmain+'&page='+str(page)
                  
                else:
                
                      url_page=urlmain
                
                data=readnet(urlmain)
                
               
                
              
                if data is None:
                    return
                '''<div id="season1-1-watch-ep" class="watch-ep-btn" data-click=" https://openload.co/embed/mb6cBGnT_ko" data-poster="http://image.tmdb.org/t/p/w1280/tVCmhoIAHMCIzNmzSBvSDja4wOY.jpg" onclick="setUpTvPlayer(this)"><i class="fa fa-play-circle"></i>Watch Episode</div> </div> </li> <li id=season1-2> <h2>Allen</h2> <span class="season-info">Season 1, Episode 2</span><br> <span class="season-info air-date">Air date: Aug-29-2005</span> <p class="synopsis-description"> Trouble is inevitable in the prison, with a race riot imminent. Michael has problems retrieving a screw from the bleachers. Veronica receives a security tape that shows Lincoln shooting Terrence Steadman. </p>'''
                blocks=data.split('<div class="Blol">')
               
                i=0
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    print "block",block.encode("utf-8")
                    regx='''<a href="(.*?)">'''
                    href=re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    regx='''div class="movief_title">(.*?)</div>'''
                    name=re.findall(regx,block, re.M|re.I)[0]
                    

                                             
                               
                    
                    name=name.encode("utf-8")
                    addDir(name,href,1,'','',1)                        
               
                   
                
                                        
                   
                #if len(match)>0:
                  #addDir("next page",urlmain,200,'','',str(page+1))
               
            

 
def getsongs(namemain,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  #http://mp.arbcinema.com/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d8%ac%d9%86%d8%a8%d9%8a%d8%a9-%d9%85%d8%aa%d8%b1%d8%ac%d9%85%d8%a9/page/2
                  
                     url_page=urlmain+'/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('<div class="blocksFilms">')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="Block">')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)"'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    regx='''<div class="movief">(.*?)</div>'''
                    name=re.findall(regx,block, re.M|re.I)[0]
                   
                    regx='''data-lazy-src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:img=img.encode("utf-8")
                    except:img=str(img)                
                    try:addDir(name,href,4,img,'',1)
                    except:pass
               
                   
                
                if len(blocks)>15:
                   addDir("next page",urlmain,300,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,300,'','',str(page+1))

#######################################host resolving                                                    




def gethosts(name,urlmain):##cinema and tv featured

                data=resolveurl(urlmain)
                #data=readnet(urlmain)
               
               
                if data:
                   
                    regx1='''<iframe.*?src="(.*?)".*?></iframe>'''
                    regx='''<iframe.*?src="(.*?)".*?></iframe>'''
                    
                    href="http:"+re.findall(regx1,data, re.M|re.I)[0]
                   
                    resolve_host(href)
                    
def playsong(urlmain):##cinema and tv featured

                data=readnet(urlmain)
                #data=readnet(urlmain)
               
               
                if data:
                   
                    regx1='''<iframe.*?src="(.*?)".*?></iframe>'''
                    regx='''<a href="(.*?)" target="_blank" class="down_toen">.*?</a>'''
                    
                    href=re.findall(regx,data, re.M|re.I)[0].split("?")[0]
                    print "href",href
                   
                    playlink(href)                   
                    
                     
                    
                    
                                          

	    
def resolve_host(url):#last good-used with local resolver
       
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
      
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    
        else:
            addDir("Error,"+stream_link,"",9,"") 	    

def playlink(url):
           
            xbmc.Player().play(url)
            sys.exit(0)            
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param



def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
elif mode==1:
        print ""+url
        gethosts(name,url)
elif mode==2:
        print ""+url
        resolve_host(url)        
elif mode==3:
        print ""+url
        playlink(url)
elif mode==4:
        print ""+url
        playsong(url)     
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)
elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
	print ""+url
        search(url)    
       


elif mode==200:

	getseries(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)
	#getvideopage(url,page)	
elif mode==202:
	getepisodes(name,url,page)

elif mode==300:

	getsongs(name,url,page)
xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
