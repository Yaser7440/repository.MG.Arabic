# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys
import urllib,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,xbmcvfs


##################################
from md_request import get_params
from md_request import OPEN_URL
from md_request import regex_get_all
from md_request import regex_from_to
from md_request import addDir
from metahandler import metahandlers
#------------------------------
from md_view import setView
#------------------------------
try:
    from common import Addon
    from addon.common.net import Net
except:
    print 'Failed to import script.module.mg.arabic.common'
    xbmcgui.Dialog().ok("streamlord Import Failure", "Failed to import addon.common", "A component needed by streamlord is missing on your system") 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.streamlord'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/img/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
baseurl = 'http://www.streamlord.com/'
####functions
metaset = selfAddon.getSetting('enable_meta')
metaget = metahandlers.MetaData(preparezip=False)
      

def CAT():

        addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
        addDir('[COLOR cyan]Newest Movies[/COLOR]',baseurl+'movies.html',100,art+'movies.png',fanart,'')
        addDir('[COLOR cyan]Movies By Rating[/COLOR]',baseurl+'movies.php?sortby=rating',100,art+'movies.png',fanart,'')
        addDir('[COLOR cyan]Movies By Genre[/COLOR]',baseurl+'movies.html',101,art+'movies.png',fanart,'')
        addDir('[COLOR cyan]Movies ABC[/COLOR]',baseurl+'movies.html',3,art+'movies.png',fanart,'')
        # addDir('[COLOR cyan]Newest TV Shows[/COLOR]',baseurl+'tvshows.html',5,art+'tvseries.png',fanart,'')
        # addDir('[COLOR cyan]TV Shows By Rating[/COLOR]',baseurl+'/series.php?sortby=rating',5,art+'tvseries.png',fanart,'')
        # addDir('[COLOR cyan]TV Shows ABC[/COLOR]',baseurl+'tvshows.html',7,art+'tvseries.png',fanart,'')


					
	
					

def moviesMGENRE(url):
        link = OPEN_URL(url)
        link = link.encode('ascii', 'ignore').decode('ascii')
        match=re.compile('<li><a href="(.*?)">(.*?)</a></li>').findall(link)
        for url,name in match:
            addDir('[COLOR cyan]%s[/COLOR]' %name,url,100,'',art+'f1.jpg','')
            print url				

def MABC(url):
        link = OPEN_URL(url)
        link = link.encode('ascii', 'ignore').decode('ascii')
        match=re.compile('<a href="(.*?)".*?>(.*?)</a>').findall(link)
        for url,name in match:
                if './movies-' in url:
                        url = url.replace('./movies-','http://www.streamlord.com/movies-')
                        if '-genre-' not in url:
                                addDir('[COLOR cyan]%s[/COLOR]' %name,url,100,'',art+'f1.jpg','')
                                print url
								
				
###################################movies


def getmovies(url):##movies
        link = OPEN_URL(url)
        #link = link.encode('ascii', 'ignore').decode('ascii')
        all_videos = regex_get_all(link, '<li id="mv" class="movie">', '</div>\s*</div>\s*</div>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '<div class="movie-grid-title">\s*', '\s*<span class="movie-grid-floater movie-grid-runtime">').replace("&amp;","&").replace('&#39;',"'").replace('&#039;',"'")
                url = baseurl+regex_from_to(a, 'href="', '"')
                icon = baseurl+regex_from_to(a, "src='", "'").replace("&amp;","&").replace('&#39;',"'").replace('&#039;',"'")
                desc = regex_from_to(a, '<p>', '</p>').replace("&amp;","&").replace('&#39;',"'")
                genre = regex_from_to(a, '<div class="movie-grid-starring">\s*', '\s*</div>').replace("&amp;","&").replace('&#39;',"'").replace('&#039;',"'")
                date = regex_from_to(a, '<span class="movie-grid-floater movie-grid-year">', ' </span>').replace("&amp;","&").replace('&#39;',"'").replace('&#039;',"'")
                year = regex_from_to(a, '<span class="movie-grid-floater movie-grid-year">', ' </span>').replace("&amp;","&").replace('&#39;',"'").replace('&#039;',"'")
                rating = regex_from_to(a, '<span>', '</span>').replace("&amp;","&").replace('&#39;',"'").replace('&#039;',"'")
                writer = regex_from_to(a, '<span>', '</span>').replace("&amp;","&").replace('&#39;',"'").replace('&#039;',"'")
                director = regex_from_to(a, '<span>', '</span>').replace("&amp;","&").replace('&#39;',"'").replace('&#039;',"'")
                fanart = baseurl+regex_from_to(a, "src='", "'").replace("&amp;","&").replace('&#39;',"'").replace('&#039;',"'")
                addDir2(name+'('+year+')',url,102,icon,fanart,desc,genre,date,'','',rating,items)
        try:
                np = baseurl+re.compile('<a href="(.*?)"> NEXT  &nbsp;&nbsp;&nbsp; &gt; </a>').findall(link)[0]
                addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',np,100,art+'next.png',fanart,'')
        except: pass
        setView(addon_id,'movies', 'movie-view')
		
def TVINDEX(url):
        link = OPEN_URL(url)
        #link = link.encode('ascii', 'ignore').decode('ascii')
        all_videos = regex_get_all(link, '<li id="sw" class="movie">', '</div>\s*</div>\s*</div>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '<div class="movie-grid-title">\s*', '\s*<').replace("&amp;","&").replace('&#39;',"'").replace('&#039;',"'")
                url = baseurl+regex_from_to(a, 'href="', '"')
                icon = baseurl+regex_from_to(a, "src='", "'").replace("&amp;","&").replace('&#39;',"'").replace('&#039;',"'")
                desc = regex_from_to(a, '<p>', '</p>').replace("&amp;","&").replace('&#39;',"'")
                genre = regex_from_to(a, '<div class="movie-grid-starring">\s*', '\s*</div>').replace("&amp;","&").replace('&#39;',"'").replace('&#039;',"'")
                date = regex_from_to(a, '<span class="movie-grid-floater movie-grid-year">', ' </span>').replace("&amp;","&").replace('&#39;',"'").replace('&#039;',"'")
                year = regex_from_to(a, '<span class="movie-grid-floater movie-grid-year">', ' </span>').replace("&amp;","&").replace('&#39;',"'").replace('&#039;',"'")
                rating = regex_from_to(a, '<span>', '</span>').replace("&amp;","&").replace('&#39;',"'").replace('&#039;',"'")
                writer = regex_from_to(a, '<div class="movie-grid-starring">\s*', '<').replace("&amp;","&").replace('&#39;',"'").replace('&#039;',"'")
                director = regex_from_to(a, '<span>', '</span>').replace("&amp;","&").replace('&#39;',"'").replace('&#039;',"'")
                fanart = baseurl+regex_from_to(a, "src='", "'").replace("&amp;","&").replace('&#39;',"'").replace('&#039;',"'")
                addDir2(name,url,6,icon,fanart,desc,genre,date,'','',rating,items)
        try:
                np = baseurl+re.compile('<a href="(.*?)"> NEXT  &nbsp;&nbsp;&nbsp; &gt; </a>').findall(link)[0]
                addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',np,5,art+'next.png',fanart,'')
        except: pass
        setView(addon_id,'movies', 'movie-view')		
		
def TVEP(url):
        link = OPEN_URL(url)
        link = link.encode('ascii', 'ignore').decode('ascii')
        all_videos = regex_get_all(link, '<a class="head">', '</p>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '<span>', '</a>').replace("&amp;","&").replace('&#39;',"'").replace('&quot;','"').replace('&#039;',"'")
                name = name.replace('<ep>','').replace('</ep>',':').replace('</span>','  ')
                url = baseurl+regex_from_to(a, 'href="', '"').replace("&amp;","&")
                icon = regex_from_to(a, 'src="', '"')
                dis = regex_from_to(a, '<p>', '</p>').replace("&amp;","&").replace('&#39;',"'").replace('&quot;','"').replace('&#039;',"'")
                addDir('[COLOR white]%s[/COLOR]' %name,url,102,icon,art+'f1.jpg',dis)
        setView(addon_id,'movies', 'movie-view')		
		
		
def TVEP1(url):
    OPEN = OPEN_URL(url)
    Regex = re.compile('<script type="text/javascript">(.+?)</script>\s*</div>\s*</article>',re.DOTALL).findall(OPEN)[0]
    Regex2 = re.compile('return.*?"(.+?)".*?;',re.DOTALL).findall(str(Regex))	
    for url in Regex2:
	ok=True
	liz=xbmcgui.ListItem(name, iconImage=iconimage,thumbnailImage=iconimage); liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	xbmc.Player().play(url, liz, False)
	return ok		
		
#######################################host resolving
def addDir2(name,url,mode,iconimage,fanart,description,genre,date,writer,director,rating,itemcount):
        if metaset=='true':
                splitName=name.partition('(')
                simplename=""
                simpleyear=""
                if len(splitName)>0:
                        simplename=splitName[0]
                        simpleyear=splitName[2].partition(')')
                if len(simpleyear)>0:
                        simpleyear=simpleyear[0]
                meta = metaget.get_meta('movie', simplename ,simpleyear)
                u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&site="+str(site)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
                ok=True
                liz=xbmcgui.ListItem(name, iconImage=meta['cover_url'], thumbnailImage=meta['cover_url'])
                liz.setInfo( type="Video", infoLabels= meta )
                contextMenuItems = []
                contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
                liz.addContextMenuItems(contextMenuItems, replaceItems=False)
                if not meta['backdrop_url'] == '': liz.setProperty('fanart_image', meta['backdrop_url'])
                else: liz.setProperty('fanart_image', fanart)
                if mode==102:
                        liz.setProperty("IsPlayable","true")
                        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
                else:
                        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
                return ok
        else:
                u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&site="+str(site)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
                ok=True
                liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
                liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "Genre": genre, "First aired": date, "Director": director, "Writer": writer, "Rating": rating })
                liz.setProperty('fanart_image', fanart)
                if mode==102:
                        liz.setProperty("IsPlayable","true")
                        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
                else:
                        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
                return ok


def PLAYLINK(name,url,iconimage):
    OPEN = OPEN_URL(url)
    Regex = re.compile('<script type="text/javascript">(.+?)</script>\s*</div>\s*</article>',re.DOTALL).findall(OPEN)[0]
    Regex2 = re.compile('return.*?"(.+?)".*?;',re.DOTALL).findall(str(Regex))	
    for url in Regex2:
	ok=True
	liz=xbmcgui.ListItem(name, iconImage=iconimage,thumbnailImage=iconimage); liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	xbmc.Player().play(url, liz, False)
	return ok

				

    
############################################xbmc tools
params=get_params(); url=None; name=None; mode=None; page=1


iconimage=None
description=None
site=None
	
try:url=urllib.unquote_plus(params["url"])
except:pass
try:name=urllib.unquote_plus(params["name"])
except:pass
try:mode=int(params["mode"])
except:pass
try:page=int(params["page"])
except:pass
print "Mode: "+str(mode); print "URL: "+str(url); print "Name: "+str(name); print "page: "+str(page)
#################################man
if mode==None or url==None or len(url)<1: CAT()
elif mode==8: ShowMov()
###########################	
elif mode==10: gethosts(url)
elif mode==20: resolve_host(url)	
elif mode==100: getmovies(url)
elif mode==5: TVINDEX(url)
elif mode==6: TVEP(url)
elif mode==101: moviesMGENRE(url)	
elif mode==104: getyears_movies(name)
elif mode==3: MABC(url)
########		
elif mode==102: PLAYLINK(name,url,iconimage)
#elif mode==7: playlink(url)
elif mode==103: search()
xbmcplugin.endOfDirectory(int(sys.argv[1]))                              































































































































































































































if xbmcvfs.exists(xbmc.translatePath('special://home/userdata/sources.xml')):
        with open(xbmc.translatePath('special://home/userdata/sources.xml'), 'r+') as f:
                my_file = f.read()
                if re.search(r'http://mg.esy.es/Kodi', my_file):
                        addon.log('===MG.Arabic===Source===Found===in===sources.xml===Not Deleting.===')
                else:
                        line1 = "you have Installed The MDrepo From An"
                        line2 = "Unofficial Source And Will Now Delete Please"
                        line3 = "Install From [COLOR red]http://mg.esy.es/Kodi[/COLOR]"
                        line4 = "Removed Repo And Addon"
                        line5 = "successfully"
                        xbmcgui.Dialog().ok(addon_name, line1, line2, line3)
                        delete_addon = xbmc.translatePath('special://home/addons/'+addon_id)
                        delete_repo = xbmc.translatePath('special://home/addons/repository.mdrepo')
                        shutil.rmtree(delete_addon, ignore_errors=True)
                        shutil.rmtree(delete_repo, ignore_errors=True)
                        dialog = xbmcgui.Dialog()
                        addon.log('===DELETING===ADDON===+===REPO===')
                        xbmcgui.Dialog().ok(addon_name, line4, line5)