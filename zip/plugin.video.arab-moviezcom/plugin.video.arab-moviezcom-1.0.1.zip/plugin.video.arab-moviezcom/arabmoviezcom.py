# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys
import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,xbmcvfs
import requests
from addon.common.addon import Addon
from addon.common.net import Net

#Common Cache
try:
  import StorageServer
except:
  import storageserverdummy as StorageServer
cache = StorageServer.StorageServer('plugin.video.arab-moviezcom')


addon_id='plugin.video.arab-moviezcom'
addon = Addon(addon_id, sys.argv)
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/img/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, art+'/icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , art+'/fanart.jpg'))
HOME   =  xbmc.translatePath('special://home/')
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
baseurl = 'http://www.arab-moviez.com'
net = Net()

def decodeHtml(text):
    text = text.replace('free counter statistics','[B][COLOR red]••MG.Arabic••http://mg.esy.es/Kodi/••[/COLOR][/B]').replace('افلام','').replace('Top News','[B][COLOR red]••MG.Arabic••[/COLOR][/B]').replace('مباشرة','')
    text = text.replace('تحميل','').replace('..','').replace('عربية','').replace('لاين','').replace('اجنبية','')
    text = text.replace('اون','').replace('بدون تحميل','').replace('مشاهدة','').replace('مترجمة','').replace('مترجم','').replace('كرتون','').replace('&#8211;','').replace('&#038;','').replace('&#8217;','').replace(',','')
    text = text.replace('   ', '').replace('افلام','').replace('أجنبية','').replace('&amp;','')
    return text 
def decodeHtml2(text):
    text = text.replace('Top News','[B][COLOR red]••MG.Arabic••[/COLOR][/B]').replace('&amp;','And')
    return text

def resolveurl(url):

            
            print "url",url
            #sys.exit(0)            
            import requests,re,time
            html=requests.get(url).text
            #<input type="hidden" name="watch" value="1">                  
            #id = re.findall('<input type="hidden" name="id" value="(.*?)">',html, re.M|re.I)[0]
            #fname = re.findall('<input type="hidden" name="fname" value="(.*?)">',html, re.M|re.I)[0]
            #hash = re.findall('<input type="hidden" name="hash" value="(.*?)">',html, re.M|re.I)[0]
            #action = re.findall('''<Form method="POST" action='(.*?)'>''',html, re.M|re.I)[0]
            #print "id,fname,hash,action",id,fname,hash,action
            time.sleep(10)
            #sys.exit(0)
            data= {
                'watch': "1",                               
                'referer': 'http://www.arab-moviez.com/',
                'method': 'POST'}   
                
            data=requests.post(url, data=data).text.encode("utf-8")
            return data

####functions
def read_url(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', 'www.arab-moviez.com')
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
	return link
    
def readnet(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      


              

##########################################parsing tools
def CAT():
        addDir('[B][COLOR white]••البحث••[/COLOR][/B]',baseurl+'/?s=',104,icon,fanart,'')
        addDir('[B][COLOR white]••افلام جديده••[/COLOR][/B]',baseurl+'/movies/',100,icon,fanart,'')
        #addDir('[B][COLOR white]••قوائم المسلاسلات••[/COLOR][/B]',baseurl,8,icon,fanart,'')
        addDir('[B][COLOR white]••قوائم الافلام••[/COLOR][/B]',baseurl,10,icon,fanart,'')
        addDir('[B][COLOR red]••MG.Arabic••http://mg.esy.es/Kodi/••[/COLOR][/B]','','',fanart,fanart,'')
def TV0ARALAB(url):
        addDir('[B][COLOR white]••بحث••[/COLOR][/B]',baseurl+'/?s=',104,icon,fanart)
        addDir('[B][COLOR white]••الافلام••[/COLOR][/B]',baseurl,4,icon,fanart,'')        
        addDir('[B][COLOR white]••عـــــــــام••[/COLOR][/B]',baseurl,5,icon,fanart,'')
        addDir('[B][COLOR white]••التصنيف بالاصدار••[/COLOR][/B]',baseurl,6,icon,fanart,'')
        addDir('[B][COLOR white]••الترتيب بالحروف••[/COLOR][/B]',baseurl,7,icon,fanart,'')
        addDir('[B][COLOR red]••MG.Arabic••http://mg.esy.es/Kodi/••[/COLOR][/B]','','',fanart,fanart,'')		
def TV1ARALAB(url):
	    
		addDir2('Search',baseurl+'/?s=',104,icon,fanart)
		link = read_url(url)
	#try:
		menu=re.compile('<ul class="main_link(.+?)/ul>',re.DOTALL).findall(link)
		for url in menu:
			matchsections = re.compile('<a  href="(.+?)">.*?</i>(.+?)</a></li>').findall(url)
			for url,name in matchsections:
				url = url
				url = re.sub(' ','%20',url)
				addDir2(decodeHtml2(name),url,100,icon,fanart)
                addDir2('[B][COLOR red]••MG.Arabic••http://mg.esy.es/Kodi/••[/COLOR][/B]','','',fanart,fanart)
def TV2ARALAB(url):
	    
		#addDir2('SEARCH','?s=',104,icon,fanart)
		link = read_url(url)
	#try:
		menu=re.compile('<ul class="genres scro(.+?)/ul>',re.DOTALL).findall(link)
		for url in menu:
			matchsections = re.compile('<li class="cat-item cat-item-.*?"><a href="(.+?)" >(.+?)</a> <i>').findall(url)
			for url,name in matchsections:
				url = url
				url = re.sub(' ','%20',url)
				addDir2(decodeHtml2(name),url,100,icon,fanart)
                addDir2('[B][COLOR red]••MG.Arabic••http://mg.esy.es/Kodi/••[/COLOR][/B]','','',fanart,fanart)				
def TV3ARALAB(url):
	    
		#addDir2('SEARCH','url',104,icon,fanart)
		link = read_url(url)
	#try:
		menu=re.compile('<ul class="year scro(.+?)/ul>',re.DOTALL).findall(link)
		for url in menu:
			matchsections = re.compile('<a href="(.+?)">(.+?)</a></li>').findall(url)
			for url,name in matchsections:
				url = url
				url = re.sub(' ','%20',url)
				addDir2(decodeHtml2(name),url,100,icon,fanart)				
                addDir2('[B][COLOR red]••MG.Arabic••http://mg.esy.es/Kodi/••[/COLOR][/B]','','',fanart,fanart)				
def TV4ARALAB(url):
	    
		#addDir2('SEARCH','url',104,icon,fanart)
		link = read_url(url)
	#try:
		menu=re.compile('<ul class="ab(.+?)/ul>',re.DOTALL).findall(link)
		for url in menu:
			matchsections = re.compile('<a href="(.+?)" >(.+?)</a></li>').findall(url)
			for url,name in matchsections:
				url = url
				url = re.sub(' ','%20',url)
				addDir2(decodeHtml2(name),url,100,icon,fanart)
                addDir2('[B][COLOR red]••MG.Arabic••http://mg.esy.es/Kodi/••[/COLOR][/B]','','',fanart,fanart)				
def TV5ARALAB(url):
        addDir('[B][COLOR white]••TV Shows••[/COLOR][/B]',baseurl+'/tvshows/',102,icon,fanart,'')
        addDir('[B][COLOR white]••Seasons••[/COLOR][/B]',baseurl+'/seasons/',102,icon,fanart,'')
        addDir('[B][COLOR white]••Episodes••[/COLOR][/B]',baseurl+'/episodes/',102,icon,fanart,'')				
        addDir('[B][COLOR red]••MG.Arabic••http://mg.esy.es/Kodi/••[/COLOR][/B]','','',fanart,fanart,'')		
				
				
				
				
		

			 
        			 
###################################movies
			  
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search Arab-Moviez.com')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered
        
          
        getmoviesSH("Search",url,0)


                        
               
                   
                
        
def getmovies(namemain,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  #http://www.arab-moviez.com/tag/romance-films-full-online-2016/page/2
                  
                  
                  url_page=urlmain+'/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('class="post(.*?)"')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="poster"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)"'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    regx='''alt="(.*?)"'''
                    name=re.findall(regx,block, re.M|re.I)[0]
                   
                    regx='''src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:img=img.encode("utf-8")
                    except:img=str(img)                
                    try:addDir(decodeHtml(name),href,1,img,'',1)
                    except:pass
               
                   
                
                addDir("next page>>",urlmain,100, art + '/nextBUTTON.png','',str(page+1))
                if len(blocks)==0:
                   addDir("Error:no results",urlmain,100,'','',str(page+1))
		   
def getTV(namemain,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  #http://www.arab-moviez.com/tag/romance-films-full-online-2016/page/2
                  
                  
                  url_page=urlmain+'/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('class="post(.*?)"')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="poster"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)"'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    regx='''alt="(.*?)"'''
                    name=re.findall(regx,block, re.M|re.I)[0]
                   
                    regx='''src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:img=img.encode("utf-8")
                    except:img=str(img)                
                    try:addDir(decodeHtml(name),href,103,img,'',1)
                    except:pass
               
                   
                
                addDir("next page>>",urlmain,102, art + '/nextBUTTON.png','',str(page+1))
                if len(blocks)==0:
                   addDir("Error:no results",urlmain,102,'','',str(page+1))				
def getTVEpis(namemain,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  #http://www.arab-moviez.com/tag/romance-films-full-online-2016/page/2
                  
                  
                  url_page=urlmain+'/page/'+str(page)+'/?s='+search_entered
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('class="mark(.*?)"')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="imagen"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)"'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    regx='''class="numerando">(.*?)</div>'''
                    name=re.findall(regx,block, re.M|re.I)[0]
                   
                    regx='''src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:img=img.encode("utf-8")
                    except:img=str(img)                
                    try:addDir(decodeHtml(name),href,1,img,'',1)
                    except:pass
               
                   
                
                addDir("next page>>",urlmain,103, art + '/nextBUTTON.png','',str(page+1))
                if len(blocks)==0:
                   addDir("Error:no results",urlmain,103,'','',str(page+1))
                    
def getmoviesSH(namemain,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  #http://www.arab-moviez.com/tag/romance-films-full-online-2016/page/2
                  
                  
                  url_page=urlmain+'/page/'+str(page)+'/?s='
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('class="result-(.*?)"')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="result-item"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)"'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    regx='''alt="(.*?)"'''
                    name=re.findall(regx,block, re.M|re.I)[0]
                   
                    regx='''src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:img=img.encode("utf-8")
                    except:img=str(img)                
                    try:addDir(decodeHtml(name),href,1,img,'',1)
                    except:pass
               
                   
                
                # addDir("next page>>",urlmain,105, art + '/nextBUTTON.png','',str(page+1))
                # if len(blocks)==0:
                   # addDir("Error:no results",urlmain,105,'','',str(page+1))
#######################################host resolving                                                    
def getmatch(match):
                if len(match)<1:
                        return
                for href in match:
                    
                    if not href.startswith("http"):
                       href="http:"+href
                    #href=href.replace("/f/","/embed/")
                    
                    
                     
                    server=href.split("/")[2].replace('www.',"").replace("embed.","").split(".")[0]
                    # if 'hqq' in server or "myvi" in server or 'videomeh' in server:
                            # return
                    addDir(server,href,2,'')
         		
        
def get_servers(name,urlmain):

                data=read_url(urlmain)
	        print data
                	
                #regx='''</span><a href='(.+?)' class='redirect_link'>'''
                #regx1='''<iframe src="(.+?)" scrolling="no" frameborder="0" width="700" height="430" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'''
                #regx2='''<iframe width="640" height="400" src="(.*?)" frameborder="0" allowfullscreen></iframe>'''
                
                regx3='''<iframe.*?src="(.*?)".*?></iframe>'''
                #regx4='''<iframe src="(.*?)"></iframe>'''
                #regx5='''<IFRAME .+? SRC="(.+?)" .+?></IFRAME>'''
               
                #match1 = re.findall(regx1,data, re.M|re.I)
                #match2 = re.findall(regx2,data, re.M|re.I)
                match3 = re.findall(regx3,data, re.M|re.I)
                #match4 = re.findall(regx4,data, re.M|re.I)
                #match5 = re.findall(regx5,data, re.M|re.I)
         
                #getmatch(match1)
                #getmatch(match2)
                getmatch(match3)
                #getmatch(match4)
                #getmatch(match5)
               
                return
            		

      
	    
def resolve_host(url):#last good-used with local resolver
       
        from urlresolver import resolve
		
   
        stream_link=str(resolve(url))
      
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    
        else:
            addDir("Error,"+stream_link,"",9,"")     	    

def playlink(url):
           
            xbmc.Player().play(url)
            sys.exit(0)            
############################################xbmc tools	    
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        hostname=query.hostname.replace("www.","")
        return hostname

def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
def addDir2(name,url,mode,iconimage,fanart,description=''):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
def setView(content, viewType):
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if selfAddon.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % selfAddon.getSetting(viewType) )

params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None
site=None
query=None
type=None	
page=1

try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass
try:
	description=urllib.unquote_plus(params["description"])
except:
	pass
try:
	query=urllib.unquote_plus(params["query"])
except:
	pass
try:
	type=urllib.unquote_plus(params["type"])
except:
	pass
try:
        page=int(params["page"])
except:
	pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "iconimage: "+str(iconimage)
print "description: "+str(description)
print "query: "+str(query)
print "type: "+str(type)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        CAT()
elif mode==4: TV1ARALAB(url)
elif mode==5: TV2ARALAB(url)
elif mode==6: TV3ARALAB(url)
elif mode==7: TV4ARALAB(url)
elif mode==8: TV5ARALAB(url)
elif mode==10: TV0ARALAB(url)		
elif mode==1:
        print ""+url
        get_servers(name,url)
elif mode==2:
        print ""+url
        resolve_host(url)		
elif mode==9:		
        GmenuTV()        
elif mode==3:
        print ""+url
        playlink(url)             
elif mode==100:
        print ""+url
        getmovies(name,url,page)
elif mode==102:
        print ""+url		
        getTV(name,url,page)
elif mode==103:
        print ""+url
        getTVEpis(name,url,page)
elif mode==105:
        print ""+url		
        getmoviesSH(name,url,page)
elif mode==10:
        print ""+url               
        YEARSEN(name)		
elif mode==104:
	print ""+url
        search(url)    

xbmcplugin.endOfDirectory(int(sys.argv[1]))                              































































































































































































































if xbmcvfs.exists(xbmc.translatePath('special://home/userdata/sources.xml')):
        with open(xbmc.translatePath('special://home/userdata/sources.xml'), 'r+') as f:
                my_file = f.read()
                if re.search(r'http://mg.esy.es/Kodi', my_file):
                        addon.log('===MG.Arabic===Source===Found===in===sources.xml===Not Deleting.===')
                else:
                        line1 = "you have Installed The MDrepo From An"
                        line2 = "Unofficial Source And Will Now Delete Please"
                        line3 = "Install From [COLOR red]http://mg.esy.es/Kodi[/COLOR]"
                        line4 = "Removed Repo And Addon"
                        line5 = "successfully"
                        xbmcgui.Dialog().ok(addon_name, line1, line2, line3)
                        delete_addon = xbmc.translatePath('special://home/addons/'+addon_id)
                        delete_repo = xbmc.translatePath('special://home/addons/repository.MG.Arabic')
                        shutil.rmtree(delete_addon, ignore_errors=True)
                        shutil.rmtree(delete_repo, ignore_errors=True)
                        dialog = xbmcgui.Dialog()
                        addon.log('===DELETING===ADDON===+===REPO===')
                        xbmcgui.Dialog().ok(addon_name, line4, line5)