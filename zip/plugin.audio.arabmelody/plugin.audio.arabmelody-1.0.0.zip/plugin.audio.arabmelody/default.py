# -*- coding: utf8 -*-

import sys
import urllib,urllib2,re,os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re



############################################

####functions

    
def readnet(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      

              

##########################################parsing tools
def showmenu():

                list1=[('http://www.arabmelody.net/cat/egyptian_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x85\xd8\xb5\xd8\xb1\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/lebanese_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x84\xd8\xa8\xd9\x86\xd8\xa7\xd9\x86\xd9\x8a\xd9\x87'), ('http://www.arabmelody.net/cat/kuwaiti_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x83\xd9\x88\xd9\x8a\xd8\xaa\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/saudi_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb3\xd8\xb9\xd9\x88\xd8\xaf\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/sudanese_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb3\xd9\x88\xd8\xaf\xd8\xa7\xd9\x86\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/yemeni_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x8a\xd9\x85\xd9\x86\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/emirati_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xa7\xd9\x85\xd8\xa7\xd8\xb1\xd8\xa7\xd8\xaa\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/iraqi_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb9\xd8\xb1\xd8\xa7\xd9\x82\xd9\x8a\xd9\x87'), ('http://www.arabmelody.net/cat/syrian_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb3\xd9\x88\xd8\xb1\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/bahraini_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xa8\xd8\xad\xd8\xb1\xd9\x8a\xd9\x86\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/omani_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb9\xd9\x85\xd8\xa7\xd9\x86\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/jordanian_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xa7\xd8\xb1\xd8\xaf\xd9\x86\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/qatari_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x82\xd8\xb7\xd8\xb1\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/moroccan_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x85\xd8\xba\xd8\xb1\xd8\xa8\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/algerian_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xac\xd8\xb2\xd8\xa7\xd8\xa6\xd8\xb1\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/tunisian_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xaa\xd9\x88\xd9\x86\xd8\xb3\xd9\x8a\xd9\x87'), ('http://www.arabmelody.net/cat/libyan_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x84\xd9\x8a\xd8\xa8\xd9\x8a\xd9\x87'), ('http://www.arabmelody.net/cat/palestinian_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x81\xd9\x84\xd8\xb3\xd8\xb7\xd9\x8a\xd9\x86\xd9\x8a\xd9\x87')]
                for item in list1:
                    #menuitems.append((item[1].encode("utf-8"),item[1],102,'img/music.png','',1))
                    try:title=item[1].encode("utf-8")
                    except:title=str(item[1])
                    addDir(title,item[0],102,'','',1)

   
                    


def getA_Z(url):
    
                regx='''<td width=".*?"><a href="(.*?)">(.*?)</a></td>'''
                data=readnet(url)
                match=re.findall(regx,data, re.M|re.I)
                print "match",match
                i=0
                for item in match:
                   i=i+1
                   href=item[0]
                   letter=item[1].encode("utf-8")
                   href=url+"/letter"+str(i)
                   href=href.replace("cat/","")
                   addDir(letter,href,100,'','',1)
                




                
			

                   
                
        
def getartists(name,urlmain,page):##movies
                print "page",page
               
               
                data=readnet(urlmain)
               
                
               
                if data is None:
                    return
               
                regx='''<a title=".*?" href="(.*?)">(.*?)</a></div>'''

                match=re.findall(regx,data, re.M|re.I)
                print "match",match
                

                for item in match:
                   href=item[0]
                   artist=item[1].encode("utf-8")
                   addDir(artist,href,200,'','',1)
                

                    

def getsongs(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  #http://www.arabmelody.net/audios/a9109/
                  
                  url_page=urlmain+"/page"+str(page)

                 
                  
                else:
                
                      url_page=urlmain
                
               
                data=readnet(url_page)
                #data=data.split('id="movie_list"')[1]
                
                
                if data is None:
                    return
                
                blocks=data.split('</tr><tr>')
                i=0
                print "url_page",url_page
               
                
                
                
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                   
                    regx='''<img border="0" src=".*?" alt="(.*?)"></a></td>'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    regx='''<td width="15%" align=center><a href="(.*?)" rel="nofollow">'''                    
                    href=re.findall(regx,block, re.M|re.I)[0]

                   
                                                
                               
                    
                    name=name.encode("utf-8")
                    try:addDir(name,href,3,'','',1)
                    except:continue
                    
               
                   
                
               
                addDir("next page",urlmain,200,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                
                                        
                    


def playlink(url):
           
            xbmc.Player().play(url)
            sys.exit(0)            
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param



def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
elif mode==1:
        print ""+url
        gethosts(name,url)
elif mode==2:
        print ""+url
        resolve_host(url)        
elif mode==3:
        print ""+url
        playlink(url)
     
        
elif mode==100:
        print ""+url
        getartists(name,url,page)
elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z(url)
	
elif mode==103:
	print ""+url
        search(url)    
       


elif mode==200:

	getsongs(name,url,page)
	
elif mode==201:
        print "mfaraj"+url
	getseasons(name,url,page)
	#getvideopage(url,page)	
elif mode==202:
	getepisodes(name,url,page)


xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
