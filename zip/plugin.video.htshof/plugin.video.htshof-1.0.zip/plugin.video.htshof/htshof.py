# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys, os, urllib
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re
import requests
import urlresolver


try:
    from addon.common.addon import Addon
    from addon.common.net import Net
    from urlresolver import resolve
except:
    print 'Failed to import script.module.addon.common'
    xbmcgui.Dialog().ok("htshof Import Failure", "Failed to import addon.common", "A component needed by htshof is missing on your system")
  
#Common Cache
import xbmcvfs
dbg = False # Set to false if you don't want debugging
  
#Common Cache
try:
  import StorageServer
except:
  import storageserverdummy as StorageServer
cache = StorageServer.StorageServer('plugin.video.htshof')


addon_id='plugin.video.htshof'
DB = os.path.join(xbmc.translatePath("special://database"), 'htshof.db')
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_handle = int(sys.argv[1])
addon_name = selfAddon.getAddonInfo('name')
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/img/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
show_tv = selfAddon.getSetting('enable_shows')
baseurl = selfAddon.getSetting('base_url')
s = requests.session()
net = Net()
base_url='https://htshof.com/'


def resolveurl(url):

            
            print "url",url
            #sys.exit(0)            
            import requests,re,time
            html=requests.get(url).text
            #<input type="hidden" name="watch" value="1">                  
            #id = re.findall('<input type="hidden" name="id" value="(.*?)">',html, re.M|re.I)[0]
            #fname = re.findall('<input type="hidden" name="fname" value="(.*?)">',html, re.M|re.I)[0]
            #hash = re.findall('<input type="hidden" name="hash" value="(.*?)">',html, re.M|re.I)[0]
            #action = re.findall('''<Form method="POST" action='(.*?)'>''',html, re.M|re.I)[0]
            #print "id,fname,hash,action",id,fname,hash,action
            time.sleep(10)
            #sys.exit(0)
            data= {
                'watch': "1",                               
                'referer': 'https://htshof.com/',
                'method': 'POST'}   
                
            data=requests.post(url, data=data).text.encode("utf-8")
            return data
def OPEN_URL(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = requests.get(url, headers=headers).text
    link = link.encode('utf-8')
    return link            

baseurl = 'https://htshof.com'
####functions
def readnet1(url):
        import requests
        data=requests.get(url, verify=False)
        return data.content
    
def readnet(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
##########################################parsing tools
def CAT():
  addDir('[B][COLOR white]قائمة الأفلام[/COLOR][/B]','url',8,art+'/mymovies.png',fanart,'')
  addDir('[B][COLOR white]قائمة المسلسلات[/COLOR][/B]','url',16,art+'/mytvshows.png',fanart,'')
  addDir('[B][COLOR white]برامج تلفزيونية[/COLOR][/B]',baseurl+'/category/tv-show/',202,art+'/mytvshows.png',fanart,'')
  addDir('[B][COLOR white]عروض مصارعه[/COLOR][/B]',baseurl+'/category/wrestling/',202,art+'/WWE.png',fanart,'')

		
		
def showmenuMV():

   menuitems=[]                
   menuitems.append(("[B][COLOR white]••البحث••[/COLOR][/B]",'url',103,art+'/search.png',fanart,1))
   menuitems.append(("[B][COLOR white]••تصنيف باسنة••[/COLOR][/B]",'url',11,art+'/years.png',fanart,1))
   menuitems.append(("[B][COLOR white]••عـــام••[/COLOR][/B]",'url',10,art+'/genres.png',fanart,1))
   menuitems.append(("[B][COLOR white]••المضاف حديثا••[/COLOR][/B]",baseurl+'/movies/wp-content/themes/movies/filter/suggestion.php',100,art+'/latest-movies.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام اجنبي••[/COLOR][/B]",baseurl+'/movies/category/movies/english-movies/',100,art+'/latest-movies.png',fanart,1))  
   menuitems.append(("[B][COLOR white]••افلام عربي••[/COLOR][/B]",baseurl+'/movies/category/movies/arabic-movies/',100,art+'/latest-movies.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام هندي••[/COLOR][/B]",baseurl+'/movies/category/movies/indian-movies/',100,art+'/latest-movies.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام كرتون••[/COLOR][/B]",baseurl+'/movies/category/movies/carton-movies/',100,art+'/latest-movies.png',fanart,1))		
   for title, url, mode,pic,desc,page in menuitems:
       addDir(title, url, mode, pic,desc,1)

def GENRES():
   menuitems=[]
   menuitems.append(("[B][COLOR white]••المضاف حديثا••[/COLOR][/B]",baseurl+'/movies/wp-content/themes/movies/filter/recent.php',100,art+'/latest-movies.png',fanart,1))
   menuitems.append(("[B][COLOR white]••الاكثر تقيما••[/COLOR][/B]",baseurl+'/movies/wp-content/themes/movies/filter/topratings.php',100,art+'/latest-movies.png',fanart,1))
   menuitems.append(("[B][COLOR white]••نقترح عليك••[/COLOR][/B]",baseurl+'/movies/wp-content/themes/movies/filter/suggestion.php',100,art+'/latest-movies.png',fanart,1))
   menuitems.append(("[B][COLOR white]••الافلام الشائعة••[/COLOR][/B]",baseurl+'/movies/wp-content/themes/movies/filter/topviews.php',100,art+'/latest-movies.png',fanart,1))   
   menuitems.append(("[B][COLOR white]••افلام رعب••[/COLOR][/B]",baseurl+'/movies/?s=&category=5&genre=horror',100,art+'/Horror.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام اكشن••[/COLOR][/B]",baseurl+'/movies/?s=&category=5&genre=action',100,art+'/Action.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام الجريمه••[/COLOR][/B]",baseurl+'/movies/?s=&category=5&genre=crime',100,art+'/BLLYOOD.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام اثاره••[/COLOR][/B]",baseurl+'/movies/?s=&category=5&genre=thriller',100,art+'/AAAA.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام دراما••[/COLOR][/B]",baseurl+'/movies/?s=&category=5&genre=darama',100,art+'/drama.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام غموض••[/COLOR][/B]",baseurl+'/movies/?s=&category=5&genre=mystery',100,art+'/AR.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام مغامرات••[/COLOR][/B]",baseurl+'/movies/?s=&category=5&genre=adventure',100,art+'/BLLYOOD.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام الفانتازيا••[/COLOR][/B]",baseurl+'/movies/?s=&category=5&genre=fantasy',100,art+'/AAAA.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام الحروب••[/COLOR][/B]",baseurl+'/movies/?s=&category=5&genre=war',100,art+'/Other.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام كوميديا••[/COLOR][/B]",baseurl+'/movies/?s=&category=5&genre=comedy',100,art+'/Comedy.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام رومانسيه••[/COLOR][/B]",baseurl+'/movies/?s=&category=5&genre=romance',100,art+'/Romantic.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام السيره الذاتيه••[/COLOR][/B]",baseurl+'/movies/?s=&category=5&genre=biography',100,art+'/AAAA.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام بوكس اوفيس••[/COLOR][/B]",baseurl+'/movies/?s=&category=5&genre=%25d8%25a7%25d9%2581%25d9%2584%25d8%25a7%25d9%2585-%25d9%2581%25d8%25a7%25d8%25b2%25d8%25aa-%25d8%25a8%25d8%25ac%25d8%25a7%25d8%25a6%25d8%25b2%25d8%25a9-%25d8%25a7%25d9%2584%25d8%25a7%25d9%2588%25d8%25b3%25d9%2583%25d8%25a7%25d8%25b1',100,art+'/box-office.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام خيال علمى••[/COLOR][/B]",baseurl+'/movies/?s=&category=5&genre=sci-fi',100,art+'/SienceFiction.png',fanart,1))
   menuitems.append(("[B][COLOR white]••موسيقي••[/COLOR][/B]",baseurl+'/movies/?s=&category=5&genre=musical',100,art+'/BLLYOOD.png',fanart,1))    
   for title, url, mode,pic,desc,page in menuitems:
       addDir(title, url, mode, pic,desc,1)	   
def YEARSmenuMV():

   menuitems=[]                
   menuitems.append(("[B][COLOR white]••افلام اجنبي••[/COLOR][/B]",'url',11,art+'/Action.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام عربي••[/COLOR][/B]",'url',12,art+'/AR.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام هندي••[/COLOR][/B]",'url',13,art+'/BLLYOOD.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام كرتون••[/COLOR][/B]",'url',14,art+'/AAAA.png',fanart,1))   		
   for title, url, mode,pic,desc,page in menuitems:
       addDir(title, url, mode, pic,desc,1)	

def showmenuTV():

   menuitems=[]                
   menuitems.append(("[B][COLOR white]البحث[/COLOR][/B]",'url',104,art+'/search.png',fanart,1))
   menuitems.append(("[B][COLOR white]مسلسلات عربي[/COLOR][/B]",baseurl+'/series/category/series/arabic-series/',200,art+'/AR.png',fanart,1))
   menuitems.append(("[B][COLOR white]مسلسلات اجنبية[/COLOR][/B]",baseurl+'/series/category/series/english-series/',200,art+'/TV.png',fanart,1))
   menuitems.append(("[B][COLOR white]مسلسلات تركي[/COLOR][/B]",baseurl+'/series/child_category/',200,art+'/musical.jpg',fanart,1))
   #menuitems.append(("[B][COLOR white]مسلسلات هندي[/COLOR][/B]",baseurl+'/series/مسلسلات-هندية/',200,art+'/BLLYOOD.png',fanart,1))
   #menuitems.append(("[B][COLOR white]برامج تليفزيونية[/COLOR][/B]",baseurl+'/series/برامج-تليفزيونية/',200,art+'/musical.jpg',fanart,1))
   #menuitems.append(("[B][COLOR white]مسلسلات كرتون[/COLOR][/B]",baseurl+'/series/مسلسلات-كارتون-و-انمي/',200,art+'/AAAA.png',fanart,1))		
   for title, url, mode,pic,desc,page in menuitems:
       addDir(title, url, mode, pic,desc,1)
	   
def searchmenuTV():

   menuitems=[]                
   menuitems.append(("[B][COLOR white]••بحث مسلسلات عربي••[/COLOR][/B]",baseurl+'/series/مسلسلات-عربية/?s=',104,art+'/AR.png',fanart,1))
   menuitems.append(("[B][COLOR white]••بحث مسلسلات اجنبية••[/COLOR][/B]",baseurl+'/series/مسلسلات-اجنبية/?s=',104,art+'/AR.png',fanart,1))
   menuitems.append(("[B][COLOR white]••بحث مسلسلات تركي••[/COLOR][/B]",baseurl+'/series/مسلسلات-تركية/?s=',104,art+'/BLLYOOD.png',fanart,1))
   menuitems.append(("[B][COLOR white]••بحث مسلسلات هندي••[/COLOR][/B]",baseurl+'/series/مسلسلات-هندية/?s=',104,art+'/BLLYOOD.png',fanart,1))
   menuitems.append(("[B][COLOR white]••بحث برامج تليفزيونية••[/COLOR][/B]",baseurl+'/series/برامج-تليفزيونية/?s=',104,art+'/AAAA.png',fanart,1))
   menuitems.append(("[B][COLOR white]••بحث مسلسلات كرتون••[/COLOR][/B]",baseurl+'/series/مسلسلات-كارتون-و-انمي/?s=',104,art+'/AAAA.png',fanart,1))   		
   for title, url, mode,pic,desc,page in menuitems:
       addDir(title, url, mode, pic,desc,1)
	   
def showmenuWW():

   menuitems=[]
                
   menuitems.append(("[B][COLOR white]البحث[/COLOR][/B]",baseurl+'/movies/category/عروض-مصارعه/?s=',105,art+'/search.png',fanart,1))
   menuitems.append(("[B][COLOR white]عروض مصارعه[/COLOR][/B]",baseurl+'/movies/category/عروض-مصارعه/',100,art+'/WWE.png',fanart,1))
   menuitems.append(("[B][COLOR white]عروض شهريه[/COLOR][/B]",baseurl+'/movies/category/عروض-مصارعه/عروض-شهريه/',100,art+'/WWE.png',fanart,1))
   menuitems.append(("[B][COLOR white]عروض Raw[/COLOR][/B]",baseurl+'/movies/category/عروض-مصارعه/عروض-raw/',100,art+'/WWE.png',fanart,1))
   menuitems.append(("[B][COLOR white]عروض SmackDown[/COLOR][/B]",baseurl+'/movies/category/عروض-مصارعه/عروض-smackdown/',100,art+'/WWE.png',fanart,1))
		
   for title, url, mode,pic,desc,page in menuitems:
       addDir(title, url, mode, pic,desc,1)                
                    
def YEARSEN(url):
       for i in range(1921,2018):
             addDir(str(i),baseurl+'/movies/release-year/'+str(i),100,art+'/years.png',fanart,1)
def YEARSAR(url):
       for i in range(1937,2018):
             addDir(str(i),baseurl+'/movies/category/افلام-عربى/?s='+str(i),100,art+'/years.png',fanart,1)
def YEARSIN(url):
       for i in range(1937,2018):
             addDir(str(i),baseurl+'/movies/category/افلام-هندى/?s='+str(i),100,art+'/years.png',fanart,1)
def YEARSAN(url):
       for i in range(1937,2018):
             addDir(str(i),baseurl+'/movies/category/افلام-انمى-و-كرتون/?s='+str(i),100,art+'/years.png',fanart,1)			 
###################################movies
			  
def searchMV():
        keyb = xbmc.Keyboard('', 'Search MOVIES')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = baseurl+'/movies/?s='+search
                getmovies(url)
def searchTV(url):
        keyb = xbmc.Keyboard('', 'Search SERIES')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = baseurl+'/series/?s='+search
                getseries(url)
        
          
        
       
def searchoth():
        keyb = xbmc.Keyboard('', 'Search WWE')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = baseurl+'/movies/category/عروض-مصارعه/?s='+search
                getmovies(url)                        
               
                   
                
        
def getmovies(url):##movies
        link = OPEN_URL(url)
        #link = link.encode('ascii', 'ignore').decode('ascii')
        all_videos = regex_get_all(link, '<div class="blockItem">', '</a>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '<h2 class="titleBack">', '</h2>').replace('فيلم ','').replace('مباشر','').replace('و تحميل','').replace('وتحميل','').replace('اون لاين','').replace('مشاهدة','').replace('مترجم','').replace('&#8211;','').replace('&#8217;','').replace('&amp;','')
                #name = addon.unescape(name)
                #name = name.encode('ascii', 'ignore').decode('ascii')
                qual = regex_from_to(a, 'النوع : </span>', '</div>').replace('مباشر','').replace('و تحميل','').replace('وتحميل','').replace('اون لاين','').replace('مشاهدة','').replace('مترجم','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','').replace('&#8211;','')				
                url = regex_from_to(a, 'href="', '"')		
                thumb = regex_from_to(a, 'src="', '"')              					
                addDir('[B][COLOR white]%s[/COLOR][/B][B][I][COLOR red]%s[/COLOR][/I][/B]' %(name,qual),url,7,thumb,fanart,items)
        try:
                np = re.compile("<link rel='next' href='(.*?)' />").findall(link)[0]
                addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',np,100,art+'/next.png',fanart,'')
        except: pass
        setView('movies', 'movie-view')

				

                    
###############################################tv shows

def getseries(url):##series
        link = OPEN_URL(url)
        #link = link.encode('ascii', 'ignore').decode('ascii')
        all_videos = regex_get_all(link, '<div class="blockItem">', '</a>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '<h2 class="titleBack">', '</h2>').replace('فيلم ','').replace('مباشر','').replace('و تحميل','').replace('وتحميل','').replace('اون لاين','').replace('مشاهدة','').replace('مترجم','').replace('&#8211;','').replace('&#8217;','')
                #name = addon.unescape(name)
                #name = name.encode('ascii', 'ignore').decode('ascii')
                qual = regex_from_to(a, 'النوع : </span>', '</div>').replace('مباشر','').replace('و تحميل','').replace('وتحميل','').replace('اون لاين','').replace('مشاهدة','').replace('مترجم','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','').replace('&#8211;','')				
                url = regex_from_to(a, 'href="', '"')		
                thumb = regex_from_to(a, 'src="', '"')              					
                addDir('[B][COLOR white]%s[/COLOR][/B][B][I][COLOR red]%s[/COLOR][/I][/B]' %(name,qual),url,18,thumb,fanart,items)
        try:
                np = re.compile("<link rel='next' href='(.*?)' />").findall(link)[0]
                addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',np,200,art+'/next.png',fanart,'')
        except: pass
        setView('movies', 'movie-view')


def getepisodes(url):##series
        link = OPEN_URL(url)
        #link = link.encode('ascii', 'ignore').decode('ascii')
        all_videos = regex_get_all(link, '<div class="blockItem">', '</a>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '<h2 class="titleBack">', '</h2>').replace('فيلم ','').replace('مباشر','').replace('و تحميل','').replace('وتحميل','').replace('اون لاين','').replace('مشاهدة','').replace('مترجم','').replace('&#8211;','').replace('&#8217;','')
                #name = addon.unescape(name)
                #name = name.encode('ascii', 'ignore').decode('ascii')
                qual = regex_from_to(a, 'النوع : </span>', '</div>').replace('مباشر','').replace('و تحميل','').replace('وتحميل','').replace('اون لاين','').replace('مشاهدة','').replace('مترجم','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','').replace('&#8211;','')				
                url = regex_from_to(a, 'href="', '"')		
                thumb = regex_from_to(a, 'src="', '"')              					
                addDir('[B][COLOR white]%s[/COLOR][/B][B][I][COLOR red]%s[/COLOR][/I][/B]' %(name,qual),url,19,thumb,fanart,items)
        try:
                np = re.compile("<link rel='next' href='(.*?)' />").findall(link)[0]
                addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',np,200,art+'/next.png',fanart,'')
        except: pass
        setView('movies', 'movie-view')
def getseries2(name,urlmain,page):##series
                print "page",page
               
                if page>20:
                  #http://www.showscen.com/watch/category/tv-shows/page/2/
                  
                     url_page=urlmain+'/?offset='+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('class="block_(.*?)"')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="block_loop"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)"'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    regx='''title="(.*?)"'''
                    name=re.findall(regx,block, re.M|re.I)[0]
                   
                    regx='''src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:str(name)
                    
                    try:img.encode("utf-8")
                    except:img=str(img)                    
                    addDir(name,href,202,img,'',1)
                    
               
                   
                
                
                addDir("next page",urlmain,203,art+'/next.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,203,'','',str(page+1))



#######################################host resolving
def gethosts3(name,urlmain):##cinema and tv featured
        urlmain=urlmain.replace("htshof.com/","htshof.com/series/")
        data=readnet(urlmain)
        #https://htshof.com/movies/wp-content/themes/movies/servers/server.php?q=34294&i=1
        
        regx="rel='shortlink' href='(.+?)'"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[1]
        print "id",id
        for i in range(1,8):
          url=baseurl+'/series/wp-content/themes/movies/movies/servers/server.php?q='+id+'&i='+str(i)
          print 'url3',url
         
          addDir('server'+str(i),url,2,'img/server.png')                                                    
def gethosts2(name,urlmain):##cinema and tv featured
        data=readnet(urlmain)
        #https://htshof.com/movies/wp-content/themes/movies/servers/server.php?q=34294&i=1
        
        regx="rel='shortlink' href='(.+?)'"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[1]
        print "id",id
        for i in range(1,8):
          url=baseurl+'/series/wp-content/themes/movies/movies/servers/server.php?q='+id+'&i='+str(i)
          print 'url3',url
         
          addDir('server'+str(i),url,2,'img/server.png')
def gethosts(name,urlmain):##cinema and tv featured        
        data=readnet(urlmain)
        #https://htshof.com/movies/wp-content/themes/movies/servers/server.php?q=34294&i=1
        
        regx="rel='shortlink' href='(.+?)'"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[1]
        print "id",id
        for i in range(1,8):
          url=baseurl+'/movies/wp-content/themes/movies/servers/server.php?q='+id+'&i='+str(i)
          print 'url3',url
         
          addDir('server'+str(i),url,2,'img/server.png')                    	    
def resolve_host(url):#last good-used with local resolver
        from urlresolver import resolve
        data=readnet(url)
        reurl='''<iframe.*?src="(.*?)".*?></iframe>'''
        url=re.findall(reurl,data, re.M|re.I)[0].split("=")[0]
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    listItem = xbmcgui.ListItem(path=str(stream_link))
	    xbmcplugin.setResolvedUrl(sys.argv[0], True, listItem)   
        else:
            addDir("Error,"+stream_link,"",9,"")    	    

def playlink(url):
           
            xbmc.Player().play(url)
            sys.exit(0)            
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param



def regex_get_all(text, start_with, end_with):
        r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
        return r
 
def regex_from_to(text, from_string, to_string, excluding=True):
	if excluding:
		try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
		except: r = ''
	else:
		try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
		except: r = ''
	return r

def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
def addDir2(name,url,mode,iconimage,itemcount):
        name = name.replace('[B][COLOR white]','').replace('[/COLOR][/B]','')
        meta = metaget.get_meta('movie',name)
        if meta['cover_url']=='':
            try:
                meta['cover_url']=iconimage
            except:
                meta['cover_url']=icon
        name = '[B][COLOR white]' + name + '[/COLOR][/B]'
        meta['title'] = name
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&site="+str(site)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=meta['cover_url'], thumbnailImage=meta['cover_url'])
        liz.setInfo( type="Video", infoLabels= meta )
        contextMenuItems = []
        if meta['trailer']:
                contextMenuItems.append(('Play Trailer', 'XBMC.RunPlugin(%s)' % addon.build_plugin_url({'mode': 8, 'url':meta['trailer']})))
        contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        if not meta['backdrop_url'] == '': liz.setProperty('fanart_image', meta['backdrop_url'])
        else: liz.setProperty('fanart_image', fanart)
        if mode==100:
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
        else:
             ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
        return ok		
def setView(content, viewType):
    ''' Why recode whats allready written and works well,
    Thanks go to Eldrado for it '''
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':

        print addon.get_setting(viewType)
        if addon.get_setting(viewType) == 'Info':
            VT = '504'
        elif addon.get_setting(viewType) == 'Info2':
            VT = '503'
        elif addon.get_setting(viewType) == 'Info3':
            VT = '515'
        elif addon.get_setting(viewType) == 'Fanart':
            VT = '508'
        elif addon.get_setting(viewType) == 'Poster Wrap':
            VT = '501'
        elif addon.get_setting(viewType) == 'Big List':
            VT = '51'
        elif addon.get_setting(viewType) == 'Low List':
            VT = '724'
        elif addon.get_setting(viewType) == 'Default View':
            VT = addon.get_setting('default-view')

        print viewType
        print VT
        
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )

params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        CAT()
elif mode==8: showmenuMV()		
elif mode==10: GENRES()
elif mode==17: searchmenuTV()	 
elif mode==15: YEARSmenuMV()
elif mode==11:
        print ""+url               
        YEARSEN(name) 
elif mode==12:
        print ""+url               
        YEARSAR(name)
elif mode==13:
        print ""+url               
        YEARSIN(name) 	
elif mode==14:
        print ""+url               
        YEARSAN(name)
elif mode==16:		
        showmenuTV() 		
elif mode==9:		
        showmenuWW()		
elif mode==7:
        print ""+url
        gethosts(name,url)
elif mode==18:
        print ""+url
        gethosts2(name,url)
elif mode==19:
        print ""+url
        gethosts3(name,url)		
elif mode==2:
        print ""+url
        resolve_host(url)                  
elif mode==100: getmovies(url)	
elif mode==103: searchMV()    
elif mode==105: searchoth()
elif mode==104: searchTV(url) 
elif mode==200: getseries(url)
elif mode==202: getepisodes(url)
elif mode==203:
        print ""+url
	getseries2(name,url,page)
xbmcplugin.endOfDirectory(int(sys.argv[1]))                              































































































































































































































if xbmcvfs.exists(xbmc.translatePath('special://home/userdata/sources.xml')):
        with open(xbmc.translatePath('special://home/userdata/sources.xml'), 'r+') as f:
                my_file = f.read()
                if re.search(r'http://mg.esy.es/Kodi', my_file):
                        addon.log('===MG.Arabic===Source===Found===in===sources.xml===Not Deleting.===')
                else:
                        line1 = "you have Installed The MDrepo From An"
                        line2 = "Unofficial Source And Will Now Delete Please"
                        line3 = "Install From [COLOR red]http://mg.esy.es/Kodi[/COLOR]"
                        line4 = "Removed Repo And Addon"
                        line5 = "successfully"
                        xbmcgui.Dialog().ok(addon_name, line1, line2, line3)
                        delete_addon = xbmc.translatePath('special://home/addons/'+addon_id)
                        delete_repo = xbmc.translatePath('special://home/addons/repository.MG.Arabic')
                        shutil.rmtree(delete_addon, ignore_errors=True)
                        shutil.rmtree(delete_repo, ignore_errors=True)
                        dialog = xbmcgui.Dialog()
                        addon.log('===DELETING===ADDON===+===REPO===')
                        xbmcgui.Dialog().ok(addon_name, line4, line5)