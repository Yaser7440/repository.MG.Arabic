# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, dandy, xbmcaddon
from addon.common.addon import Addon
import requests
import os, json
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.1080pmovies_gw'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = '1080pmovies_gw'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"
BASEURL = 'http://1movies.im'
USERDATA_PATH = xbmc.translatePath('special://home/userdata/addon_data')
ADDON_DATA = os.path.join(USERDATA_PATH,'plugin.video.1080pmovies_gw')
if not os.path.exists(ADDON_DATA):
    os.makedirs(ADDON_DATA)
favourites = os.path.join(ADDON_DATA, 'favourites')
if os.path.exists(favourites) == True:
    FAV = open(favourites).read()
else:
    FAV = []


def Main_menu():
    addDir('[B][COLOR white]Latest Movies[/COLOR][/B]',BASEURL + '/movies/latest',5,ART + 'lat_mov.jpg',FANART,'')
    addDir('[B][COLOR white]Most Viewed[/COLOR][/B]',BASEURL+'/movies/mostviewed',5,ART + 'mostv.jpg',FANART,'')
    addDir('[B][COLOR white]Hot[/COLOR][/B]',BASEURL+'/movies/hot',5,ART + 'hot.jpg',FANART,'')
    addDir('[B][COLOR white]Genres[/COLOR][/B]',BASEURL,3,ART + 'bygenre.jpg',FANART,'')
    addDir('[B][COLOR white]Release Year[/COLOR][/B]',BASEURL,2,ART + 'by_year.jpg',FANART,'')
    addDir('[B][COLOR white]Country[/COLOR][/B]',BASEURL,4,ART + 'count.jpg',FANART,'')
    addDir('[B][COLOR white]TV Shows[/COLOR][/B]',BASEURL+'/movies/series',5,ART + 'tvshows.jpg',FANART,'')
    addDir('[B][COLOR white]Search All[/COLOR][/B]','url',6,ART + 'search.jpg',FANART,'')
    addDir('[B][COLOR red]Your Favourites[/COLOR][/B]','url',10,ART + 'search.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_content(url):    
    OPEN = Open_Url(url)
    ref=url
    Regex = re.compile('<div class="item_movie".+?href="(.+?)" title="(.+?)".+?img src=".+?url=(.+?)"',re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
        if 'http:' not in url:
            url= 'http:' + url
        icon = 'http:' + icon + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36&Referer='+ref
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,FANART,'')
    np = re.compile('class="c-content-pagination c-theme">(.+?)</ul>',re.DOTALL).findall(OPEN)
    np2 = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(np)) 
    for url,page in np2:
        if '&gt;&gt;' in page:
            addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
    setView('movies', 'movie-view')
    
def Get_Genres(url):
    OPEN = Open_Url(url)
    Regex = re.compile('title="Genre"(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)">',re.DOTALL).findall(str(Regex))
    for url in Regex2:
        name = url.split('/')[2].title()
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,5,ART + 'bygenre.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_country(url):
    OPEN = Open_Url(url)
    Regex = re.compile('title="Country"(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)"',re.DOTALL).findall(str(Regex))
    for url in Regex2:
        name = url.split('/')[2].upper()
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,5,ART + 'count.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_year(url):
    OPEN = Open_Url(url)
    Regex = re.compile('Release years(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)" title="(.+?)">',re.DOTALL).findall(str(Regex))
    for url, name in Regex2:
        #url = 'http:' + url
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,ART + 'by_year.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')	

def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = 'https://search.1movies.im/?q=' + search
                Get_content(url)
    
def search_res(url):    
    OPEN = Open_Url(url)
    ref=url
    Regex = re.compile('<div class="item_movie".+?href="(.+?)" title="(.+?)".+?img src=".+?url=(.+?)"',re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
        icon = 'http:' + icon + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36&Referer='+ref
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,FANART,'')
    
def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def addDir(name,url,mode,iconimage,fanart,description,showcontext=True):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
    liz.setProperty('fanart_image', fanart)
    if mode==100:
        if showcontext:
            contextMenu = []
            if showcontext == 'fav':
                contextMenu.append(('Remove from 1080p Favorites', 'XBMC.RunPlugin(%s?mode=12&name=%s)'
                                % (sys.argv[0], urllib.quote_plus(name))))
            if not name in FAV:
                contextMenu.append(('Add to 1080p Favorites',
                                    'XBMC.RunPlugin(%s?mode=11&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=%s)'
                                    % (sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(url),
                                        urllib.quote_plus(iconimage), urllib.quote_plus(fanart), mode)))
            contextMenu.append(('Queue Item', 'RunPlugin(%s?mode=13)' % sys.argv[0]))
            liz.addContextMenuItems(contextMenu)
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def setView(content, viewType):
    ''' Why recode whats allready written and works well,
    Thanks go to Eldrado for it '''
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':

        print addon.get_setting(viewType)
        if addon.get_setting(viewType) == 'Info':
            VT = '504'
        elif addon.get_setting(viewType) == 'Info2':
            VT = '503'
        elif addon.get_setting(viewType) == 'Info3':
            VT = '515'
        elif addon.get_setting(viewType) == 'Fanart':
            VT = '508'
        elif addon.get_setting(viewType) == 'Poster Wrap':
            VT = '501'
        elif addon.get_setting(viewType) == 'Big List':
            VT = '51'
        elif addon.get_setting(viewType) == 'Low List':
            VT = '724'
        elif addon.get_setting(viewType) == 'List':
            VT = '50'
        elif addon.get_setting(viewType) == 'Default Menu View':
            VT = addon.get_setting('default-view1')
        elif addon.get_setting(viewType) == 'Default TV Shows View':
            VT = addon.get_setting('default-view2')
        elif addon.get_setting(viewType) == 'Default Episodes View':
            VT = addon.get_setting('default-view3')
        elif addon.get_setting(viewType) == 'Default Movies View':
            VT = addon.get_setting('default-view4')
        elif addon.get_setting(viewType) == 'Default Docs View':
            VT = addon.get_setting('default-view5')
        elif addon.get_setting(viewType) == 'Default Cartoons View':
            VT = addon.get_setting('default-view6')
        elif addon.get_setting(viewType) == 'Default Anime View':
            VT = addon.get_setting('default-view7')

        print viewType
        print VT
        
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )

    
def resolve(url):
    OPEN = Open_Url(url)
    REFX=url
    if 'class="full list_ep"' in OPEN:
        res_quality = []
        stream_url = []
        quality = ''
        match = re.compile('class="ep_link full"(.+?)</div>',re.DOTALL).findall(OPEN)
        match2 = re.compile('href="(.+?)" class=".+?>(.+?)</a>',re.DOTALL).findall(str(match)) 
        for link,label in match2:
            #link = 'http:'+link
            quality = '[B][COLOR white]%s[/COLOR][/B]' %label        
            res_quality.append(quality)
            stream_url.append(link)
        if len(match2) >1:
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Please Select Episode',res_quality)
            if ret == -1:
                return
            elif ret > -1:
                newurl = stream_url[ret]
        else:
            pass
            #url = re.compile('<h3>.+?href="(.+?)"',re.DOTALL).findall(OPEN)[0]
        EPISODE = Open_Url(newurl)
        REFX=newurl        
        movID = re.compile('load_player\((.+?)\)',re.DOTALL).findall(EPISODE)[0]
        headers = {'User-Agent':User_Agent,'Referer':newurl}
        try:
            get_url = '%s/ajax/movie/load_player_v3?retry=2&id=%s' %(BASEURL,movID)
        except:
            get_url = '%s/ajax/movie/load_player_v3?id=%s' %(BASEURL,movID)
        link=requests.get(get_url,headers=headers).content
        holder = re.compile('"value":"(.+?)"',re.DOTALL).findall(link)[0]
        holder = 'http:'+holder
        holder = holder.replace('\/','/')
        headers = {'User-Agent':User_Agent,'Referer':newurl}
        final = requests.get(holder,headers=headers).content
        print 'final>>>'        
        url = re.compile('"file":"(.+?)"',re.DOTALL).findall(final)[0]
        url = url.replace('\/','/')
        url = url+'|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36&Referer='+REFX        
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
       
    else:
        print 'THISROUTE:::::::::::::::::::::::::::::::::::::'    
        movID = re.compile('load_player\((.+?)\)',re.DOTALL).findall(OPEN)[0]
        headers = {'User-Agent':User_Agent,'Referer':url}
        try:
            get_url = '%s/ajax/movie/load_player_v3?retry=2&id=%s' %(BASEURL,movID) 
        except:
            get_url = '%s/ajax/movie/load_player_v3&id=%s' %(BASEURL,movID)
        link=requests.get(get_url,headers=headers).content
        holder = re.compile('"value":"(.+?)"',re.DOTALL).findall(link)[0]
        print 'holder gw> ' +holder
        holder = 'http:'+holder
        holder = holder.replace('\/','/')
        print '2ndholder gw> ' +holder
        headers = {'User-Agent':User_Agent,'Referer':url}
        final = requests.get(holder,headers=headers).content    
        url = re.compile('"file":"(.+?)"',re.DOTALL).findall(final)[0]
        print 'gwurl >' +url
        url = url.replace('\/','/')
        url = url+'|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36&Referer='+REFX        
        print 'gwurl >' +url        
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

# ===============================Favourites================================

def queueItem():
    return xbmc.executebuiltin('Action(Queue)')

def addFavorite(name, url, mode, iconimage, fanart, desc):
    favList = []
    try:
        # seems that after
        name = name.encode('utf-8', 'ignore')
    except:
        pass
    if os.path.exists(favourites) == False:
        favList.append((name, url, mode, iconimage, fanart, desc))
        a = open(favourites, "w")
        a.write(json.dumps(favList))
        a.close()
    else:
        a = open(favourites).read()
        data = json.loads(a)
        data.append((name, url, mode, iconimage, fanart, desc))
        b = open(favourites, "w")
        b.write(json.dumps(data))
        b.close()


def getFavourites():
    if os.path.exists(favourites) == False:
        favList = []
        favList.append(('1080pmovies Section', '', '', '', '', ''))
        a = open(favourites, "w")
        a.write(json.dumps(favList))
        a.close()
    else:
        items = json.loads(open(favourites).read())
        for i in items:
            name = i[0]
            url = i[1]
            mode = i[2]
            iconimage = i[3]
            fanart = i[4]
            desc = i[5]
            addDir(name, url, mode, iconimage, fanart, '', 'fav')


def rmFavorite(name):
    data = json.loads(open(favourites).read())
    for index in range(len(data)):
        if data[index][0] == name:
            del data[index]
            b = open(favourites, "w")
            b.write(json.dumps(data))
            b.close()
            break
    xbmc.executebuiltin("XBMC.Container.Refresh")


############################## FAVOURITES END ###############################

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None
fav_mode=None


try:
    fav_mode=int(params["fav_mode"])
except:
    pass
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 2: Get_year(url)
elif mode == 3: Get_Genres(url)
elif mode == 4: Get_country(url)
elif mode == 5 : Get_content(url)
elif mode == 6 : Search()
elif mode == 10: getFavourites()
elif mode==11:
    try:
        name = name.split('\\ ')[1]
    except:
        pass
    try:
        name = name.split('  - ')[0]
    except:
        pass
    addFavorite(name, url, fav_mode, iconimage, fanart, description)
elif mode==12:
    try:
        name = name.split('\\ ')[1]
    except:
        pass
    try:
        name = name.split('  - ')[0]
    except:
        pass
    rmFavorite(name)
elif mode == 13 : queueItem()
elif mode == 100 : resolve(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
