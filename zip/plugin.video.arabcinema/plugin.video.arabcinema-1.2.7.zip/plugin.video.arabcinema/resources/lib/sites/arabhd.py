import re
import os
import sys
import sqlite3
import urllib

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils

progress = utils.progress
mobileagent = {'User-Agent': 'Mozilla/5.0 (Linux; U; Android 2.2; en-us; Droid Build/FRG22D) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1'}
arabhd = 'http://arabhd.co/'

@utils.url_dispatcher.register('280')
def Main():
    #utils.addDir('[COLOR red]Refresh Cam4 images[/COLOR]','',283,'',Folder=False)
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]MENU[/B]',arabhd,284,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]MOVIES[/B]',arabhd + 'category/movies/',281,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Years[/B]',arabhd,285,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]SEARCH[/B]',arabhd + '?s=',286,'','')
    List(arabhd,'')
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('284', ['url'])
def Cat(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<div class="mainMenu">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    match1 = re.compile('<li id=".*?class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-.*?><a href="([^"]+)">([^<]+)</a></li>', re.DOTALL | re.IGNORECASE).findall(match[0])
    for caturl, name in match1:

        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, caturl, 281, '', 1)
    xbmcplugin.endOfDirectory(utils.addon_handle)
	
@utils.url_dispatcher.register('285', ['url'])
def Years(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<div class="yearSpan">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    match1 = re.compile('<a href="([^"]+)"><p>([^<]+)</p></a>', re.DOTALL | re.IGNORECASE).findall(match[0])
    for caturl, name in match1:

        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, caturl, 281, '', 1)
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('286', ['url'], ['keyword'])  
def TPSearch(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 286)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title 
        print "Searching URL: " + searchUrl
        List(searchUrl, 1)
		
@utils.url_dispatcher.register('283')
def clean_database(showdialog=True):
    conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % ".cam4s.com")
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try: os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
                except: pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % ".cam4s.com")
            if showdialog:
                utils.notify('Finished','Cam4 images cleared')
    except:
        pass


@utils.url_dispatcher.register('281', ['url'], ['page'])
def List(url, page=1):
    # if utils.addon.getSetting("chaturbate") == "true":
        # clean_database(False)
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None
    match = re.compile(r'<div class="blockItem">.*?href="([^"]+)">.*?<img src="([^"]+)".*?<h2 class="titleBack">([^"]+)</h2>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, name in match:
          if thumb.startswith('//'): thumb = 'http://' + thumb  
          # desc = utils.cleantext(desc)
          # desc = utils.cleanhtml(desc)
          name = utils.cleantext(name)
          name = utils.cleanhtml(name)
		 
          utils.addDownLink('[B]%s[/B]' %name,videourl,282,thumb,'','')
    try:
          np = re.compile('href="(.+?)".*?&laquo;</a></li>').findall(listhtml)[0]
          utils.addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',np,281,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('282', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    progress.create('Play video', 'Searching videofile.')
    progress.update( 25, "", "Loading video page", "" )
    data = utils.getHtml(url, '')
    if "rel='shortlink'" in data:
        res_quality = []
        stream_url = []
        quality = ''
        regx="rel='shortlink' href='.*?p=(.+?)'"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[0]
        print "id",id
        #range=['1','2','3','4','5','6','7','8']
        for i in range(1,6):
          catpage='http://arabhd.co/wp-content/themes/MA/servers/server.php?q=' + id + '&i=' + str(i)
          print catpage
          quality = '[B][COLOR white]SERVER [%s][/COLOR][/B]' %str(i)
          res_quality.append(quality)
          stream_url.append(catpage)
        if len(id) >0:
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Please Select Servers',res_quality)
            if ret == -1:
                return
            elif ret > -1:
                videourl = stream_url[ret]
            try:
                    server = utils.getHtml(videourl, url)
            except:
                   return None
        a = re.compile('''src="(.*?)"''', re.DOTALL | re.IGNORECASE).findall(server)
        b = re.compile('''<ifram.*?src="([^'"]+)"''', re.DOTALL | re.IGNORECASE).findall(server)
        c = re.compile('''<IFRAM.*?SRC=([^'"]+)".*?</IFRAME>''', re.DOTALL | re.IGNORECASE).findall(server)
        d = re.compile('''<ifram.*?src="([^'"]+)".*?</iframe>''', re.DOTALL | re.IGNORECASE).findall(server)
        try:
           videourl = a[0]
        except:
            try:
               videourl = b[0]
            except:
                try:
                   videourl = c[0]
                except:
                      videourl = d[0]
        if videourl:
            utils.playvideo(videourl, name, download, url)
        else:
            utils.notify('Oh oh','Couldn\'t find a video')
