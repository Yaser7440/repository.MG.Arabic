import xbmcgui
import urllib
import re
import os.path
import sys
import socket

import xbmc
import xbmcplugin
import xbmcaddon
from resources.lib import utils
from resources.lib import favorites
from resources.lib.sites import *

socket.setdefaulttimeout(60)

xbmcplugin.setContent(utils.addon_handle, 'movies')
addon = xbmcaddon.Addon(id=utils.__scriptid__)

progress = utils.progress
dialog = utils.dialog

imgDir = utils.imgDir
rootDir = utils.rootDir

@utils.url_dispatcher.register('0')
def INDEX():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR red][B]http://mg.esy.es/Kodi/[/B][/COLOR]','','',os.path.join(rootDir, 'fanart.jpg'),'Developed By (http://mg.esy.es/Kodi/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]6arbyat[/B]','http://www.6arbyat.com/',40,os.path.join(imgDir, 'tarbyat.png'),'The Website is (http://www.6arbyat.com/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]HD-Arab[/B]','https://hd-arab.com/',90,os.path.join(imgDir, 'hdarab.png'),'The Website is (https://hd-arab.com/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]AlArab[/B]','http://tv1.alarab.com/',50,os.path.join(imgDir, 'alarab.png'),'The Website is (http://tv1.alarab.com/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]MoviesWBB[/B]','http://movieswbb.com/',80,os.path.join(imgDir, 'movieswbb.png'),'The Website is (http://movieswbb.com/)')
   #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Mago.Tv[/B]','http://www.mago.tv',260,os.path.join(imgDir, 'mago.tv.png'),'The Website is (http://www.mago.tv)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Shof[/B]','http://shof.co.il/',340,os.path.join(imgDir, 'shof.png'),'The Website is (http://shof.co.il/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]SeeHD[/B]','http://www.seehd.ws/',450,os.path.join(imgDir, 'seehd.png'),'The Website is (http://www.seehd.ws/)')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Shahid4u[/B]','http://shahid4u.com/',179,os.path.join(imgDir, 'shahid4u.png'),'The Website is (http://shahid4u.com/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]AnakbNet[/B]','http://www.anakbnet.com/video/',182,os.path.join(imgDir, 'anakbnet.png'),'The Website is (http://www.anakbnet.com/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]El7l.Tv[/B]','https://el7l.tv/',10,os.path.join(imgDir, 'el7l.png'),'The Website is (https://el7l.tv/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]AlMstba[/B]','https://www.almstba.tv/',245,os.path.join(imgDir, 'almstba.png'),'The Website is (https://www.almstba.tv/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Arab-Moviez[/B]','http://arab-moviez.org/',230,os.path.join(imgDir, 'arab.moviez.png'),'The Website is (http://arab-moviez.org/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]4oof[/B]','http://www.4oof.com/',60,os.path.join(imgDir, '4oof.png'),'The Website is (http://www.4oof.com/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Streamlord[/B]','http://www.streamlord.com/',480,os.path.join(imgDir, 'streamlord.png'),'The Website is (http://www.streamlord.com/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Arablionz[/B]','http://arablionz.tv',200,os.path.join(imgDir, 'arablionz.png'),'The Website is (http://arablionz.tv/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Series4Watch[/B]','http://www.series4watch.tv',100,os.path.join(imgDir, 'series4watch.png'),'The Website is (http://www.series4watch.tv)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]AflamyOnlinee[/B]','http://www.aflamyonlinee.com/',370,os.path.join(imgDir, 'aflamyonlinee.png'),'The Website is (http://www.aflamyonlinee.com//)')
   #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]AflamyHD[/B]','http://www.aflamyhd.com/',250,os.path.join(imgDir, 'aflamyhd.png'),'The Website is (http://www.aflamyhd.com/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]ShahidLive[/B]','http://shahidlive.co',475,os.path.join(imgDir, 'shahidlive.png'),'The Website is (http://shahidlive.co)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]ArabHD[/B]','http://arabhd.co/',280,os.path.join(imgDir, 'arabhd.png'),'The Website is (http://arabhd.co/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]MovizLand[/B]','http://movizland.com/',270,os.path.join(imgDir, 'movizland.png'),'The Website is (http://movizland.com/)')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Egy.Best[/B]','http://egy.best',110,os.path.join(imgDir, 'egybest.png'),'The Website is (http://egy.best/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]CinmaStar[/B]','https://cinmastar.com/',470,os.path.join(imgDir, 'cinmastar.png'),'The Website is (https://cinmastar.com/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Aflamonlinee[/B]','http://www.aflamonlinee.org/new/',320,os.path.join(imgDir, 'aflamonlinee.png'),'The Website is (http://www.aflamonlinee.org/new/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Movie4k[/B]','http://movie4k.tv/',360,os.path.join(imgDir, 'movie4k.png'),'The Website is (http://movie4k.tv/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]123MoviesHub[/B]','http://123movieshub.com/',420,os.path.join(imgDir, '123movieshub.png'),'The Website is (http://123movieshub.com/)')		
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]CimaClub[/B]','http://cimaclub.com/',310,os.path.join(imgDir, 'cimaclub.png'),'The Website is (http://cimaclub.com/)')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Htshof[/B]','https://htshof.com',130,os.path.join(imgDir, 'hatshof.png'),'The Website is (https://htshof.com)')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Mazika2day[/B]','https://mazika2day.tv',20,os.path.join(imgDir, 'mazika2day.png'),'The Website is (https://mazika2day.tv)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]beout[COLOR purple]Q[/COLOR] Sport [COLOR yellow]TEST[/COLOR][/B]','http://beoutq.se/ar/',380,os.path.join(imgDir, 'beoutq.png'),'The Website is (http://beoutq.se/ar/ And https://cdn.streaminghd.tn/)')
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]IPTV[/B] [B][COLOR yellow]TEST[/COLOR][/B]','http://iptv.filmover.com/',610,'','The Website is (http://iptv.filmover.com/)')	
   #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]EasyCima[/B][/COLOR] : [B][COLOR yellow]Not Yet[/COLOR][/B]','http://www.easycima.com/',400,os.path.join(imgDir, 'mrsexe.png'),'The Website is (http://www.easycima.com/)')		
  # utils.addDir('[COLOR red]MG.Arabic[/COLOR] Movies[/COLOR]','',2,os.path.join(rootDir, 'icon.png'),'The Website is ')
  # utils.addDir('[COLOR red]MG.Arabic[/COLOR] Hentai[/COLOR]','',3,os.path.join(rootDir, 'icon.png'),'The Website is ')
  # utils.addDir('[COLOR red]MG.Arabic[/COLOR] Tubes[/COLOR]','',6,os.path.join(rootDir, 'icon.png'),'The Website is ')
  # utils.addDir('[COLOR red]MG.Arabic[/COLOR] Webcams & Streams[/COLOR]','',7,os.path.join(rootDir, 'icon.png'),'The Website is ')
    utils.add_item(title="[COLOR red]MG.Arabic[/COLOR] [B]RadioTime[/B]",url="plugin://plugin.audio.tuneinradio/default.py",thumbnail=os.path.join(imgDir, 'radiotime.png'),folder=True )
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Favorites[/B]','',901,os.path.join(rootDir, 'icon.png'),'')
    download_path = addon.getSetting('download_path')
    if download_path != '' and os.path.exists(download_path):
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Download Folder[/B]',download_path,4,os.path.join(rootDir, 'icon.png'),'')
    xbmcplugin.endOfDirectory(utils.addon_handle, cacheToDisc=False)

# @utils.url_dispatcher.register('1')
# def INDEXS():
    # if sys.version_info >= (2, 7, 9):
        # utils.addDir('[COLOR hotpink]WatchXXXFree[/COLOR]','http://www.watchxxxfree.com/page/1/',10,os.path.join(imgDir, 'wxf.png'),'')
        # utils.addDir('[COLOR hotpink]PornTrex[/COLOR]','http://www.porntrex.com/videos?o=mr&page=1',50,os.path.join(imgDir, 'pt.png'),'')
    # utils.addDir('[COLOR hotpink]PornAQ[/COLOR]','http://www.pornaq.com/page/1/',60,os.path.join(imgDir, 'paq.png'),'')
    # utils.addDir('[COLOR hotpink]Porn00[/COLOR]','http://www.porn00.com/page/1/',64,os.path.join(imgDir, 'p00.png'),'')

    # utils.addDir('[COLOR hotpink]ElReyX[/COLOR]','http://elreyx.com/index1.html',110,os.path.join(imgDir, 'elreyx.png'),'')
    # utils.addDir('[COLOR hotpink]XvideoSpanish[/COLOR]','http://www.xvideospanish.com/',130,os.path.join(imgDir, 'xvideospanish.png'),'')
    # utils.addDir('[COLOR hotpink]HQPorner[/COLOR]','http://hqporner.com/hdporn/1',150,os.path.join(imgDir, 'hqporner.png'),'')
    # utils.addDir('[COLOR hotpink]VideoMegaPorn[/COLOR]','http://www.videomegaporn.com/index.html',160,os.path.join(imgDir, 'videomegaporn.png'),'')
    # #utils.addDir('[COLOR hotpink]StreamXXX[/COLOR]','http://streamxxx.tv/category/clips/',170,os.path.join(imgDir, 'streamxxx.png'),'')
    # utils.addDir('[COLOR hotpink]JustPorn[/COLOR]','http://justporn.to/category/scenes/',240,os.path.join(imgDir, 'justporn.png'),'')
    # utils.addDir('[COLOR hotpink]YourFreeTube[/COLOR]','http://www.yourfreetube.net/newvideos.html',190,'','')
    # utils.addDir('[COLOR hotpink]Xtasie[/COLOR]','http://xtasie.com/porn-video-list/page/1/',200,os.path.join(imgDir, 'xtasie.png'),'')
    # utils.addDir('[COLOR hotpink]HD Zog[/COLOR]','http://www.hdzog.com/new/',340,os.path.join(imgDir, 'hdzog.png'),'')    
    # utils.addDir('[COLOR hotpink]Mr Sexe[/COLOR]','http://www.mrsexe.com/',400,os.path.join(imgDir, 'mrsexe.png'),'')
    # utils.addDir('[COLOR hotpink]Ero-tik[/COLOR]','http://www.ero-tik.com/',260,os.path.join(imgDir, 'erotik.png'),'')
     
    # utils.addDir('[COLOR hotpink]XXX Streams (eu)[/COLOR]','http://xxxstreams.eu/',410,os.path.join(imgDir, 'xxxstreams.png'),'')
    # utils.addDir('[COLOR hotpink]XXX Streams (org)[/COLOR]','http://xxxstreams.org/',420,os.path.join(imgDir, 'xxxsorg.png'),'')
    # utils.addDir('[COLOR hotpink]K18[/COLOR]','http://k18.co/',230,os.path.join(imgDir, 'k18.png'),'')
    # utils.addDir('[COLOR hotpink]Sexix[/COLOR]','http://sexix.net/','',os.path.join(imgDir, 'sexix.png'),'')
    # utils.addDir('[COLOR hotpink]daftsex[/COLOR]','https://daftsex.com/',610,'','')

    # utils.addDir('[COLOR hotpink]One list, to watch them all[/COLOR]','',5,'',1)
    # xbmcplugin.endOfDirectory(utils.addon_handle, cacheToDisc=False)

# @utils.url_dispatcher.register('2')
# def INDEXM():
    # if sys.version_info >= (2, 7, 9):
        # utils.addDir('[COLOR hotpink]Xtheatre[/COLOR]','http://xtheatre.net/page/1/',20,os.path.join(imgDir, 'xt.png'),'')
    # utils.addDir('[COLOR hotpink]PornHive[/COLOR]','http://www.pornhive.tv/en/movies/all',70,os.path.join(imgDir, 'ph.png'),'')
    # utils.addDir('[COLOR hotpink]ElReyX[/COLOR]','http://elreyx.com/index1.html',116,os.path.join(imgDir, 'elreyx.png'),'')
    # utils.addDir('[COLOR hotpink]PelisxPorno[/COLOR]','http://www.pelisxporno.com/',140,os.path.join(imgDir, 'pelisxporno.png'),'')
    # utils.addDir('[COLOR hotpink]StreamXXX[/COLOR]','http://streamxxx.tv/category/movies/',175,os.path.join(imgDir, 'streamxxx.png'),'')
    # utils.addDir('[COLOR hotpink]Cat3Movie[/COLOR]','http://cat3movie.us',350,os.path.join(imgDir, 'cat3movie.png'),'')
    # utils.addDir('[COLOR hotpink]ParadiseHill[/COLOR]','http://www.paradisehill.tv/en/',250,os.path.join(imgDir, 'paradisehill.png'),'')
    # utils.addDir('[COLOR hotpink]FreeOMovie[/COLOR]','http://www.freeomovie.com/',370,os.path.join(imgDir, 'freeomovie.png'),'')
    # utils.addDir('[COLOR hotpink]Eroticage[/COLOR]','http://www.eroticage.net/',430,'','')
    # xbmcplugin.endOfDirectory(utils.addon_handle, cacheToDisc=False)

# @utils.url_dispatcher.register('6')
# def INDEXT():
    # utils.addDir('[COLOR hotpink]BubbaPorn[/COLOR]','http://3lbh.net/',90,os.path.join(imgDir, 'bubba.png'),'')
    # utils.addDir('[COLOR hotpink]Poldertube.nl[/COLOR] [COLOR orange](Dutch)[/COLOR]','http://www.poldertube.nl/pornofilms/nieuw',100,os.path.join(imgDir, 'poldertube.png'),0)
    # utils.addDir('[COLOR hotpink]Milf.nl[/COLOR] [COLOR orange](Dutch)[/COLOR]','http://www.milf.nl/videos/nieuw',100,os.path.join(imgDir, 'milfnl.png'),1)
    # utils.addDir('[COLOR hotpink]Sextube.nl[/COLOR] [COLOR orange](Dutch)[/COLOR]','http://www.sextube.nl/videos/nieuw',100,os.path.join(imgDir, 'sextube.png'),2)
    # utils.addDir('[COLOR hotpink]TubePornClassic[/COLOR]','http://www.tubepornclassic.com/latest-updates/',360,os.path.join(imgDir, 'tubepornclassic.png'),'')
    # utils.addDir('[COLOR hotpink]HClips[/COLOR]','http://www.hclips.com/latest-updates/',380,os.path.join(imgDir, 'hclips.png'),'')
    # utils.addDir('[COLOR hotpink]PornHub[/COLOR]','http://www.pornhub.com/newest.html',390,os.path.join(imgDir, 'pornhub.png'),'')
    # utils.addDir('[COLOR hotpink]Porndig[/COLOR] Professional[/COLOR]','http://www.porndig.com',290,os.path.join(imgDir, 'porndig.png'),'')
    # utils.addDir('[COLOR hotpink]Porndig[/COLOR] Amateurs[/COLOR]','http://www.porndig.com',290,os.path.join(imgDir, 'porndig.png'),'')
    # utils.addDir('[COLOR hotpink]AbsoluPorn[/COLOR]','http://www.absoluporn.com/en/',300,os.path.join(imgDir, 'absoluporn.gif'),'')
    # utils.addDir('[COLOR hotpink]Anybunny[/COLOR]','http://anybunny.com/',320,os.path.join(imgDir, 'anybunny.png'),'')    
    # utils.addDir('[COLOR hotpink]SpankBang[/COLOR]','http://spankbang.com/new_videos/',440,os.path.join(imgDir, 'spankbang.png'),'')	
    # utils.addDir('[COLOR hotpink]Amateur Cool[/COLOR]','http://www.amateurcool.com/most-recent/',490,os.path.join(imgDir, 'amateurcool.png'),'')	
    # utils.addDir('[COLOR hotpink]Vporn[/COLOR]','https://www.vporn.com/newest/',500,os.path.join(imgDir, 'vporn.png'),'')
    # utils.addDir('[COLOR hotpink]xHamster[/COLOR]','https://xhamster.com/',505,os.path.join(imgDir, 'xhamster.png'),'')
    # xbmcplugin.endOfDirectory(utils.addon_handle, cacheToDisc=False)

# @utils.url_dispatcher.register('7')
# def INDEXW():
    # utils.addDir('[COLOR hotpink]Chaturbate[/COLOR] [COLOR white]- webcams[/COLOR]','https://chaturbate.com/?page=1',220,os.path.join(imgDir, 'chaturbate.png'),'')
    # utils.addDir('[COLOR hotpink]MyFreeCams[/COLOR] [COLOR white]- webcams[/COLOR]','https://www.myfreecams.com',270,os.path.join(imgDir, 'myfreecams.jpg'),'')
    # utils.addDir('[COLOR hotpink]Cam4[/COLOR] [COLOR white]- webcams[/COLOR]','http://www.cam4.com',280,os.path.join(imgDir, 'cam4.png'),'')    
    # utils.addDir('[COLOR hotpink]Camsoda[/COLOR] [COLOR white]- webcams[/COLOR]','http://www.camsoda.com',475,os.path.join(imgDir, 'camsoda.png'),'')    
    # utils.addDir('[COLOR hotpink]naked.com[/COLOR] [COLOR white]- webcams[/COLOR]','http://www.naked.com',480,os.path.join(imgDir, 'naked.png'),'')
    # if sys.version_info >= (2, 7, 9):
        # utils.addDir('[COLOR hotpink]streamate.com[/COLOR] [COLOR white]- webcams[/COLOR]','http://www.streammate.com',515,os.path.join(imgDir, 'streamate.png'),'')
    # utils.addDir('[COLOR hotpink]bongacams.com[/COLOR] [COLOR white]- webcams[/COLOR]','http://www.bongacams.com',520,os.path.join(imgDir, 'bongacams.png'),'')
    # xbmcplugin.endOfDirectory(utils.addon_handle, cacheToDisc=False)

# @utils.url_dispatcher.register('3')
# def INDEXH():
    # utils.addDir('[COLOR hotpink]Hentaihaven[/COLOR]','http://hentaihaven.org/?sort=date',460,os.path.join(imgDir, 'hh.png'),'')
    # xbmcplugin.endOfDirectory(utils.addon_handle, cacheToDisc=False)    


# @utils.url_dispatcher.register('5', ['page'])
# def ONELIST(page=1):
    # watchxxxfree.WXFList('http://www.watchxxxfree.com/page/1/',page, True)
    # hdporn.PAQList('http://www.pornaq.com/page/1/',page, True)
    # hdporn.PAQList('http://www.porn00.org/page/1/',page, True)
    # porntrex.PTList('http://www.porntrex.com/videos?o=mr&page=1',page, True)
    # npage = page + 1
    # utils.addDir('[COLOR hotpink]Next page ('+ str(npage) +')[/COLOR]','',5,'',npage)
    # xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('4', ['url'])
def OpenDownloadFolder(url):
    xbmc.executebuiltin('ActivateWindow(Videos, '+url+')')


def change():
    if os.path.isfile(utils.arabcinemachange):
        heading = '[B][COLOR red]ArabCinema[/COLOR] Changelog[/COLOR][/B]'
        utils.textBox(heading,utils.arabcinemachange)
        os.remove(utils.arabcinemachange)


# if not addon.getSetting('uwcage') == 'true':
    # age = dialog.yesno('[COLOR red]MG.Arabic[/COLOR] [COLOR red][B]http://mg.esy.es/Kodi/[/B][/COLOR]', nolabel='Exit', yeslabel='Enter')
    # if age:
        # addon.setSetting('uwcage','true')
# else:
    # age = True


def main(argv=None):
    if sys.argv: argv = sys.argv
    queries = utils.parse_query(sys.argv[2])
    mode = queries.get('mode', None)
    utils.url_dispatcher.dispatch(mode, queries)


if __name__ == '__main__':
#    if age:
        #change()
        sys.exit(main())
