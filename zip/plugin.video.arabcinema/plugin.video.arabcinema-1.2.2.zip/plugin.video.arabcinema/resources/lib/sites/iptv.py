'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream, hdgdl
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib2
import os
import re
import sys

import urllib,urllib2,re,xbmcplugin,xbmcgui
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse
import StringIO
import urllib2,urllib
import re
import httplib,itertools
from urllib2 import Request, build_opener, HTTPCookieProcessor, HTTPHandler
import cookielib
import time
from resources.lib import utils





@utils.url_dispatcher.register('610')
def Main():
    try:
        listhtml = utils.getHtml('https://www.m3uliste.pw/', '')
    except:        
        return None
    #page = re.compile(r'<div class="zs-accordion  selected" name="tab1"(.*?)</span><br></div></span></div>', re.DOTALL | re.IGNORECASE).findall(listhtml)				
    match = re.compile(r'<a href="([^"]+m3u)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for video in match:
        #name = utils.cleantext(name)
        #nu = utils.cleanspec(nu)		
        #nu = utils.cleantext(nu)
        #nu = utils.cleanhtml(nu)		
        ##name = name + "[COLOR red]"+nu+"[/COLOR]"
        utils.addDir(video,video, 614, '', '')		
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('615', ['url'])
def index(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None
    match = re.compile(r'<div class="td-module-thumb"><a href="([^"]+)".*?title="([^"]+)".*?src="([^"]+)" srcset=', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for video, name, nu in match:
        name = utils.cleantext(name)
        #nu = utils.cleanspec(nu)		
        #nu = utils.cleantext(nu)
        #nu = utils.cleanhtml(nu)		
        ##name = name + "[COLOR red]"+nu+"[/COLOR]"
        utils.addDir('[B]%s[/B]'%name,video, 611, nu, '')
    try:
        nextp=re.compile('rel="next" href="(.*?)" />').findall(listhtml)[0]
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]' ,nextp,  615, '')
    except: pass		
    xbmcplugin.endOfDirectory(utils.addon_handle)

	
@utils.url_dispatcher.register('611', ['url'], ['page'])
def List(url, page=0):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None
    match = re.compile(r'<a href="([^"]+m3u)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for video in match:
        #name = utils.cleantext(name)
        #name = "[COLOR red]"+nu+"[/COLOR]" + name
        utils.addDir('[B]%s[/B]'%video, video, 614, '', '')		
    try:	
        nextp=re.compile('<a class="next page-numbers" href="(.*?)">&raquo;</a>').findall(listhtml)[0]
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]' ,nextp,  611, '')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('614', ['url'])
def Channels(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None
    match = re.compile(r'#EXTINF:-1,(.*?)[\n\r]+http:(.*?)[\n\r]', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for name, video in match:
        name = utils.cleantext(name)
        addLink('[B]%s[/B]'%name,'http:' + video, 612)		
    xbmcplugin.endOfDirectory(utils.addon_handle)


	
	




	
@utils.url_dispatcher.register('612', ['url'])
def Playvid(url):
	finalPayPath = url#+' app= swfUrl= live=1 pageUrl='
	listItem = xbmcgui.ListItem(path=str(finalPayPath))
	xbmcplugin.setResolvedUrl(utils.addon_handle, True, listItem)

def addLink(name,url,mode):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    #ic="http://www.teledunet.com/logo/"+name.replace(" ","%20")+".jpg"
    ok=True
    liz=xbmcgui.ListItem(name)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    ok=xbmcplugin.addDirectoryItem(handle=utils.addon_handle,url=u,listitem=liz,isFolder=False)
    return ok

@utils.url_dispatcher.register('613', ['url'], ['keyword'])
def Search(url, keyword=None):
    searchUrl = url
    xbmc.log("Search: " + searchUrl)
    if not keyword:
        utils.searchDir(url, 613)
    else:
        title = keyword.replace(' ','_')
        searchUrl = searchUrl + title
        xbmc.log("Search: " + searchUrl)
        List(searchUrl)