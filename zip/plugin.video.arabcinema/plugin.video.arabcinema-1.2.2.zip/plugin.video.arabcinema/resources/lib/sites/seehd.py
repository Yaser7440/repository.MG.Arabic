'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmcgui
import xbmc
from httplib import HTTP
import xbmcplugin
from resources.lib import utils
seehd = 'http://www.seehd.ws/' 
progress = xbmcgui.DialogProgress()
dialog = xbmcgui.Dialog()
@utils.url_dispatcher.register('450', ['url'])
def Main(url):
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]Search[/B][/COLOR]',seehd + '?s=',454,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]YEARS[/B][/COLOR]','url', 457, '', '')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]Movies[/B][/COLOR]',seehd + 'category/movies/', 451, '', '')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]TV-Shows[/B][/COLOR]',seehd + 'category/tv-shows/', 451, '', '')
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]Complete TV-Shows[/B][/COLOR]',seehd + '?s=complete', 451, '', '')	
    List(seehd + '/category/movies/?s=new')
    xbmcplugin.endOfDirectory(utils.addon_handle)



@utils.url_dispatcher.register('457', ['url'])	
def YEARSEN(url):
    for i in range(2005,2018):
       utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]%s[/B][/COLOR]' %str(i),seehd + '/category/movies/?s='+str(i),451, '', '')
    xbmcplugin.endOfDirectory(utils.addon_handle)
	
@utils.url_dispatcher.register('451', ['url'], ['page'])
def List(url, page=1):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None
    match = re.compile(r'<article id="post-.*?src="([^"]+)".*?<a href="([^"]+)" rel="bookmark">\s*([^"]+)</a>.*?rel="bookmark">', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for thumb, videourl, name in match:
        thumb = thumb.replace('&amp;','&').replace(' ','%20').replace('&#039;',"'").replace('\/','/')
        name = utils.cleantext(name)
        name = name.replace('\r','').replace('\n','').replace('\t','').replace('Free Online','').replace('Watch Online','')
        info = utils.getHtml(videourl, '')
        match2 = re.findall(r'<div class="tabcontent">(.+?)<h3>', info, re.DOTALL)
        for items in match2:		
         desc = re.findall(r'<strong>([^"]+)</strong><br />\s*<strong>Plot:</strong>([^"]+)<br />\s*<strong>Ratings:</strong>([^"]+)<br />', items)
         for genre, des, rating in desc:
             des = utils.cleanhtml(des) ; des = utils.cleanspec(des) ; des = utils.cleantext(des)
             genre = utils.cleanhtml(genre) ; genre = utils.cleanspec(genre) ; genre = utils.cleantext(genre)
            # director = utils.cleanhtml(director) ; director = utils.cleantext(director)			
        if '-complete-' in videourl:
		    utils.addDir('[B]%s[/B]'%name, videourl , 452, thumb, des, genre, '', '', '', 'rating')
        else:		
		    utils.addDownLink('[B]%s[/B]'%name, videourl, 455, thumb, des, genre, '', '', '', rating)
    try:
        if '?s=' in url:
		    nexnew=re.compile('<div class="nav-previous"><a href="([^"]+)" >.*?</a>', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
		    utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]' ,nexnew,  451, '')			
        else:	
		    nextp=re.compile('rel="next" href="([^"]+)">.*?</a>', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]						
		    utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]' ,nextp,  451, '')	
    except: pass			
    xbmcplugin.endOfDirectory(utils.addon_handle)



@utils.url_dispatcher.register('452', ['url'], ['page'])
def Listtv(url, page=1):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None
    match = re.compile('<h2 class="tabtitle">([^"]+)</h2>.*?<source src="([^"]+)" type=', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for name, videourl in match:
        name = utils.cleantext(name)
        name = name.replace('\r','').replace('\n','').replace('\t','').replace('Free Online','').replace('Watch Online','')		
        utils.addDownLink('[B]%s[/B]'%name, videourl, 455, '','')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('456', ['url', 'name'], ['download'])
def Playvidtv(url, name, download=None, desc=None):	
   url = url.replace('&amp;','&').replace(' ','%20').replace('&#039;',"'").replace('\/','/')
   xbmc.Player().play(url)


	
@utils.url_dispatcher.register('453', ['url'])
def Categories(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<a href="(http://cimaclub.com/genre/[^"]+)">.*?<span>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name in match:
        utils.addDir(name, catpage, 451, '')    
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('454', ['url'], ['keyword'])
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 454)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        List(searchUrl)
		
@utils.url_dispatcher.register('455', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    if '.mp4' in url:
      xbmc.Player().play(url)
    else:
     try:
        listhtml = utils.getHtml(url, '')
     except:        
        return None
     match = re.compile('<head>.*?<title>([^"]+)</title>.*?<link rel=', re.DOTALL | re.IGNORECASE).findall(listhtml)
     for name in match:
      name = name.replace('\r','').replace('Seehd.ws','').replace('&#8211;','').replace('\n','').replace('\t','').replace('Free Online','').replace('Watch Online','').replace('Watch Movies for Free','')
      utils.PLAYVIDEO(url, name, download)
    xbmcplugin.endOfDirectory(utils.addon_handle)	  