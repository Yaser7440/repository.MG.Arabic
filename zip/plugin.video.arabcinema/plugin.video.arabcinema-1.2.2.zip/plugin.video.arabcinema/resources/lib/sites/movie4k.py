'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils

progress = utils.progress
movie4k = ['http://movie4k.tv/', 'http://movie.to/', 'http://movie4k.me/', 'http://movie4k.org/', 'http://movie4k.pe/', 'http://movie4k.am/']

@utils.url_dispatcher.register('360')
def Main():
    #utils.addDir('[COLOR hotpink]Categories[/COLOR]','http://movie4k.tv/xxx-updates.html', 361, '', '')
    #utils.addDir('[COLOR hotpink]Top Rated[/COLOR]',movie4k[0], 361, '', '')
    #utils.addDir('[COLOR hotpink]Most Viewed[/COLOR]','http://www.tubepornclassic.com/most-popular/', 361, '', '')
    #utils.addDir('[COLOR hotpink]Search[/COLOR]','http://www.tubepornclassic.com/search/', 364, '', '')    
    List(movie4k[0])
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('361', ['url'])
def List(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        return None
    match = re.compile(r'style="float.*?href="([^"]+)"><img src="([^"]+jpg)" alt="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, img, name in match:
      if 'http' not in videopage:
        videopage = videopage.replace('./','')	  
        videopage = movie4k[0] + videopage
        if img.startswith('/'): img = movie4k[0] + img  
        name = utils.cleantext(name)
        #name = name + " [COLOR deeppink]" + duration + "[/COLOR]"
        utils.addDownLink('[B]%s[/B]'%name, videopage, 362, img, '')
    try:
        nextp = re.compile('<a href="([^"]+)"[^>]+>Next', re.DOTALL | re.IGNORECASE).findall(listhtml)
        utils.addDir('Next Page', 'http://www.tubepornclassic.com/' + nextp[0], 361,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('364', ['url'], ['keyword'])    
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 364)
    else:
        title = keyword.replace(' ','%20')
        searchUrl = searchUrl + title + "/"
        print "Searching URL: " + searchUrl
        List(searchUrl)


@utils.url_dispatcher.register('363', ['url'])
def Cat(url):
    listhtml = utils.getHtml(url, '')
	
    match = re.compile('<div id="menue"(.*?)</div>\s*</div>\s*</div>', re.DOTALL | re.IGNORECASE).findall(listhtml)	
    match1 = re.compile('<a class=".*?href="([^<]+)">([^"]+)</a>', re.DOTALL | re.IGNORECASE).findall(match[0])
    for catpage, name in match1:
      if 'http:' not in catpage:
        catpage = catpage.replace('./','')	    
        catpage = movie4k[0] + catpage	
        name = utils.cleantext(name)
        utils.addDir(catpage, catpage, 361, '', '')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('362', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    progress.create('Play video', 'Searching videofile.')
    progress.update( 25, "", "Loading video page", "" )
    OPEN = utils.getHtml(url, '')   
    if 'valign="top"' in OPEN:
        res_quality = []
        stream_url = []
        quality = ''
        match = re.compile('<tr id="tablemoviesindex2"(.*?)</table>', re.DOTALL | re.IGNORECASE).findall(OPEN)
        match2 = re.compile('href=\"([^"]*html)\".*?> &nbsp;([^"]+)</a>', re.DOTALL | re.IGNORECASE).findall(str(match)) 
        for link,label in match2:
            link = movie4k[0]+link
            quality = '[B][COLOR white]%s[/COLOR][/B]' %label        
            res_quality.append(quality)
            stream_url.append(link)
        if len(match2) >1:
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Please Select Episode',res_quality)
            if ret == -1:
                return
            elif ret > -1:
                videourl = stream_url[ret]
				

                utils.PLAYVIDEO(videourl, name, download)