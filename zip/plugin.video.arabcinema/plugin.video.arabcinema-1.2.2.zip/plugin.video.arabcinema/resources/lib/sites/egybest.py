'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 Fr33m1nd

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re
import xbmc
import xbmcgui
import xbmcplugin
from resources.lib import utils

progress = utils.progress
egy = 'http://egy.best'

@utils.url_dispatcher.register('110')
def EXMain():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]MENU[/B]',egy,113,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]General[/B]',egy + '/movies/',119,'','')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Search[/B]',egy + '/explore/?q=',114,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]TV[/B]',egy + '/tv',115,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Trending[/B]',egy + '/trending/',116,'','')
    EXList(egy + '/movies/')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('111', ['url'], ['page'])
def EXList(url, page=1):	
     try:
        listhtml = utils.getHtml(url, '')
     except:
        
        return None		
     match = re.compile('<a href="([^"]+)"[^>]+><[^"]+src="([^"]+)".*?class="title">([^"]+)<[^"]+>.*?<[^"]+>([^"]+)</[^"]+></[^"]+>', re.DOTALL | re.IGNORECASE).findall(listhtml)
     for videopage, img, name, hd in match:
        name = utils.cleantext(name)
        name = utils.cleanspec(name)	
        if img.startswith('//'): img = 'http:' + img
        name = name + hd 
        if 'tv' in url:
          utils.addDir('[B]%s[/B]'%name, videopage, 117, img, '')		
        else:		
          utils.addDownLink('[B]%s[/B]'%name, videopage, 112, img, '')
     try:	  
          npag = re.compile(r'</a><a href=".*?(=[^"]+)" args="&output_mode=movies_list"', re.DOTALL | re.IGNORECASE).findall(listhtml)	  
          if 'page' not in url:
           for np in npag:
              url = url + '?page' + np
              utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]', url, 111, '')
          else:
           for np in npag:
             #range=['1','2','3','4','5','6','7','8','9']
             for i in range(1,100):
              url = url.replace('=' + str(i),np)			  
             utils.addDir('[COLOR red][B]Next Page ('+np+')[/B][/COLOR]', url, 111, '')

     except: pass		  
     xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('114', ['url'], ['keyword'])      
def EXSearch(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 114)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title + ".html"
        print "Searching URL: " + searchUrl
        EXList(searchUrl)


@utils.url_dispatcher.register('113', ['url'])
def EXCat(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<div class="hcenter tal">(.*?)<div class="tam pdb">', re.DOTALL | re.IGNORECASE).findall(cathtml)
    match1 = re.compile('<a href="([^"]+)">([^<]+)</a>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name in match1:
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 111, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)   


@utils.url_dispatcher.register('112', ['url', 'name'], ['download'])
def TPPlayvid(url, name, download=None):
    utils.PLAYVIDEO(url, name, download)


@utils.url_dispatcher.register('115', ['url'])
def EXTv(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<div id="main" class="td vat">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    match1 = re.compile('href="([^"]+)[^>]+><[^"]+[^>]+><[^>]+>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(match[0])
    for catpage, name in match1:
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 111, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('116', ['url'])
def EXMovies(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<div id="main" class="td vat">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    match1 = re.compile('href="([^"]+)"[^>]+><[^"]+[^>]+><[^>]+>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(match[0])
    for catpage, name in match1:
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 111, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('117', ['url'])
def EXTVList(url):
    listhtml = utils.getHtml(url, '')
    match = re.compile('<div class="h_scroll">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    match1 = re.compile('<a href="([^"]+)"[^>]+><[^"]+src="([^"]+)".*?class="title">([^"]+)<[^>]+> </a>', re.DOTALL | re.IGNORECASE).findall(match[0])
    for videopage, img, name in match1:
        img = 'http:' + img   
        utils.addDir('[B]%s[/B]'%name, videopage, 118, img, '')
    # try:
        # nextp=re.compile("<a href='([^']+)' title='([^']+)'>&raquo;</a>", re.DOTALL | re.IGNORECASE).findall(listhtml)
        # next = urllib.quote_plus(nextp[0][0])
        # next = next.replace(' ','+')
        # utils.addDir('Next Page', os.path.split(url)[0] + '/' + next, 117,'')
    # except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('118', ['url'])
def EXepiList(url):
    listhtml = utils.getHtml(url, '')
    match = re.compile('<div class="pda">(.*?)</a></div>\s*</div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    match1 = re.compile('href="([^"]+)"[^>]+><[^"]+src="([^"]+)".*?class="title">([^"]+)<[^>]+> <[^"]+[^>]+><[^>]+>([^"]+)<[^>]+></span>', re.DOTALL | re.IGNORECASE).findall(match[0])
    for videopage, img, name, nam in match1:
        name = name + nam
        img = 'http:' + img   
        utils.addDownLink('[B]%s[/B]'%name, videopage, 112, img, '')
    # try:
        # nextp=re.compile("<a href='([^']+)' title='([^']+)'>&raquo;</a>", re.DOTALL | re.IGNORECASE).findall(listhtml)
        # next = urllib.quote_plus(nextp[0][0])
        # next = next.replace(' ','+')
        # utils.addDir('Next Page', os.path.split(url)[0] + '/' + next, 118,'')
    # except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)
	

@utils.url_dispatcher.register('119', ['url'])
def EXG(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('class="sub_nav">(.*?)</div></div></div>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    match1 = re.compile(r'href="([^"]+)".*?>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(match[0])
    for catpage, name in match1:
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 111, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)	
