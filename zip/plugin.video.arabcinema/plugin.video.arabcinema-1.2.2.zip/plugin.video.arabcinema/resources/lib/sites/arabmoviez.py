'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib2
import os



import xbmc

import xbmcgui


import urllib
import re
import sys

import xbmcplugin
from resources.lib import utils

progress = utils.progress
web = 'http://arab-moviez.org/'

@utils.url_dispatcher.register('230')
def Main():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]MENU[/B][/COLOR]',web,233,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]YEARS[/B][/COLOR]',web,236,'','')	
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]Search[/B][/COLOR]','http://arab-moviez.org/search.php?t=',234,'','')
    Listqu(web)
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('231', ['url'], ['page'])
def List(url, page=1):
    try:
        listhtml = utils.getHtml(url, '')
    except:       
        return None
    match = re.compile('<img src="([^"]+)" alt="([^"]+)".*?class="category">.*?<a href="([^"]+)" title=".*?>([^"]+)</a>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for img, name, videopage, desc in match:
        name = utils.cleantext(name)
        videopage = videopage.replace('film','play')
        utils.addDownLink('[B]%s[/B]'%name, videopage, 232, img, utils.cleanhtml(desc),'','')
    if 'tag' in url:
        nextp=re.compile('href="([^"]+)" class="next">.*?&gt;</a>', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        utils.addDir('[B][COLOR red]Next Page[/COLOR][/B]' ,nextp,231, '')		
    elif 'online2' in url:	
        nextp=re.compile('<a href="([^"]+)">&rsaquo;</a>', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        utils.addDir('[B][COLOR red]Next Page[/COLOR][/B]' ,nextp,231, '')
    else:
        match = re.compile('<div class="pagination">(.*?)align="center">', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        match1 = re.compile(r'<a  href="([^"]+)">([^"]+)</a>', re.DOTALL | re.IGNORECASE).findall(match)
        for nextp, name in match1:
             name = utils.cleantext(name)	
             utils.addDir('[B][COLOR red]Next Page [%s][/COLOR][/B]' %name, nextp, 235,'')		
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('235', ['url'], ['page'])
def Listqu(url, page=1):
    try:	
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile('href="([^"]+)".*?<img src="([^"]+)".*?>.*?<div class="video_typ2">([^"]+)</div>\s*</div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, img, name in match:
        name = utils.cleantext(name)
        videopage = videopage.replace('film','play')
        utils.addDownLink('[B]%s[/B]'%name, videopage, 232, img, '','','')
    try:		
        match = re.compile('<div class="pagination">(.*?)align="center">', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        match1 = re.compile(r'<a  href="([^"]+)">([^"]+)</a>', re.DOTALL | re.IGNORECASE).findall(match)
        for nextp, name in match1:
             name = utils.cleantext(name)	
             utils.addDir('[B][COLOR red]Next Page [%s][/COLOR][/B]' %name, nextp, 235,'')
    except: pass	
    xbmcplugin.endOfDirectory(utils.addon_handle)
	
def getCookiesString():
    cookieString=""
    import cookielib
    try:
        cookieJar = cookielib.LWPCookieJar()
        cookieJar.load(utils.cookiePath,ignore_discard=True)
        for index, cookie in enumerate(cookieJar):
            cookieString+=cookie.name + "=" + cookie.value +";"
    except:
        import sys,traceback
        traceback.print_exc(file=sys.stdout)
    return cookieString


@utils.url_dispatcher.register('234', ['url'], ['keyword'])    
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 234)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        List(searchUrl)


@utils.url_dispatcher.register('236', ['url'])
def Years(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<a rel="dofollow" title="([^"]+)"href="([^<]+)">', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for name, catpage in match:
        name = utils.cleantext(name)
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]' %name, catpage, 231, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)   

@utils.url_dispatcher.register('233', ['url'])
def Cat(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<li><a href="([^"]+)">([^<]+)</a></li>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name in match:
        name = utils.cleantext(name)
        if 'quality' in catpage:		
		   utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]' %name, catpage, 235, '')
        elif 'year' in catpage:
		   utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]' %name, catpage, 235, '')
        elif 'boxoffice' in catpage:
		   utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]' %name, catpage, 235, '')		   
        else:		
           utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]' %name, catpage, 231, '')
		   
    xbmcplugin.endOfDirectory(utils.addon_handle)
	
@utils.url_dispatcher.register('232', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    progress.create('Play video', 'Searching videofile.')
    progress.update( 10, "", "Loading video page", "" )
    videopage = utils.getHtml(url, '')
    utils.playvideo(videopage, name, download, url)

