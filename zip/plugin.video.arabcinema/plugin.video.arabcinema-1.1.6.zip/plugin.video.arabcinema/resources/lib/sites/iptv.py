'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream, hdgdl
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib2
import os
import re
import sys

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils

@utils.url_dispatcher.register('610')
def Main():
    try:
        listhtml = utils.getHtml('http://iptv.filmover.com/', '')
    except:        
        return None
    match = re.compile(r'<li class="cat-item cat-item-.*?<.*?<a href="([^"]+)" >([^"]+)</a>([^"]+)</li>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for video, name, nu in match:
        name = utils.cleantext(name)
        nu = utils.cleanspec(nu)		
        nu = utils.cleantext(nu)
        nu = utils.cleanhtml(nu)		
        name = name + "[COLOR red]"+nu+"[/COLOR]"
        utils.addDir('[B]%s[/B]'%name,video, 611, '', '')		
    xbmcplugin.endOfDirectory(utils.addon_handle)

	
@utils.url_dispatcher.register('611', ['url'], ['page'])
def List(url, page=0):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None
    match = re.compile(r'<article id=".*?<h2 class="entry-title post-title"><a href="([^"]+)" rel="bookmark">([^"]+)</a></h2>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for video, name in match:
        name = utils.cleantext(name)
        utils.addDir(name, video, 614, '', '')		
    try:	
        nextp=re.compile('<a class="next page-numbers" href="(.*?)">&raquo;</a>').findall(listhtml)[0]
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]' ,nextp,  611, '')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('614', ['url'])
def Channels(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None
    match = re.compile(r'#EXTINF:-1,(.*?)<.*?http:(.*?)<', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for name, video in match:
        name = utils.cleantext(name)
        utils.addDownLink(name,'http:' + video, 612, '', '')		
    xbmcplugin.endOfDirectory(utils.addon_handle)


	
	




	
@utils.url_dispatcher.register('612', ['url'])
def Playvid(url):
   xbmc.Player().play(url)

		 
@utils.url_dispatcher.register('613', ['url'], ['keyword'])
def Search(url, keyword=None):
    searchUrl = url
    xbmc.log("Search: " + searchUrl)
    if not keyword:
        utils.searchDir(url, 613)
    else:
        title = keyword.replace(' ','_')
        searchUrl = searchUrl + title
        xbmc.log("Search: " + searchUrl)
        List(searchUrl)