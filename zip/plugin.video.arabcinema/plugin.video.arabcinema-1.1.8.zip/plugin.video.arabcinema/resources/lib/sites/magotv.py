'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmcplugin
from resources.lib import utils

progress = utils.progress

mago = 'http://www.mago.tv'
@utils.url_dispatcher.register('260')
def EROMain():
    #utils.addDir('[COLOR hotpink]Categories[/COLOR]','http://www.ero-tik.com',263,'','')
    #utils.addDir('[COLOR hotpink]Top Rated[/COLOR]','http://www.ero-tik.com/topvideos.html?page=1',261,'','')
    #utils.addDir('[COLOR hotpink]Most Liked[/COLOR]','http://www.mago.tv/uncategorised/%d8%a3%d9%81%d9%84%d8%a7%d9%85/',265,'','')
    #utils.addDir('[COLOR hotpink]Search[/COLOR]','http://www.ero-tik.com/search.php?keywords=',264,'','')
    EROCat(mago)
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('261', ['url'])
def EROList(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
		
		
    if '/uncategorised/' in url:	
        url = url.replace('/uncategorised/','/')
        match = re.compile('widget-project-container.*?href="([^"]+)".*?src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
        for videopage, img in match:	
          utils.addDir('', videopage, 262, img, '')
    else:	
        match = re.compile('widget-project-container.*?href="([^"]+)".*?src="([^"]+)".*?alt="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
        for videopage, img, name in match:
          name = utils.cleantext(name)
          utils.addDownLink('[B]%s[/B]'%name, videopage, 262, img, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('265', ['url'])
def ERList(url):
    try:
        url = url.replace('/uncategorised/','/')
        listhtml = utils.getHtml(url, '').replace('/uncategorised/','/')
    except:
        
        return None
        url = url.replace('/uncategorised/','/')
        match = re.compile('widget-project-container.*?href="([^"]+)".*?src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
        for videopage, img in match:	
          utils.addDir('', videopage, 262, img, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('264', ['url'], ['keyword']) 
def EROSearch(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 264)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        EROList(searchUrl)


@utils.url_dispatcher.register('263', ['url'])
def EROCat(url):
    cathtml = utils.getHtml(url, mago)
    match = re.compile('<ul id="menu-main-1"(.*?)class="nav navbar-nav navbar-right">', re.DOTALL | re.IGNORECASE).findall(cathtml)[0]
    match1 = re.compile('<a title="([^"]+)" href="([^<]+)"', re.DOTALL | re.IGNORECASE).findall(match)
    for name, catpage in match1:
         name = utils.cleantext(name)
	 if '/uncategorised/' in catpage:		
          catpage = catpage.replace('/uncategorised/','/')
          utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 265, '')
	 else:		
          utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 261, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('262', ['url', 'name'], ['download'])
def EROPlayvid(url, name, download=None):
    utils.PLAYVIDEO(url, name, download)
