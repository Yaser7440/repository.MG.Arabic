'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import urlparse
import json

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
 
progress = utils.progress
oof = 'http://www.4oof.com/'

@utils.url_dispatcher.register('60')
def PAQMain():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]MENU[/B][/COLOR]',oof,63,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]Search[/B][/COLOR]',oof+'?s=',68,'','')
    PAQList('http://www.4oof.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%89/page/1',1)
    xbmcplugin.endOfDirectory(utils.addon_handle)
 


@utils.url_dispatcher.register('61', ['url'], ['page'])
def PAQList(url, page=1):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
    if '4oof' in url:
        match = re.compile(r'class="moviefilm">\s+<div class="ribbon">([^"]+)</div>\s+<a href="([^"]+)".*?src="([^"]+)".*?class="movief"><a href=".*?>([^"]+)</a></div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
        for desc, videopage, img, name in match:
            name = utils.cleantext(name)
            desc = utils.cleantext(desc)			
            utils.addDownLink('[B]%s[/B]' %name, videopage + '?watch=true', 62, img, desc)
    try:
		nextp=re.compile('<li><a href="(.*?)" >.*?&laquo;</a></li>').findall(listhtml)[0]
		utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]' ,nextp,  61, '')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


def GetAlternative(url, alternative):
    progress.update( 70, "", "Loading alternative page", "" )
    if alternative == 1:
        nalternative = 2
        url = url + str(nalternative)
    else:
        nalternative = int(alternative) + 1
        url.replace('/'+str(alternative),'/'+str(nalternative))
    return url, nalternative


@utils.url_dispatcher.register('62', ['url', 'name'], ['download'])
def PPlayvid(url, name, download=None, desc=None, alternative=1):

    def playvid(videourl, referer):
        progress.close()
        if download == 1:
            utils.downloadVideo(videourl, name)
        else:
            videourl = videourl + "|referer="+ referer
            iconimage = xbmc.getInfoImage("ListItem.Thumb")
            listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
            listitem.setInfo('video', {'Title': name, 'Genre': '[COLOR red][B]MG-Arabic[/B][/COLOR]', 'Plot': desc})
            xbmc.Player().play(videourl, listitem)    
    
    progress.create('Play video', 'Searching videofile.')
    progress.update( 25, "", "Loading video page", "" )
    data = utils.getHtml(url, '')
    if "data:" in data:
        res_quality = []
        stream_url = []
        quality = ''
        regx="data: 'q=(.+?)&i="
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[0]
        print "id",id
        range=['1','2','3','4','5','6','7']
        for i in range:
          catpage='http://www.4oof.com/wp-content/themes/twentyfifteen/servers/server.php?q=' + id + '&i=' + str(i)
          print catpage
          quality = '[B][COLOR white]SERVER [%s][/COLOR][/B]' %str(i)
          res_quality.append(quality)
          stream_url.append(catpage)
        if len(range) >0:
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Please Select Servers',res_quality)
            if ret == -1:
                return
            elif ret > -1:
                videourl = stream_url[ret]
            try:
                    server = utils.getHtml(videourl, url)
            except:
                   return None
        a = re.compile('''src="(.*?)"''', re.DOTALL | re.IGNORECASE).findall(server)
        b = re.compile('''<ifram.*?src="([^'"]+)"''', re.DOTALL | re.IGNORECASE).findall(server)
        c = re.compile('''<IFRAM.*?SRC=([^'"]+)".*?</IFRAME>''', re.DOTALL | re.IGNORECASE).findall(server)
        d = re.compile('''<ifram.*?src="([^'"]+)".*?</iframe>''', re.DOTALL | re.IGNORECASE).findall(server)
        try:
           videourl = a[0]
        except:
            try:
               videourl = b[0]
            except:
                try:
                   videourl = c[0]
                except:
                      videourl = d[0]
        if videourl:
            utils.playvideo(videourl, name, download)
        else:
            utils.notify('Oh oh','Couldn\'t find a video')



@utils.url_dispatcher.register('63', ['url'])
def PCat(url):
    caturl = utils.getHtml(url, '')
    if '4oof' in url:
        match = re.compile('<li id="menu-item-.*?href="([^<]+)">([^<]+)</a>', re.DOTALL | re.IGNORECASE).findall(caturl)
    for videolist, name in match:
            utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]' %name, videolist, 61, '', 1)           
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('68', ['url'], ['keyword'])
def PSearch(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 68)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        PAQList(searchUrl, 1)


def getVK(url):

    def __get_private(oid, video_id):
        private_url = 'http://vk.com/al_video.php?act=show_inline&al=1&video=%s_%s' % (oid, video_id)
        html = utils.getHtml(private_url,'')
        html = re.sub(r'[^\x00-\x7F]+', ' ', html)
        match = re.search('var\s+vars\s*=\s*({.+?});', html)
        try: return json.loads(match.group(1))
        except: return {}
        return {}
    
    query = url.split('?', 1)[-1]
    query = urlparse.parse_qs(query)
    api_url = 'http://api.vk.com/method/video.getEmbed?oid=%s&video_id=%s&embed_hash=%s' % (query['oid'][0], query['id'][0], query['hash'][0])
    progress.update( 40, "", "Opening VK video page", "" )
    html = utils.getHtml(api_url,'')
    html = re.sub(r'[^\x00-\x7F]+', ' ', html)
    
    try: result = json.loads(html)['response']
    except: result = __get_private(query['oid'][0], query['id'][0])
    
    quality_list = []
    link_list = []
    best_link = ''
    for quality in ['url240', 'url360', 'url480', 'url540', 'url720']:
        if quality in result:
            quality_list.append(quality[3:])
            link_list.append(result[quality])
            best_link = result[quality]
    
    if quality_list:
        if len(quality_list) > 1:
            result = xbmcgui.Dialog().select('Choose the quality', quality_list)
            if result == -1:
                utils.notify('Oh oh','No video selected')
            else:
                return link_list[result] + '|User-Agent=%s' % (utils.USER_AGENT)
        else:
            return link_list[0] + '|User-Agent=%s' % (utils.USER_AGENT)
    return

