'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 anton40

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils

progress = utils.progress
movies = 'https://1movies.to'  

@utils.url_dispatcher.register('390')
def Main():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Search[/B]',movies +'/search_all/', 394, '', '')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Categories[/B]',movies +'/genres', 393, '', '')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]movies[/B]',movies +'/latest/movies', 391, '', '')	
    List(movies +'/latest/movies')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('391', ['url'])
def List(url):
    #print "1movies::List " + url
    try:
        listhtml = utils.getHtml(url, '')
    except:
        return None
    match = re.compile(r'<div class="offer_box">.*?data-href="([^"]+)"\s*?data-name="([^"]+)"\s*?data-genre="<b>Genre:</b>([^"]+)"\s*?data-quality="([^"]+)"\s*?data-img=".*?url=([^"]+)"\s*?data-imdb="IMDb:([^"]+)"\s*?data-year="([^"]+)".*?data-desc="([^"]+)"', re.DOTALL).findall(listhtml)
    for videopage, name, genre, hd, img, rating, aired, desc in match:
        if hd.find('HD') > 0:
            hd = " [COLOR orange]HD[/COLOR] "
        else:
            hd = " "            
        name = utils.cleantext(name)
        name = name + ' ' + aired + hd 
        utils.addDownLink(name, movies + videopage + '-watch-online-free.html', 392, img, desc, genre, 'director', 'writer', aired, rating)
    try:
        nextp=re.compile('class="next"><a href="(.+?)" data-page=', re.DOTALL).findall(listhtml)
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]', movies + nextp[0].replace('&amp;','&'), 391,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('394', ['url'], ['keyword'])    
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 394)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        List(searchUrl)


@utils.url_dispatcher.register('393', ['url'])
def Categories(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None	
    match = re.compile('class="control_nav genres">(.*?)</div>\s*?</div>', re.DOTALL | re.IGNORECASE).findall(listhtml)	
    match1 = re.compile('href="([^<]+)">([^"]+)</a>', re.DOTALL | re.IGNORECASE).findall(match[0])
    for catpage, name in match1:	
        name = utils.cleantext(name)
        catpage = movies + catpage	
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 391, '', '')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('392', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    #utils.PLAYVIDEO(url, name, download)
    html = utils.getHtml(url, '')
    match = re.compile(r"""quality_([0-9]{3,4})p\s*=(?:"|')?([^'";]+)(?:"|')?;""", re.DOTALL | re.IGNORECASE).findall(html)
    match = sorted(match, key=lambda x: int(x[0]), reverse=True)
    videolink = match[0][1]
    if "/*" in videolink:
        videolink = re.sub(r"/\*[^/]+/", "", videolink).replace("+","")

        linkparts = re.compile(r"(\w+)", re.DOTALL | re.IGNORECASE).findall(videolink)
        for part in linkparts:
            partval = re.compile(part+'="(.*?)";', re.DOTALL | re.IGNORECASE).findall(html)[0]
            partval = partval.replace('" + "','')
            videolink = videolink.replace(part, partval)

    videourl = videolink.replace(" ","")
    if download == 1:
        utils.downloadVideo(videourl, name)
    else:
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
        xbmc.Player().play(videourl, listitem)
