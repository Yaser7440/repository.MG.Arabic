import re
import xbmcgui
import xbmcplugin
from resources.lib import utils
progress = utils.progress 
addon = utils.addon

sortlistxt = [addon.getLocalizedString(30022), addon.getLocalizedString(30023), addon.getLocalizedString(30024),
            addon.getLocalizedString(30025)]   

mazika = 'https://mazika2day.tv'
@utils.url_dispatcher.register('20')
def XTMain():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Categories[/B]',mazika,22,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Search[/B]',mazika + '/?s=',24,'','')
    #Sort = '[COLOR red]MG.Arabic[/COLOR] [B]Current sort:[/B]' + sortlistxt[int(addon.getSetting("sortxt"))]
    #utils.addDir(Sort, '', 25, '', '')    
    XTList(mazika,1)
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('25')
def XTSort():
    addon.openSettings()
    XTMain()


@utils.url_dispatcher.register('22', ['url'])
def XTCat(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<li id="menu-item-.*?href="([^"]+)">([^"]+)</a></li>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name in match:
        #catpage = catpage + 'page/1/'
        #name = name + ' [COLOR deeppink]' + videos + '[/COLOR]'
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 21, '', '')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('24', ['url'], ['keyword'])
def XTSearch(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 24)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title 
        print "Searching URL: " + searchUrl
        XTList(searchUrl, 1)


@utils.url_dispatcher.register('21', ['url'], ['page'])
def XTList(url, page=1):
    # sort = getXTSortMethod()
    # if re.search('\?', url, re.DOTALL | re.IGNORECASE):
        # url = url + '&filtre=' + sort + '&display=extract'
    # else:
        # url = url + '?filtre=' + sort + '&display=extract'
    try:
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile(r'<div class="moviefilm.*?src="([^"]+jpg)" class="attachment.*?<div class="movief"><a href="([^"]+)">([^"]+)</a></div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for img, videopage, name in match:
        name = utils.cleantext(name)
        name = utils.cleanhtml(name)
        utils.addDownLink('[B]%s[/B]'%name, videopage+'?watch=1', 23, img, '')		
    try:			
     if '.tv/mazika2day' in url:	
        nextp=re.compile('<li><a href="([^"]+)">.*?&laquo;</a></li>', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        utils.addDir('[B][COLOR red]Next Page[/COLOR][/B]' ,nextp,21, '')
     elif '?s=' in url:	
        nextp=re.compile('<li><a href="([^"]+)">.*?&laquo;</a></li>', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        utils.addDir('[B][COLOR red]Next Page[/COLOR][/B]' ,nextp,21, '')		
     else:
        match = re.compile('<div class="pagination">(.*?)</li></ul>', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        match1 = re.compile(r'href="([^"]+)">([^"]+)</a></li><li>', re.DOTALL | re.IGNORECASE).findall(match)
        for nextp, name in match1:
             name = utils.cleantext(name)		
             utils.addDir('[B][COLOR red]Next Page [%s][/COLOR][/B]' %name, nextp, 21,'')		
    # if re.search('<link rel="next"', listhtml, re.DOTALL | re.IGNORECASE):
        # npage = page + 1        
        # url = url.replace('/page/'+str(page)+'/','/page/'+str(npage)+'/')
        # utils.addDir('Next Page ('+str(npage)+')', url, 21, '', npage)
    except: pass		
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('23', ['url', 'name'], ['download'])
def XTVideo(url, name, download=None):
    progress.create('Play video', 'Searching videofile.')
    progress.update( 25, "", "Loading video page", "" )
    data = utils.getHtml(url, url)
    if "data:" in data:
        res_quality = []
        stream_url = []
        quality = ''
        regx="data: 'q=(.*?)&i='"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[0]
        print "id",id
        #range=['1','2','3','4','5','6','7','8']
        for i in range(1,7):
          catpage='http://mazika2day.tv/wp-content/themes/mazika2day/servers/server.php?q=' + id + '&i=' + str(i)
          print catpage
          quality = '[B][COLOR white]SERVER [%s][/COLOR][/B]' %str(i)
          res_quality.append(quality)
          stream_url.append(catpage)
        if len(id) >0:
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Please Select Servers',res_quality)
            if ret == -1:
                return
            elif ret > -1:
                videourl = stream_url[ret]
            try:
                    server = utils.getHtml(videourl, url)
            except:
                   return None
        a = re.compile('''src="(.*?)"''', re.DOTALL | re.IGNORECASE).findall(server)
        b = re.compile('''<ifram.*?src="([^'"]+)"''', re.DOTALL | re.IGNORECASE).findall(server)
        c = re.compile('''<IFRAM.*?SRC=([^'"]+)".*?</IFRAME>''', re.DOTALL | re.IGNORECASE).findall(server)
        d = re.compile('''<ifram.*?src="([^'"]+)".*?</iframe>''', re.DOTALL | re.IGNORECASE).findall(server)
        try:
           videourl = a[0]
        except:
            try:
               videourl = b[0]
            except:
                try:
                   videourl = c[0]
                except:
                      videourl = d[0]
        if videourl:
            utils.playvideo(videourl, name, download, url)
        else:
            utils.notify('Oh oh','Couldn\'t find a video')

  

def getXTSortMethod():
    sortoptions = {0: 'date',
                   1: 'title',
                   2: 'views',
                   3: 'likes'}
    sortvalue = addon.getSetting("sortxt")
    return sortoptions[int(sortvalue)]    
