import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils

progress = utils.progress
movie4k = 'https://movie4k.is/'

#,'http://movie4k.tv/', 'http://movie.to/', 'http://movie4k.me/', 'http://movie4k.org/', 'http://movie4k.pe/', 'http://movie4k.am/']

@utils.url_dispatcher.register('360')
def Main():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Search[/B]',movie4k +'?s=', 364, '', '') 
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Genres[/B]',movie4k, 363, '', '')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Release Year[/B]',movie4k, 365, '', '')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Quality[/B]',movie4k, 366, '', '')   
    List(movie4k)
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('361', ['url'], ['page'])
def List(url, page=1):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None
    match = re.compile(r'<div id="mt-.*?href="([^"]+)">\s*<[^"]+[^>]+>\s*<img src="([^"]+jpg)" alt="([^"]+)".*?<span class="ttx">([^"]+)<[^"]+[^>]+></div>.*?class="imdbs">([^"]+)</span>.*?class="year">([^"]+)</span>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, name, desc, rating, aired in match:
        thumb = thumb
        desc = utils.cleantext(desc)
        thumb = thumb.replace('&amp;','&').replace(' ','%20').replace('&#039;',"'").replace('\/','/')
        name = utils.cleantext(name)
        videourl = videourl
        name = name + " [COLOR red]" + aired + "[/COLOR]"	
        utils.addDownLink('[B]%s[/B]'%name, videourl, 362, thumb, desc, 'genre', 'director', 'writer', aired, rating)
    try:
		nextp= re.compile('href="(.*?)">Next</a></div>').findall(listhtml)[0]
		utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]' ,nextp,  361, '')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('364', ['url'], ['keyword'])    
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 364)
    else:
        title = keyword.replace(' ','%20')
        searchUrl = searchUrl + title 
        print "Searching URL: " + searchUrl
        List(searchUrl)


@utils.url_dispatcher.register('363', ['url'])
def Cat(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None	
    match = re.compile('<ul class="scrolling cat">(.*?)</ul>', re.DOTALL | re.IGNORECASE).findall(listhtml)	
    match1 = re.compile('href="([^<]+)">([^"]+)</a>', re.DOTALL | re.IGNORECASE).findall(match[0])
    for catpage, name in match1:	
        name = utils.cleantext(name)
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 361, '', '')
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('365', ['url'])
def ReY(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None	
    match = re.compile('<ul class="scrolling">(.*?)</ul>', re.DOTALL | re.IGNORECASE).findall(listhtml)	
    match1 = re.compile('href="([^<]+)">([^"]+)</a>', re.DOTALL | re.IGNORECASE).findall(match[0])
    for catpage, name in match1:	
        name = utils.cleantext(name)
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 361, '', '')
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('366', ['url'])
def Qua(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None	
    match = re.compile('<ul class="scrolling" style="max-height: 87px;">(.*?)</ul>', re.DOTALL | re.IGNORECASE).findall(listhtml)	
    match1 = re.compile('href="([^<]+)">([^"]+)</a>', re.DOTALL | re.IGNORECASE).findall(match[0])
    for catpage, name in match1:	
        name = utils.cleantext(name)
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 361, '', '')
    xbmcplugin.endOfDirectory(utils.addon_handle)
	
@utils.url_dispatcher.register('362', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    utils.PLAYVIDEO(url, name, download)