import re
import os
import sys
import sqlite3
import urllib
import xbmcaddon
import xbmcplugin
import xbmcgui
from resources.lib import utils
addon_path=os.path.dirname(__file__)
sys.path.append(os.path.join(utils.rootDir, 'pelisresolver'))
sys.path.append(os.path.join(utils.rootDir, 'urlresolver'))




progress = utils.progress
arabhd = 'http://movizland.com/'

@utils.url_dispatcher.register('280')
def Main():
    #utils.addDir('[COLOR red]Refresh Cam4 images[/COLOR]','',283,'',Folder=False)
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]MENU[/B]',arabhd,284,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]MOVIES[/B]',arabhd + 'cat/foreign/',281,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Years[/B]',arabhd,285,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]SEARCH[/B]',arabhd + '?s=',286,'','')
    #List(arabhd,'')
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('284', ['url'])
def Cat(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('class="menu-bar-cat">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    match1 = re.compile('<h2><a href="([^"]+)" title="([^<]+)">.*?</a></h2>', re.DOTALL | re.IGNORECASE).findall(match[0])
    for caturl, name in match1:

        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, caturl, 281, '', 1)
    xbmcplugin.endOfDirectory(utils.addon_handle)
	
# @utils.url_dispatcher.register('285', ['url'])
# def Years(url):
    # cathtml = utils.getHtml(url, '')
    # match = re.compile('<div class="yearSpan">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    # match1 = re.compile('<a href="([^"]+)"><p>([^<]+)</p></a>', re.DOTALL | re.IGNORECASE).findall(match[0])
    # for caturl, name in match1:

        # utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, caturl, 281, '', 1)
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('286', ['url'], ['keyword'])  
def TPSearch(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 286)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title 
        print "Searching URL: " + searchUrl
        List(searchUrl, 1)
		
@utils.url_dispatcher.register('283')
def clean_database(showdialog=True):
    conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % ".cam4s.com")
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try: os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
                except: pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % ".cam4s.com")
            if showdialog:
                utils.notify('Finished','Cam4 images cleared')
    except:
        pass


@utils.url_dispatcher.register('281', ['url'], ['page'])
def List(url, page=1):
    # if utils.addon.getSetting("chaturbate") == "true":
        # clean_database(False)

    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None
    match = re.compile(r'<div class="block" id="movie.*?<a title="([^"]+)".*?src="([^"]+jpg)" class=.*?<li><a href="(http://vb[^"]+)">.*?</a></li>\s*</ul>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for name, thumb, videourl  in match:
        name = utils.cleantext(name)
        utils.addDir('[B]%s[/B]'%name, videourl, 282, thumb)
    try:
        nextpage = re.compile('<div class="pagination">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
        nextp = re.compile('<li><a href="(.*?)" title="(.*?)">', re.DOTALL | re.IGNORECASE).findall(nextpage[0])
        for pageurl, name in nextp:
          pageurl = aflamyhd + pageurl		
          utils.addDir('[COLOR red][B]Next Page (%s)[/B][/COLOR]' %name,pageurl,  281, '')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('282', ['url'])
def Playvid(url):
    data = readnet(url)
    match = re.compile(r'href="http://e5tsar.com/(.+?)" target="_blank">').findall(data)
    print "match",match               
    for link in match:
        href='http://e5tsar.com/'+link
        print "href",href		
        data = readnet(href)
        regx='''<a href='(.+?)'.+?Click to get your link'''                       
        server_link = re.findall(regx,data,re.M|re.I)[0]
        print "server_link",server_link
        server_name=getDomain(server_link)
        if True:
              if server_name=="ok":                             
                  get_video_url(server_link)

							  
def get_video_url(server_url):
    import requests , re
    s = requests.Session()
    r = s.get(server_url)
    html = r.content
    html=html.replace("\u0026", "&")
    html=html.replace("\&","&")

    regx='''hlsManifestUrl(.*?)&quot;,'''        
    M3U8Url=re.findall(regx,html, re.M|re.I)[0][13:]
    print "stream_link3",M3U8Url
   
    r = s.get(M3U8Url)
    data=r.content

    
    #stream_links = r.content
    #print "stream_link2",stream_link
    #from xbmctools import addDir
    video_urls=[]
    print data
    #quals=['sd','lowest','low','hd','mobile']
    quality=''
    #line=#EXT-X-STREAM-INF:PROGRAM-ID=1, BANDWIDTH=161349, QUALITY=mobile
    try:
        lines=data.split("\n")
        i=0
        
        for line in lines:
           
            line=line.strip()
            if 'QUALITY=' in line:
                quality=line.split('QUALITY=')[1]
                
            if not line.startswith("http"):
                continue
            addDir(quality,str(line).strip(),285,"","",1)
            if quality=='hd':
                hd=str(line).strip()
            i=i+1
        return "hd",str(line).strip()            
    except:
        trace_error()

def trace_error():
    import sys
    import traceback
    traceback.print_exc(file=sys.stdout)
    
    if os.path.exists("/tmp/TSmedia"):
        logfile = '/tmp/TSmedia/TSmedia_log'
    else:
        logfile =os.path.dirname(__file__)+'/TSmedia_log'
    traceback.print_exc(file=open(logfile, 'a'))	

def readnet(url):
    return requestsurl(url)

	
def requestsurl(url):
    try:
        import requests
        
        session = requests.Session()
        USER_AGENT = 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
        session.headers.update({'User-Agent': USER_AGENT})

        return session.get(url,verify=False).content
    
    except:
        #trace_error()
        #addDir('Error:Download error', '', '', '', '', 1)
        return None

		
@utils.url_dispatcher.register('285', ['url'])		
def playlink(url):
    if url is None or url.startswith('Error') or 'unresolvable' in url or '://' not in url or not url.startswith('http') and not url.startswith('rtmp'):
        addDir('Error:invalid stream link', '', '', '', '', 1)
        return
    else:
        xbmc.Player().play(url)
        sys.exit(0)
        return
		
		
def addDir(name, url, mode, iconimage, extra = '', page = 0, plugin = None, link = False, searchall = None, maintitle = False):
    spath = sys.argv[0]
    extra = str(extra)
    try:
        name = name.encode('utf-8', 'ingnore')
    except:
        pass

    if name is not None and maintitle == True:
        extra = 'maintitle'
    if plugin is not None:
        path = spath.replace('/arabhd.py', '')
        spath = os.path.split(path)[0] + '/' + plugin + '/arabhd.py'
        if not extra.strip() == '':
            u = url + '&extra=' + urllib.quote_plus(extra)
        else:
            u = url
    elif not extra.strip() == '':
        try:
            extra = extra.encode('utf-8', 'ingnore')
        except:
            pass

        u = spath + '?url=' + urllib.quote_plus(url) + '&mode=' + str(mode) + '&name=' + urllib.quote_plus(name) + '&page=' + str(page) + '&extra=' + urllib.quote_plus(extra)
    elif link == True:
        u = url
    else:
        u = spath + '?url=' + urllib.quote_plus(url) + '&mode=' + str(mode) + '&name=' + urllib.quote_plus(name) + '&page=' + str(page)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage='DefaultFolder.png', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title': name})
    if searchall is not None:
        try:
            dirname = os.path.split(searchall)[0]
            plugin_name = os.path.basename(dirname)
            search_file = searchall.replace('arabhd.pyc', 'searchall').replace('arabhd.pyo', 'searchall').replace('arabhd.py', 'searchall')
            afile = open(search_file, 'w')
            afile.write(plugin_name + ';;' + u)
            afile.close()
        except:
            pass

    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok

def getDomain(url):
    tmp = re.compile('//(.+?)/').findall(url)
    domain = 'server'
    if len(tmp) > 0:
        domain = tmp[0].replace('www.', '')
    if 'google' in domain:
        domain = 'google'
    if '.' in domain:
        domain = domain.split('.')[0]
    print 'server_url,server', url, domain
    return domain		