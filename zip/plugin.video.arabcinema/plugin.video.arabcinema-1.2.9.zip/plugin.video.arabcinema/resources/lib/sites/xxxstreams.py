'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream
    Copyright (C) 2016 anton40

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmcplugin
import xbmcgui
from resources.lib import utils
progress = utils.progress 
arabseed = 'http://arabseed.tv'

@utils.url_dispatcher.register('410')
def Main():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Categories[/B]',arabseed,413,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Search[/B]',arabseed + '?s=',414,'','')
    List(arabseed)
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('411', ['url'])
def List(url):
    try:
        html = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile(r'<div class="wrap">\s*<a href="([^"]+)".*?src="([^"]+)" itemprop="image"> <h2>([^"]+)</h2>.*?<ul class="list_down_title">([^"]+)</ul>', re.DOTALL | re.IGNORECASE).findall(html)
    for videopage, img, name, genre in match:
        name = utils.cleantext(name)
        genre = utils.cleanhtml(genre)
        genre = utils.cleantext(genre)
        genre = utils.cleanspec(genre)		
        utils.addDownLink(name, videopage, 412, img, 'genre',genre)
    try:
        nextp = re.compile("<a href='([^']+)'>&rsaquo;</a>", re.DOTALL | re.IGNORECASE).findall(html)
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]', nextp[0], 411,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


		   
@utils.url_dispatcher.register('412', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    progress.create('Play video', 'Searching videofile.')
    progress.update( 25, "", "Loading video page", "" )
    data = utils.getHtml(url, url)
    if "rel='shortlink'" in data:
        res_quality = []
        stream_url = []
        quality = ''
        regx="rel='shortlink' href='.*?p=(.+?)'"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[0]
        print "id",id		
        for i in range(0,5):
          catpage='http://arabseed.tv/wp-content/themes/asd2018/functions/inc/single/server/film.php?id=' + id + '&key=' + str(i) + '&type=normal'
          print catpage
          quality = '[B][COLOR white]SERVER [%s][/COLOR][/B]' %str(i)
          res_quality.append(quality)
          stream_url.append(catpage)
        if len(id) >0:
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Please Select Servers',res_quality)
            if ret == -1:
                return
            elif ret > -1:
                videourl = stream_url[ret]
            try:
                    server = utils.getHtml(videourl, url)
            except:
                   return None
        a = re.compile('''src="(.*?)"''', re.DOTALL | re.IGNORECASE).findall(server)
        b = re.compile('''<ifram.*?src="([^'"]+)"''', re.DOTALL | re.IGNORECASE).findall(server)
        c = re.compile('''<IFRAM.*?SRC=([^'"]+)".*?</IFRAME>''', re.DOTALL | re.IGNORECASE).findall(server)
        d = re.compile('''<ifram.*?src="([^'"]+)".*?</iframe>''', re.DOTALL | re.IGNORECASE).findall(server)
        try:
           videourl = a[0]
        except:
            try:
               videourl = b[0]
            except:
                try:
                   videourl = c[0]
                except:
                      videourl = d[0]
        if videourl:
            utils.playvideo(videourl, name, download, url)
        else:
            utils.notify('Oh oh','Couldn\'t find a video')

	
	
@utils.url_dispatcher.register('413', ['url'])
def Categories(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<li.*?class="menu-item menu-item-type-taxonomy.*?"><a href="(.+?)">(.+?)</a></li>').findall(cathtml)
    for catpage, name in match:
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 411, '')    
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('414', ['url'], ['keyword'])
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 414)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        List(searchUrl)

