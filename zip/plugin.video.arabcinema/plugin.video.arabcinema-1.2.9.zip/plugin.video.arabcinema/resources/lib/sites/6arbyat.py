import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
tarbyat = 'http://www.6arbyat.com'
    
@utils.url_dispatcher.register('40')
def NFMain():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]MENU[/B]',tarbyat,44,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]TO 10[/B]',tarbyat,47,'',1)
    NFScenes(tarbyat + '/aghany-songs')
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('47', ['url'])
def NCat(url):
    cathtml = utils.getHtml(url, '')
	
    match1 = re.compile(r'<nav class="col-md-(.+?)</ul>', re.DOTALL | re.IGNORECASE).findall(cathtml)[0]
    match = re.compile(r"<li><i class=.*?href='([^']+)'>([^<]+)<", re.DOTALL | re.IGNORECASE).findall(match1)
    for catpage, name in match:
        catpage = catpage.replace(' ','%20')
        catpage = tarbyat + catpage		
        if 'top10' in catpage:	
            utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 48, '', 1)		
        else:	
            utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 42, '', 1)
    xbmcplugin.endOfDirectory(utils.addon_handle)
	
@utils.url_dispatcher.register('48', ['url'])
def TOP(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile(r"<li class='col-md-.*?href='([^']+)'>([^']+)</a></li>\s*<li class='col-md-.*?>([^']+)</li>", re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name, names in match:
        name = name + '[COLOR gold]('+names+')[/COLOR]'
        catpage = catpage.replace(' ','%20')
        catpage = tarbyat + catpage	
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 42, '', 1)
    xbmcplugin.endOfDirectory(utils.addon_handle)
	
@utils.url_dispatcher.register('44', ['url'])
def NFCat(url):
    try:
        cathtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile(r"col-md-3 col-xs-4 col-sm-2.*?<a href='([^']+)'>([^<]+)<", re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name in match:
          catpage = catpage.replace(' ','%20')
          catpage = tarbyat + catpage
          if 'hashtag' in catpage:	
              utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 42, '', 1)		
          else:	
              utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 41, '', 1)
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('41', ['url'], ['page'])
def NFList(url, page=1):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile("<li class=.*?col-md-.*?<a href='([^']+)'>\s*<img alt='([^']+)' src='([^']+)' />", re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, name, img in match:
        videopage = tarbyat + videopage
        img = tarbyat + img		
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, videopage, 45, img, '')
    try:		
        nextp= tarbyat + re.compile('<a href="(.*?)"><i class="fa fa-angle-left">').findall(listhtml)[0]
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]' ,nextp,  41, '')
    except: pass		
    xbmcplugin.endOfDirectory(utils.addon_handle)


	
@utils.url_dispatcher.register('45', ['url'])
def NScenes(url):
    try:
        scenehtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile("class='col-md-2'>.*?href='([^']+)' target='.*?alt='([^']+)' src='([^']+)'.*?class='album_infos'>", re.DOTALL | re.IGNORECASE).findall(scenehtml)
    for sceneurl, name, img in match:	
        sceneurl = tarbyat + sceneurl
        img = tarbyat + img		
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, sceneurl, 42, img, '')        
    xbmcplugin.endOfDirectory(utils.addon_handle)	
	
@utils.url_dispatcher.register('42', ['url'], ['page'])
def NFScenes(url, page=1):
    try:
        scenehtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile(r"<i class='fa fa-music'></i>.*?href='([^']+)'>([^']+)</a>", re.DOTALL | re.IGNORECASE).findall(scenehtml)
    for sceneurl, name in match:	
        sceneurl = tarbyat + sceneurl		
        utils.addDownLink('[B]%s[/B]'%name, sceneurl, 43, '', '') 
    try:		
        nextp= re.compile(r'<a href="(.*?)" rel="next">').findall(scenehtml)[0]
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]' ,nextp,  42, '')
    except: pass				
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('43', ['url', 'name'], ['download'])
def NFPlayvid(url, name, download=None):
    try:
        videopage = utils.getHtml(url, '')
    except:
        
        return None
    mp3 = re.compile('''<source src="([^'"]*mp3)"''', re.DOTALL | re.IGNORECASE).findall(videopage)
    videourl = mp3[0]
    videourl = videourl.replace('&amp;','&').replace(' ','%20').replace('&#039;',"'").replace('\/','/')
    if download == 1:
        utils.downloadVideo(videourl, name)
    else:
        videourl = videourl.replace('&amp;','&').replace(' ','%20').replace('&#039;',"'").replace('\/','/')
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        listitem.setInfo('video', {'Title': name, 'Genre': '[COLOR red][B]MG-Arabic[/B][/COLOR]'})
        xbmc.Player().play(videourl, listitem)
