'''

   http://www.mg-tv.org/
   
   http://mg.esy.es/Kodi/


    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import urllib2
import urllib
import os
import sys
import random
import sqlite3
import json

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
progress = utils.progress



shahidlive = 'http://shahidlive.co'




	
	
	
@utils.url_dispatcher.register('475')
def PAQMain():
    #utils.addDir('[COLOR red]Refresh Camsoda images[/COLOR]','',479,'',Folder=False)
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]MENU[/B][/COLOR]',shahidlive,500,'','')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]MOVIES[/B][/COLOR]','http://shahidlive.co/Cat-100-1',476,'','')
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]Search[/B][/COLOR]',oof+'?s=',68,'','')
    List(shahidlive+'/Cat-46-1')
    xbmcplugin.endOfDirectory(utils.addon_handle)	
	
	
@utils.url_dispatcher.register('500', ['url'])
def GENRES(url):
    pshtml = utils.getHtml(url, '')
    Regex2 = re.findall(r'<ul class="hidden-xs">(.+?)</ul>', pshtml, re.DOTALL)
    for items in Regex2:
      Regex3 = re.findall(r'href="(.+?)">(.+?)</a>', items)
      for url,name in Regex3:
        if 'http' not in url:
           url = shahidlive + url
           # if '93-1' in url:
                 # utils.addDir('[COLOR red]MG.Arabic[/COLOR][B]%s[/B]'%name, url, 501, '', '', '')
           # else:
           utils.addDir('[COLOR red]MG.Arabic[/COLOR][B]%s[/B]'%name, url, 476, '', '', '')
    xbmcplugin.endOfDirectory(utils.addon_handle)	
	
#MOVIES	
@utils.url_dispatcher.register('476', ['url'], ['page'])
def List(url, page=1):
    if utils.addon.getSetting("chaturbate") == "true":
        clean_database(False)
    try:
        listhtml = utils.getHtml(url, '')
    except Exception as e:        
        return None
    match = re.compile(r'div class="col-md-3.*?href="([^"]+)".*?src="([^"]+jpg)" class=.*?class="title"><h4>([^"]+)</h4></div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    cookieString = getCookiesString()	
    for videourl, thumb, name in match:
        name = utils.cleantext(name)
        thumb = thumb + "|Cookie=" + urllib.quote(cookieString) + "&User-Agent=" + urllib.quote(utils.USER_AGENT)	
		
		
        video = videourl.replace('/vid_','').replace(' ','%20')
        if 'al_' in videourl:
		
           videourl = shahidlive + videourl
           utils.addDir('[B]%s[/B]'%utils.cleanspec(name), videourl, 476, thumb, '', '','')
        else:
           utils.addDownLink('[B]%s[/B]'%utils.cleanspec(name), video, 478, thumb, '', '','')
    try:
        #nextpage = re.compile('<div class="pagination">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
          nextp = re.compile('<li class=""><a href="(.*?)">.*?</a></li></ul>', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]

          nextp = shahidlive + nextp		
          utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]',nextp,  476, '')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


#TV
@utils.url_dispatcher.register('501', ['url'], ['page'])
def Listtv(url, page=1):
    if utils.addon.getSetting("chaturbate") == "true":
        clean_database(False)
    try:
        listhtml = utils.getHtml(url, '')
    except Exception as e:        
        return None
    match = re.compile(r'<a href="/al_([^"]+)">.*?src="([^"]+jpg)" class=.*?class="title"><h4>([^"]+)</h4></div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    cookieString = getCookiesString()	
    for videourl, thumb, name in match:
        thumb = thumb + "|Cookie=" + urllib.quote(cookieString) + "&User-Agent=" + urllib.quote(utils.USER_AGENT)
        name = utils.cleantext(name)

        utils.addDownLink('[B]%s[/B]'%utils.cleanspec(name), videourl, 478, thumb, '', '','')
    try:
        #nextpage = re.compile('<div class="pagination">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
          nextp = re.compile('<li class=""><a href="(.*?)">.*?</a></li></ul>', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]

          nextp = shahidlive + nextp		
          utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]',nextp,  501, '')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)
	
def getCookiesString():
    cookieString=""
    import cookielib
    try:
        cookieJar = cookielib.LWPCookieJar()
        cookieJar.load(utils.cookiePath,ignore_discard=True)
        for index, cookie in enumerate(cookieJar):
            cookieString+=cookie.name + "=" + cookie.value +";"
    except:
        import sys,traceback
        traceback.print_exc(file=sys.stdout)
    return cookieString
	
@utils.url_dispatcher.register('479')
def clean_database(showdialog=True):
    conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            lst = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % ".shahidlive.co")
            for row in lst:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try:
                    os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
                except:
                    pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % ".shahidlive.co")
            if showdialog:
                utils.notify('Finished', 'shahidlive images cleared')
    except:
        pass


@utils.url_dispatcher.register('478', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    progress.create('Play video', 'Searching videofile.')
    progress.update( 25, "", "Loading video page", "" )
    url = 'http://shahidlive.com/Play/'+url
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    target= re.findall(r'<iframe src="(.*?)\s(.*?)"', link, re.DOTALL)	
    target= target[0]
    target = target[0].replace('"','').strip()
    req_target = urllib2.Request(target)
    req_target.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response_target = urllib2.urlopen(req_target)
    link_target=response_target.read()
    #RTMPVideoURL(url=RTMP_URL, clip=PLAYPATH, swf_url=swf_url, args=(dict()))
    video_url= str(link_target).split('src="')[1].split('"')[0]#.strip().split('vod')
    videourl = ''.join(video_url)
    sep = '"'
    videourl = videourl.split(sep,1)[0]	
	
    if download == 1:
            utils.downloadVideo(videourl, name)
    else:
            iconimage = xbmc.getInfoImage("ListItem.Thumb")
            listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
            listitem.setInfo('video', {'Title': name, 'Genre': '[COLOR red]MG-Arabic[/COLOR]'})
            xbmc.Player().play(videourl, listitem)