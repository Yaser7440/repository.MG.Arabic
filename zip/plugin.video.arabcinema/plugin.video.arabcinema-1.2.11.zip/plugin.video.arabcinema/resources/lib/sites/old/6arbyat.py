'''

   http://www.mg-tv.org/
   
   http://mg.esy.es/Kodi/


    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''



import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
tarbyat = 'http://www.6arbyat.com'
    
@utils.url_dispatcher.register('40')
def NMain():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]MENU[/B]',tarbyat,44,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]NEW[/B]',tarbyat,47,'',1)
    singer(tarbyat + '/aghany-songs')
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('47', ['url'])
def NCat(url):
    cathtml = utils.getHtml(url, '')
	
    match = re.compile(r'<div class="news-block".*?href="([^"]+)".*?img src="([^"]+)" alt="([^"]+)".*?class="songName">([^"]+)</span>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, img, name, albumsname in match:
        img = tarbyat + img
        catpage = tarbyat + catpage		
        name = "[B]" + name +' ' "[COLOR red]" + albumsname + "[/COLOR][/B]" 
		
        utils.addDownLink('[COLOR red]MG.Arabic[/COLOR] %s'%name, catpage, 43, img, '')		

    xbmcplugin.endOfDirectory(utils.addon_handle)
	
# @utils.url_dispatcher.register('48', ['url'])
# def TOP(url):
    # cathtml = utils.getHtml(url, '')
    # match = re.compile(r"<li class='col-md-.*?href='([^']+)'>([^']+)</a></li>\s*<li class='col-md-.*?>([^']+)</li>", re.DOTALL | re.IGNORECASE).findall(cathtml)
    # for catpage, name, names in match:
        # name = name + '[COLOR gold]('+names+')[/COLOR]'
        # catpage = catpage.replace(' ','%20')
        # catpage = tarbyat + catpage	
        # utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 42, '', 1)
    # xbmcplugin.endOfDirectory(utils.addon_handle)
	
@utils.url_dispatcher.register('44', ['url'])
def NFMENU(url):
    try:
        cathtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile(r'<li><a href="([^"]+)">([^<]+)<', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name in match:
          catpage = catpage.replace(' ','%20')
          catpage = tarbyat + catpage
          # if 'singers' in catpage:	
              # utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 42, '', 1)		
          # else:	
          utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 41, '', 1)
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('41', ['url'], ['page'])
def NFList(url, page=1):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile('class="col-md-.*?href="([^"]+)">\s*<img src="([^"]+)" alt="([^"]+)" />', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, img, name in match:
        videopage = tarbyat + videopage
        img = tarbyat + img
        if '/albums' in videopage:	
          utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, videopage, 45, img, 1)		
        else:	
          utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, videopage, 48, img, 1)

    try:		
        nextp= tarbyat + re.compile('<a href="(.*?)"><i class="fa fa-angle-left">').findall(listhtml)[0]
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]' ,nextp,  41, '')
    except: pass		
    xbmcplugin.endOfDirectory(utils.addon_handle)


	
@utils.url_dispatcher.register('45', ['url'])
def albums(url):
    try:
        scenehtml = utils.getHtml(url, '')
    except:
        
        return None
		
    match1 = re.compile('class="col-md-8.*?<h2>([^"]+)</h2>', re.DOTALL | re.IGNORECASE).findall(scenehtml)
    for albumsname in match1:		
        albumsname = albumsname
    match2 = re.compile('class="col-md-8.*?<img src="([^"]+)">', re.DOTALL | re.IGNORECASE).findall(scenehtml)
    for img in match2:		
        img = tarbyat + img		
    match = re.compile('circle"></i> <a href="([^"]+)">([^"]+)</a>', re.DOTALL | re.IGNORECASE).findall(scenehtml)
    for sceneurl, name in match:	
        sceneurl = tarbyat + sceneurl
        name = "[B]" + name +' ' "[COLOR red]" + albumsname + "[/COLOR][/B]" 
		
        utils.addDownLink('[COLOR red]MG.Arabic[/COLOR] %s'%name, sceneurl, 43, img, '')        
    xbmcplugin.endOfDirectory(utils.addon_handle)	

@utils.url_dispatcher.register('48', ['url'])
def singers(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile('<li class="col-md-3 col-xs-12.*?href="([^"]+)">\s*<img src="([^"]+)" />([^"]+)</a>\s*</li>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, img, name in match:
        name = utils.cleantext(name)		
        videopage = tarbyat + videopage
        img = tarbyat + img
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, videopage, 45, img, 1)
    xbmcplugin.endOfDirectory(utils.addon_handle)

	
@utils.url_dispatcher.register('42', ['url'], ['page'])
def singer(url, page=1):
    try:
        scenehtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile(r'<i class="far fa-play-circle"></i>.*?href="([^"]+)">([^"]+)</a>.*?class="pull-left">.*?href=".*?">([^"]+)</a>', re.DOTALL | re.IGNORECASE).findall(scenehtml)
    for sceneurl, name, singer in match:
        name = "[B]" + name +' ' "[COLOR red]" + singer + "[/COLOR][/B]"
        sceneurl = tarbyat + sceneurl		
        utils.addDownLink(name, sceneurl, 43, '', '') 
    try:		
        nextp= re.compile(r'<a href="(.*?)" rel="next">').findall(scenehtml)[0]
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]' ,nextp,  42, '')
    except: pass				
    xbmcplugin.endOfDirectory(utils.addon_handle)


	

@utils.url_dispatcher.register('43', ['url', 'name'], ['download'])
def NFPlayvid(url, name, download=None):
    try:
        videopage = utils.getHtml(url, '')
    except:
        
        return None
    mp3 = re.compile('''src="([^'"]*mp3)"''', re.DOTALL | re.IGNORECASE).findall(videopage)
    videourl = mp3[0]
    videourl = videourl.replace('&amp;','&').replace(' ','%20').replace('&#039;',"'").replace('\/','/')
    if download == 1:
        utils.downloadVideo(videourl, name)
    else:
        videourl = videourl.replace('&amp;','&').replace(' ','%20').replace('&#039;',"'").replace('\/','/')
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        listitem.setInfo('video', {'Title': name, 'Genre': '[COLOR red][B]MG-Arabic[/B][/COLOR]'})
        xbmc.Player().play(videourl, listitem)
