'''

   http://www.mg-tv.org/
   
   http://mg.esy.es/Kodi/


    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib2
import re
import sys
import random
import urllib

try:
    import simplejson
except:
    import json as simplejson   

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib import websocket
progress = utils.progress
movizland = 'http://movizland.com/'

@utils.url_dispatcher.register('270')
def Main():
    #utils.addDir('[COLOR red]Refresh Cam4 images[/COLOR]','',283,'',Folder=False)
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]SEARCH[/B]',movizland + '?s=',276,'','')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]MENU[/B]',movizland ,274,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]MOVIES[/B]',movizland + 'cat/foreign/',271,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]YEARS[/B]', 'url',275,'','')
    List(movizland)
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('274', ['url'])
def XTCCat(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<h2><a href="([^"]+)" title="([^"]+)">.*?</a></h2>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name in match:

        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 271, '')	 
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('275', ['url'])
def getyears_movies(url):
    for i in range(1915,2019):
       utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]' %str(i),movizland + '/?type=year&s='+str(i),271,'','')
    xbmcplugin.endOfDirectory(utils.addon_handle)
	
@utils.url_dispatcher.register('271', ['url'], ['page'])
def List(url, page=1):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None
    match = re.compile(r'<div class="block" id="movie.*?<a title="([^"]+)" href="([^"]+)".*?src="([^"]+)" class=.*?</strong><a href=".*?" title="(.*?)">.*?href=".*?" title="(.*?)">.*?</a>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for name, videourl, thumb, gen1, gen2 in match:
        name = utils.cleantext(name)
        gener = gen1 + ' / ' + gen2
        utils.addDir('[B]%s[/B]'%name, videourl, 272, thumb,gener)
    try:
        nextp = re.compile('<li><a href="(.*?)">.*?&laquo;</a></li>').findall(listhtml)[0]		
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]', nextp,  271, '')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)
    



@utils.url_dispatcher.register('272', ['url', 'name'])
def Playvid(url, name):

	
  data = utils.getHtml(url, '')
  #regx='''font-size: 25px;" href="(.+?)">.+?</a>'''
  Regex2 = re.findall(r'<a class="RedirecTliNK"(.+?)<div class="ad">', data, re.DOTALL)
  for items in Regex2:  
  
   match2 = re.findall(r'font-size: 25px;" href="(.+?)">.+?</a>', items)
   for new_url in match2:
    print "new_url",new_url                        
    new_url = new_url
    data = resolveurl(new_url)
    Regex = re.compile("<br>\s*<script type='text/javascript'>(.+?)</script>",re.DOTALL).findall(data)[0]
    match = re.compile('''file:"([^'"]*mp4)",label:"([^"]+)"''', re.DOTALL | re.IGNORECASE).findall(Regex)
    for url,name in match:
          utils.addDownLink(name,url,  273, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)        
        

@utils.url_dispatcher.register('273', ['url', 'name'], ['download'])
def XTCPlayvid(url, name, download=None):
    progress.create('Play video', 'Searching videofile.')
    progress.update( 10, "", "Loading video page", "" )
    utils.playvid(url, name, download)

@utils.url_dispatcher.register('276', ['url'], ['keyword'])    
def XTCSearch(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 271)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        XTCListSE(searchUrl)
#######################################host resolving 


	
def resolveurl(url):
    import re,time
    print "url",url
    #sys.exit(0)
    html = utils.getHtml(url, '')                         
    id = re.compile(r'<input type="hidden" name="id" value="(.*?)">', re.DOTALL | re.IGNORECASE).findall(html)[0]
    fname = re.compile(r'<input type="hidden" name="fname" value="(.*?)">', re.DOTALL | re.IGNORECASE).findall(html)[0]
    hash = re.compile(r'<input type="hidden" name="hash" value="(.*?)">', re.DOTALL | re.IGNORECASE).findall(html)[0]
    action = re.compile('''<Form method="POST" action='(.*?)'>''', re.DOTALL | re.IGNORECASE).findall(html)[0]
    print "id,fname,hash,action",id,fname,hash,action
    time.sleep(10)
    #sys.exit(0)
    data= {'imhuman': "Proceed to video", 'op': 'download1', 'usr_login': '', 'id': id, 'fname': fname, 'referer': '', 'method': 'POST', 'action': action, 'hash': hash}   
    result = utils.net.http_POST(url, data, headers={}, compression=True).content
    print "result",result.encode("utf-8")
    return result



