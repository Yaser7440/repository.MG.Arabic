'''

   http://www.mg-tv.org/
   
   http://mg.esy.es/Kodi/


    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
import xbmcgui
import xbmcplugin
from resources.lib import utils
addon = utils.addon
progress = utils.progress
egy = 'https://vi.egybest.vip'

@utils.url_dispatcher.register('110')
def EXMain():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]MENU[/B]',egy,113,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]General[/B]',egy + '/movies/',119,'','')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Search[/B]',egy + '/explore/?q=',114,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]TV[/B]',egy + '/tv',115,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Trending[/B]',egy + '/trending/',116,'','')
    EXList(egy + '/movies/')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('111', ['url'], ['page'])
def EXList(url, page=1):	
     try:
        listhtml = utils.getHtml(url, '')
     except:
        
        return None		
     match = re.compile('<a href="([^"]+)"[^>]+>.*?data-src="([^"]+)" title="([^"]+)" alt=', re.DOTALL | re.IGNORECASE).findall(listhtml)
     for videopage, img, name in match:
        name = utils.cleantext(name)
        name = utils.cleanspec(name)
        name = utils.cleanhtml(name)		
        if img.startswith('//'): img = 'https:' + img
        #rate = rate + '\n' + hd
        if 'tv' in url:
          utils.addDir('[B]%s[/B]'%name, videopage, 117, img, '')		
        else:		
          utils.addDownLink('[B]%s[/B]'%name, videopage, 112, img, '')
     try:	  
          npag = re.compile(r'</a><a href=".*?(=[^"]+)" args="&output_mode=movies_list"', re.DOTALL | re.IGNORECASE).findall(listhtml)	  
          if 'page' not in url:
           for np in npag:
              url = url + '?page' + np
              utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]', url, 111, '')
          else:
           for np in npag:
             #range=['1','2','3','4','5','6','7','8','9']
             for i in range(1,100):
              url = url.replace('=' + str(i),np)			  
             utils.addDir('[COLOR red][B]Next Page ('+np+')[/B][/COLOR]', url, 111, '')

     except: pass		  
     xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('114', ['url'], ['keyword'])      
def EXSearch(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 114)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title #+ ".html"
        print "Searching URL: " + searchUrl
        EXList(searchUrl)


@utils.url_dispatcher.register('113', ['url'])
def EXCat(url):
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]TOP[/B]',egy + '/movies/top',111,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Popular[/B]',egy + '/movies/popular',111,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Latest[/B]',egy + '/movies/latest',111,'','')	
    cathtml = utils.getHtml(url, '')
    match = re.compile('<div class="hcenter tal">(.*?)<div class="tam pdb">', re.DOTALL | re.IGNORECASE).findall(cathtml)
    match1 = re.compile('<a href="([^"]+)">([^<]+)</a>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name in match1:
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 111, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)   


@utils.url_dispatcher.register('112', ['url', 'name'])
def Playvid(url, name):
    playmode = int(addon.getSetting('chatplay'))
    chatslow = int(addon.getSetting('chatslow'))
    listhtml = utils.getHtml(url, hdr=cbheaders)
    iconimage = xbmc.getInfoImage("ListItem.Thumb")
    
    m3u8url = re.compile(r"jsplayer, '([^']+)", re.DOTALL | re.IGNORECASE).findall(listhtml)
    if m3u8url:
        m3u8stream = m3u8url[0]
        if chatslow == 1:
            m3u8stream = m3u8stream.replace('_fast','')
    else:
        m3u8stream = False
    
    if playmode == 0:
        if m3u8stream:
            videourl = m3u8stream
        else:
            utils.notify('Oh oh','Couldn\'t find a playable webcam link')
            return
        
    elif playmode == 1:
        if m3u8stream:
            from F4mProxy import f4mProxyHelper
            f4mp=f4mProxyHelper()
            f4mp.playF4mLink(m3u8stream,name,proxy=None,use_proxy_for_chunks=False, maxbitrate=0, simpleDownloader=False, auth=None, streamtype='HLS',setResolved=False,swf=None , callbackpath="",callbackparam="", iconImage=iconimage)
            return
        else:
            utils.notify('Oh oh','Couldn\'t find a playable webcam link')
            return        
    
    elif playmode == 2:
        flv_info = []
        embed = re.compile(r"EmbedViewerSwf\(*(.+?)\);", re.DOTALL).findall(listhtml)[0]
        for line in embed.split("\n"):
            data = re.search("""\s+["']([^"']+)["'],""", line)
            if data:
                flv_info.append(data.group(1))
        
        streamserver = "rtmp://%s/live-edge"%(flv_info[2])
        modelname = flv_info[1]
        username = flv_info[8]
        password = urllib.unquote(flv_info[12])
        unknown = flv_info[13]
        swfurl = "https://chaturbate.com/static/flash/CBV_2p650.swf"
        
        videourl = "%s app=live-edge swfUrl=%s tcUrl=%s pageUrl=http://chaturbate.com/%s/ conn=S:%s conn=S:%s conn=S:2.650 conn=S:%s conn=S:%s playpath=mp4"%(streamserver,swfurl,streamserver,modelname,username,modelname,password,unknown)

    listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
    listitem.setProperty("IsPlayable","true")
    xbmc.Player().play(videourl, listitem)


@utils.url_dispatcher.register('115', ['url'])
def EXTv(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<div id="main" class="td vat">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    match1 = re.compile('href="([^"]+)[^>]+><[^"]+[^>]+><[^>]+>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(match[0])
    for catpage, name in match1:
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 111, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('116', ['url'])
def EXMovies(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<div id="main" class="td vat">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    match1 = re.compile('href="([^"]+)"[^>]+><[^"]+[^>]+><[^>]+>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(match[0])
    for catpage, name in match1:
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 111, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('117', ['url'])
def EXTVList(url):
    listhtml = utils.getHtml(url, '')
    match = re.compile('<div class="h_scroll">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    match1 = re.compile('<a href="([^"]+)"[^>]+><[^"]+src="([^"]+)".*?class="title">([^"]+)<[^>]+> </a>', re.DOTALL | re.IGNORECASE).findall(match[0])
    for videopage, img, name in match1:
        img = 'http:' + img   
        utils.addDir('[B]%s[/B]'%name, videopage, 118, img, '')
    # try:
        # nextp=re.compile("<a href='([^']+)' title='([^']+)'>&raquo;</a>", re.DOTALL | re.IGNORECASE).findall(listhtml)
        # next = urllib.quote_plus(nextp[0][0])
        # next = next.replace(' ','+')
        # utils.addDir('Next Page', os.path.split(url)[0] + '/' + next, 117,'')
    # except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('118', ['url'])
def EXepiList(url):
    listhtml = utils.getHtml(url, '')
    match = re.compile('<div class="pda">(.*?)</a></div>\s*</div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    match1 = re.compile('href="([^"]+)"[^>]+><[^"]+src="([^"]+)".*?class="title">([^"]+)<[^>]+> <[^"]+[^>]+><[^>]+>([^"]+)<[^>]+></span>', re.DOTALL | re.IGNORECASE).findall(match[0])
    for videopage, img, name, nam in match1:
        name = name + nam
        img = 'http:' + img   
        utils.addDownLink('[B]%s[/B]'%name, videopage, 112, img, '')
    # try:
        # nextp=re.compile("<a href='([^']+)' title='([^']+)'>&raquo;</a>", re.DOTALL | re.IGNORECASE).findall(listhtml)
        # next = urllib.quote_plus(nextp[0][0])
        # next = next.replace(' ','+')
        # utils.addDir('Next Page', os.path.split(url)[0] + '/' + next, 118,'')
    # except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)
	

@utils.url_dispatcher.register('119', ['url'])
def EXG(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('class="sub_nav">(.*?)</div></div></div>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    match1 = re.compile(r'href="([^"]+)".*?>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(match[0])
    for catpage, name in match1:
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 111, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)	
