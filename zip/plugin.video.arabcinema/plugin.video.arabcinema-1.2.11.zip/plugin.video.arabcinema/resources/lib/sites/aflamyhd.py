'''

   http://www.mg-tv.org/
   
   http://mg.esy.es/Kodi/


    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
progress = utils.progress
dialog = utils.dialog
aflamyhd = 'http://www.aflamyhd.com'

@utils.url_dispatcher.register('250')
def Main():
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]MENU[/B][/COLOR]',aflamyhd,253,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]MOVIES[/B][/COLOR]',aflamyhd + '/movies.html',251,'','')	
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]Search[/B][/COLOR]','http://en.paradisehill.cc/search_results/?search=',254,'','')
    List(aflamyhd + '/movies')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('251', ['url'], ['page'])
def List(url, page=1):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None
    match = re.compile(r'href="([^"]+)">\s*<img src="([^"]+jpg)" alt="([^"]+)"  />', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, name in match:
        thumb = aflamyhd + thumb
        name = utils.cleantext(name)
        videourl = aflamyhd + videourl
        utils.addDownLink('[B]%s[/B]'%utils.cleanspec(name), videourl, 252, thumb, '', '','')
    try:
        nextpage = re.compile('<div class="pagination">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
        nextp = re.compile('<li><a href="(.*?)" title="(.*?)">', re.DOTALL | re.IGNORECASE).findall(nextpage[0])
        for pageurl, name in nextp:
          pageurl = aflamyhd + pageurl		
          utils.addDir('[COLOR red][B]Next Page (%s)[/B][/COLOR]' %name,pageurl,  251, '')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('253', ['url'])
def Cat(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<div class="top_menu">(.*?)</ul></div>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    match1 = re.compile('href="([^"]+)"><span class="yjm_has_none"><span class="yjm_title">([^<]+)</span></span></a>', re.DOTALL | re.IGNORECASE).findall(match[0])
    for caturl, name in match1:
        catpage = aflamyhd + caturl #+ "?page=1"
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 251, '', 1)
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('254', ['url'], ['keyword'])
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 254)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title + '&page=1'
        List(searchUrl, 1)


@utils.url_dispatcher.register('252', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name)
    vp.progress.update(25, "", "Loading video page", "")
    vidsite = utils.getHtml(url, aflamyhd)
    video = re.compile('''<(?:iframe|IFRAME).*?(?:src|SRC)\s*=\s*["']([^'"]+)''', re.DOTALL | re.IGNORECASE).findall(vidsite)[0]
    vp.play_from_link_to_resolve(video)