'''
   http://www.mg-tv.org/
   
   http://mg.esy.es/Kodi/
'''


import urllib
import re
import os.path
import sys
import socket

import xbmc
import xbmcplugin
import xbmcaddon
from resources.lib import utils
from resources.lib import favorites
from resources.lib.sites import *

socket.setdefaulttimeout(60)

xbmcplugin.setContent(utils.addon_handle, 'movies')
addon = xbmcaddon.Addon(id=utils.__scriptid__)

progress = utils.progress
dialog = utils.dialog

imgDir = utils.imgDir
rootDir = utils.rootDir

@utils.url_dispatcher.register('0')
def INDEX():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR red][B]http://mg.esy.es/Kodi/[/B][/COLOR]','','',os.path.join(rootDir, 'fanart.jpg'),'Developed By (http://mg.esy.es/Kodi/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]6arbyat[/B]','http://www.6arbyat.com/',40,os.path.join(imgDir, 'tarbyat.png'),'The Website is (http://www.6arbyat.com/)')
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]HD-Arab[/B]','https://hd-arab.com/',90,os.path.join(imgDir, 'hdarab.png'),'The Website is (https://hd-arab.com/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]AlArab[/B]','http://tv1.alarab.com/',50,os.path.join(imgDir, 'alarab.png'),'The Website is (http://tv1.alarab.com/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]MoviesWBB[/B]','http://movieswbb.com/',80,os.path.join(imgDir, 'movieswbb.png'),'The Website is (http://movieswbb.com/)')
   #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Mago.Tv[/B]','http://www.mago.tv',260,os.path.join(imgDir, 'mago.tv.png'),'The Website is (http://www.mago.tv)')
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Arabseed.Tv[/B]','http://arabseed.tv/',410,os.path.join(imgDir, 'xxxstreams.png'),'The Website is (http://arabseed.tv/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Shof[/B]','http://shof.co.il/',340,os.path.join(imgDir, 'shof.png'),'The Website is (http://shof.co.il/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]SeeHD[/B]','http://www.seehd.ws/',450,os.path.join(imgDir, 'seehd.png'),'The Website is (http://www.seehd.ws/)')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Shahid4u[/B]','http://shahid4u.com/',179,os.path.join(imgDir, 'shahid4u.png'),'The Website is (http://shahid4u.com/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]AnakbNet[/B]','http://www.anakbnet.com/video/',182,os.path.join(imgDir, 'anakbnet.png'),'The Website is (http://www.anakbnet.com/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]El7l.Tv[/B]','https://el7l.tv/',10,os.path.join(imgDir, 'el7l.png'),'The Website is (https://el7l.tv/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]AlMstba[/B]','https://www.almstba.tv/',245,os.path.join(imgDir, 'almstba.png'),'The Website is (https://www.almstba.tv/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Arab-Moviez[/B]','http://arab-moviez.org/',230,os.path.join(imgDir, 'arab.moviez.png'),'The Website is (http://arab-moviez.org/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]4oof[/B]','http://www.4oof.com/',60,os.path.join(imgDir, '4oof.png'),'The Website is (http://www.4oof.com/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Streamlord[/B]','http://www.streamlord.com/',480,os.path.join(imgDir, 'streamlord.png'),'The Website is (http://www.streamlord.com/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Arablionz[/B]','http://arablionz.tv',200,os.path.join(imgDir, 'arablionz.png'),'The Website is (http://arablionz.tv/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Series4Watch[/B]','http://www.series4watch.tv',100,os.path.join(imgDir, 'series4watch.png'),'The Website is (http://www.series4watch.tv)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Afonlinee[/B]','https://www.afonlinee.com/',370,os.path.join(imgDir, 'aflamonlinee.png'),'The Website is (https://www.afonlinee.com/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]AflamyHD[/B]','http://www.aflamyhd.com/',250,os.path.join(imgDir, 'aflamyhd.png'),'The Website is (http://www.aflamyhd.com/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]ShahidLive[/B]','http://shahidlive.co',475,os.path.join(imgDir, 'shahidlive.png'),'The Website is (http://shahidlive.co)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]ArabHD[/B]','http://arabhd.co/',280,os.path.join(imgDir, 'arabhd.png'),'The Website is (http://arabhd.co/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]MovizLand[/B]','http://movizland.com/',270,os.path.join(imgDir, 'movizland.png'),'The Website is (http://movizland.com/)')
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]1movies.to[/B]','https://1movies.to/',390,os.path.join(imgDir, 'pornhub.png'),'The Website is (https://1movies.to/)')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Egy.Best[/B]','http://egy.best',110,os.path.join(imgDir, 'egybest.png'),'The Website is (http://egy.best/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]CinmaStar[/B]','https://cinmastar.com/',470,os.path.join(imgDir, 'cinmastar.png'),'The Website is (https://cinmastar.com/)')
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Aflamonlinee[/B]','http://www.aflamonlinee.org/new/',320,os.path.join(imgDir, 'aflamonlinee.png'),'The Website is (http://www.aflamonlinee.org/new/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Movie4k[/B]','http://movie4k.tv/',360,os.path.join(imgDir, 'movie4k.png'),'The Website is (http://movie4k.tv/)')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]123MoviesHub[/B]','http://123movieshub.com/',420,os.path.join(imgDir, '123movieshub.png'),'The Website is (http://123movieshub.com/)')		
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]CimaClub[/B]','http://cimaclub.com/',310,os.path.join(imgDir, 'cimaclub.png'),'The Website is (http://cimaclub.com/)')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Htshof[/B]','https://htshof.com',130,os.path.join(imgDir, 'hatshof.png'),'The Website is (https://htshof.com)')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Mazika2day[/B]','https://mazika2day.tv',20,os.path.join(imgDir, 'mazika2day.png'),'The Website is (https://mazika2day.tv)')
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]EasyCima[/B]','http://www.easycima.com/',400,os.path.join(imgDir, 'mrsexe.png'),'The Website is (http://www.easycima.com/)')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]beout[COLOR purple]Q[/COLOR] Sport [COLOR yellow]TEST[/COLOR][/B]','http://beoutq.se/ar/',380,os.path.join(imgDir, 'beoutq.png'),'The Website is (http://beoutq.se/ar/ And https://cdn.streaminghd.tn/)')
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]IPTV[/B] [B][COLOR yellow]TEST[/COLOR][/B]','https://cera.video',610,'','The Website is (http://iptv.filmover.com/)')	
    utils.add_item(title="[COLOR red]MG.Arabic[/COLOR] [B]RadioTime[/B]",url="plugin://plugin.audio.tuneinradio/default.py",thumbnail=os.path.join(imgDir, 'radiotime.png'),folder=True )   
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Favorites[/B]','',901,os.path.join(rootDir, 'icon.png'),'')
    download_path = addon.getSetting('download_path')
    if download_path != '' and os.path.exists(download_path):
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Download Folder[/B]',download_path,4,os.path.join(rootDir, 'icon.png'),'')
    xbmcplugin.endOfDirectory(utils.addon_handle, cacheToDisc=False)





@utils.url_dispatcher.register('4', ['url'])
def OpenDownloadFolder(url):
    xbmc.executebuiltin('ActivateWindow(Videos, ' + url + ')')


@utils.url_dispatcher.register('8')
def smrSettings():
    utils.urlresolver.display_settings()


def change():
    if addon.getSetting('changelog_seen_version') == utils.__version__ or not os.path.isfile(utils.changelog):
        return
    addon.setSetting('changelog_seen_version', utils.__version__)
    heading = '[B][COLOR red]ArabCinema[/COLOR] [COLOR white]Changelog[/COLOR][/B]'
    with open(utils.changelog) as f:
        cl_lines = f.readlines()
    announce = ''
    for line in cl_lines:
        if not line.strip():
            break
        announce += line
    utils.textBox(heading, announce)
    




def main(argv=None):
    if sys.argv: argv = sys.argv
    queries = utils.parse_query(sys.argv[2])
    mode = queries.get('mode', None)
    utils.url_dispatcher.dispatch(mode, queries)


if __name__ == '__main__':
        sys.exit(main())