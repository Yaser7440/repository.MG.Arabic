'''

   http://www.mg-tv.org/
   
   http://mg.esy.es/Kodi/


    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import os
import sys
import sqlite3

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
progress = utils.progress
streamlord = 'http://www.streamlord.com/'

@utils.url_dispatcher.register('480')
def Main():
	#utils.addDir('[COLOR red]Refresh streamlord.com images[/COLOR]','',483,'',Folder=False)
	utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]MOVIES GENRES[/B][/COLOR]',streamlord,485,'','')
	utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]MOVIES ABC[/B][/COLOR]',streamlord+'movies-genre-adventure.html',486,'','')
	utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]MOVIES RATING[/B][/COLOR]',streamlord + 'movies.php?sortby=rating',481,'','')
	utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]NEW MOVIES[/B][/COLOR]',streamlord + 'movies.php',481,'','')	
	utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]MOVIES[/B][/COLOR]',streamlord + 'movies.html',481,'','')
	#utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]TV SERIES[/B][/COLOR]',streamlord + 'tvshows.html',484,'','')	
	#List(streamlord + 'movies.html')
	xbmcplugin.endOfDirectory(utils.addon_handle)

#MOVIES GENRES
@utils.url_dispatcher.register('485', ['url'], ['page'])
def GENRES(url, page=1):
    pshtml = utils.getHtml(url, '')
    Regex2 = re.findall(r'<ul class="fallback">(.+?)</ul>', pshtml, re.DOTALL)
    for items in Regex2:
      Regex3 = re.findall(r'<a href="(.+?)">(.+?)</a></li>', items)
      for url, name in Regex3:
        if 'http' not in url:
           url = streamlord + url		   
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name,  url, 481, '', '', 1)
    xbmcplugin.endOfDirectory(utils.addon_handle)

#MOVIES ABC
@utils.url_dispatcher.register('486', ['url'], ['page'])
def GENRES(url, page=1):
    pshtml = utils.getHtml(url, '')
    Regex2 = re.findall(r'<div id="alphabet"(.+?)</div>', pshtml, re.DOTALL)
    for items in Regex2:
      Regex3 = re.findall(r'<a href="./(.+?)".*?>(.+?)</a>', items)
      for url, name in Regex3:
        if 'http' not in url:
           url = streamlord + url		   
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name,  url, 481, '', '', 1)
    xbmcplugin.endOfDirectory(utils.addon_handle)	
	
	
@utils.url_dispatcher.register('481', ['url'], ['page'])
def List(url, page=1):
    # if utils.addon.getSetting("chaturbate") == "true":
        # clean_database(False)
    try:
        data = utils.getHtml(url, '')
    except:
        
        return None
    model_list = re.compile('href="([^"]+)"><img src=([^"]+) w.*?/></a>.*?class="movie-grid-title">([^"]+)<span class=.*?class="movie-grid-floater movie-grid-year">([^"]+)</span>.*?<p class="search-rating">.*?<span>([^"]+)</span>.*?</p>', re.DOTALL | re.IGNORECASE).findall(data)
    for  url, thumb, name, aired, rating in model_list:
        videourl = streamlord + url
        thumb = streamlord + thumb.replace("'","")#.strip()
        name = utils.cleantext(name)
        name = utils.cleanspec(name)
        name = name + " [COLOR red]("+aired+rating+")[/COLOR]"		
        utils.addDownLink('[B]%s[/B]'%name, videourl, 482, thumb, 'None','None','None','None',aired, rating)
    try:
        nextp=re.compile('<a href="(.*?)"> NEXT  &nbsp;&nbsp;&nbsp; &gt; </a>').findall(data)[0]
        nextp = streamlord + nextp.replace("./","")
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]' ,nextp,  481, '')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)

#TV SERIES	
@utils.url_dispatcher.register('484', ['url'], ['page'])
def Listtv(url, page=1):
    # if utils.addon.getSetting("chaturbate") == "true":
        # clean_database(False)
    try:
        data = utils.getHtml(url, '')
    except:
        
        return None
    model_list = re.compile('href="([^"]+)"><img src=([^"]+) w.*?/></a>.*?class="movie-grid-title">([^"]+)<span class=.*?class="movie-grid-floater movie-grid-year">', re.DOTALL | re.IGNORECASE).findall(data)
    for  url, thumb, name in model_list:
        videourl = streamlord + url
        thumb = streamlord + thumb.replace("'","")#.strip()
        name = utils.cleantext(name)
        name = utils.cleanspec(name)
        #name = name + " [COLOR red]("+aired+rating+")[/COLOR]"		
        utils.addDir('[B]%s[/B]'%name, videourl, 487, thumb, 'None','None','None','None','aired', 'rating')
    try:
        nextp=re.compile('<a href="(.*?)"> NEXT  &nbsp;&nbsp;&nbsp; &gt; </a>').findall(data)[0]
        nextp = streamlord + nextp.replace("./","")
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]' ,nextp,  481, '')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)

#EPISODE	
@utils.url_dispatcher.register('487', ['url'], ['page'])
def Listep(url, page=1):

    try:
        data = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile('<div class="col span_10 gutters row">(.*?)<ul id="improved">', re.DOTALL | re.IGNORECASE).findall(data)[0]
    for season in match:
        season = season	
    model_list = re.compile('<a class="head"><span>([^"]+)<ep>.*?</ep>([^"]+)</span>([^"]+)</a>.*?<a href="([^"]+)"><img src="([^"]+)"></a>.*?<p>([^"]+)</p>', re.DOTALL | re.IGNORECASE).findall(match)
    for Ep, namber, name, videourl, thumb, desc in model_list:
	
        videourl = streamlord + videourl
        #thumb = thumb.replace("'","")#.strip()
        name = utils.cleantext(name)
        name = utils.cleanspec(name)
        name = "[COLOR red]("+ Ep + namber+")[/COLOR] " + name		
        utils.addDownLink('[B]%s[/B]'%name, videourl, 482, thumb, utils.cleantext(desc),'None','None','None','aired', 'rating')
    xbmcplugin.endOfDirectory(utils.addon_handle)	

	
@utils.url_dispatcher.register('483')
def clean_database(showdialog=True):
    conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % ".streamlord.com")
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try: os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
                except: pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % ".streamlord.com")
            if showdialog:
                utils.notify('Finished','streamlord.com images cleared')
    except:
        pass


@utils.url_dispatcher.register('482', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
  try:
    progress.create('Play video', 'Searching videofile.')
    progress.update( 10, "", "Loading video page", "" )
    url = url.split('#')[0]
    videopage = utils.getHtml(url, '')
    a = re.compile('return.*?"(.+?)".*?;', re.DOTALL | re.IGNORECASE).findall(videopage)[0]

    videourl = a	
    videourl = videourl.replace('&amp;','&').replace(' ','%20').replace('&#039;',"'").replace('\/','/')
    if download == 1:
            utils.downloadVideo(videourl, name)
    else:
            videourl = videourl.replace('&amp;','&').replace(' ','%20').replace('&#039;',"'").replace('\/','/')
            iconimage = xbmc.getInfoImage("ListItem.Thumb")
            listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
            listitem.setInfo('video', {'Title': name, 'Genre': '[COLOR red][B]MG-Arabic[/B][/COLOR]'})
            listitem.setProperty("IsPlayable","true")
            if int(sys.argv[1]) == -1:
               pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
               pl.clear()
               pl.add(videourl, listitem)
               xbmc.Player().play(pl)
            else:
               listitem.setPath(str(videourl))
               xbmcplugin.setResolvedUrl(utils.addon_handle, True, listitem)
    # else:
        # utils.notify('Oh oh','Couldn\'t find a playable webcam link')
  except Exception:
            return		