'''

   http://www.mg-tv.org/
   
   http://mg.esy.es/Kodi/


    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmcplugin
from resources.lib import utils

progress = utils.progress
almstba = 'https://www.almstba.tv/video/'


@utils.url_dispatcher.register('245')
def MainMovies():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]SEARCH[/B][/COLOR]',almstba + 'search.php?keywords=', 244, '', '')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]MENU[/B][/COLOR]',almstba,246,'','')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]Categories[/B][/COLOR]',almstba,247,'','')
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]TV[/B][/COLOR]','https://www.almstba.tv/video/category.php?cat=english-series&page=1&sortby=views',243,'','')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]Movies[/B][/COLOR]',almstba + 'category.php?cat=arabic-movies&page=1&sortby=views', 241, '', '')
    List(almstba)
    xbmcplugin.endOfDirectory(utils.addon_handle)

	
@utils.url_dispatcher.register('246', ['url'])
def MENU(url):
    listhtml = utils.getHtml(url, '')
    match = re.compile('<li class=""><a href="([^"]+)".*?>([^"]+)</a></li>').findall(listhtml)
    for catpage, name in match:
        name = utils.cleantext(name)
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]' %name, catpage + '&page=1&sortby=views', 241, '', '')
    xbmcplugin.endOfDirectory(utils.addon_handle)
@utils.url_dispatcher.register('247', ['url'])
def Categories(url):
    listhtml = utils.getHtml(url, '')
    match = re.compile('<a href="([^"]+)" class="tag_cloud_link".*?>([^"]+)</a>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for catpage, name in match:
        name = utils.cleantext(name)		
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]' %name, catpage, 241, '', '')
    xbmcplugin.endOfDirectory(utils.addon_handle)
	
@utils.url_dispatcher.register('241', ['url'], ['page'])
def List(url, page=1):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None
    match = re.compile(r'href="([^"]+)" title="([^"]+)">.*?data-echo="([^"]+)" class="img-responsive">', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, name, img in match:
      if 'watch.php' in videopage:
         videopage = videopage.replace("watch.php","view.php")
         name = utils.cleantext(name)
         utils.addDownLink('[B]%s[/B]' %name, videopage, 242, img, '')
    try:
        nextp = re.compile('<li class="">\s*<a href="([^"]+)">&raquo;</a>', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        if 'almstba' not in nextp:
         nextp = almstba + nextp		
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]', nextp, 241,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('243', ['url'])
def ListCategories(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile(r'uniq_id: "([^"]+)",').findall(listhtml)
    for videopage, img, name in match:
        print "Processing: " + name
        name = utils.cleantext(name)
        #videopage = videopage.replace("/f/","/play/")
        utils.addDownLink('[COLOR white][B]%s[/B][/COLOR]' %name, videopage, 242, img, '')
    try:
        print "Adding next"
        nextp=re.compile('<a href="(.+?)" class="next">', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        if 'almstba' not in nextp:
         nextp = almstba + nextp
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]', nextp, 243,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)
	
@utils.url_dispatcher.register('244', ['url'], ['keyword'])    
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 244)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        List(searchUrl)


@utils.url_dispatcher.register('242', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    utils.PLAYVIDEO(url, name, download)