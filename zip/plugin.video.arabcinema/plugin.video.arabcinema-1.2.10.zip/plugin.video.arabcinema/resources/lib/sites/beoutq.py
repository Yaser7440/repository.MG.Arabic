'''

   http://www.mg-tv.org/
   
   http://mg.esy.es/Kodi/


    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils

progress = utils.progress


@utils.url_dispatcher.register('380')
def Main():
    utils.addDownLink('[B][COLOR white]beout[COLOR purple]Q[/COLOR] Sport 1[/COLOR][/B]','http://c.blackhouse.sx/live1/index.m3u8',382,'http://www.beoutq.sx/uploads/channels/MBOa5aTdiq5PFkmrfQavgqqAEjPCGR6ypKjKqhvy.png','')
    utils.addDownLink('[B][COLOR white]beout[COLOR purple]Q[/COLOR] Sport 2[/COLOR][/B]','http://c.blackhouse.sx/live2/index.m3u8',382,'http://www.beoutq.sx/uploads/channels/S0VaE6iiC3gBY4Eh6y9xM8BZwYYgBglMVnhBt1P3.png','')
    utils.addDownLink('[B][COLOR white]beout[COLOR purple]Q[/COLOR] Sport 3[/COLOR][/B]','http://c.blackhouse.sx/live3/index.m3u8',382,'http://www.beoutq.sx/uploads/channels/15c2v9sqcjF1r2qDvzVTSQrPgpDmuOLA3equtc7V.png','')
    utils.addDownLink('[B][COLOR white]beout[COLOR purple]Q[/COLOR] Sport 4[/COLOR][/B]','http://blackhouse.sx/live4/index.m3u8',382,'http://www.beoutq.sx/uploads/channels/Dd8GDcUVd9P9HXvgHburrfvVeydazmROGyHEjD17.png','')
    utils.addDownLink('[B][COLOR white]beout[COLOR purple]Q[/COLOR] Sport 5[/COLOR][/B]','http://blackhouse.sx/live5/index.m3u8',382,'http://www.beoutq.sx/uploads/channels/y2ecVdHZ8VnAeY1LcLIKKa7DpN7zNEHwJlgBEQIX.png','')
    utils.addDownLink('[B][COLOR white]beout[COLOR purple]Q[/COLOR] Sport 6[/COLOR][/B]','http://blackhouse.sx/live6/index.m3u8',382,'http://www.beoutq.sx/uploads/channels/DKizOgIrNCIFDaemzcY6mQolf3W4kSHnvdvRZRgb.png','')
    utils.addDownLink('[B][COLOR white]beout[COLOR purple]Q[/COLOR] Sport 7[/COLOR][/B]','http://blackhouse.sx/live7/index.m3u8',382,'http://www.beoutq.sx/uploads/channels/95BtiJUwastMgVk3e8sb9393YgDpnBEvz5iCtaS8.png','')
    utils.addDownLink('[B][COLOR white]beout[COLOR purple]Q[/COLOR] Sport 8[/COLOR][/B]','http://blackhouse.sx/live8/index.m3u8',382,'http://www.beoutq.sx/uploads/channels/SDoAovTbNPfyRJ4AkAAwOoYaYyf6N0RS3QesG0S3.png','')
    utils.addDownLink('[B][COLOR white]beout[COLOR purple]Q[/COLOR] Sport 9[/COLOR][/B]','http://blackhouse.sx/live9/index.m3u8',382,'http://www.beoutq.sx/uploads/channels/5VKxdsCG7pIoUeuAB6IIELjPl8FJywIUZRtVa8La.png','')
    utils.addDownLink('[B][COLOR white]beout[COLOR purple]Q[/COLOR] Sport 10[/COLOR][/B]','http://blackhouse.sx/live10/index.m3u8',382,'http://www.beoutq.sx/uploads/channels/Q8g1BFmzlDSb67oeghxkTSe68qDFN5VA4IXIkCwR.png','')




	
    # utils.addDownLink('[B][COLOR white]DW Arabic Live[/COLOR][/B]','https://cdn.streaminghd.tn/live/cntubRqB0maEWj9NNUz1nA/1507477736/dwarabic/index.m3u8',382,'https://www.streaminghd.tn/img/tv/dw.png','')
    # utils.addDownLink('[B][COLOR white]Ennahar TV Live[/COLOR][/B]','https://cdn.streaminghd.tn/live/hqaRnvDYEgvi-kTciUOWMg/1507477868/ennahar/index.m3u8',382,'https://www.streaminghd.tn/img/tv/ennahar.png','')
    # utils.addDownLink('[B][COLOR white]First TV Live[/COLOR][/B]','https://cdn.streaminghd.tn/live/iJ16uJi9SbEXg33cVavGmw/1507478021/first/index.m3u8',382,'https://www.streaminghd.tn/img/tv/first.png','')
    # utils.addDownLink('[B][COLOR white]France 24 Ar Live[/COLOR][/B]','https://cdn.streaminghd.tn/live/8w8j_VvUGUmvKm8yRDrKpQ/1507478115/france24ar/index.m3u8',382,'https://www.streaminghd.tn/img/tv/france24_ar.png','')
    # utils.addDownLink('[B][COLOR white]France 24 Fr Live[/COLOR][/B]','https://cdn.streaminghd.tn/live/TvT6jDqQrJLFJxBvBxHPNw/1507478199/france24fr/index.m3u8',382,'https://www.streaminghd.tn/img/tv/france24_fr.png','')
    # utils.addDownLink('[B][COLOR white]Hannibal TV Live[/COLOR][/B]','https://cdn.streaminghd.tn/live/6BQoJ0ZYGvF_seK75wHptw/1507478255/hannibal/index.m3u8',382,'https://www.streaminghd.tn/img/tv/hannibal.png','')
    # utils.addDownLink('[B][COLOR white]Insen TV Live[/COLOR][/B]','https://cdn.streaminghd.tn/live/CFP7lUKg8mfBH70qb3hrhw/1507478313/insen/index.m3u8',382,'https://www.streaminghd.tn/img/tv/insen.png','')
    # utils.addDownLink('[B][COLOR white]INTV Live[/COLOR][/B]','https://cdn.streaminghd.tn/live/aSqVobup-SgM6zW1_NCeOQ/1507478370/intv/index.m3u8',382,'https://www.streaminghd.tn/img/tv/intv.png','')
    # utils.addDownLink('[B][COLOR white]Janoubia TV Live[/COLOR][/B]','https://cdn.streaminghd.tn/live/11dsqC2qLnVqnGXz-ggKDw/1507478437/janoubia/index.m3u8',382,'https://www.streaminghd.tn/img/tv/janoubia.png','')
    # utils.addDownLink('[B][COLOR white]Jawhara TV Live[/COLOR][/B]','https://cdn.streaminghd.tn/live/-T1Zxw_JVdtxhMf-mynKHg/1507478494/jawhara/index.m3u8',382,'https://www.streaminghd.tn/img/tv/jawhara.png','')
    # utils.addDownLink('[B][COLOR white]Latina TV Tunez Live[/COLOR][/B]','https://cdn.streaminghd.tn/live/db5oCe40kM0ttYLFhwWrXw/1507478557/latina/index.m3u8',382,'https://www.streaminghd.tn/img/tv/latina.png','')
    # utils.addDownLink('[B][COLOR white]MTunisia TV Live[/COLOR][/B]','https://cdn.streaminghd.tn/live/k8_37ydAfuMYBWRKh77_BQ/1507478605/mtunisia/index.m3u8',382,'https://www.streaminghd.tn/img/tv/mtunisia.png','')
    # utils.addDownLink('[B][COLOR white]Tunisna TV Live[/COLOR][/B]','https://cdn.streaminghd.tn/live/b_c89ZdXyZz3ggbQbSalow/1507478660/tounesna/index.m3u8',382,'https://www.streaminghd.tn/img/tv/tunisna.png','')
    # utils.addDownLink('[B][COLOR white]Watania 1 Live[/COLOR][/B]','https://cdn.streaminghd.tn/live/khnnVes_hMqyPEAy4ldSwQ/1507478754/nat1/index.m3u8',382,'https://www.streaminghd.tn/img/tv/nat1.png','')
    # utils.addDownLink('[B][COLOR white]Watania 2 Live[/COLOR][/B]','https://cdn.streaminghd.tn/live/37XUnq9u34Ok0012zTXQ_g/1507478801/nat2/index.m3u8',382,'https://www.streaminghd.tn/img/tv/nat2.png','')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('381', ['url'])
def List(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile('<a href="([^"]+)"[^<]+<img src="([^"]+)" alt="([^"]+)"[^<]+[^>]+>([^<]+)</span>(.*?)<strong', re.DOTALL).findall(listhtml)
    for videopage, img, name, dur, hd in match:
        if 'hd' in hd:
            hd = " [COLOR orange]HD[/COLOR] "
        else:
            hd = " "
        name = utils.cleantext(name)
        name = name + hd + "[COLOR deeppink]" + dur + "[/COLOR]"
        videopage = 'http://www.hclips.com/embed/' + videopage.split(':')[-2]
        utils.addDownLink(name, videopage, 382, img, '')
    try:
        nextp=re.compile('<li class="next">.+?<a href="([^"]+)".*?>Next</a>', re.DOTALL | re.IGNORECASE).findall(listhtml)
        utils.addDir('Next Page', 'http://www.hclips.com' + nextp[0], 381,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('384', ['url'], ['keyword'])    
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 384)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        List(searchUrl)


@utils.url_dispatcher.register('383', ['url'])
def Categories(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('href="([^"]+)" class="thumb">.*?src="([^"]+)"[^<]+<strong class="title">([^<]+)<.*?<b>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, img, name, vids in match:
        name = '%s [COLOR deeppink]%s videos[/COLOR]' %(name, vids)
        utils.addDir(name, catpage, 381, img, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('385', ['url'])
def Channels(url):
    listhtml = utils.getHtml(url, '')
    match = re.compile('<a href="([^"]+)" class="video_thumb" title="([^"]+)">.+?<img height="165" width="285" src="([^"]+)"', re.DOTALL).findall(listhtml)
    for chanpage, name, img in match:
        name = utils.cleantext(name)
        utils.addDir(name, "http://hclips.com" + chanpage, 386, "http://hclips.com" + img, '')
    try:
        nextp=re.compile(r'<li class="next">\s+<a href="([^"]+)".*?>Next</a>', re.DOTALL | re.IGNORECASE).findall(listhtml)
        utils.addDir('Next Page', 'http://www.hclips.com' + nextp[0], 385,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('386', ['url'])
def ChannelList(url):
    listhtml = utils.getHtml(url, '')
    match = re.compile('<a href="([^"]+)" class="thumb" data-rt=".+?">.+?<img  width="220" height="165" src="([^"]+)" alt="([^"]+)"', re.DOTALL).findall(listhtml)
    for videopage, img, name in match:
        name = utils.cleantext(name)
        utils.addDownLink(name, 'http://www.hclips.com' + videopage, 382, img, '')
    try:
        nextp=re.compile('<li class="next">.+?<a href="([^"]+)".*?>Next</a>', re.DOTALL | re.IGNORECASE).findall(listhtml)
        utils.addDir('Next Page', 'http://www.hclips.com' + nextp[0], 386,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('382', ['url'])    
def Playvid(url):
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        listitem.setInfo('video', {'Title': '[COLOR red][B]MG-Arabic[/B][/COLOR]'})
        xbmc.Player().play(url, listitem)