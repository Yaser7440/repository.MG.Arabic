'''

   http://www.mg-tv.org/
   
   http://mg.esy.es/Kodi/


    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import sys
import json

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils

# from youtube-dl
from resources.lib.compat import (
    compat_chr,
    compat_ord,
    compat_urllib_parse_unquote,
)

dialog = utils.dialog
addon = utils.addon
movieswbb = 'http://movieswbb.com/'

# def BGVersion():
    # bgpage = utils.getHtml('http://beeg.com','')
    # bgversion = re.compile(r"cpl/(\d+)\.js", re.DOTALL | re.IGNORECASE).findall(bgpage)[0]
    # bgsavedversion = addon.getSetting('bgversion')
    # if bgversion <> bgsavedversion:
        # addon.setSetting('bgversion',bgversion)
        # bgjspage = utils.getHtml('http://static.beeg.com/cpl/'+bgversion+'.js','http://beeg.com')
        # bgsalt = re.compile('beeg_salt="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(bgjspage)[0]
        # addon.setSetting('bgsalt',bgsalt)


@utils.url_dispatcher.register('80')
def BGMain():
    # BGVersion()
    # bgversion = addon.getSetting('bgversion')

    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Categories[/B]',movieswbb,83,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Search[/B]',movieswbb + '/?s=',84,'','')
    BGList(movieswbb)
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('81', ['url'], ['page'])
def BGList(url, page=1):
    #bgversion = addon.getSetting('bgversion')
    try:
        listjson = utils.getHtml(url,'')
    except:
        
        return None

    match = re.compile(r'class="blogcontent"><p>.*?src="([^"]+)" alt="Download([^"]+)" /></p><ul><li><strong>Genre:</strong>([^"]+)</li><li>.*?href="([^"]+)" class="more-link">.*?class="post-meta-time" href=".*?">([^"]+)</a></span>', re.DOTALL | re.IGNORECASE).findall(listjson)
    for img, title, genre, videopage, data in match:
        genre = utils.cleanhtml(genre)
        #img = "http://img.beeg.com/236x177/" + videoid +  ".jpg"
        #videopage = "https://api.beeg.com/api/v6/"+bgversion+"/video/" + videoid
        #name = title.encode("utf8")
        utils.addDownLink('[B]%s[/B]'%title, videopage, 82, img, data,genre,'')
    try:
        nextp = re.compile('href="([^"]+)" class="nextpostslink">&raquo;</a>', re.DOTALL | re.IGNORECASE).findall(listjson)[0]
        # page = int(page)
        # npage = page + 1
        # jsonpage = re.compile(r'pages":(\d+)', re.DOTALL | re.IGNORECASE).findall(listjson)[0]
        # if int(jsonpage) > page:
            # nextp = url.replace("/"+str(page)+"/", "/"+str(npage)+"/")
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]', nextp,81,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)

# from youtube-dl   
def split(o, e):
    def cut(s, x):
        n.append(s[:x])
        return s[x:]
    n = []
    r = len(o) % e
    if r > 0:
        o = cut(o, r)
    while len(o) > e:
        o = cut(o, e)
    n.append(o)
    return n

def decrypt_key(key):
    bgsalt = addon.getSetting('bgsalt')
    # Reverse engineered from http://static.beeg.com/cpl/1738.js
    a = bgsalt
    e = compat_urllib_parse_unquote(key)
    o = ''.join([
        compat_chr(compat_ord(e[n]) - compat_ord(a[n % len(a)]) % 21)
        for n in range(len(e))])
    return ''.join(split(o, 3)[::-1])   


@utils.url_dispatcher.register('82', ['url', 'name'], ['download'])
def BGPlayvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download=download, regex='''(?:src|SRC|href|HREF)=(?:.*?|\s*)(http[^'"]+)''', direct_regex=None)
    vp.play_from_site_link(url, url)
#src=.*?(http[^"]+)&quot;
#(?:src=\s*|SRC=\s*|href=\s*|HREF=\s*)["']([^'"]+)
@utils.url_dispatcher.register('83', ['url'])
def BGCat(url):
    #bgversion = addon.getSetting('bgversion')
    caturl = utils.getHtml(url, '')
    tags = re.compile(r'widget_categories">(.*?)class="gototop">', re.DOTALL | re.IGNORECASE).findall(caturl)[0]
    tags = re.compile('href="([^"]+)" >([^"]+)</a>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(tags)
    for videolist, tag, tagn in tags:
        name = tag.encode("utf8")
        name = name + tagn
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, videolist, 81, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('84', ['url'], ['keyword'])
def BGSearch(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 84)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        BGList(searchUrl)
