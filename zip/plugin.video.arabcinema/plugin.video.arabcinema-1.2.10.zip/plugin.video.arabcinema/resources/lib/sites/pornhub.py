'''

   http://www.mg-tv.org/
   
   http://mg.esy.es/Kodi/


    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import urllib2
import json
import random
import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils

progress = utils.progress
movies = 'https://1movies.se'  

@utils.url_dispatcher.register('390')
def Main():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Search[/B]',movies +'/search_all/', 394, '', '')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Categories[/B]',movies +'/genres', 393, '', '')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]movies[/B]',movies +'/1movies', 391, '', '')	
    List(movies +'/allmovies')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('391', ['url'])
def List(url):
    #print "1movies::List " + url
    try:
        listhtml = utils.getHtml(url, '')
    except:
        return None
    match = re.compile(r'<div class="offer_box">.*?data-href="([^"]+)"\s*?data-name="([^"]+)"\s*?data-genre="<b>Genre:</b>([^"]+)"\s*?data-quality="([^"]+)"\s*?data-img=".*?url=([^"]+)"\s*?data-imdb="IMDb:([^"]+)"\s*?data-year="([^"]+)".*?data-desc="([^"]+)"', re.DOTALL).findall(listhtml)
    for videopage, name, genre, hd, img, rating, aired, desc in match:
        if hd.find('HD') > 0:
            hd = " [COLOR orange]HD[/COLOR] "
        else:
            hd = " "            
        name = utils.cleantext(name)
        name = name + ' ' + aired + hd 
        utils.addDownLink('[B]%s[/B]'%name, movies + videopage + '-watch-online-free.html', 392, img, desc, genre, 'director', 'writer', aired, rating)
    try:
        nextp=re.compile('class="next"><a href="(.+?)" data-page=', re.DOTALL).findall(listhtml)
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]', movies + nextp[0].replace('&amp;','&'), 391,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('394', ['url'], ['keyword'])    
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 394)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        List(searchUrl)


@utils.url_dispatcher.register('393', ['url'])
def Categories(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None	
    match = re.compile('class="control_nav genres">(.*?)</div>\s*?</div>', re.DOTALL | re.IGNORECASE).findall(listhtml)	
    match1 = re.compile('href="([^<]+)">([^"]+)</a>', re.DOTALL | re.IGNORECASE).findall(match[0])
    for catpage, name in match1:	
        name = utils.cleantext(name)
        catpage = movies + catpage	
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 391, '', '')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('392', ['url', 'name'])
def Playvid(url, name, download=None):
    progress.create('Play video', 'Searching videofile.')
    progress.update( 25, "", "Loading video page", "" )
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    target= re.findall(r'<video class="jw-video jw-reset".*?jw-loaded="data" src="(.*?)\s(.*?)" jw-played.*?</video>', link, re.DOTALL)	
    target= target[0]
    target = target[0].replace('"','').strip()
    req_target = urllib2.Request(target)
    req_target.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response_target = urllib2.urlopen(req_target)
    link_target=response_target.read()
    video_url= str(link_target).split('src="')[1].split('"')[0]
    videourl = ''.join(video_url)
    sep = '"'
    videourl = videourl.split(sep,1)[0]	
	
    if download == 1:
            utils.downloadVideo(videourl, name)
    else:
            iconimage = xbmc.getInfoImage("ListItem.Thumb")
            listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
            listitem.setInfo('video', {'Title': name, 'Genre': '[COLOR red]MG-Arabic[/COLOR]'})
            xbmc.Player().play(videourl, listitem)
