'''

   http://www.mg-tv.org/
   
   http://mg.esy.es/Kodi/


    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import sys

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils

progress = utils.progress
shof = 'http://tv.shof.co.il/'

@utils.url_dispatcher.register('340')
def Main():
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]Search[/B][/COLOR]','https://shof.net/movies/?s=', 343, '', '')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]MENU[/B][/COLOR]',shof,346,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]Movies[/B][/COLOR]',shof+'?mod=videocat&ID=2', 345, '', '')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]TV Shows[/B][/COLOR]',shof + '?mod=videocat&ID=1', 344, '', '')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]TV Shof[/B][/COLOR]',shof + '?mod=videocat&ID=22', 345, '', '')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]Kids[/B][/COLOR]',shof + '?mod=videocat&ID=14', 345, '', '')		
    List(shof + '?mod=videoalbum&ID=17')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('341', ['url'])
def List(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile('<div class="col-lg-25".*?href=".([^"]+)".*?src="([^"]+)".*?<div class="txt">([^"]+)</div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, img, name in match:
        name = utils.cleantext(name)
        name = utils.cleanspec(name)
        name = utils.cleanhtml(name)
        name = name.replace('         ','')		
        if 'http' not in videopage: 		
           videopage = shof + videopage
        if 'videoalbum' in videopage: 
           utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]%s[/B][/COLOR]' %name, videopage, 345, img, '')
        else:   
           utils.addDownLink('[COLOR white][B]%s[/B][/COLOR]' %name, videopage, 342, img, '')
    try:
        nextp=re.compile('<li><a href="(.+?)">.*?</a></li></ul>').findall(listhtml)
        if 'http' not in videopage: 		
           nextp = shof + nextp		
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]',nextp[0], 341,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)

 
@utils.url_dispatcher.register('343', ['url'], ['keyword']) 
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 343)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        List(searchUrl)


@utils.url_dispatcher.register('344', ['url'])
def Categories(url):
    listhtml = utils.getHtml(url, '')
    match = re.compile(r"<div class=.*?cat-title.*?href='(.+?)'>(.+?)</a>", re.DOTALL | re.IGNORECASE).findall(listhtml)
    for catpage, name in match:
        name = utils.cleantext(name)
        name = utils.cleanspec(name)
        name = utils.cleanhtml(name)
        name = name.replace('         ','')			
        if 'http' not in catpage: 		
           catpage = shof + catpage
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]%s[/B][/COLOR]' %name, catpage, 341, '', '')
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('346', ['url'])
def Models(url):
    listhtml = utils.getHtml(url, '')
    videopage = re.compile('<div class="menu navbar-collapse">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    match = re.compile('<a href="([^"]+)">([^"]+)</a>', re.DOTALL | re.IGNORECASE).findall(videopage[0])
    for catpage, name in match:
        name = utils.cleantext(name)
        name = utils.cleanspec(name)
        name = utils.cleanhtml(name)
        name = name.replace('         ','')			
        if 'http' not in catpage: 		
           catpage = shof + catpage
           utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]%s[/B][/COLOR]' %name, catpage, 341, '', '')
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('345', ['url'])
def Channels(url):
    listhtml = utils.getHtml(url, '')
    match = re.compile('<div class="col-lg-.*?href=".([^"]+)".*?src="([^"]+)".*?<div class="txt">([^"]+)</div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for catpage, img, name in match:
        name = utils.cleantext(name)
        name = utils.cleanspec(name)
        name = utils.cleanhtml(name)
        name = name.replace('         ','')			
        if 'http' not in catpage: 		
           catpage = shof + catpage
        if 'showvideo' in catpage:  
           utils.addDownLink('[COLOR white][B]%s[/B][/COLOR]' %name, catpage, 342, img, '')		   
        else:
           utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]%s[/B][/COLOR]' %name, catpage, 341, img, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)





@utils.url_dispatcher.register('342', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    progress.create('Play video', 'Searching videofile.')
    progress.update( 25, "", "Loading video page", "" )
    videopage = utils.getHtml(url, '')
    match = re.compile('<iframe class="video" src="([^"]+)".*?</iframe>', re.DOTALL | re.IGNORECASE).findall(videopage)
    for url in 	match:
	    url = url
    videopage = utils.getHtml(url, url)
    a = re.compile('''"file": "([^'"]*mp4)"''', re.DOTALL | re.IGNORECASE).findall(videopage)
    b = re.compile('''"([^'"]*mp4)"''', re.DOTALL | re.IGNORECASE).findall(videopage)
    c = re.compile('''"file": "([^'"]*mp4)",''', re.DOTALL | re.IGNORECASE).findall(videopage)
    d = re.compile('''"file": "([^'"]*mp4)"''', re.DOTALL | re.IGNORECASE).findall(videopage)	
    try:
        videourl = a[0]
    except:
        try:
            videourl = b[0]
        except:
            try:		
                videourl = c[0]
            except:
                  videourl = d[0]
    videourl = videourl.replace('&amp;','&').replace(' ','%20').replace('&#039;',"'").replace('\/','/')
    if download == 1:
        utils.downloadVideo(videourl, name)
    else:
        videourl = videourl.replace('&amp;','&').replace(' ','%20').replace('&#039;',"'").replace('\/','/')
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        listitem.setInfo('video', {'Title': name, 'Genre': '[COLOR red][B]MG-Arabic[/B][/COLOR]'})
        xbmc.Player().play(videourl, listitem)