'''

   http://www.mg-tv.org/
   
   http://mg.esy.es/Kodi/


    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
import xbmcgui
import xbmcplugin
from resources.lib import utils

progress = utils.progress
htshof = 'https://htshof.com/'
  
   
@utils.url_dispatcher.register('130')
def Main():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]SEARCH[/B][/COLOR]',htshof + '?s=', 134, '', '')	
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]GENRE[/B][/COLOR]',htshof + 'series/', 133, '', '')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]TV-SHOWS[/B][/COLOR]',htshof + 'series/', 133, '', '')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]MOVIES[/B][/COLOR]',htshof + 'movies/', 133, '', '')
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]YEARS[/B][/COLOR]',htshof , 133, '', '')	
    List(htshof+ 'movies/')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('131', ['url'], ['page'])
def List(url, page=1):
    try:
        link = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile('<div class="blockItem">.*?href="([^"]+)".*?src="(https[^"]+)".*?<h2 class="titleBack">([^"]+)</h2>.*?<div class="Labels2">\s*<span class="RibbonLabels">.*?</span>([^"]+)</div>', re.DOTALL).findall(link)
    for videourl, thumb, name, qual in match:
        name = utils.cleantext(name)
        qual = utils.cleantext(qual)
        qual = utils.cleanspec(qual)
        qual = utils.cleanhtml(qual)		
        print 'thumb',thumb
        if 'filmes' in videourl:
          utils.addDir('[B]%s[/B]' %name,videourl,131,thumb,'',qual)
        else:
		  
          utils.addDownLink('[B]%s[/B]' %name,videourl,132,thumb,'',qual)
    try:
          np = re.compile('href="(.+?)".*?&laquo;</a></li>').findall(link)[0]
          utils.addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',np,131,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)



@utils.url_dispatcher.register('134', ['url'], ['keyword'])    
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 134)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        List(searchUrl)


@utils.url_dispatcher.register('133', ['url'])
def CatMOVIES(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<li id="menu-item-.*?menu-item-type-taxonomy menu-item-object-category.*?href="([^"]+)">([^<]+)</a>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name in match:
        #name = name + ' [COLOR deeppink]' + videos + ' videos[/COLOR]'
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 131, '')
    match = re.compile('<a href="([^"]+)"><p>([^<]+)</p></a>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name in match:
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 131, '')		
    xbmcplugin.endOfDirectory(utils.addon_handle)



@utils.url_dispatcher.register('132', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    #utils.PLAYVIDEO(url, name, download)

    progress.create('Play video', 'Searching videofile.')
    progress.update( 25, "", "Loading video page", "" )
    data = utils.getHtml(url, '')
    if "rel='shortlink'" in data:
        res_quality = []
        stream_url = []
        quality = ''
        regx="rel='shortlink' href='.*?p=(.+?)'"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[0]
        print "id",id
        #range=['1','2','3','4','5','6','7','8']
        for i in range(1,9):
          catpage='https://htshof.com/movies/wp-content/themes/movies/servers/server.php?q=' + id + '&i=' + str(i)
          print catpage
          quality = '[B][COLOR white]SERVER [%s][/COLOR][/B]' %str(i)
          res_quality.append(quality)
          stream_url.append(catpage)
        if len(id) >0:
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Please Select Servers',res_quality)
            if ret == -1:
                return
            elif ret > -1:
                videourl = stream_url[ret]
            try:
                    server = utils.getHtml(videourl, url)
            except:
                   return None
        # a = re.compile('''src="([^"]+)"''', re.DOTALL | re.IGNORECASE).findall(server)
        # b = re.compile('''<ifram.*?src="([^"]+)"''', re.DOTALL | re.IGNORECASE).findall(server)
        # c = re.compile('''<IFRAM.*?SRC="([^"]+)".*?</IFRAME>''', re.DOTALL | re.IGNORECASE).findall(server)
        # d = re.compile('''<iframe.*?src="([^"]+)".*?></iframe>''', re.DOTALL | re.IGNORECASE).findall(server)
        # try:
           # videourl = a[0]
        # except:
            # try:
               # videourl = b[0]
            # except:
                # try:
                   # videourl = c[0]
                # except:
                      # videourl = d[0]
        if videourl:
            utils.PLAYVIDEO(videourl, name, download, '''src=\s*["']([^'"]+)''')
        else:
            utils.notify('Oh oh','Couldn\'t find a video')
