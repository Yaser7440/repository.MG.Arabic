'''

   http://www.mg-tv.org/
   
   http://mg.esy.es/Kodi/


    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import urlparse
import json

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
 
addon = utils.addon

sortlistxt = [addon.getLocalizedString(30022), addon.getLocalizedString(30023), addon.getLocalizedString(30024),
            addon.getLocalizedString(30025)]   
progress = utils.progress
oof = 'http://www.4oof.com/'

@utils.url_dispatcher.register('60')
def PAQMain():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]Genre[/B][/COLOR]',oof,63,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]MENU[/B][/COLOR]',oof,69,'','')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]Movies[/B][/COLOR]',oof+ 'movies',61,'','')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]Series[/B][/COLOR]',oof+'series',68,'','')	
    PAQList(oof)
    xbmcplugin.endOfDirectory(utils.addon_handle)
 

 
 
@utils.url_dispatcher.register('69', ['url'])
def MENU(url):
    caturl = utils.getHtml(url, '')
    if '4oof' in url:
        match = re.compile('id="menu-item-.*?<a href="([^<]+)">([^<]+)</a>', re.DOTALL | re.IGNORECASE).findall(caturl)
    for videolist, name in match:
            utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]' %name, videolist, 61, '', 1)           
    xbmcplugin.endOfDirectory(utils.addon_handle) 
 


 

@utils.url_dispatcher.register('61', ['url'], ['page'])
def PAQList(url, page=1):
    sort = getXTSortMethod()
    if re.search('\?', url, re.DOTALL | re.IGNORECASE):
        url = url + '&filtre=' + sort + '&display=extract'
    else:
        url = url + '?filtre=' + sort + '&display=extract'
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None	
    match = re.compile(r'class="MovieBlock".*?href="([^"]+)">.*?<im.*?src="([^"]+)".*?class="title">([^"]+)</div>.*?class="description">([^"]+)</div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, img, name, desc in match:
               name = utils.cleantext(name)
               desc = utils.cleantext(desc)			
               utils.addDownLink('[B]%s[/B]' %name, videopage , 62, img, desc)
    try:
		nextp=re.compile('href="(.*?)".*?&laquo;</a>').findall(listhtml)[0]
		utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]' ,nextp,  61, '')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


def GetAlternative(url, alternative):
    progress.update( 70, "", "Loading alternative page", "" )
    if alternative == 1:
        nalternative = 2
        url = url + str(nalternative)
    else:
        nalternative = int(alternative) + 1
        url.replace('/'+str(alternative),'/'+str(nalternative))
    return url, nalternative

@utils.url_dispatcher.register('68', ['url'], ['page'])
def series(url, page=1):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None	
    match1 = re.compile(r'class="SeriesItem">\s*<a href="([^"]+)">.*?src="([^"]+)" alt="([^"]+)" />', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, img, name in match1:
               name = utils.cleantext(name)
               utils.addDir('[B]%s[/B]' %name, videopage + '?watch=true', 61, img, '')
    try:
		nextp=re.compile('href="(.*?)".*?&laquo;</a>').findall(listhtml)[0]
		utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]' ,nextp,  68, '')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)			   


	
@utils.url_dispatcher.register('62', ['url', 'name'], ['download'])
def PPlayvid(url, name, download=None, desc=None, alternative=1):

    def playvid(videourl, referer):
        progress.close()
        if download == 1:
            utils.downloadVideo(videourl, name)
        else:
            videourl = videourl + "|referer="+ referer
            iconimage = xbmc.getInfoImage("ListItem.Thumb")
            listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
            listitem.setInfo('video', {'Title': name, 'Genre': '[COLOR red][B]MG-Arabic[/B][/COLOR]', 'Plot': desc})
            xbmc.Player().play(videourl, listitem)    
    
    progress.create('Play video', 'Searching videofile.')
    progress.update( 25, "", "Loading video page", "" )
    data = utils.getHtml(url, '')
    if "data:" in data:
        res_quality = []
        stream_url = []
        quality = ''
        regx="data: 'q=(.+?)&i="
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[0]
        print "id",id
        #range=['1','2','3','4','5','6','7']
        for i in range(1,9):
          catpage='http://www.4oof.com/wp-content/themes/twenty/Interface/Ajax/Single/Watch/Server.php?q=' + id + '&i=' + str(i)
          print catpage
          quality = '[B][COLOR white]SERVER [%s][/COLOR][/B]' %str(i)
          res_quality.append(quality)
          stream_url.append(catpage)
        if len(id) >0:
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Please Select Servers',res_quality)
            if ret == -1:
                return
            elif ret > -1:
                videourl = stream_url[ret]
            try:
                    server = utils.getHtml(videourl, url)
            except:
                   return None
        # a = re.compile('''src="(.*?)"''', re.DOTALL | re.IGNORECASE).findall(server)
        # b = re.compile('''<ifram.*?src="([^'"]+)"''', re.DOTALL | re.IGNORECASE).findall(server)
        # c = re.compile('''<IFRAM.*?SRC=([^'"]+)".*?</IFRAME>''', re.DOTALL | re.IGNORECASE).findall(server)
        # d = re.compile('''<ifram.*?src="([^'"]+)".*?</iframe>''', re.DOTALL | re.IGNORECASE).findall(server)
        # try:
           # videourl = a[0]
        # except:
            # try:
               # videourl = b[0]
            # except:
                # try:
                   # videourl = c[0]
                # except:
                      # videourl = d[0]
        if videourl:
            utils.PLAYVIDEO(videourl, name, download, '''src=\s*["']([^'"]+)''')
        else:
            utils.notify('Oh oh','Couldn\'t find a video')



@utils.url_dispatcher.register('63', ['url'])
def PCat(url):
    caturl = utils.getHtml(url, '')
    if '4oof' in url:
        match = re.compile('class="BGGenre".*?(http[^<]+jpg).*?"></div>.*?href="([^<]+)">.*?<h2>([^<]+)</h2>\s*</a>', re.DOTALL | re.IGNORECASE).findall(caturl)
    for img, videolist, name in match:
            utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]' %name, videolist, 61, img, 1)           
    xbmcplugin.endOfDirectory(utils.addon_handle)




def getXTSortMethod():
    sortoptions = {0: 'series',
                   1: 'popular',
                   2: 'rated',
                   3: 'completed'}
    sortvalue = addon.getSetting("sortxt")
    return sortoptions[int(sortvalue)] 

