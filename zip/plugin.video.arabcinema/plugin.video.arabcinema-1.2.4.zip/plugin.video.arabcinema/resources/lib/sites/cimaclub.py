import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
progress = utils.progress
cimaclub = 'http://cimaclub.com/' 



    
@utils.url_dispatcher.register('310', ['url'])
def Main(url):
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]SEARCH[/B][/COLOR]',cimaclub + '?s=',314,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]GENRES[/B][/COLOR]',cimaclub,313,'','')
    caturl = utils.getHtml(url, '')
    match = re.compile(r'<li id="menu-item-.*?href="([^"]+)">([^"]+)</a></li>', re.DOTALL | re.IGNORECASE).findall(caturl)
    for caturl, menu in match:
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]%s[/B][/COLOR]'%menu, caturl, 311, '', '', '')
    List(cimaclub)
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('311', ['url'])
def List(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None
    match = re.compile(r'class="movie">.*?href="([^"]+)".*?<img alt="([^"]+)" src="([^"]+)".*?<p>([^"]+)</p>.*?<i class="fa fa-star StarLabels"><span>([^"]+)</span></i>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, name, thumb, desc, rating in match:
        thumb = thumb
        thumb = thumb.replace('&amp;','&').replace(' ','%20').replace('&#039;',"'").replace('\/','/')
        name = utils.cleantext(name)
        desc = desc.replace('\r','').replace('\n','').replace('\t','')
        name = name + " [COLOR red]" + rating + "[/COLOR]"
        if '/cat/' in url:
		    utils.addDir('[B]%s[/B]'%name, videourl , 312, thumb, '', '', '')
        else:		
		    utils.addDownLink('[B]%s[/B]'%name, videourl, 312, thumb, desc, '','')
    try:
		nextp=re.compile('<li><a href="([^"]+)">.*?&laquo;</a></li>', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
		utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]' ,nextp,  311, '')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('312', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    progress.create('Play video', 'Searching videofile.')
    progress.update( 25, "", "Loading video page", "" )
    data = utils.getHtml(url, '')
    if "rel='shortlink'" in data:
        res_quality = []
        stream_url = []
        quality = ''
        regx="rel='shortlink' href='.*?p=(.+?)'"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[0]
        print "id",id
        #range=['1','2','3','4','5','6','7','8']
        for i in range(1,9):
          catpage='http://cimaclub.com/wp-content/themes/Cimaclub/servers/server.php?q=' + id + '&i=' + str(i)
          print catpage
          quality = '[B][COLOR white]SERVER [%s][/COLOR][/B]' %str(i)
          res_quality.append(quality)
          stream_url.append(catpage)
        if len(id) >0:
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Please Select Servers',res_quality)
            if ret == -1:
                return
            elif ret > -1:
                videourl = stream_url[ret]
            try:
                    server = utils.getHtml(videourl, url)
            except:
                   return None
        a = re.compile('''src="(.*?)"''', re.DOTALL | re.IGNORECASE).findall(server)
        b = re.compile('''<ifram.*?src="([^'"]+)"''', re.DOTALL | re.IGNORECASE).findall(server)
        c = re.compile('''<IFRAM.*?SRC=([^'"]+)".*?</IFRAME>''', re.DOTALL | re.IGNORECASE).findall(server)
        d = re.compile('''<ifram.*?src="([^'"]+)".*?</iframe>''', re.DOTALL | re.IGNORECASE).findall(server)
        try:
           videourl = a[0]
        except:
            try:
               videourl = b[0]
            except:
                try:
                   videourl = c[0]
                except:
                      videourl = d[0]
        if videourl:
            utils.playvideo(videourl, name, download)
        else:
            utils.notify('Oh oh','Couldn\'t find a video')


@utils.url_dispatcher.register('313', ['url'])
def Categories(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<a href="(http://cimaclub.com/genre/[^"]+)">.*?<span>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name in match:
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 311, '')    
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('314', ['url'], ['keyword'])
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 314)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        List(searchUrl)

