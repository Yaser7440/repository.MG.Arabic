'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream
    Copyright (C) 2016 anton40
 
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
 
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
 
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc , xbmcgui
import xbmcplugin
from resources.lib import utils

progress = utils.progress

movieshub = 'http://123movieshub.com/' 
@utils.url_dispatcher.register('420') 
def Main():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]GENRES[/B][/COLOR]',movieshub,423,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]TV SHOWS[/B][/COLOR]',movieshub+'tvshows/',421,'','')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]SEARCH[/B][/COLOR]',movieshub + '?s=',424,'','')
    List(movieshub + 'movies/')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('421', ['url']) 
def List(url):
    try:
        html = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile('href="([^"]+)".*?<img src="([^"]+)" alt="([^"]+)">\s*<[^"]+[^>]+><[^"]+[^>]+></span>([^"]+)</div>', re.DOTALL | re.IGNORECASE).findall(html)
    for videopage, img, name, rating in match:
        name = utils.cleantext(name).replace('Watch','')
        name = '[B]'+ name + '[/B]' + " [COLOR red]" + rating + "[/COLOR]"
        if 'tvshows' in videopage:
           utils.addDir(name, videopage, 425, '', '', '')
        else:		
		
           utils.addDownLink(name, videopage, 422, img, '')
    try:
           nextp = re.compile('<link rel="next" href="([^"]+)" />', re.DOTALL | re.IGNORECASE).findall(html)
           utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]', nextp[0], 421,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('425', ['url'])
def ListTV(url):
    html = utils.getHtml(url, '').replace('\n','')
    match = re.compile('href="([^"]+)".*?<img src="([^"]+)" alt="([^"]+)">\s*<[^"]+[^>]+><[^"]+[^>]+></span>([^"]+)</div>').findall(html)
    for videopage, img, name, rating in match:
        name = utils.cleantext(name).replace('Watch','')
        name = '[B]'+ name + '[/B]' + " [COLOR red]" + rating + "[/COLOR]"
        utils.addDir(name, videopage, 422, img, '')
    try:
        nextp = re.compile('<link rel="next" href="(.+?)" />', re.DOTALL | re.IGNORECASE).findall(html)
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]', nextp[0], 425,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('422', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    progress.create('Play video', 'Searching videofile.')
    progress.update( 10, "", "Loading video page", "" )
    url = url.split('#')[0]
    videopage = utils.getHtml(url, '')
    a = re.compile('''<iframe(.+?)</iframe>''', re.DOTALL | re.IGNORECASE).findall(videopage)[0]
    b = re.compile('''src="([^'"]+)''', re.DOTALL | re.IGNORECASE).findall(a)[0]
    #c = re.compile('''"([^'"]*mp4)''', re.DOTALL | re.IGNORECASE).findall(videopage)[0]
    videourl = b
    videourl = 'http:%s'%videourl
    videopage2 = utils.getHtml(videourl, url)
    c = re.compile("""var kF = '(.+?)download';""", re.DOTALL | re.IGNORECASE).findall(videopage2)[0]
    if download == 1:
            utils.downloadVideo(c, name)
    else:
            #videourl = videourl.replace('&amp;','&').replace(' ','%20').replace('&#039;',"'").replace('\/','/')
            iconimage = xbmc.getInfoImage("ListItem.Thumb")
            listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
            listitem.setInfo('video', {'Title': name, 'Genre': '[COLOR red][B]MG-Arabic[/B][/COLOR]'})
            xbmc.Player().play(c, listitem)


@utils.url_dispatcher.register('423', ['url']) 
def Categories(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<li id="menu-item-.*?<a href="([^"]+)">([^"]+)</a></li>').findall(cathtml)
    for catpage, name in match:
        if 'tvshows' in catpage:
           utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]%s[/B][/COLOR]' %name, catpage, 425, '', '', '')	
        else:	
           utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]%s[/B][/COLOR]' %name, catpage, 421, '')    
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('424', ['url'], ['keyword'])    
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 424)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        ListSearch(searchUrl)