'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 anton40

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmcgui
import xbmcplugin
from resources.lib import utils

progress = utils.progress
cinmastar = 'https://cinmastar.com/'

@utils.url_dispatcher.register('470')
def Main():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]SEARCH[/B][/COLOR]',cinmastar + '?s=', 473, '', '')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]GENRE[/B][/COLOR]',cinmastar, 474, '', '')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]MENU[/B][/COLOR]',cinmastar, 477, '', '')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]YEARS[/B][/COLOR]',cinmastar , 461, '', '')	
    List(cinmastar)
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('477', ['url'])
def MENU(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<li id="menu-item-.*?class="menu-item menu-item-type-taxonomy menu-item-object-category.*?<a href="([^"]+)">([^"]+)</a>', re.DOTALL | re.IGNORECASE).findall(cathtml)	
    for catpage, name in match:
        name = utils.cleantext(name)
        name = utils.cleanspec(name)
        name = utils.cleanhtml(name)
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 471, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)
	

@utils.url_dispatcher.register('471', ['url'], ['page'])
def List(url, page=1):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile(r'<i class="fa fa-film">.*?href="([^"]+)">\s*<div class="boxtitle">', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for video in match[1:]:
        videopage = utils.OPEN_URL(video)
        imgdesc = re.compile(r'<meta itemprop="thumbnailURL" content="([^"]+.jpg)".*?itemprop="description" content="([^"]+)".*?property="og:title" content="([^"]+)".*?property="og:description" content="([^"]+)" />', re.DOTALL | re.IGNORECASE).findall(videopage)
        for img, desc, name, genre in imgdesc:
            desc = utils.cleantext(desc)
            desc = utils.cleanspec(desc)
            desc = utils.cleanhtml(desc)
            name = utils.cleantext(name)
            name = utils.cleanspec(name)
            genre = utils.cleanhtml(genre)
            genre = utils.cleantext(genre)
            genre = utils.cleanspec(genre)			
            if img.startswith('//'): img = 'http:' + img
		
            utils.addDownLink('[B]%s[/B]'%name, video, 472, img, desc, genre, '', '', '', '')		

    try:	
            nextp = re.compile('<li><a.*?href="(.*?)".*?&laquo;</a></li>').findall(listhtml)[0]
            utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]', nextp, 471,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('473', ['url'], ['keyword'])
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 473)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        List(searchUrl)


@utils.url_dispatcher.register('474', ['url'])
def GENRE(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('class="menu-item menu-item-type-custom menu-item-object-custom.*?<a href="(.+?)">(.+?)</a></li>', re.DOTALL | re.IGNORECASE).findall(cathtml)	
    for catpage, name in match:
        name = utils.cleantext(name)
        name = utils.cleanspec(name)
        name = utils.cleanhtml(name)
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 471, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)




@utils.url_dispatcher.register('461', ['url'])
def YEARS(url):
    for i in range(1921,2018):
     utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%str(i),'https://cinmastar.com/category/movies/?s='+str(i),471,'','')	  
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('472', ['url', 'name'], ['download'])
def Playvid(url, name, download=None, desc=None):

    def playvid(videourl, referer):
        progress.close()
        if download == 1:
            utils.downloadVideo(videourl, name)
        else:
            videourl = videourl + "|referer="+ referer
            iconimage = xbmc.getInfoImage("ListItem.Thumb")
            listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
            listitem.setInfo('video', {'Title': name, 'Genre': '[COLOR red][B]MG-Arabic[/B][/COLOR]', 'Plot': desc})
            xbmc.Player().play(videourl, listitem)    
 
    progress.create('Play video', 'Searching videofile.')
    progress.update( 25, "", "Loading video page", "" )
    data = utils.getHtml(url, '')
    if "rel='shortlink'" in data:
        res_quality = []
        stream_url = []
        quality = ''
        regx="rel='shortlink' href='.*?p=(.+?)'"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[0]
        print "id",id
        range=['1','2','3','4','5','6','7','8','9','10']
        for i in range:
          catpage='https://cinmastar.com/wp-content/themes/CinmaStar/servers/server.php?q=' + id + '&i=' + str(i)
          print catpage
          quality = '[B][COLOR white]SERVER [%s][/COLOR][/B]' %str(i)
          res_quality.append(quality)
          stream_url.append(catpage)
        if len(range) >0:
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Please Select Servers',res_quality)
            if ret == -1:
                return
            elif ret > -1:
                videourl = stream_url[ret]
            try:
                    server = utils.getHtml(videourl, url)
            except:
                   return None
        a = re.compile('''src="(.*?)"''', re.DOTALL | re.IGNORECASE).findall(server)
        b = re.compile('''<ifram.*?src="([^'"]+)"''', re.DOTALL | re.IGNORECASE).findall(server)
        c = re.compile('''<IFRAM.*?SRC=([^'"]+)".*?</IFRAME>''', re.DOTALL | re.IGNORECASE).findall(server)
        d = re.compile('''<ifram.*?src="([^'"]+)".*?</iframe>''', re.DOTALL | re.IGNORECASE).findall(server)
        try:
           videourl = a[0]
        except:
            try:
               videourl = b[0]
            except:
                try:
                   videourl = c[0]
                except:
                      videourl = d[0]
        if videourl:
            utils.playvideo(videourl, name, download)
        else:
            utils.notify('Oh oh','Couldn\'t find a video')