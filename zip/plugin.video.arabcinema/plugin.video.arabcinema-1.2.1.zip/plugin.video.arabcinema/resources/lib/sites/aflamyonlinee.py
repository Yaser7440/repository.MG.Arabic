'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 anton40

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmcgui
import xbmcplugin
from resources.lib import utils
progress = utils.progress
aflamy = 'http://www.aflamyonlinee.com'


@utils.url_dispatcher.register('370') 
def Main():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]Search[/B][/COLOR]',aflamy + '/?s=', 374, '', '')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]GENRES[/B][/COLOR]',aflamy, 373, '', '')    
    List(aflamy + '/category/%D8%A3%D9%81%D9%84%D8%A7%D9%85-%D8%A3%D8%AC%D9%86%D8%A8%D9%8A%D8%A9-%D8%A3%D9%88%D9%86-%D9%84%D8%A7%D9%8A%D9%86/')
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('371', ['url'], ['page'])
def List(url, page=1):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile('<div class="moviefilm">.*?src="([^"]+)" class=.*?<div class="movief"><a href="([^"]+)">([^"]+)</a>.*?<div class="movieDesc">([^"]+)</div>', re.DOTALL).findall(listhtml)
    for img, videopage, name, desc in match:
        name = utils.cleantext(name)
        desc = utils.cleantext(desc)
        desc = utils.cleanspec(desc)
        desc = utils.cleanhtml(desc)
        utils.addDownLink('[B]%s[/B]' %name, videopage, 372, img, desc)
    try:
        nextp = re.compile(r'<li><a href="(.+?)">.*?&laquo;</a></li>').findall(listhtml)[0]
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]', nextp, 371,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('374', ['url'], ['keyword'])     
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 374)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        List(searchUrl)

@utils.url_dispatcher.register('373', ['url']) 
def Cat(url):
    listhtml = utils.getHtml(url, '')
    match = re.compile("""<li id="menu-item-.*?href="([^"]+)">([^<]+)</a></li>""", re.DOTALL | re.IGNORECASE).findall(listhtml)
    for catpage, name in match:
        name = utils.cleantext(name)
        catpage = catpage
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]' %name, catpage, 371, '', '')
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('372', ['url', 'name'], ['download'])   
def Playvid(url, name, download=None):
    progress.create('Play video', 'Searching videofile.')
    progress.update( 25, "", "Loading video page", "" )
    data = utils.getHtml(url, '')
    if "rel='shortlink'" in data:
        res_quality = []
        stream_url = []
        quality = ''
        regx=",post:'(.+?)',"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[0]
        print "id",id
        range=['1','2','3','4','5']
        for i in range:
          catpage='http://www.aflamyonlinee.com/wp-content/themes/yourcolor88/servers/server.php?q=' + id + '&i=' + str(i)
          print catpage
          quality = '[B][COLOR white]SERVER [%s][/COLOR][/B]' %str(i)
          res_quality.append(quality)
          stream_url.append(catpage)
        if len(range) >0:
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Please Select Servers',res_quality)
            if ret == -1:
                return
            elif ret > -1:
                videourl = stream_url[ret]
            try:
                    server = utils.getHtml(videourl, url)
            except:
                   return None
        a = re.compile('''src="(.*?)"''', re.DOTALL | re.IGNORECASE).findall(server)
        b = re.compile('''<ifram.*?src="([^'"]+)"''', re.DOTALL | re.IGNORECASE).findall(server)
        c = re.compile('''<IFRAM.*?SRC=([^'"]+)".*?</IFRAME>''', re.DOTALL | re.IGNORECASE).findall(server)
        d = re.compile('''<ifram.*?src="([^'"]+)".*?</iframe>''', re.DOTALL | re.IGNORECASE).findall(server)
        try:
           videourl = a[0]
        except:
            try:
               videourl = b[0]
            except:
                try:
                   videourl = c[0]
                except:
                      videourl = d[0]
        if videourl:
            utils.playvideo(videourl, name, download)
        else:
            utils.notify('Oh oh','Couldn\'t find a video')