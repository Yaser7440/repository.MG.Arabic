'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 Fr33m1nd

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
import xbmcgui
import xbmcplugin
from resources.lib import utils

progress = utils.progress
htshof = 'https://htshof.com/'
  

@utils.url_dispatcher.register('130')
def Main():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]SEARCH[/B][/COLOR]',htshof + '?s=', 134, '', '')	
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]GENRE[/B][/COLOR]',htshof + 'series/', 133, '', '')	
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]TV-SHOWS[/B][/COLOR]',htshof + 'series/', 133, '', '')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]MOVIES[/B][/COLOR]',htshof + 'movies/', 133, '', '')
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]YEARS[/B][/COLOR]',htshof , 133, '', '')	
    List(htshof+ 'movies/')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('131', ['url'], ['page'])
def List(url, page=1):
    try:
        link = utils.OPEN_URL(url)
    except:
        
        return None
    all_videos = utils.regex_get_all(link, '<div class="blockItem">', '</a>')
    for a in all_videos:
          name = utils.regex_from_to(a, '<h2 class="titleBack">', '</h2>').replace('&#8211;','').replace('&#8217;','').replace('&amp;','')
          name = utils.cleantext(name[7:])
          #name = name.encode('ascii', 'ignore').decode('ascii')
          qual = utils.regex_from_to(a, 'class="Labels2">\s*<span class="RibbonLabels">.*?</span>', '</div>').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','').replace('  ','')	  
          url = utils.regex_from_to(a, 'href="', '"')		
          thumb = utils.regex_from_to(a, 'src="', '"')              					
          utils.addDownLink('[B][COLOR white]%s[/COLOR][/B][B][I][COLOR red]%s[/COLOR][/I][/B]' %(name,qual),url,132,thumb,'','')
    try:
          np = re.compile('href="(.+?)".*?&laquo;</a></li>').findall(link)[0]
          utils.addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',np,131,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)



@utils.url_dispatcher.register('134', ['url'], ['keyword'])    
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 134)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        List(searchUrl)


@utils.url_dispatcher.register('133', ['url'])
def CatMOVIES(url):
    cathtml = utils.OPEN_URL(url)
    match = re.compile('<li id="menu-item-.*?menu-item-object-category.*?href="([^"]+)">([^<]+)</a>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name in match:
        #name = name + ' [COLOR deeppink]' + videos + ' videos[/COLOR]'
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 131, '')
    for i in range(1921,2018):
       utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%str(i),url+'/release-year/'+str(i),131,'','',1)		
    xbmcplugin.endOfDirectory(utils.addon_handle)



@utils.url_dispatcher.register('132', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    #utils.PLAYVIDEO(url, name, download)

    progress.create('Play video', 'Searching videofile.')
    progress.update( 25, "", "Loading video page", "" )
    data = utils.getHtml(url, '')
    if "rel='shortlink'" in data:
        res_quality = []
        stream_url = []
        quality = ''
        regx="rel='shortlink' href='.*?p=(.+?)'"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[0]
        print "id",id
        range=['1','2','3','4','5','6','7','8']
        for i in range:
          catpage='https://htshof.com/movies/wp-content/themes/movies/servers/server.php?q=' + id + '&i=' + str(i)
          print catpage
          quality = '[B][COLOR white]SERVER [%s][/COLOR][/B]' %str(i)
          res_quality.append(quality)
          stream_url.append(catpage)
        if len(range) >0:
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Please Select Servers',res_quality)
            if ret == -1:
                return
            elif ret > -1:
                videourl = stream_url[ret]
            try:
                    server = utils.getHtml(videourl, url)
            except:
                   return None
        a = re.compile('''src="(.*?)"''', re.DOTALL | re.IGNORECASE).findall(server)
        b = re.compile('''<ifram.*?src="([^'"]+)"''', re.DOTALL | re.IGNORECASE).findall(server)
        c = re.compile('''<IFRAM.*?SRC=([^'"]+)".*?</IFRAME>''', re.DOTALL | re.IGNORECASE).findall(server)
        d = re.compile('''<iframe.*?src="(.*?)".*?></iframe>''', re.DOTALL | re.IGNORECASE).findall(server)
        try:
           videourl = a[0]
        except:
            try:
               videourl = b[0]
            except:
                try:
                   videourl = c[0]
                except:
                      videourl = d[0]
        if videourl:
            utils.playvideo(videourl, name, download)
        else:
            utils.notify('Oh oh','Couldn\'t find a video')
