'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmcplugin
from resources.lib import utils

progress = utils.progress

arablionz = 'http://arablionz.tv'
@utils.url_dispatcher.register('200')
def XTCMain():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]GENRES[/B][/COLOR]',arablionz+'/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85/',206,'','')
    #utils.addDir('[COLOR hotpink]Top Rated[/COLOR]','http://xtasie.com/top-rated-porn-videos/page/1/',201,'','')
    #utils.addDir('[COLOR hotpink]Most Rated[/COLOR]','http://xtasie.com/most-viewed-porn-videos/page/1/',201,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]Search[/B][/COLOR]',arablionz+'/?s=',204,'','')
    XTCCat(arablionz)
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('201', ['url'], ['page'])
def XTCList(url, page=1):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile(r'href="([^"]+)" class="BlockMov">.*?data-style="background-image:url([^"]+);" class="backGroundMOV">.*?<h3 class="TitlePopover">([^"]+)</h3>.*?<div class="contentShow">([^"]+)</div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, img, name, desc in match:
        name = utils.cleantext(name)
        desc = utils.cleanhtml(desc)
        desc = utils.cleanspec(desc)
        desc = utils.cleantext(desc)		
        img = img.replace('(','').replace(')','')  
        utils.addDownLink('[B]%s[/B]'%name, videopage, 202, img, desc)
    try:
        nextp=re.compile('rel="next" href="([^"]+)"').findall(listhtml)[0]
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]', nextp, 201,'', page)
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('204', ['url'], ['keyword'])    
def XTCSearch(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 204)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        XTCListSE(searchUrl)

@utils.url_dispatcher.register('205', ['url'])
def XTCListSE(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile(r'<a href="([^"]+)".*?data-style="background-image:url([^"]+);".*?<h3 class="TitlePopover">([^"]+)</h3>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, img, name in match:
        name = utils.cleantext(name)
        img = img.replace('(','').replace(')','').replace('&amp;','&').replace(' ','%20').replace('&#039;',"'").replace('\/','/')	
        utils.addDownLink('[B]%s[/B]'%name, videopage, 202, img, '')
    try:
        nextp=re.compile('<li><a href="([^"]+)">.*?&laquo;</a></li>', re.DOTALL | re.IGNORECASE).findall(listhtml)
        next = nextp[0]
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]', next, 205,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('203', ['url'])
def XTCCat(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<li id="menu-item-.*?><a href="([^"]+)">([^"]+)</a>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name in match:
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 201, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('206', ['url'])
def XTCCatG(url):
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]YEARS[/B][/COLOR]',arablionz+'/release-year/',207,'','')
    cathtml = utils.getHtml(url, '')
    match = re.compile('<a href="([^"]+)" data-id=.*?>([^"]+)</a>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name in match:
     if 'genre' in catpage:
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 205, '')
     else:
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, catpage, 201, '')	 
    xbmcplugin.endOfDirectory(utils.addon_handle)
	
@utils.url_dispatcher.register('207', ['url'])
def getyears_movies(url):
    for i in range(1915,2018):
       utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]' %str(i),arablionz+'/release-year/'+str(i)+"/",205,'','')
    xbmcplugin.endOfDirectory(utils.addon_handle)			 
@utils.url_dispatcher.register('202', ['url', 'name'], ['download'])
def XTCPlayvid(url, name, download=None):
    utils.PLAYVIDEO(url, name, download)
