'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils

dialog = utils.dialog
aflamyhd = 'http://www.aflamyhd.com'

@utils.url_dispatcher.register('250')
def Main():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]MENU[/B][/COLOR]',aflamyhd,253,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]MOVIES[/B][/COLOR]','http://www.aflamyhd.com/movies.html',251,'','')	
    utils.addDir('[COLOR hotpink]Search[/COLOR]','http://en.paradisehill.cc/search_results/?search=',254,'','')
    List(aflamyhd + '/movies')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('251', ['url'])
def List(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None
    match = re.compile(r'href="([^"]+)">\s*<img src="([^"]+jpg)" alt="([^"]+)"  />', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, name in match:
        thumb = aflamyhd + thumb
        name = utils.cleantext(name)
        videourl = aflamyhd + videourl
        utils.addDownLink('[B]%s[/B]'%utils.cleanspec(name), videourl, 252, thumb, '', '','')
    try:
		nextp=re.compile('<li><a href="(.*?)" rel="next">&raquo;</a></li>').findall(listhtml)[0]
		utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]' ,nextp,  251, '')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('253', ['url'])
def Cat(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<div class="top_menu">(.*?)</ul></div>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    match1 = re.compile('href="([^"]+)"><span class="yjm_has_none"><span class="yjm_title">([^<]+)</span></span></a>', re.DOTALL | re.IGNORECASE).findall(match[0])
    for caturl, name in match1:
        catpage = aflamyhd + caturl #+ "?page=1"
        utils.addDir(name, catpage, 251, '', 1)
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('254', ['url'], ['keyword'])
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 254)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title + '&page=1'
        List(searchUrl, 1)


@utils.url_dispatcher.register('252', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    if utils.addon.getSetting("aflamyhd") == "true": playall = True
    else: playall = ''
    videopage = utils.getHtml(url, '')
    match = re.compile('<iframe src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videopage)
    videos = match
    
    if playall == '':
        if len(videos) > 1:
            i = 1
            videolist = []
            for x in videos:
                videolist.append('Part ' + str(i))
                i += 1
            videopart = dialog.select('Multiple videos found', videolist)
            if videopart == -1:
                return
            videourl = videos[videopart]
        else: videourl = videos[0]
        videourl = videourl.replace('\/','/')
        videourl = videourl + "|referer="+ url

    if download == 1 and playall == '':
        utils.downloadVideo(videourl, name)
    else:
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
      
        if playall:
            pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            pl.clear()
            i = 1
            for videourl in videos:
                newname = name + ' Part ' + str(i)
                listitem = xbmcgui.ListItem(newname, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
                listitem.setInfo('video', {'Title': newname, 'Genre': 'Porn'})
                listitem.setProperty("IsPlayable","true")
                videourl = videourl + "|referer="+ url
                pl.add(videourl, listitem)
                i += 1
                listitem = ''
            xbmc.Player().play(pl)
        else:
            listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
            listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})        
            xbmc.Player().play(videourl, listitem)
            