import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from random import randint

progress = utils.progress
alarab = 'http://tv1.alarab.com'
def decodeurl(text):
    text = text.replace('&amp;','&').replace(' ','%20').replace('&#039;',"'").replace('\/','/')
    return text
	
@utils.url_dispatcher.register('50')    
def PTMain():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]Music[/B][/COLOR]','http://mp31.alarab.com/',56,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [COLOR white][B]Search[/B][/COLOR]',alarab+'/q/',54,'','')
    PTCat(alarab)
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('51', ['url'], ['page'])
def PTList(url, page=1):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile(r'class="video-box".*?href="([^"]+)".*?src=".*?/data(.*?)" alt="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, img, name in match:

           videopage = 'http://tv1.alarab.com' + videopage
           if img.startswith('/'): img = 'http://images.alarab.com/data' + img
           if 'series' in videopage:
              utils.addDir('[B]%s[/B]'%name, videopage, 55, img, '')		
           else:			
              utils.addDownLink('[B]%s[/B]'%name, videopage, 52, img, '')
    try:

        target_pg = re.findall(r'<a class="tsc_3d(.*?)</a>', listhtml, re.DOTALL)
        target_page_counter = re.findall(r'<a class="tsc_3d_button blue"(.*?)</a>', listhtml)
        for counts in target_page_counter:
            real_number = counts.split('title=" \xd8\xb5\xd9\x81\xd8\xad\xd8\xa9 ')[1].split('" >')[0]
        counter = int(real_number)+1	
        for pg in target_pg:
		pg_path_str = pg.split('href="')[1].split('"')[0]
		pg_path_link = 'http://tv1.alarab.com/' + pg_path_str
		#pg_number_str = re.findall(r' title=" \xd8\xb5\xd9\x81\xd8\xad\xd8\xa9 (.*?)" >',pg)
		pg_number_str = pg.split('title=" \xd8\xb5\xd9\x81\xd8\xad\xd8\xa9 ')[1].split('" >')[0]
		pg_number = int(pg_number_str)
		if (counter == pg_number):
			utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]', pg_path_link, 51, "")
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)
	
@utils.url_dispatcher.register('55', ['url'])	
def getSerieFolge(url):

	link = utils.getHtml(url, '')
	target_episodes = re.findall(r'<div class="related_on">(.*?)<div id="results">', link, re.DOTALL)
	print target_episodes
	for episodes in target_episodes:
		episode_name = re.findall(r'div class="">(.*?)</div',episodes,re.DOTALL)
		episode_path = re.findall(r'a href="/(.*?)"', episodes,re.DOTALL)
		episode_img = re.findall(r'src="(.*?)"', episodes,re.DOTALL)		
		for name, paths, img in zip(episode_name, episode_path, episode_img):
			holder = 'http://tv1.alarab.com/'+paths
			print name
			print paths
			print img
			utils.addDownLink('[B]%s[/B]'%name,holder,52,img)		   
	xbmcplugin.endOfDirectory(utils.addon_handle)
	
	
@utils.url_dispatcher.register('52', ['url', 'name'], ['download'])
def PTPlayvid(url, name, download=None):
 try:
  if 'mp3' in url:
    if download == 1:
        utils.downloadVideo(url, name)
    else:
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        listitem.setInfo('video', {'Title': name, 'Genre': '[COLOR red][B]MG-Arabic[/B][/COLOR]'})
        xbmc.Player().play(url, listitem)
	
  else:		
    progress.create('Play video', 'Searching videofile.')
    progress.update( 25, "", "Loading video page", "" )

    videopage = utils.getHtml(url, '')
    match = re.compile('''file: "([^'"]*mp4)".*?label: "HD 1080p"''', re.DOTALL | re.IGNORECASE).findall(videopage)
    match2 = re.compile('''file: "([^'"]*mp4)"''', re.DOTALL | re.IGNORECASE).findall(videopage)
    match3 = re.compile('''file: "([^']+)", label: "HD 1080p"''', re.DOTALL | re.IGNORECASE).findall(videopage)
    try:
        videourl = match[0]
    except:
        try:
            videourl = match2[0]
        except:
            videourl = match3[0]
    
    progress.update( 75, "", "Video found", "" )
    progress.close()

    if download == 1:
        utils.downloadVideo(videourl, name)
    else:
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        listitem.setInfo('video', {'Title': name, 'Genre': '[COLOR red][B]MG-Arabic[/B][/COLOR]'})
        xbmc.Player().play(videourl, listitem)
 except Exception:
        return

@utils.url_dispatcher.register('53', ['url'])
def PTCat(url):
    try:
        listhtml = utils.getHtml(url, alarab)
    except:
        
        return None
    urldata = re.compile(r'<ul class="menu">(.*?)</ul>',re.DOTALL | re.IGNORECASE).findall(listhtml)
    reobj = re.compile(r'<li  id=".*?<a title="" href="(.+?)".*?<span>(.+?)</span></a>', re.DOTALL | re.IGNORECASE).findall(urldata[0])
    for catchannel, catname in reobj:
        catname = utils.cleanspec(catname)	
        catname = utils.cleanhtml(catname)
        if 'http' not in catchannel:
         catchannel = alarab + catchannel
         utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%catname, catchannel, 51, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('56', ['url'])
def MUCat(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None
    urldata = re.compile(r'<li class=current-menu-item>(.*?)<div class=head_ads>',re.DOTALL | re.IGNORECASE).findall(listhtml)
    reobj = re.compile(r'</i><A href="(.+?)">(.+?)</A></li>', re.DOTALL | re.IGNORECASE).findall(urldata[0])
    for catchannel, catname in reobj:
        catname = utils.cleanspec(catname)	
        catname = utils.cleanhtml(catname)
        if 'http' not in catchannel:
         catchannel = 'http://mp31.alarab.com' + catchannel
         utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%catname, catchannel, 57, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('57', ['url'], ['page'])
def MUList(url, page=1):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile(r'<div class=frame>.*?href="([^"]+)".*?<img alt="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, name in match:
           videopage = 'http://mp31.alarab.com' + videopage		
           utils.addDir('[B]%s[/B]'%name, videopage, 58, '', '')
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('58', ['url'], ['page'])
def MUList(url, page=1):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile(r'<td><strong><a.*?">([^"]+)</a>.*?<td><a href="([^"]+mp3)" download>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for name, videopage in match:
         # if 'http' not in videopage:
            # videopage = 'http://mp31.alarab.com' + videopage
            videopage = decodeurl(videopage)			
            utils.addDownLink('[B]%s[/B]'%name, videopage, 52, '', '')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('54', ['url'], ['keyword'])  
def PTSearch(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 54)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title #+ '/'
        print "Searching URL: " + searchUrl
        PTList(searchUrl, 1)
