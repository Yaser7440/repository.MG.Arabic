'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
progress = utils.progress    

vartuchdr = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36',
       'Accept': '*/*',
       'Accept-Encoding': 'gzip, deflate, sdch, br',
       'Accept-Language': 'en-US,en;q=0.8,nl;q=0.6',
       'Connection': 'keep-alive'}

vartuchdr2 = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36',
       'Accept': '*/*',
       'Accept-Encoding': 'gzip, deflate, sdch',
       'Accept-Language': 'en-US,en;q=0.8,nl;q=0.6',
       'X-Requested-With': 'ShockwaveFlash/22.0.0.209',
       'Connection': 'keep-alive'}        


aflamonlinee = 'http://www.aflamonlinee.org/new/'	   
	   
	   
	   
	   
@utils.url_dispatcher.register('320')
def Main():
    #utils.addDir('[COLOR hotpink]Top videos[/COLOR]','',321,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]MENU[/B]',aflamonlinee,323,'','')
    #utils.addDir('[COLOR hotpink]Categories - all[/COLOR]','http',325,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]SEARCH[/B]',aflamonlinee + '?s=',324,'','')
    List(aflamonlinee)
    xbmcplugin.endOfDirectory(utils.addon_handle)

    
@utils.url_dispatcher.register('321', ['url'])
def List(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile(r'class="moviefilm">.*?href="([^"]+)".*?src="([^"]+)" class="attachment.*?<div class="movief"><a href=".*?>([^"]+)</a></div>\s*<div class="movieDesc">([^"]+)</div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, img, name, ino in match:
        name = utils.cleantext(name)
        ino = utils.cleantext(ino)
        ino = utils.cleanhtml(ino)
        if '\xD9\x83\xD8\xA7\xD9\x85\xD9\x84' in name:
           listht = utils.getHtml(videopage, '')
           match2 = re.compile(r'<div class="servers2 servers" align="center">\s*<a href="([^"]+)" target="_blank"', re.DOTALL | re.IGNORECASE).findall(listht)
           for videop in match2:
		
		
            utils.addDir('[B]%s[/B]' %name, videop, 325, img, ino)
        else:
           utils.addDownLink('[B]%s[/B]' %name, videopage, 322, img, ino)
    try:
        nextp = re.compile('<link rel="next" href="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]', nextp[0], 321,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('322', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    progress.create('Play video', 'Searching videofile.')
    progress.update( 25, "", "Loading video page", "" )
    data = utils.getHtml(url, '')
    if "rel='shortlink'" in data:
        res_quality = []
        stream_url = []
        quality = ''
        regx="rel='shortlink' href='.*?p=(.+?)'"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[0]
        print "id",id
        #range=['1','2','3','4','5','6','7','8']
        for i in range(1,5):
          catpage='http://www.aflamonlinee.org/new/wp-content/themes/yourcolor/servers/server.php?q=' + id + '&i=' + str(i)
          print catpage
          quality = '[B][COLOR white]SERVER [%s][/COLOR][/B]' %str(i)
          res_quality.append(quality)
          stream_url.append(catpage)
        if len(id) >0:
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Please Select Servers',res_quality)
            if ret == -1:
                return
            elif ret > -1:
                videourl = stream_url[ret]
            try:
                    server = utils.getHtml(videourl, url)
            except:
                   return None
        a = re.compile('''src="(.*?)"''', re.DOTALL | re.IGNORECASE).findall(server)
        b = re.compile('''<ifram.*?src="([^'"]+)"''', re.DOTALL | re.IGNORECASE).findall(server)
        c = re.compile('''<IFRAM.*?SRC=([^'"]+)".*?</IFRAME>''', re.DOTALL | re.IGNORECASE).findall(server)
        d = re.compile('''<ifram.*?src="([^'"]+)".*?</iframe>''', re.DOTALL | re.IGNORECASE).findall(server)
        try:
           videourl = a[0]
        except:
            try:
               videourl = b[0]
            except:
                try:
                   videourl = c[0]
                except:
                      videourl = d[0]
        if videourl:
            utils.playvideo(videourl, name, download, url)
        else:
            utils.notify('Oh oh','Couldn\'t find a video')


@utils.url_dispatcher.register('323', ['url'])
def Categories(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
    match = re.compile('<li id="menu-item-.*?" class="menu.*?"><a href="([^"]+)">([^"]+)</a></li>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for catid, name in match:		
            utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]' %name, catid, 321, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('325', ['url'])
def Categories2(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile(r'class="moviefilm">.*?href="([^"]+)".*?src="([^"]+)" class="attachment.*?<div class="movief"><a href=".*?>([^"]+)</a></div>\s*<div class="movieDesc">([^"]+)</div>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videopage, img, name, ino in match:
        name = utils.cleantext(name)
        ino = utils.cleantext(ino)
        ino = utils.cleanhtml(ino)
        utils.addDownLink('[B]%s[/B]' %name, videopage, 322, img, ino)
    try:
        nextp = re.compile('<link rel="next" href="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
        utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]', nextp[0], 325,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('324', ['url'], ['keyword'])
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 324)
    else:
        title = keyword.replace(' ','_')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        List(searchUrl)
