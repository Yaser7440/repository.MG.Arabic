import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
progress = utils.progress
Albh_url = 'https://hd-arab.com/'

@utils.url_dispatcher.register('90')
def TPMain():
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]SEARCH[/B]','https://hd-arab.com/search/', 94, '', '')
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]MENU[/B]',Albh_url,99,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]GENRES[/B]',Albh_url + '/movies',95,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]MOVIES[/B]',Albh_url + 'movies/',91,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]MOVIES ABC[/B]',Albh_url + 'movies/',99,'','')	
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]TV SHOWS[/B]',Albh_url + 'tvshows/',91,'','')
    #utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]TV SHOWS ABC[/B]',Albh_url + 'tvshows/',99,'','')	
    #TPList(Albh_url + 'popular-movies/')
    xbmcplugin.endOfDirectory(utils.addon_handle)

#ABC
@utils.url_dispatcher.register('99', ['url'])
def ABC(url):
    caturl = utils.getHtml(url, '')
    match = re.compile(r'<li class=""><a href="([^"]+)">([^"]+)</a></li>', re.DOTALL | re.IGNORECASE).findall(caturl)
    for pageurl, menu in match:

        if '/aseries' in pageurl:
           utils.addDir('[B]%s[/B]'%menu, pageurl, 97, '', '', '')
        else:  
           utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%menu, pageurl, 91, '', '', '')
    xbmcplugin.endOfDirectory(utils.addon_handle)	
	


def decodeurl(text):
    text = text.replace('&amp;','&').replace(' ','%20').replace('&#039;',"'").replace('\/','/')
    return text

#	TV SHOWS & MOVIES
@utils.url_dispatcher.register('91', ['url'], ['page'])
def TPList(url, page=1):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None
    match = re.compile(r'class="movie-details">\s*<a href="([^"]+)" class="movie-poster.*?data-src="([^"]*jpg)".*?alt="([^"]+)".*?class="movie-year">([^"]+)</div>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, name, rating in match:
	
	
        if thumb.startswith('/'): thumb = Albh_url + thumb	
        name = utils.cleantext(name)
        name = utils.cleanspec(name)
        name = name + '[COLOR red] ' + rating + '[/COLOR]'

        if 'tvshows' in url:
            utils.addDir('[B]%s[/B]'%name, videourl, 93, thumb, '', '', '')
        else:		
            utils.addDownLink('[B]%s[/B]'%name, videourl, 92, thumb, '', '', '', '', '', '')
    try:
            nextp = re.compile('<a href="([^"]+)" rel="next">').findall(listhtml)[0]
            next = url + nextp
            utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]' ,next,  91, '')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('97', ['url'], ['page'])
def TPList2(url, page=1):
    try:
        listhtml = utils.getHtml(url, '')
    except:        
        return None
    match = re.compile(r'href="([^"]+)">\s*<[^"]+[^>]+>\s*<img src="([^"]+jpg)[^<]+[^"]+"([^"]+)" />.*?<p>([^"]+)</p>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, name, desc in match:
        thumb = Albh_url + thumb
        thumb = thumb.replace('&amp;','&').replace(' ','%20').replace('&#039;',"'").replace('\/','/')
        name = utils.cleantext(name)
        videourl = Albh_url + videourl
        utils.addDir('[B]%s[/B]'%utils.cleanspec(name), decodeurl(videourl), 96, thumb, utils.cleantext(desc), '','')
    try:
		nextp=re.compile('<li><a href="(.*?)" rel="next">&raquo;</a></li>').findall(listhtml)[0]
		utils.addDir('[COLOR red][B]Next Page[/B][/COLOR]' ,nextp,  97, '')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)
	
#season
@utils.url_dispatcher.register('93', ['url'])
def SEASON(url):
    caturl = utils.getHtml(url, '')
    match = re.compile(r'<li>\s*<a href="([^"]+)">.*?class="episode_name"><span>([^"]+)</span>\s*</a>', re.DOTALL | re.IGNORECASE).findall(caturl)
    for caturl, season in match:

		
        utils.addDownLink('[B]%s[/B]'%season, caturl, 92, '', '', '')
    xbmcplugin.endOfDirectory(utils.addon_handle)	

#EPISODE
@utils.url_dispatcher.register('96', ['url'])
def episode(url):
    caturl = utils.getHtml(url, '')
    match = re.compile(r'class="col-md-3+[^"]+[^>]+">\s*<img src="([^"]+)"+[^"]+[^>]+/>', re.DOTALL | re.IGNORECASE).findall(caturl)
    for thumb in match:	
        thumb = Albh_url + thumb
    caturl = utils.getHtml(url, '')
    match = re.compile(r'class="col-md-3+[^"]+[^>]+" href="([^"]+)">\s*<[^>]+>\s*<[^"]+[^>]+><[^>]+>\s*(.+?)\s*</div>', re.DOTALL | re.IGNORECASE).findall(caturl)
    for caturl, episode in match:
        caturl = Albh_url + caturl
        if 'aseries' in url: 		
            utils.addDownLink('[B]%s[/B]'%utils.cleantext(episode), decodeurl(caturl), 92, thumb, '','')
        else:
            utils.addDownLink('[B]%s[/B]'%utils.cleantext(episode), decodeurl(caturl), 92, thumb, '','')
    xbmcplugin.endOfDirectory(utils.addon_handle)


#GENRES
@utils.url_dispatcher.register('95', ['url'], ['page'])
def GENRES(url, page=1):
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]IMDB TOP[/B]',Albh_url + 'imdb-top/',91,'','')
    utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]Popular Movies[/B]',Albh_url + 'popular-movies/',91,'','')	
    pshtml = utils.getHtml(url, '')
    Regex2 = re.findall(r'<ul class="sub-menu">(.+?)</ul>', pshtml, re.DOTALL)
    for items in Regex2:
      Regex3 = re.findall(r'<li><a href="(.+?)">(.+?)</a></li>', items)
      for url,name in Regex3:
        if 'http' not in url:
           url = Albh_url + url		   
        utils.addDir('[COLOR red]MG.Arabic[/COLOR] [B]%s[/B]'%name, decodeurl(url), 91, '', '', 1)
    xbmcplugin.endOfDirectory(utils.addon_handle)

	
@utils.url_dispatcher.register('92', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
	utils.PLAYVIDEO(url, name, download)	





			

@utils.url_dispatcher.register('94', ['url'], ['keyword'])
def TPSearch(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 94)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title 
        print "Searching URL: " + searchUrl 
        TPList(searchUrl, 1)
