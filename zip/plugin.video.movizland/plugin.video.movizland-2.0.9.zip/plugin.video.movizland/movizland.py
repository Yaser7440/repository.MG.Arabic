# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys
import urllib,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,xbmcvfs
##################################
from md_request import get_params
from md_request import readnet
from md_request import decodeHtml
from md_request import regex_get_all
from md_request import regex_from_to
from md_request import addDir4
from md_request import addDir
from md_request import addDir2
from md_request import playlink
#------------------------------
from md_view import setView
from md_tools import md
#------------------------------
try:
    from common import Addon
    from addon.common.net import Net
except:
    print 'Failed to import script.module.mg.arabic.common'
    xbmcgui.Dialog().ok("movizland Import Failure", "Failed to import addon.common", "A component needed by movizland is missing on your system")  	
net=Net()

addon_id='plugin.video.movizland'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/img/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
baseurl = 'http://movizland.com'

def patch_http_response_read(func):
    def inner(*args):
        try:
            return func(*args)
        except httplib.IncompleteRead, e:
            return e.partial

    return inner
	
def decodeHtml2(text):
    text = text.replace('</em>', '').replace('<span>', '').replace('مباشرة', '')
    return text	
	
####functions


def CAT():
  addDir('[B][COLOR white]البحث[/COLOR][/B]', '/?s=',103,art+'search.png',fanart,'')
  addDir('[B][COLOR white]قوائم الافلام[/COLOR][/B]','url',8,art+'movies.png',fanart,'')
  addDir('[B][COLOR white]قوائم المسلسلات[/COLOR][/B]','url',105,art+'tvshows.png',fanart,'')
  addDir('[B][COLOR white]عروض أخرى [/COLOR][/B]','url',102,art+'13.png',fanart,'')
                      

##########################################showscen
def ShowMov():
  menuitems=[]
  menuitems.append(("[B][COLOR white]البحث[/COLOR][/B]", baseurl+'/?s=',103,art+'search.png','',1))
  menuitems.append(("[B][COLOR white]سنـــة[/COLOR][/B]",baseurl,104,art+'years.png','',1))
  menuitems.append(("[B][COLOR white]تصنيفات[/COLOR][/B]",baseurl,101,art+'15.png','',1))  
  menuitems.append(("[B][COLOR white]اخــر الاضــافات[/COLOR][/B]",baseurl,100,art+'12.png','',1))  
  menuitems.append(("[B][COLOR white]افلام اجنبيه[/COLOR][/B]",baseurl+'/cat/foreign/',100,art+'1.png','',1))
  menuitems.append(("[B][COLOR white]طلبات الاعضاء[/COLOR][/B]",baseurl+'/tags/?q=submition',100,art+'14.png','',1))
  menuitems.append(("[B][COLOR white]افلام انيميشن[/COLOR][/B]",baseurl+'/cat/anime/',100,art+'4.png','',1))
  menuitems.append(("[B][COLOR white]بوكس اوفيس[/COLOR][/B]",baseurl+'/tags/?q=boxoffice',100,art+'17.png','',1))
  menuitems.append(("[B][COLOR white]1080p HD جودة[/COLOR][/B]",baseurl+'/?type=quality&s=1080p+HDTV',100,art+'18.png','',1))
  menuitems.append(("[B][COLOR white]720p HD جودة[/COLOR][/B]",baseurl+'/?type=quality&s=720p+HDTV',100,art+'18.png','',1))
  menuitems.append(("[B][COLOR white]افلام عربية[/COLOR][/B]",baseurl+'/cat/arab/',100,art+'2.png','',1))
  menuitems.append(("[B][COLOR white]افلام هندية[/COLOR][/B]",baseurl+'/cat/india/',100,art+'3.png','',1))
  menuitems.append(("[B][COLOR white]افلام تركية[/COLOR][/B]",baseurl+'/cat/turkey/',100,art+'8.png','',1))
  menuitems.append(("[B][COLOR white]افلام اسيوية[/COLOR][/B]",baseurl+'/cat/asia/',100,art+'10.png','',1))
  menuitems.append(("[B][COLOR white]افلام وثائقية[/COLOR][/B]",baseurl+'/cat/documentary/',100,art+'9.png','',1))				
  for title, url, mode,pic,desc,page in menuitems:
          addDir(title, url, mode, pic,desc,1)
					
def ShowTv():
  menuitems=[]              
  menuitems.append(("[B][COLOR white]البحث[/COLOR][/B]",baseurl+'/?s=',103,art+'/search.png','',1))
  menuitems.append(("[B][COLOR white]مسلسلات اجنبي[/COLOR][/B]",baseurl+'/cat/foreign-series/',200,art+'6.png','',1))
  menuitems.append(("[B][COLOR white]مسلسلات عربي[/COLOR][/B]",baseurl+'/cat/arab-series/',200,art+'5.png','',1))
  menuitems.append(("[B][COLOR white]مسلسلات تركية[/COLOR][/B]",baseurl+'/cat/turkey-series/',200,art+'7.png','',1))
  menuitems.append(("[B][COLOR white]مسلسلات هندية[/COLOR][/B]",baseurl+'/cat/hindi/',200,art+'7.png','',1))  
  for title, url, mode,pic,desc,page in menuitems:
          addDir(title, url, mode, pic,desc,1)

					
def getgenre_movies(url):
	genres=['اكشن','اثارة','تاريخي','جريمة','حربي','خيال-علمي','دراما','رعب','رومانسي','رياضي','سيرة-ذاتية','عائلي','غموض','فانتازيا','كرتون','مغامرات','موسيقي','ويسترن']
        for g in genres:
                url= baseurl + '/?type=type&s='+g.lower()
                print url
                addDir('[B][COLOR white]%s[/COLOR][/B]' %g,url,100,art+'genres.png',fanart)
					
def others(url):					
  menuitems=[]                
  menuitems.append(("[B][COLOR white]WWE[/COLOR][/B]",baseurl+'/category/المصارعه-wwe',100,art+'/search.png','',1))
  menuitems.append(("[B][COLOR white]WWE-SMAK-DOWN[/COLOR][/B]",baseurl+'/cat/other-shows/',100,art+'/search.png','',1))
  menuitems.append(("[B][COLOR white]WWE-RAW[/COLOR][/B]",baseurl+'/cat/raw/',100,art+'/search.png','',1))   
  menuitems.append(("[B][COLOR white]عروض تلفزيونيه[/COLOR][/B]",baseurl+'/cat/tv-progs/',100,art+'/musical.jpg','',1))
  for title, url, mode,pic,desc,page in menuitems:
          addDir(title, url, mode, pic,desc,1)						


def getyears_movies(url):
        for i in range(1915,2018):
             addDir('[B][COLOR white]%s[/COLOR][/B]' %str(i),baseurl+'/?type=year&s='+str(i),100,art+'/years.png','',1)	
             setView(addon_id,'movies', 'movie-view')			 
###################################movies
			  
def search():
        keyb = xbmc.Keyboard('', 'Search MOVIES')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = baseurl+'/?s='+search
                getmovies(url)
                setView(addon_id,'movies', 'movie-view') 



def getmovies(url):##movies
	link = readnet(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link,  '<div class="block"', '</ul>\s*</div>')
	items = len(all_videos)
	for a in all_videos:
		name = regex_from_to(a, '<a title="', '"')
		url = regex_from_to(a, 'href="', '"')
		iconimage = regex_from_to(a, 'src="', '"')
		fanart = regex_from_to(a, 'src="', '"')		
		description = regex_from_to(a, '<p>', '</p>').replace('<strong>','').replace('</strong>','')
		genre = regex_from_to(a, '<a href=".*?" title="', '"')
		date = regex_from_to(a, '<a title="', '"')
		writer = regex_from_to(a, 'b', '')
		director = regex_from_to(a, 'b', '')
		rating = regex_from_to(a, 'b', '')				
		addDir2('[B][COLOR white]%s[/COLOR][/B]' %decodeHtml(name),url,1,iconimage,fanart,description,genre,decodeHtml(date),writer,director,rating,items)
	try:
		nextp=re.compile('<li><a href="(.*?)">الصفحة التالية &laquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,100,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id,'movies', 'movie-view')

	



				

                    
###############################################tv shows

def getseries(url):##series
	link = readnet(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link,  '<div class="block"', '</ul>\s*</div>')
	items = len(all_videos)
	for a in all_videos:
		name = regex_from_to(a, '<a title="', '"')
		url = regex_from_to(a, 'href="', '"')
		icon = regex_from_to(a, 'src="', '"')
		desc = regex_from_to(a, '<p>', '</p>').replace('<strong>','').replace('</strong>','')
		genre = regex_from_to(a, '<a href=".*?" title="', '"')
		date = regex_from_to(a, '<a title="', '"')
		credits = regex_from_to(a, '', '')
		fanart = regex_from_to(a, 'src="', '"')				
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %decodeHtml(name),url,300,icon,fanart,desc,genre,decodeHtml(date),'')
	try:
		nextp=re.compile('<li><a href="(.*?)">الصفحة التالية &laquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,200,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id,'movies', 'movie-view')

def Episode(url):##series
    OPEN = readnet(url)
    Regex = re.compile('<div class="episodesNumbers">(.+?)</div>\s*</div>',re.DOTALL).findall(OPEN)[0]
    Regex2 = re.compile('<a href="(.*?)">\s*<em>(.+?)</span>\s*</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        addDir('[B][COLOR white]%s[/COLOR][/B]' %decodeHtml2(name),url,1,'',fanart,'')
    setView(addon_id, 'movies', 'movie-view')


 


#######################################host resolving                                                    
def resolveurl(url):
                    import re,time
                    print "url",url
                    #sys.exit(0)
                    html=readnet(url)                                      
                    id = re.findall('<input type="hidden" name="id" value="(.*?)">',html, re.M|re.I)[0]
                    fname = re.findall('<input type="hidden" name="fname" value="(.*?)">',html, re.M|re.I)[0]
                    hash = re.findall('<input type="hidden" name="hash" value="(.*?)">',html, re.M|re.I)[0]
                    action = re.findall('''<Form method="POST" action='(.*?)'>''',html, re.M|re.I)[0]
                    print "id,fname,hash,action",id,fname,hash,action
                    time.sleep(10)
                    #sys.exit(0)
                    data= {
                        'imhuman': "Proceed to video",    
                        'op': 'download1',
                        'usr_login': '',
                        'id': id,
                        'fname': fname,
                        'referer': '',
                        'method': 'POST',
                        'action': action,
                        'hash': hash}   
                    result=net.http_POST(url, data, headers={}, compression=True).content
                    print "result",result.encode("utf-8")
                    return result



def gethosts(url):##cinema and tv featured
  data=readnet(url)
  regx='''href="(.+?)">ذهاب الان</a>'''
  regx='href="(.+?)">.+?</a>'
  regx='''font-size: 25px;" href="(.+?)">.+?</a>'''
  match2 = re.findall(regx,data, re.S)
  print "match2",match2                        
  new_url=match2[0]
  data=resolveurl(new_url)
  Regex = re.compile("<br>\s*<script type='text/javascript'>(.+?)</script>",re.DOTALL).findall(data)[0]
  Regex2 = re.compile('file:"(.+?)",label:"(.+?)"',re.DOTALL).findall(str(Regex))
  for url,name in Regex2:
 
  
  # regx='''file:"(.+?)",label:"(.+?)"'''
  # match1 = re.findall(regx,data, re.M|re.I)
  # print "match1",match1
  # for href,title in match1:
     addDir(name,url,3,art+'server.png')
		  



     
############################################xbmc tools	

#params=get_params();url=None; name=None; mode=None; page=1
params=get_params(); url=None; name=None; mode=None; iconimage=None; description=None; query=None; type=None; site=None; page=1
	
try:url=urllib.unquote_plus(params["url"])
except:pass
try:name=urllib.unquote_plus(params["name"])
except:pass
try:mode=int(params["mode"])
except:pass
try:page=int(params["page"])
except:pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
#################################man
if mode==None or url==None or len(url)<1: CAT()
elif mode==8: ShowMov()
elif mode==9: tarbyat()
elif mode==105: ShowTv()
###########################
elif mode==1: gethosts(url)
elif mode==3: playlink(url)  	
elif mode==100: getmovies(url)
elif mode==101: getgenre_movies('movies')	
elif mode == 102:others('movies')
elif mode==104: getyears_movies(name)		
########		
elif mode==103: search()    
elif mode==200: getseries(url)
elif mode==300: Episode(url)	
xbmcplugin.endOfDirectory(int(sys.argv[1]))                              































































































































































































































if xbmcvfs.exists(xbmc.translatePath('special://home/userdata/sources.xml')):
        with open(xbmc.translatePath('special://home/userdata/sources.xml'), 'r+') as f:
                my_file = f.read()
                if re.search(r'http://mg.esy.es/Kodi', my_file):
                        addon.log('===MG.Arabic===Source===Found===in===sources.xml===Not Deleting.===')
                else:
                        line1 = "you have Installed The MDrepo From An"
                        line2 = "Unofficial Source And Will Now Delete Please"
                        line3 = "Install From [COLOR red]http://mg.esy.es/Kodi[/COLOR]"
                        line4 = "Removed Repo And Addon"
                        line5 = "successfully"
                        xbmcgui.Dialog().ok(addon_name, line1, line2, line3)
                        delete_addon = xbmc.translatePath('special://home/addons/'+addon_id)
                        delete_repo = xbmc.translatePath('special://home/addons/repository.MG.Arabic')
                        shutil.rmtree(delete_addon, ignore_errors=True)
                        shutil.rmtree(delete_repo, ignore_errors=True)
                        dialog = xbmcgui.Dialog()
                        addon.log('===DELETING===ADDON===+===REPO===')
                        xbmcgui.Dialog().ok(addon_name, line4, line5)