import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/Yaser7440/repository.MG.Arabic/master/zip/video/Home.txt'
addon = xbmcaddon.Addon('plugin.video.MGIPTV')