# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys
import urllib,urllib2,re,os,string,shutil,requests,random,hashlib,base64
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re
import xbmcvfs
from urllib import urlencode
#------------------------------
from md_request import get_params
from md_request import OPEN_URL
from md_request import removeunicode
from md_request import gethostname
from md_request import regex_get_all
from md_request import regex_from_to
from md_request import addDir
from md_request import addDir2
from md_request import readnet
from md_request import playlink
from md_request import resolve_host
#------------------------------
from common import Addon
from md_view import setView
from addon.common.net import Net
#------------------------------
#By. MG.Arabic http://mg.esy.es/Kodi/ (07/2017)


addon_id='plugin.video.easycima'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_handle = int(sys.argv[1])
addon_name = selfAddon.getAddonInfo('name')
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/img/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'


baseurl = 'http://www.easycima.com'
####functions
host='www.easycima.com'
####functions
def read_url(url):
      try:  
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', host)
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
        return link
      except:
            addDir("Download failed:"+url,"","",'')
            return None
    

def decodeHtml(text):
    text = text.replace('&auml;', 'ae').replace('&Auml;', 'Ae').replace('&ouml;', 'oe').replace('&ouml;', 'Oe').replace('&uuml;', 'ue')
    text = text.replace('&Uuml;', 'Ue').replace('&szlig;', 'ss').replace('&amp;', '&').replace('&quot;', '"').replace('&gt;', "'")
    text = text.replace('&#228;', 'ae').replace('&#246;', 'oe').replace('&#252;', 'ue').replace('&#223;', 'ss').replace('&#8230;', '...')
    text = text.replace('&#8222;', ',').replace('&#8220;', "'").replace('&#8216;', "'").replace('&#8217;', "'").replace('&#8211;', '-')
    text = text.replace('&#8230;', '...').replace('&#8217;', "'").replace('&#128513;', ':-)').replace('&#8221;', '"')
    text = text.replace('&#038;', '&').replace('&#039;', "'")
    text = text.replace('\\u00c4', 'Ae').replace('\\u00e4;', 'ae').replace('\\u00d6', 'Oe').replace('\\u00f6', 'oe')
    text = text.replace('\\u00dc', 'Ue').replace('\\u00fc', 'ue').replace('\\u00df', 'ss').replace('\\u00df', 'ss')
    text = text.replace('&#196;', 'Ae').replace('&#228;', 'ae').replace('&#214;', 'Oe').replace('&#246;', 'oe').replace('&#220;', 'Ue').replace('&#252;', 'ue')
    text = text.replace('<br />\n', '').replace('(u','').replace(', u','(').replace("'"," ").replace('"','').replace('&','')
   
    return text

              
   

              

##########################################parsing tools
def CAT():
        #addDir('[B][COLOR white]البحث[/COLOR][/B]', 'url',103,'special://home/addons/plugin.video.easycima/img/search.png',fanart,'')
        addDir('[B][COLOR white]قوائم الافلام[/COLOR][/B]','url',8,art+'/1.png',fanart,'')
        addDir('[B][COLOR white]السنة[/COLOR][/B]','url',10,art+'/tvshows.png',fanart,'')

		
		
def showmenuMV():

                menuitems=[]
                
                menuitems.append(("[B][COLOR white]افلام عربى[/COLOR][/B]",baseurl+'/dep/dp/2/افلام+عربى',100,art+'/search.png','',1))
                menuitems.append(("[B][COLOR white]افلام اجنبيه[/COLOR][/B]",baseurl+'/dep/dp/1/افلام+اجنبى',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]افلام هندى[/COLOR][/B]",baseurl+'/dep/dp/3/افلام+هندى',100,art+'/7.png','',1))
                menuitems.append(("[B][COLOR white]افلام كرتون[/COLOR][/B]",baseurl+'/dep/dp/4/افلام+كرتون',100,art+'/musical.jpg','',1))
		
                for title, url, mode,pic,desc,page in menuitems:
                    addDir(title, url, mode, pic,desc,1)

              
                    

			
###################################movies
               
def getmovies(url):##movies
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="col-md-3 file_index">', '/div>\s*</div>')
	items = len(all_videos)
	for a in all_videos:
		name = regex_from_to(a, '<img alt="', '"').replace('&#039;',"'").replace('&amp;',"&")
		url = regex_from_to(a, 'href="', '"').replace('&#039;',"'").replace('&amp;',"&")
		icon = regex_from_to(a, 'src="', '"').replace('&#039;',"'").replace('&amp;',"&")
		desc = regex_from_to(a, '<div class="descrfile">', '</div>\s*</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','')
		genre =regex_from_to(a, '<div class="typefile">', '<').replace('<br />','').replace('&#039;',"'").replace('&amp;',"&").replace('مترجم','').replace('فلم','')
		date = regex_from_to(a, '<span class="yeaspro">', '</span>')
		rating = regex_from_to(a, '<div class="col-md-6 mIMDB">\s*', '<i class="fa fa-imdb">')
		credits = regex_from_to(a, '<h4>', '</h4>').replace('&#039;',"'").replace('&amp;',"&")
		fanart = regex_from_to(a, 'src="', '"').replace('&#039;',"'").replace('&amp;',"&")		
		addDir2('[B][COLOR white]%s[/COLOR][/B] [B][I][COLOR white](%s)[/COLOR][/I][/B]' %(name,date),(removeunicode(url)),1,icon,fanart,desc,genre,date,'',credits,rating,items)		
	try:
		nextp=re.compile('<li><a href="(.*?)">').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,100,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')



def search():
        keyb = xbmc.Keyboard('', 'Search MOVIES')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = baseurl+'/home/src'+search
                getmovies(url)				

def YEARSEN(url):
       for i in range(1965,2018):
	   
             addDir('[B][COLOR white]%s[/COLOR][/B]'%str(i),'http://www.easycima.com/srch/sh/'+str(i)+"/",100,'','',1)                    

#######################################host resolving                                                    

def gethosts(urlmain):##cinema and tv featured

                
                data=read_url(urlmain)
                if data is None:
                    return
                regx1='''<iframe src="(.*?)" frameborder=0 marginwidth=0 marginheight=0 scrolling=NO allowfullscreen='true' width=640 height=400></iframe>'''
                regx2='''<div class="col-md-3"><a href="(.*?)"'''
               

		host1= re.findall(regx1,data, re.M|re.I)
		host2= re.findall(regx2,data, re.M|re.I)
		
		i=0
		if host2:
			 for href in host2:
			   host="[B][COLOR white]SERVER[/COLOR][/B] :"+str(i+1)
			   i=i+1
			   
                           addDir(host,href,21,'')                                                

                
            
def gethosts2(urlmain):##cinema and tv featured

                
                data=readnet(urlmain)
               
                if data is None:
                    return
                regx='''</div><div class="col-lg-4"><a href="(.*?)" target="_blank"'''
		host= re.findall(regx,data, re.M|re.I)
		if host:
                        for href in host:
                          host=gethostname(href)
			  addDir('[B][COLOR white]%s[/COLOR][/B]'%host,href,20,'')
			  

           
############################################xbmc tools	    
params=get_params(); url=None; name=None; mode=None; iconimage=None; description=None; query=None; type=None; site=None; page=1
# OpenELEQ: query & type-parameter (added 2 lines above)

try:url=urllib.unquote_plus(params["url"])
except:pass
try:name=urllib.unquote_plus(params["name"])
except:pass
try:iconimage=urllib.unquote_plus(params["iconimage"])
except:pass
try:mode=int(params["mode"])
except:pass
try:description=urllib.unquote_plus(params["description"])
except:pass
try:query=urllib.unquote_plus(params["query"])
except:pass
try:type=urllib.unquote_plus(params["type"])
except:pass
try:page=int(params["page"])
except:pass	

if mode==None or url==None or len(url)<1:
        CAT()
elif mode==8:		
        showmenuMV()
elif mode==9:		
        showmenuTV()		
elif mode==1:
        print ""+url
        gethosts(url)
elif mode==21:
        print ""+url
        gethosts2(url)		

elif mode==20: resolve_host(url)        
elif mode==3: playlink(url)    
       
elif mode==100: getmovies(url)

elif mode==10:
        print ""+url               
        YEARSEN(name)	
elif mode==103: search()    
       


elif mode==200:
        print ""+url
	getseries(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)

elif mode==202:
	getepisodes(name,url,page)
elif mode==300:

	getsongs(name,url,page)
xbmcplugin.endOfDirectory(int(sys.argv[1]))                              































































































































































































































if xbmcvfs.exists(xbmc.translatePath('special://home/userdata/sources.xml')):
        with open(xbmc.translatePath('special://home/userdata/sources.xml'), 'r+') as f:
                my_file = f.read()
                if re.search(r'http://mg.esy.es/Kodi', my_file):
                        addon.log('===MG.Arabic===Source===Found===in===sources.xml===Not Deleting.===')
                else:
                        line1 = "you have Installed The MDrepo From An"
                        line2 = "Unofficial Source And Will Now Delete Please"
                        line3 = "Install From [COLOR red]http://mg.esy.es/Kodi[/COLOR]"
                        line4 = "Removed Repo And Addon"
                        line5 = "successfully"
                        xbmcgui.Dialog().ok(addon_name, line1, line2, line3)
                        delete_addon = xbmc.translatePath('special://home/addons/'+addon_id)
                        delete_repo = xbmc.translatePath('special://home/addons/repository.MG.Arabic')
                        shutil.rmtree(delete_addon, ignore_errors=True)
                        shutil.rmtree(delete_repo, ignore_errors=True)
                        dialog = xbmcgui.Dialog()
                        addon.log('===DELETING===ADDON===+===REPO===')
                        xbmcgui.Dialog().ok(addon_name, line4, line5)