#test
import wsyspath
from tsmresolver import resolve
web_url=('http://vodlocker.com/yqzqrp3hcke1')#https://player.vimeo.com/video/136759516'
stream_url=resolve(web_url = web_url,host=None,media_id=None,urllist=True )

print 'final stream_url',stream_url

