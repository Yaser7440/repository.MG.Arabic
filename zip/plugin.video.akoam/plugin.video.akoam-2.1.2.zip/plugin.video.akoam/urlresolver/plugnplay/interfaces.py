# 2014.11.21 08:44:41 Arabian Standard Time
#Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/TSmedia/scripts/script.module.urlresolver/lib/urlresolver/plugnplay/interfaces.py
"""
This module defines several interfaces that you can implement when writing 
your URL resolving plugin.

* :class:`UrlResolver`: Resolves URLs. All plugins should implement this.
* :class:`SiteAuth`: Handles logging in to the file hoster.
* :class:`PluginSettings`: Allows a plugin to save and retrieve settings.

Interfaces you wish to implement must be included in the inheritance list of
you class definition, as well as added to the ``implements`` attribute of your
class.

For example, if you want to implement all the available interfaces, your plugin 
should be defined as follows::

        class MyPluginResolver(Plugin, UrlResolver, SiteAuth, PluginSettings):
            implements = [UrlResolver, SiteAuth, PluginSettings]

"""

def _function_id(obj, nFramesUp):
    """Create a string naming the function n frames up on the stack."""
    fr = sys._getframe(nFramesUp + 1)
    co = fr.f_code
    return '%s.%s' % (obj.__class__, co.co_name)


def not_implemented(obj = None):
    """Use this instead of ``pass`` for the body of abstract methods."""
    raise Exception('Unimplemented abstract method: %s' % _function_id(obj, 1))


class UrlResolver:

    class unresolvable:

        def __init__(self, code = 0, msg = 'Unknown Error'):
            pass

        def __nonzero__(self):
            pass


class SiteAuth:
    pass


class PluginSettings:

    def get_setting(self, key):
        pass
# okay decompyling I:\TSmediaTools\Kodi\scripts\script.module.urlresolver\lib\urlresolver\plugnplay\interfaces.pyo 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2014.11.21 08:44:41 Arabian Standard Time
