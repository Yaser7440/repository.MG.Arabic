# -*- coding: UTF-8 -*-
#/*
# *      Copyright (C) 2013 mx3L
# *
# *
# *  This Program is free software; you can redistribute it and/or modify
# *  it under the terms of the GNU General Public License as published by
# *  the Free Software Foundation; either version 2, or (at your option)
# *  any later version.
# *
# *  This Program is distributed in the hope that it will be useful,
# *  but WITHOUT ANY WARRANTY; without even the implied warranty of
# *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# *  GNU General Public License for more details.
# *
# *  You should have received a copy of the GNU General Public License
# *  along with this program; see the file COPYING.  If not, write to
# *  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# *  http://www.gnu.org/copyleft/gpl.html
# *
# */
import re,json,urllib2
__name__ = 'videomail'
def supports(url):
    return not _regex(url) == None

# returns the steam url

def read_url2(url):#redirect error
        try:


           p = urllib2.build_opener(urllib2.HTTPCookieProcessor).open(url)

           return p.read()
        except:
                addDir("Download failed:","","",'')
                #xbmc.executebuiltin("XBMC.Notification(LiveStreams,We failed to reach a server. - "+str(e.reason)+",10000,"+icon+")")                
                return None
def read_url(url):
        try:
            req = urllib2.Request(url)
            response = urllib2.urlopen(req)
            data = response.read()
            response.close()
            return data
        except urllib2.URLError, e:
            print 'URL: '+url
            if hasattr(e, 'code'):
                print 'We failed with error code - %s.' % e.code
                #xbmc.executebuiltin("XBMC.Notification(musichcannels,We failed with error code - "+str(e.code)+",10000,"+icon+")")
            elif hasattr(e, 'reason'):
                print 'We failed to reach a server.'
                print 'Reason: %s' %e.reason
                #xbmc.executebuiltin("XBMC.Notification(LiveStreams,We failed to reach a server. - "+str(e.reason)+",10000,"+icon+")")
def read_url3(url):
      try:  
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', 'www.vidhos.com')
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
        return link
      except:
            addDir("Download failed:"+str(e.reason),"","",'')  
def resolve(url):
    #m = _regex(url)
    
    #sys.exit(0)
    #js='http://videoapi.my.mail.ru/videos/mail/euploader/_myvideo/1027.json'
    
    if True:
        print "url",url
        data=read_url3(url)
        parts=data.split("|")
        regx='''<span id='vplayer'><img src="(.+?)" style'''
        ip=re.findall(regx,data, re.M|re.I)[0]
        #<span id='vplayer'><img src="http://81.94.202.234/i/01/00009/ilsvcyeekfwg.jpg" style
        ip=ip.split("i/")[0]
        link=None
        for i in range(1,len(parts)):
            if parts[i]=='provider':
                link=parts[i+1]
                if link.strip=='':
                   continue        
            if parts[i]=='flv':
               link=parts[i+1]
              

                
        #link=re.findall('|provider|(.+?)|skin',data, re.M|re.I)[0]
        print "js",link
        if link is not None:
           link=ip+link+'/v.flv?start=0'
        return link

