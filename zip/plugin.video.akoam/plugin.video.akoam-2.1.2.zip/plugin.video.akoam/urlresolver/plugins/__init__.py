# 2014.11.21 08:42:28 Arabian Standard Time
#Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/TSmedia/scripts/script.module.urlresolver/lib/urlresolver/plugins/__init__.py
pass
# okay decompyling I:\TSmediaTools\Kodi\scripts\script.module.urlresolver\lib\urlresolver\plugins\__init__.pyo 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2014.11.21 08:42:28 Arabian Standard Time
