# 2014.11.21 08:42:47 Arabian Standard Time
#Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/TSmedia/scripts/script.module.urlresolver/lib/urlresolver/plugins/dailymotion.py
"""
dailymotion urlresolver plugin
Copyright (C) 2011 cyrus007

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
"""
import os
import xbmc
from t0mm0.common.net import Net
from urlresolver.plugnplay.interfaces import UrlResolver
from urlresolver.plugnplay.interfaces import PluginSettings
from urlresolver.plugnplay import Plugin
import re
import urllib2, urllib
from urlresolver import common
logo = os.path.join(common.addon_path, 'resources', 'images', 'redx.png')
def getStreamUrl(id):
    import json
    
    from t0mm0.common.net import Net
    net=Net()
    content =net.http_GET("http://www.dailymotion.com/embed/video/"+id).content
    if content.find('"statusCode":410') > 0 or content.find('"statusCode":403') > 0:
        print "unable to get source"
        return ""
    
    else:
        get_json_code = re.compile(r'dmp\.create\(document\.getElementById\(\'player\'\),\s*([^);]+)').findall(content)[0]
        #print len(get_json_code)
       
        
        try:cc= json.loads(get_json_code)['metadata']['qualities']  #['380'][0]['url']
        except:cc=None
        #print cc
        list1=[]
        if cc is None:
           list1.append(('720',cc['720'][0]['url']))
           #return cc['720'][0]['url']
        
        if '1080' in cc.keys():
            #print 'found hd'
            list1.append(('1080',cc['1080'][0]['url']))            
            #return cc['1080'][0]['url']
        if '720' in cc.keys():
            #return cc['720'][0]['url']
            list1.append(('720',cc['720'][0]['url']))    
        if '480' in cc.keys():
            list1.append(('480',cc['480'][0]['url']))  
        if '380' in cc.keys():
            list1.append(('380',cc['380'][0]['url']))  
        if '240' in cc.keys():
            list1.append(('240',cc['240'][0]['url']))  
        if 'auto' in cc.keys():
            list1.append(('auto',cc['auto'][0]['url']))  
        #else:
            #xbmc.executebuiltin('XBMC.Notification(Info:, No playable Link found (DailyMotion)!,5000)')
        return list1
class DailymotionResolver2(Plugin, UrlResolver, PluginSettings):
    implements = [UrlResolver, PluginSettings]
    name = 'dailymotion'

    def __init__(self):
        p = self.get_setting('priority') or 100
        self.priority = int(p)
        self.net = Net()

    def get_media_url(self, host, media_id):
        if True:
            import sys
            web_url = sys.argv[len(sys.argv)-1]
            try:id=os.path.split(web_url)[1]
            except:id=web_url
            return getStreamUrl(id)
            
            if link.find('"error":') >= 0:
                err_title = re.compile('"title":"(.+?)"').findall(link)[0]
                if not err_title:
                    err_title = 'Content not available.'
                err_message = re.compile('"message":"(.+?)"').findall(link)[0]
                if not err_message:
                    err_message = 'No such video or the video has been removed due to copyright infringement issues.'
                common.addon.log_error(self.name + ' - fetching %s - %s - %s ' % (web_url, err_title, err_message))
                xbmc.executebuiltin('XBMC.Notification([B][COLOR white]DAILYMOTION[/COLOR][/B] - ' + err_title + ',[COLOR red]' + err_message + '[/COLOR],8000,' + logo + ')')
                return self.unresolvable(code=1, msg=err_message)
            imgSrc = re.compile('"thumbnail_url":"(.+?)"').findall(link)[0]
            common.addon.log('img:' + imgSrc)
            dm_live = re.compile('live_rtsp_url":"(.+?)"', re.DOTALL).findall(link)
            dm_1080p = re.compile('"stream_h264_hd1080_url":"(.+?)"', re.DOTALL).findall(link)
            dm_720p = re.compile('"stream_h264_hd_url":"(.+?)"', re.DOTALL).findall(link)
            dm_high = re.compile('"stream_h264_hq_url":"(.+?)"', re.DOTALL).findall(link)
            dm_low = re.compile('"stream_h264_url":"(.+?)"', re.DOTALL).findall(link)
            dm_low2 = re.compile('"stream_h264_ld_url":"(.+?)"', re.DOTALL).findall(link)
            videoUrl = []
            if dm_live:
                liveVideoUrl = urllib.unquote_plus(dm_live[0]).replace('\\/', '/')
                liveVideoUrl = liveVideoUrl.replace('protocol=rtsp', 'protocol=rtmp')
                liveVideoUrl = self.net.http_GET(liveVideoUrl).content
                videoUrl.append(liveVideoUrl)
            else:
                if dm_1080p:
                    videoUrl.append(urllib.unquote_plus(dm_1080p[0]).replace('\\/', '/'))
                if dm_720p:
                    videoUrl.append(urllib.unquote_plus(dm_720p[0]).replace('\\/', '/'))
                if dm_high:
                    videoUrl.append(urllib.unquote_plus(dm_high[0]).replace('\\/', '/'))
                if dm_low:
                    videoUrl.append(urllib.unquote_plus(dm_low[0]).replace('\\/', '/'))
                if dm_low2:
                    videoUrl.append(urllib.unquote_plus(dm_low2[0]).replace('\\/', '/'))
            vUrl = ''
            vUrlsCount = len(videoUrl)
            print "videoUrl",videoUrl,len(videoUrl)
            if vUrlsCount > 0:
                q = self.get_setting('quality')
                if q == '0':
                    vUrl = videoUrl[0]
                elif q == '1':
                    vUrl = videoUrl[int(vUrlsCount / 2)]
                elif q == '2':
                    vUrl = videoUrl[vUrlsCount - 1]
            common.addon.log('url:' + vUrl)
           
            
            return videoUrl
        

    def get_url(self, host, media_id):
        return 'http://www.dailymotion.com/embed/video/%s' % media_id

    def get_host_and_id(self, url):
        r = re.search('//(.+?)/embed/video/([0-9A-Za-z]+)', url)
        if r:
            return r.groups()
        r = re.search('//(.+?)/swf/video/([0-9A-Za-z]+)', url)
        if r:
            return r.groups()
        r = re.search('//(.+?)/video/([0-9A-Za-z]+)', url)
        if r:
            return r.groups()
        r = re.search('//(.+?)/swf/([0-9A-Za-z]+)', url)
        if r:
            return r.groups()
        r = re.search('//(.+?)/sequence/([0-9A-Za-z]+)', url)
        if r:
            return r.groups()
        else:
            return False

    def valid_url(self, url, host):
        if self.get_setting('enabled') == 'false':
            return False
        return re.match('http://(www.)?dailymotion.com/sequence/[0-9A-Za-z]+', url) or re.match('http://(www.)?dailymotion.com/video/[0-9A-Za-z]+', url) or re.match('http://(www.)?dailymotion.com/swf/[0-9A-Za-z]+', url) or re.match('http://(www.)?dailymotion.com/embed/[0-9A-Za-z]+', url) or self.name in host

    def get_settings_xml(self):
        xml = PluginSettings.get_settings_xml(self)
        xml += '<setting label="Video Quality" id="%s_quality" ' % self.__class__.__name__
        xml += 'type="enum" values="High|Medium|Low" default="0" />\n'
        return xml
# okay decompyling I:\TSmediaTools\Kodi\scripts\script.module.urlresolver\lib\urlresolver\plugins\dailymotion.pyo 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2014.11.21 08:42:49 Arabian Standard Time
