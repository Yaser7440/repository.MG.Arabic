# 2015.02.20 15:35:01 Arabian Standard Time
#Embedded file name: /media/hdd/Extensions/TSmedia/addons/arabic/plugin.video.akoam/hostresolver.py
import urllib, urllib2, re, xbmcplugin, xbmcgui, sys, os
from httplib import HTTP
from urlparse import urlparse
import StringIO
import urllib2, urllib
import re
import httplib
USER_AGENT = 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
from t0mm0.common.net import Net
net = Net()
import lib.jsunpack as jsunpack
import lib.unwise  as  unwise

def resolve_upload180(web_url):
    html = net.http_GET(web_url).content
    if re.search('File Not Found', html):
        return self.unresolvable(code=1, msg='File Not Found')
    data = {}
    r = re.findall('type="hidden" name="(.+?)" value="(.+?)"', html)
    if r:
        for name, value in r:
            data[name] = value

        data['referer'] = web_url
        print data
    else:
        raise Exception('Cannot find data values')
    html = net.http_POST(web_url, data).content
    packed = re.search('id="player_code".*?(eval.*?\\)\\)\\))', html, re.DOTALL)
    if packed:
        js = jsunpack.unpack(packed.group(1))
        link = re.search('name="src"*0="([^"]+)"/>', js.replace('\\', ''))
        if link:
            common.addon.log('180Upload Link Found: %s' % link.group(1))
            return link.group(1)
        link = re.search("'file','(.+?)'", js.replace('\\', ''))
        if link:
            return link.group(1)


def resolve_youwatch(web_url):
    print 'youwatch data'
    from packer import unpack, detect
    from t0mm0.common.net import Net
    net = Net()
    resp = net.http_GET(web_url)
    data = resp.content
    get_packedjava = re.search('<script type=.text.javascript.>(eval.function.*?)</script>', data, re.S | re.DOTALL)
    if get_packedjava and detect(get_packedjava.group(1)):
        print 'get_packedjava'
        sJavascript = get_packedjava.group(1)
        sUnpacked = unpack(sJavascript)
        if sUnpacked:
            print 'unpacked'
            stream_url = re.search('file:"(.*?)"', sUnpacked, re.S)
            if stream_url:
                link = stream_url.group(1)
                return link
    print 'Error:no valic stream link found'


def resolve_vodlocker(web_url):
    from t0mm0.common.net import Net
    net = Net()
    resp = net.http_GET(web_url)
    html = resp.content
    debug = True
    if debug:
        data = {}
        r = re.findall('type="hidden" name="(.+?)"\\s* value="?(.+?)">', html)
        data['usr_login'] = ''
        for name, value in r:
            data[name] = value

        data['imhuman'] = 'Proceed to video'
        data['btn_download'] = 'Proceed to video'
        xbmc.sleep(2000)
        html = net.http_POST(web_url, data).content
        print html
    else:
        return 'unresolvable'
    r = re.search('file\\s*:\\s*"(http://.+?)"', html)
    if r:
        stream_url = str(r.group(1))
    else:
        return 'unresolvable'
    return stream_url


def resolve_vidzi(web_url):
    if web_url:
        headers = {'User-Agent': USER_AGENT,
         'Referer': web_url}
        html = net.http_GET(web_url).content
        if '404 Not Found' in html:
            raise Exception('File Not Found or removed')
        regx = 'file: "(.+?)mp4"'
        print html
        r = re.findall(regx, html, re.M | re.I)
        if not r:
            return 'unresolvable'
            raise Exception('Unable to locate link')
        else:
            stream_url = r.group(1) + 'mp4'
            return stream_url


def resolve_sharevid(web_url):
    html = net.http_GET(web_url).content
    regx = 'file:"(.+?)"'
    r = re.findall(regx, html)
    if not r:
        return 'unresolvable'
    for name in r:
        url = name
        return url


def resolve_vidbull(web_url):
    html = net.http_GET(web_url).content
    data = {}
    html = re.search('<Form(.+?)/Form', html, re.DOTALL).group(1)
    r = re.findall('type="hidden"\\s*name="(.+?)"\\s*value="(.+?)"', html)
    for name, value in r:
        data[name] = value

    common.addon.show_countdown(4, title='Vidbull', text='Loading Video...')
    html = net.http_POST(url, data).content
    sPattern = '<script type=(?:"|\')text/javascript(?:"|\')>eval\\(function\\(p,a,c,k,e,[dr]\\)(?!.+player_ads.+).+?</script>'
    r = re.search(sPattern, html, re.DOTALL + re.IGNORECASE)
    if r:
        sJavascript = r.group()
        sUnpacked = jsunpack.unpack(sJavascript)
        stream_url = re.search('[^\\w\\.]file["\']?\\s*[:,]\\s*["\']([^"\']+)', sUnpacked)
        if stream_url:
            return stream_url.group(1)
    raise Exception('File Not Found or removed')


def resolve_allmyvideos(web_url):
    import time
    url = web_url
    headers = {'User-Agent': USER_AGENT,
     'Referer': url}
    html = net.http_GET(url, headers=headers).content
    r = re.search('"mediaid"\\s*:\\s*".*?",\\s*"sources"\\s*:\\s*.\n*\\s*.\n*\\s*"file"\\s*:\\s*"(.+?)"', html)
    if r:
        time.sleep(10)
        return r.group(1) + '|User-Agent=%s' % USER_AGENT
    url = web_url
    headers = {'User-Agent': USER_AGENT,
     'Referer': url}
    html = self.net.http_GET(url, headers=headers).content
    data = {}
    r = re.findall('type="hidden" name="(.+?)"\\s* value="?(.+?)">', html)
    for name, value in r:
        data[name] = value

    html = net.http_POST(url, data, headers=headers).content
    r = re.search('"sources"\\s*:\\s*.\n*\\s*.\n*\\s*"file"\\s*:\\s*"(.+?)"', html)
    if r:
        time.sleep(10)
        return r.group(1) + '|User-Agent=%s' % USER_AGENT
    raise Exception('could not find video')


def resolve_vidto(url):
    html = net.http_GET(url).content
    print html
    import time
    time.sleep(6)
    data = {}
    r = re.findall('type="(?:hidden|submit)?" name="(.+?)"\\s* value="?(.+?)">', html)
    for name, value in r:
        data[name] = value

    html = net.http_POST(url, data).content
    r = re.search('<a id="lnk_download" href="(.+?)"', html)
    if r:
        r = re.sub(' ', '%20', r.group(1))
        return r
    else:
        return 'unresolvable'
    raise Exception('could not find video')


def resolve_nosvideo(web_url):
    html = net.http_GET(web_url).content
    if 'File Not Found' in html:
        code = 1
        raise Exception('File Not Found')
    headers = {'Referer': web_url}
    data = {}
    r = re.findall('type="hidden" name="(.+?)"\\s* value="(.+?)"', html)
    for name, value in r:
        data[name] = value

    data.update({'method_free': 'Free Download'})
    html = net.http_POST(web_url, data, headers=headers).content
    r = re.search('(eval\\(function\\(p,a,c,k,e,[dr].*)', html)
    if not r:
        return 'unresolvable'
    if r:
        js = jsunpack.unpack(r.group(1))
        r = re.search('playlist=(.*)&config=', js)
        if r:
            html = net.http_GET(r.group(1)).content
            r = re.search('<file>\\s*(.*)\\s*</file>', html)
            if r:
                return r.group(1)
            raise Exception('Unable to locate video file')
        else:
            raise Exception('Unable to locate playlist')
    else:
        raise Exception('Unable to locate packed data')


def resolve_videoweed(web_url):
    media_id = web_url.split('=')[1]
    html = net.http_GET(web_url).content
    html = unwise.unwise_process(html)
    filekey = unwise.resolve_var(html, 'flashvars.filekey')
    api_call = ('http://www.videoweed.es/api/player.api.php?user=undefined&codes=1&file=%s' + '&pass=undefined&key=%s') % (media_id, filekey)
    api_html = net.http_GET(api_call).content
    rapi = re.search('url=(.+?)&title=', api_html)
    if rapi:
        stream_url = rapi.group(1)
    else:
        return 'unresolvable'
        raise Exception('File Not Found or removed')
    return stream_url


def resolve_vk(url):
    web_url = url
    print '45m', web_url
    debug = True
    from addon.common.net import Net
    import json
    net = Net()
    try:
        soup = net.http_GET(web_url).content
        html = soup.decode('cp1251')
        print 'html', html
        vars_s = re.findall('var vars = (.+)', html)
        if vars_s:
            jsonvars = json.loads(vars_s[0])
            purged_jsonvars = {}
            for item in jsonvars:
                if re.search('url[0-9]+', str(item)):
                    purged_jsonvars[item] = jsonvars[item]

            lines = []
            ls_url = []
            for item in purged_jsonvars:
                ls_url.append(item)
                quality = item.lstrip('url')
                lines.append(str(quality))

            if len(ls_url) == 1:
                return purged_jsonvars[ls_url[0]].encode('utf-8')
            else:
                result = 1
                if result != -1:
                    return purged_jsonvars[ls_url[result]].encode('utf-8')
                return self.unresolvable(0, 'No link selected')
        else:
            return self.unresolvable(0, 'No var_s found')
    except:
        return 'unresolvable'
# okay decompyling I:\TSmediaTools\Kodi\scripts\script.module.urlresolver\lib\urlresolver\hostresolver.pyo 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2015.02.20 15:35:02 Arabian Standard Time
