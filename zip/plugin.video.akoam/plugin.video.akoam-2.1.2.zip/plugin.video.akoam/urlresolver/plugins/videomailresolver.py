# -*- coding: UTF-8 -*-
#/*
# *      Copyright (C) 2013 mx3L
# *
# *
# *  This Program is free software; you can redistribute it and/or modify
# *  it under the terms of the GNU General Public License as published by
# *  the Free Software Foundation; either version 2, or (at your option)
# *  any later version.
# *
# *  This Program is distributed in the hope that it will be useful,
# *  but WITHOUT ANY WARRANTY; without even the implied warranty of
# *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# *  GNU General Public License for more details.
# *
# *  You should have received a copy of the GNU General Public License
# *  along with this program; see the file COPYING.  If not, write to
# *  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# *  http://www.gnu.org/copyleft/gpl.html
# *
# */
import re, json,urllib2
__name__ = 'videomail'
def supports(url):
    return not _regex(url) == None

# returns the steam url
def read_url(url):
        try:
            req = urllib2.Request(url)
            response = urllib2.urlopen(req)
            data = response.read()
            response.close()
            return data
        except urllib2.URLError, e:
            print 'URL: '+url
            if hasattr(e, 'code'):
                print 'We failed with error code - %s.' % e.code
                #xbmc.executebuiltin("XBMC.Notification(musichcannels,We failed with error code - "+str(e.code)+",10000,"+icon+")")
            elif hasattr(e, 'reason'):
                print 'We failed to reach a server.'
                print 'Reason: %s' %e.reason
                #xbmc.executebuiltin("XBMC.Notification(LiveStreams,We failed to reach a server. - "+str(e.reason)+",10000,"+icon+")")

def resolve(url):
    #m = _regex(url)
    
    #sys.exit(0)
    #js='http://videoapi.my.mail.ru/videos/mail/euploader/_myvideo/1027.json'
        
        req = urllib2.Request(url)
        resp = urllib2.urlopen(req)
        data = resp.read()
        vkey = []
        print data
      
        match = re.search('"metadataUrl"\s*:\s*"([^"]+)', data)
        if match:
            json_url = match.group(1)
            response = read_url(json_url)
            html = response.content
            if html:
                js_data = json.loads(html)
                headers = dict(response._response.info().items())
                stream_url = ''
                best_quality = 0
                for video in js_data['videos']:
                    if int(video['key'][:-1]) > best_quality:
                        stream_url = video['url']
                        best_quality = int(video['key'][:-1])
                    
                    if 'set-cookie' in headers:
                        stream_url += '|Cookie=%s' % (headers['set-cookie'])
                    
                if stream_url:
                    return stream_url
def _regex(url):
    m1 = re.search('metadataUrl":"(.+?)json"', url, re.IGNORECASE | re.DOTALL)
    
    #m2 = re.search('http://video\.mail\.ru\/(?P<url>.+?)\.html', url, re.IGNORECASE | re.DOTALL)
    return m1 
