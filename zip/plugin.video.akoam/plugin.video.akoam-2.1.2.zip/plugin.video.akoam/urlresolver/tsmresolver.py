# 2014.11.21 08:42:23 Arabian Standard Time
#Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/TSmedia/scripts/script.module.urlresolver/lib/urlresolver/tsmresolver.py
import os, sys, urllib

def gethostname(url):
    try:
        return url.split('/')[2].replace('www.', '').replace('embed.', '').split('.')[0]
    except:
        return url


def get_linkid(web_url):
    parts = web_url.split('/')
    if parts:
        web_url = web_url.split('/')[len(parts) - 1]
    return web_url


def resolve(web_url = None,host=None,media_id=None,urllist=False ):
    if host is None and web_url is not None:
        host = gethostname(web_url)
    stream_url = None
    done = True
    try:
        host = host.lower()
    except:
        pass

    print '16host,web_url', host, web_url
    #sys.exit(0)
    debug = True

    if debug:
        print 'web_url', web_url
  
        if web_url is not None and media_id is None:
            media_id = get_linkid(web_url)
            if '.' in media_id:
                media_id = media_id.split('.')[0]
            print 'extracted_media_id', media_id
        if ('dailymotion' in host or 'dailymotion' in web_url) and urllist==True:
                from urlresolver.plugins.dailymotion2 import DailymotionResolver2  as Resolver
                sys.argv.append(web_url)
                host='dailymotion'
               
                rs=Resolver()
               
                stream_urls = rs.get_media_url(host, media_id)
                print 'stream_urls',stream_urls
                return stream_urls  
            
        if 'dailymotion' in host or 'dailymotion' in web_url:
                from urlresolver.plugins.dailymotion import DailymotionResolver  as Resolver
                sys.argv.append(web_url)
                host='dailymotion'
            
        elif host == 'hqq' or 'hqq' in web_url:
            from urlresolver.plugins.hqqresolver import resolve
           
            #sys.argv.append(web_url)
            host = 'hqq'
            stream_url=resolve(web_url)
            if stream_url is None:
                stream_url='unresolvable'
            return stream_url            
            
        elif host == 'vidhos' or 'vidhos' in web_url:
            from urlresolver.plugins.vidhosresolver import resolve
           
            #sys.argv.append(web_url)
            host = 'vidhos'
            stream_url=resolve(web_url)
            if stream_url is None:
                stream_url='unresolvable'
            return stream_url        
        elif host == 'movpod' or 'movpod' in web_url:
            from urlresolver.plugins.movpod import MovpodResolver  as Resolver
            sys.argv.append(web_url)
            
            host = 'movpod'
        elif host == 'daclips' or 'daclips' in web_url:
            from urlresolver.plugins.daclips import DaclipsResolver  as Resolver
            sys.argv.append(web_url)
            
            host = 'movpod'            
        elif host == 'videoapi' or 'videoapi' in web_url:
            from urlresolver.plugins.videomailresolver import resolve
           
            #sys.argv.append(web_url)
            host = 'videoapi'
            stream_url=resolve(web_url)
            if stream_url is None:
                stream_url='unresolvable'
            return stream_url
        
        elif host == 'hqq' or 'hqq' in web_url:
            from urlresolver.plugins.hqqresolver import resolve
           
            #sys.argv.append(web_url)
            host = 'shared'
            stream_url=resolve(web_url)
            if stream_url is None:
                stream_url='unresolvable'
            return stream_url
        elif host == 'shared' or 'shared.sx' in web_url:
            from urlresolver.plugins.sharedsx import SharedsxResolver as Resolver
           
            sys.argv.append(web_url)
            host = 'shared'       
        elif host == 'vidspot' or 'vidspot' in web_url:
            from urlresolver.plugins.vidspot import VidSpotResolver as Resolver
           
            sys.argv.append(web_url)
            host = 'vidspot'       
        elif host == 'mrfile' or 'mrfile' in web_url:
            from urlresolver.plugins.mrfile import mrfileResolver as Resolver
           
            sys.argv.append(web_url)
            host = 'mrfile'   
        elif host == 'letwatch' or 'letwatch' in web_url:
            from urlresolver.plugins.letwatch import LetwatchResolver as Resolver
           
            sys.argv.append(web_url)
            host = 'letwatch'    
        elif host == 'primeshare' or 'primeshare' in web_url:
            from urlresolver.plugins.primeshare import PrimeshareResolver as Resolver
           
            sys.argv.append(web_url)
            host = 'primeshare' 
            
        elif host == 'video.tt' or 'video.tt' in web_url:
            from urlresolver.plugins.videott import VideoTTResolver as Resolver
           
            sys.argv.append(web_url)
            host = 'video.tt'             
             
        elif host == 'vshare' or 'vshare' in web_url:
            from urlresolver.plugins.vshare import VshareResolver as Resolver
           
            sys.argv.append(web_url)
            host = 'vshare'  
    
        elif host == 'realvid' or 'realvid' in web_url:
            from urlresolver.plugins.realvid import RealvidResolver as Resolver
           
            sys.argv.append(web_url)
            host = 'realvid'  
    
        elif host == 'cloudyvideos' or 'cloudyvideos' in web_url:
            from urlresolver.plugins.cloudyvideos import CloudyvideosResolver as Resolver
           
            sys.argv.append(web_url)
            host = 'cloudyvideos'  
            
        elif host == 'streamin' or 'streamin' in web_url:
            from urlresolver.plugins.streaminto import streamintoResolver as Resolver
           
            sys.argv.append(web_url)
            host = 'streamin'  
        elif host == 'videomega' or 'videomega' in web_url:
            from urlresolver.plugins.videomega import VideomegaResolver as Resolver
           
            sys.argv.append(web_url)
            host = 'videomega'            
        elif host == 'exashare' or 'exashare' in web_url:
            from urlresolver.plugins.exashare import ExashareResolver as Resolver
           
            sys.argv.append(web_url)
            host = 'exashare'
            
        elif host == 'vidxden' or 'vidxden' in web_url:
            from urlresolver.plugins.vidxden import VidxdenResolver as Resolver
           
            sys.argv.append(web_url)
            host = 'vidxden'
            
        elif host == 'vidzi' or 'vidzi' in web_url:
            from urlresolver.plugins.vidzi import vidziResolver as Resolver
            if '-' in web_url:
                media_id = web_url.split('-')[1]
            sys.argv.append(web_url)
            host = 'vidzi'
            
        elif host == 'srvid' or 'shrvid' in web_url:
            from urlresolver.plugins.shrvid import AllmyvideosResolver as Resolver
            
            sys.argv.append(web_url)
            host = 'shrvid'
        elif host == 'vimeo' or 'vimeo' in web_url:
            from urlresolver.plugins.vimeo import VimeoPlayer as Resolver
            rs=Resolver()
            stream_url=rs.playVideo(videoid=media_id,urllist=urllist)
            return stream_url        
            
            
        elif host == 'vidbull' or 'vidbull' in web_url:
            from urlresolver.plugins.vidbull import VidbullResolver as Resolver
                    
            sys.argv.append(web_url)
            host = 'vidbull'
        elif host == 'bestreams' or 'bestreams' in web_url:
            from urlresolver.plugins.bestreams import BestreamsResolver as Resolver
            host = 'bestreams'
        elif host == 'vodlocker' or 'vodlocker' in web_url:
            from urlresolver.plugins.vodlocker import VodlockerResolver as Resolver
            host = 'vodlocker'
            sys.argv.append(web_url)
        elif host == 'thevideo' or 'thevideo' in web_url:
            from urlresolver.plugins.thevideo import TheVideoResolver as Resolver
            sys.argv.append(web_url)
            host = 'thevideo'
        elif host == 'gorillavid' or 'gorillavid' in web_url:
            if web_url.endswith('.flv'):
                return web_url
            from urlresolver.plugins.gorillavid import GorillavidResolver as Resolver
            host = 'gorillavid'
        elif 'firedrive' in host or 'putlocker' in host or 'sockshare' in host or 'putlocker' in web_url or 'sockshare' in web_url or 'firedrive' in host:
            if 'sockshare' in host or 'sockshare' in web_url:
                from urlresolver.plugins.sockshare import sockshareResolver as Resolver
                host = 'sockshare'
            else:
                from urlresolver.plugins.putlocker import PutlockerResolver as Resolver
                host = 'putlocker'
            print 'myresolver33putlocker', web_url
        elif 'facebook' in host.lower() or 'facebook' in web_url:
            from urlresolver.plugins.facebook import FacebookResolver as Resolver
            host = 'facebook'
        elif 'stagevu' in host.lower() or 'stagevu' in web_url:
            from urlresolver.plugins.stagevu import StagevuResolver as Resolver
            host = 'stagevu'
        elif 'mightyupload' in host.lower() or 'mightyupload' in web_url:
            from urlresolver.plugins.mightyupload import MightyuploadResolver as Resolver
            sys.argv.append(web_url)
            host = 'mightyload'
        elif 'sharerepo' in host.lower() or 'sharerepo' in web_url:
            from urlresolver.plugins.sharerepo import SharerepoResolver as Resolver
            sys.argv.append(web_url)
            host = 'sharerepo'
        elif 'thefile' in host.lower() or 'thefile' in web_url:
            from urlresolver.plugins.thefile import TheFileResolver as Resolver
            host = 'thefile'
        elif host.lower() == 'vidto' or 'vidto' in web_url:
            from urlresolver.plugins.vidto import vidto as Resolver
            sys.argv.append(web_url)
            host = 'vidto'
        elif host == 'clicktoview' or 'clicktoview' in web_url:
            from urlresolver.plugins.clicktoview import ClicktoviewResolver as Resolver
            host = 'clicktoview'
        elif host == 'xvidstage' or 'xvidstage' in web_url:
            from urlresolver.plugins.xvidstage import XvidstageResolver as Resolver
            sys.argv.append(web_url)
            host = 'xvidstage'
        elif host == 'nowvideo' or 'nowvideo' in web_url:
            from urlresolver.plugins.nowvideo import NowvideoResolver as Resolver
            host = 'nowvideo'
            if '=' in web_url:
                media_id = web_url.split('=')[1]
        elif 'divxstage' in host or 'divxstage' in web_url or 'cloudtime' in host or 'cloudtime' in web_url:
            from urlresolver.plugins.divxstage import DivxstageResolver as Resolver
            web_url=web_url.replace("divxstage","cloudtime")

            sys.argv.append(web_url)
            host = 'divxstage'
        elif host == 'ok' or 'ok.ru' in web_url:
            from urlresolver.plugins.okruresolver import resolve
           
            #sys.argv.append(web_url)
            host = 'ok'
            stream_url=resolve(web_url,urllist=urllist)
            
            if stream_url is None:
                stream_url='unresolvable'
            return stream_url      
            
        
            
        elif 'vk' in host.lower() or '.vk' in web_url or 'video_ext.php' in web_url:
            from urlresolver.plugins.vk import VKResolver as Resolver
            
            sys.argv.append(web_url)
            host = 'vk'
        elif 'vidspot' in host or 'allmyvideos' in host or 'allmyvideos' in web_url:
            from urlresolver.plugins.allmyvideos import AllmyvideosResolver as Resolver
            if 'vidspot' in host:
                host = 'vidspot'
            else:
                host = 'allmyvideos'
            sys.argv.append(web_url)    
        elif 'bayfiles' in host or 'bayfiles' in web_url:
            from urlresolver.plugins.bayfiles import bayfilesResolver as Resolver
            try:
                web_url = os.path.basename(web_url)
            except:
                pass

            host = 'bayfiles'
        else:

            if 'nosvideo' in host or 'nosvideo' in web_url:
                from urlresolver.plugins.nosvideo import NosvideoResolver as Resolver
                media_id = web_url.split('=')[1]
                host = 'nosvideo'
            elif 'filenuke' in host or 'filenuke' in web_url:
                from urlresolver.plugins.filenuke import FilenukeResolver as Resolver
                media_id="f/"+media_id
                host = 'filenuke'
            elif 'flashx' in host or 'flashx' in web_url:
                from urlresolver.plugins.flashx import FlashxResolver as Resolver
                try:
                    sys.argv.append(web_url)
                except:
                    pass

                host = 'flashx'
            elif 'hugefiles' in web_url or 'hugefiles' in web_url:
                from urlresolver.plugins.hugefiles import HugefilesResolver as Resolver
                host = 'hugefiles'
            elif 'movshare' in host.lower() or 'movshare' in web_url:
                from urlresolver.plugins.movshare import MovshareResolver as Resolver
                try:
                    id = web_url.split('=')[1]
                    print id
                    if '&' in id:
                        media_id = id.split('&')[0]
                        print media_id

                    
                except:
                    pass

                host = 'movshare'

            elif 'neodrive' in host.lower() or 'neodrive' in web_url:
                from urlresolver.plugins.neodrive import neodriveResolver as Resolver
                sys.argv.append(web_url)
               
                host = 'newdrive'

                
            elif 'zalaa' in host.lower() or 'zalaa' in web_url:
                from urlresolver.plugins.zalaa import ZalaaResolver as Resolver
                sys.argv.append(web_url)
                try:
                    media_id = web_url.split('/')[3] + '/' + web_url.split('/')[4]
                except:
                    pass

                host = 'zalaa'
            else:
                if 'youtube' in host or 'youtube' in web_url:
                    print 'myresolver84', web_url
                    from tube_resolver.plugin import resolve
                    host = 'youtube'
                    print 'myresolver85', host
                    stream_url, error = resolve(web_url)
                    print 'myresolver86', stream_url, error
                    return (stream_url, error)
                if 'vidhog' in host or 'vidhog' in web_url:
                    from urlresolver.plugins.vidhog import VidhogResolver as Resolver
                    host = 'vidhog'
                elif 'videoweed' in host or 'videoweed' in web_url :
                    from urlresolver.plugins.videoweed import VideoweedResolver as Resolver
                    sys.argv.append(web_url)
                    host = 'videoweed'
                elif 'openload' in host or 'openload' in web_url :
                    from urlresolver.plugins.openload import OpenLoadResolver as Resolver
                    sys.argv.append(web_url)
                    host = 'openload'
                    
                elif 'videowood' in host or 'videowood' in web_url :
                    from urlresolver.plugins.videowood import VideowoodResolver as Resolver
                    sys.argv.append(web_url)
                    host = 'videowood'
                   
                elif 'novamov' in host or 'novamov' in web_url:
                    
                    from urlresolver.plugins.novamov import NovamovResolver as Resolver
                    media_id = get_linkid(web_url)
                    host = 'novamov'
                elif 'veeHD' in host or 'veeHD' in web_url:
                    from urlresolver.plugins.veeHD import veeHDResolver as Resolver
                    host = 'veeHD'
                elif 'uploadc' in host or 'uploadc' in web_url:
                    from urlresolver.plugins.uploadc import UploadcResolver as Resolver
                    sys.argv.append(web_url) 
                    host = 'uploadc'
                elif 'streamcloud' in host or 'streamcloud' in web_url:
                    from urlresolver.plugins.streamcloud import StreamcloudResolver as Resolver
                    host = 'streamcloud'
                elif 'sharesix' in host or 'sharesix' in web_url:
                    from urlresolver.plugins.sharesix import SharesixResolver as Resolver
                    sys.argv.append(web_url)
                    host = 'sharesix'
                elif 'purevid' in host or 'purevid' in web_url:
                    from urlresolver.plugins.purevid import purevidResolver as Resolver
                    host = 'purevid'
                elif 'promptfile' in host or 'promptfile' in web_url:
                    from urlresolver.plugins.promptfile import PromptfileResolver as Resolver
                    sys.argv.append(web_url)
                    host = 'promptfile'
                elif 'movreel' in host or 'movreel' in web_url:
                   
                    from urlresolver.plugins.movreel import movreelResolver as Resolver
                    sys.argv.append(web_url)
                    web_url = web_url.replace('http://', '')
                    parts = web_url.split('/')
                    if parts:
                        media_id = web_url.split('/')[len(parts) - 1]
                    host = 'movreel'
                    print 'host',host,media_id
                    
                elif 'youwatch' in host or 'youwatch' in web_url:
                    from urlresolver.plugins.youwatch import YouwatchResolver as Resolver
                    sys.argv.append(web_url)

                    host = 'youwatch'
                elif 'played' in host or 'played' in web_url:
                    from urlresolver.plugins.played import playedResolver as Resolver
                    host = 'played'
                elif '180upload' in host or '180upload' in web_url:
                    from urlresolver.plugins.one80upload import OneeightyuploadResolver as Resolver
                    web_url = web_url.replace('http://', '')
                    parts = web_url.split('/')
                    if parts:
                        media_id = web_url.split('/')[len(parts) - 1]
                    host = '180upload'
                elif 'billionuploads' in host or 'billionuploads' in web_url:
                    from urlresolver.plugins.billionuploads import billionuploads as Resolver
                    sys.argv.append(web_url)
                else:
                    print 'No supported host'
                    return 'unresolvable link,No supported host'
        resolver = Resolver()
        stream_url = resolver.get_media_url(host, media_id)
        print "stream_url",stream_url
       
        try:
            if '"' in stream_url:
                stream_url = stream_url.split('"')[0]
        except:
            pass

        print 'stream_url-176', stream_url
    else:
        print 'error in resolving url'
        return 'unresolvable link,Error in resolving url'
    
    
    
    
    if stream_url is not None:
        try:
            if '|' in stream_url:
                try:
                    stream_url = stream_url.split('|')[0]
                except:
                    pass

        except:
            pass

    print 'Stream_url/myresolver/176', str(stream_url) + ':' + host
    print '186', str(stream_url)
    stream_url = str(stream_url)
    if 'unresolvable' in stream_url or 'None' in stream_url:
        stream_url = 'unresolvable:unable to resolve link'
    return stream_url
# okay decompyling I:\TSmediaTools\Kodi\scripts\script.module.urlresolver\lib\urlresolver\tsmresolver.pyo 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2014.11.21 08:42:25 Arabian Standard Time
