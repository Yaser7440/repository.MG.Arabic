# -*- coding: utf-8 -*-
# Embedded file name: /media/hdd/Extensions/TSmedia/addons/arabic/plugin.video.aflamhd/default.py
try:import sys,syspath
except:pass
import os, sys, platform
import httplib
import time
from urllib import urlencode
import urllib, urllib2, re, sys
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse
from addon.common.net import Net
net=Net()
import StringIO
platform = platform.system().lower()
__settings__ = xbmcaddon.Addon(id='plugin.video.akoam')
__icon__ = __settings__.getAddonInfo('icon')
__fanart__ = __settings__.getAddonInfo('fanart')
__language__ = __settings__.getLocalizedString
_thisPlugin = int(sys.argv[1])
_pluginName = sys.argv[0]
baseurl = 'http://akoam.com'
host='www.akoam.com'
def read_url6(url):
      req = urllib2.Request(url, headers={'User-Agent' : "Magic Browser"}) 
      con = urllib2.urlopen( req )
      return con.read()      
def read_url5(url):
        
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', 'www.akoam.com')
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
	return link
def read_url4(url):
               #pass#print "Here in getUrl url =", url
               
               url=url.replace("?url=","")
               print "mfarajx",url
               req = urllib2.Request(url)
               req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
               response = urllib2.urlopen(req)
               data=response.read()
               response.close()
               return data
def read_url2(url):
        try:
            req = urllib2.Request(url)
            response = urllib2.urlopen(req)
            data = response.read()
            response.close()
            return data
        except urllib2.URLError, e:
            print 'URL: '+url
            if hasattr(e, 'code'):
                print 'We failed with error code - %s.' % e.code
                #xbmc.executebuiltin("XBMC.Notification(musichcannels,We failed with error code - "+str(e.code)+",10000,"+icon+")")
                addDir("Download failed:"+str(e.code),"","",'')
            elif hasattr(e, 'reason'):
                print 'We failed to reach a server.'
                print 'Reason: %s' %e.reason
                addDir("Download failed:"+str(e.reason),"","",'')
                #xbmc.executebuiltin("XBMC.Notification(LiveStreams,We failed to reach a server. - "+str(e.reason)+",10000,"+icon+")")

def read_url3(url):#filmon
              data=None
              m=True
              try:
                        req = urllib2.Request(url)
                        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                        response = urllib2.urlopen(req)
                        
                        data=response.read()
                        
                         
              except:
                        addDir("Download error,try again","","",'')
                        return

              return data
def read_url(url):
      if True:  
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', host)
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
        return link
      else:
            addDir("Download failed:"+url,"","",'')
            return None
def decodeHtml(text):
    text = text.replace('&auml;', 'ae').replace('&Auml;', 'Ae').replace('&ouml;', 'oe').replace('&ouml;', 'Oe').replace('&uuml;', 'ue')
    text = text.replace('&Uuml;', 'Ue').replace('&szlig;', 'ss').replace('&amp;', '&').replace('&quot;', '"').replace('&gt;', "'")
    text = text.replace('&#228;', 'ae').replace('&#246;', 'oe').replace('&#252;', 'ue').replace('&#223;', 'ss').replace('&#8230;', '...')
    text = text.replace('&#8222;', ',').replace('&#8220;', "'").replace('&#8216;', "'").replace('&#8217;', "'").replace('&#8211;', '-')
    text = text.replace('&#8230;', '...').replace('&#8217;', "'").replace('&#128513;', ':-)').replace('&#8221;', '"')
    text = text.replace('&#038;', '&').replace('&#039;', "'")
    text = text.replace('\\u00c4', 'Ae').replace('\\u00e4;', 'ae').replace('\\u00d6', 'Oe').replace('\\u00f6', 'oe')
    text = text.replace('\\u00dc', 'Ue').replace('\\u00fc', 'ue').replace('\\u00df', 'ss')
    text = text.replace('&#196;', 'Ae').replace('&#228;', 'ae').replace('&#214;', 'Oe').replace('&#246;', 'oe').replace('&#220;', 'Ue').replace('&#252;', 'ue')
    text = text.replace('<br />\n', '')
    return text 



def showmenu():
                list=[]

                #list.append(('Search', 'http://akoam.com/search/'))    
                addDir('SEARCH','http://akoam.com/search/',10,'special://home/addons/plugin.video.akoam/img/SEARCH.png',1)
               	addDir('أفـــلام اجنبية','http://akoam.com/cat/156/%D8%A7%D9%84%D8%A3%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D9%84%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9',11,'special://home/addons/plugin.video.akoam/img/mov.png',1)
               	addDir('سلسلة أفــلام أجنبية','http://akoam.com/cat/164/%D8%A7%D8%B1%D8%B4%D9%8A%D9%81-%D9%88-%D8%B3%D9%84%D8%A7%D8%B3%D9%84-%D8%A7%D9%84%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D9%84%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9',205,'special://home/addons/plugin.video.akoam/img/MSE.png',1)
               	addDir('مسلسلات أجنبية','http://akoam.com/cat/166/%D8%A7%D9%84%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%A7%D9%84%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9',205,'special://home/addons/plugin.video.akoam/img/E.png',1) 
                  
                addDir('أفــلام عربية','http://akoam.com/cat/155/الأفلام_العربية',11,'special://home/addons/plugin.video.akoam/img/AR.png',1)              

                addDir('مسلسلات عربية','http://akoam.com/cat/80/',204,'special://home/addons/plugin.video.akoam/img/SER.png',1) 
                addDir('مسرحيــات','http://akoam.com/cat/149/%D9%85%D8%B3%D8%B1%D8%AD%D9%8A%D8%A7%D8%AA',11,'special://home/addons/plugin.video.akoam/img/THEATER.png',1) 
                addDir('أعلانات وحفلات','http://akoam.com/cat/98/%D8%A7%D8%AE%D8%B1%D9%89',11,'special://home/addons/plugin.video.akoam/img/BROMO.png',1) 
                addDir('أفــلام هندية','http://akoam.com/cat/168/%D8%A7%D9%84%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D9%84%D9%87%D9%86%D8%AF%D9%8A%D8%A9',11,'special://home/addons/plugin.video.akoam/img/IN.png',1)  
                                 
                addDir('أفــلام الانيمي','http://akoam.com/cat/83/%D8%A7%D9%84%D8%A7%D9%86%D9%85%D9%8A',11,'special://home/addons/plugin.video.akoam/img/ANIM.png',1)
                addDir('أهــداف كرة قدم','http://akoam.com/cat/87/%D8%B1%D9%8A%D8%A7%D8%B6%D8%A9',11,'special://home/addons/plugin.video.akoam/img/f.png',1) 
                             
                addDir('المصــارعه','http://akoam.com/cat/88/%D8%A7%D9%84%D9%85%D8%B5%D8%A7%D8%B1%D8%B9%D8%A9-%D8%A7%D9%84%D8%AD%D8%B1%D8%A9',205,'special://home/addons/plugin.video.akoam/img/WWE.png',1)              
                addDir('أفــلام ثقافية','http://akoam.com/cat/94/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D9%88%D8%AB%D8%A7%D8%A6%D9%82%D9%8A%D8%A9',11,'special://home/addons/plugin.video.akoam/img/DOC.png',1) 
                addDir('اسلاميات','http://akoam.com/cat/84/%D8%A7%D8%B3%D9%84%D8%A7%D9%85%D9%8A%D8%A7%D8%AA',205,'special://home/addons/plugin.video.akoam/img/islam.png',1) 
                addDir('برامج تلفزيونية','http://akoam.com/cat/81/%D8%A7%D9%84%D8%A8%D8%B1%D8%A7%D9%85%D8%AC-%D8%A7%D9%84%D8%AA%D9%84%D9%81%D8%B2%D9%8A%D9%88%D9%86%D9%8A%D8%A9',205,'special://home/addons/plugin.video.akoam/img/pro.png',1) 
                addDir('فيديو كليب','http://akoam.com/cat/89/%D9%81%D9%8A%D8%AF%D9%8A%D9%88-%D9%83%D9%84%D9%8A%D8%A8',11,'special://home/addons/plugin.video.akoam/img/clib.png',1) 
                
                
		#genreliste.insert(0, ("--- Search ---", "search",103))
                for title, url in list:
                    if "Search" in title:
                          mode=103
                    elif 'Arabic series' in title:
                          mode=200
                    else:
                          mode=100
                    addDir(title, url, mode, '', 1)
                    
def getgenre(name='movies'):##cinema and tv featured

                data=read_url(baseurl)
                if data is None:
                    return
		match = re.findall('menu_genre">(.*?)</ul>', data, re.S|re.I)
		if match:
			Cats = re.findall('href=".*?">(.*?)<',match[0], re.S)
			if Cats:
				for Cat in Cats:
					#self.genreliste.append((Cat, True))
                                        if name=='movies':
                                           addDir(Cat,baseurl+"/category/genre="+Cat,100,'')
                                           addDir(Cat,baseurl+"/category/genre="+Cat,25501,'')
                                        else:
                                           url=baseurl+"/tv-shows/genre=%s" % Cat   
                                           addDir(Cat,url,200,'')
                                           

def getA_Z(name='movies'):
		abc = ["0-9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        if name=='movies':
			  addDir(letter,baseurl+"/category/letter="+letter.lower(),100,'',1)
			  
			else:
                          url = baseurl+"/tv-shows/letter=%s" % letter.lower()    
                          addDir(letter,url,200,'',1)    
###################################movies		 
def search():
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   print "mfarajx3",search_entered
                   
        else:
             print "search error"
            
        
        
         
        url= 'http://akoam.com/search/%s' % (search_entered)
        
          
        getvideos_search("Search",url,1,search_entered)
def getvideos_search(name,urlmain,page,searchterm):##cinema and tv featured
                if page>1:
                  #page-2
                  url_page=urlmain+'/page/'+str(page)+"/"
                  
                else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
                
                data=read_url3(url_page)
                
                if data is None:
                    return

                regx='''<li\sid="entry_.*?<a href="(.*?)" title="(.*?)"\s.*?<img src="(.*?)" alt=.*?/>'''
		regx='''<a class="border-sizing" href="(.*?)</a>'''
		regx='''<div class="tags_box">\s.*?<a href="(.*?)">'''
                
                 
		#http://akoam.com/c/17010/%D9%81%D9%8A%D9%84%D9%85-%D8%A7%D9%84%D8%A3%D9%83%D8%B4%D9%86-%D9%88%D8%A7%D9%84%D8%AE%D9%8A%D8%A7%D9%84-%D9%88%D8%A7%D9%84%D9%85%D8%BA%D8%A7%D9%85%D8%B1%D8%A9-%D8%A7%D9%84%D8%B1%D8%A7%D8%A6%D8%B9-Divergent-2014-%D9%85%D8%AA%D8%B1%D8%AC%D9%85
		match = re.findall(regx, data, re.M | re.I)
                print "match",match
                
                
		if len(match)>0:
			for (href) in match:
                           
				#image=''
				
				title="divergent"
				#title=decodeHtml(title.strip())
				#href=href.split("&#")[0]
				#title=href.split("&#")[1]
				title=os.path.split(href)[1]
				
                                addDir(title,href,1,'')
                        addDir("next page",urlmain,100,'img/NEXT.png',str(page+1))
                else:
                      
                        addDir("Error:script error",urlmain,1,'',1)

                return                                        
def getvideos_cinema(name,urlmain,page):##cinema and tv featured
                if page>1:
                  #page-2
                 #http://akoam.com/cat/80/%D8%A7%D9%84%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%A7%D9%84%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9/page/3     
                  #url_page="http://akoam.com/cat/80/%D8%A7%D9%84%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%A7%D9%84%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9/page/"+str(page)+"/"
                  url_page=urlmain+'/page/'+str(page)+"/"
                else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
                #url_page='http://akoam.com/cat/80/%D8%A7%D9%84%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA_%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9'      
                print "url_page",url_page
                data=read_url3(url_page)
               
                if data is None:
                    return
                regxname='''<h2 class="sub_epsiode_title">(.*?)</h2>'''  
		regxlink='''<div class='inner_link inner_link_youtube inner_link_small' style='background-image: url((.*?));'><a target='_blank' class='sub_btn show' href='(.*?)'>'''
                regx='''<div class="subject_box shape">\s.*?<a href="(.*?)">\s.*?\s<img src="(.*?)" alt="اسم الموضوع">\s.*?<div class="subject_title ">\s.*?<h3>(.*?)</h3>\s.*?</div>'''
                
		links=re.findall(regx, data, re.S)
		
                print "links",len(links),links
                
                    
		
                for href,image,title in links:
                     
                          
                          
                          
                          addDir(title,href,1,image)
                addDir('next page',urlmain,100,'img/NEXT.png',page=page+1)
                
                
                
                
                
                
         
                
                          
###############################################tv shows
def getvideos_tvshows(name,urlmain,page):##series
                if page>1:
                  #page-2
                 #http://akoam.com/cat/80/%D8%A7%D9%84%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%A7%D9%84%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9/page/3     
                  url_page="http://akoam.com/cat/80/%D8%A7%D9%84%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%A7%D9%84%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9/page/"+str(page)+"/"
                  #url_page=urlmain+'/page/'+str(page)+"/"
                else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
                #url_page='http://akoam.com/cat/80/%D8%A7%D9%84%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA_%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9'      
                print "url_page",url_page
                data=read_url3(url_page)
               
                if data is None:
                    return
                regxname='''<h2 class="sub_epsiode_title">(.*?)</h2>'''  
		regxlink='''<div class='inner_link inner_link_youtube inner_link_small' style='background-image: url((.*?));'><a target='_blank' class='sub_btn show' href='(.*?)'>'''
                regx='''<div class="subject_box shape">\s.*?<a href="(.*?)">\s.*?\s<img src="(.*?)" alt="اسم الموضوع">\s.*?<div class="subject_title ">\s.*?<h3>(.*?)</h3>\s.*?</div>'''
                
		links=re.findall(regx, data, re.S)
		
                print "links",len(links),links
                
                    
		
                for href,image,title in links:
                     
                          
                          
                          
                          addDir(title,href,203,image)
                addDir('next page',urlmain,200,'img/NEXT.png',page=page+1)
                          
def getvideos_episodes(name,urlmain,page):##series
                if page>1:
                  #page-2
                  url_page=urlmain+'/page-'+str(page)+"/"
                  
                else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
                #url_page='http://akoam.com/cat/80/%D8%A7%D9%84%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA_%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9'      
                print "url_page",url_page
                data=read_url3(url_page)
                print "data",data
                if data is None:
                    return
                regxname='''<h2 class="sub_epsiode_title">(.*?)</h2>'''  
		regxlink='''<div class='inner_link inner_link_youtube inner_link_small' style='background-image: url((.*?));'><a target='_blank' class='sub_btn show' href='(.*?)'>'''
                
                
		
		
                
                
                
                links=re.findall(regxlink, data, re.S)
               
		
                for image,image2,href in links:
                     
                          
                          
                          title=os.path.split(href)[1]
                          addDir(title,href,303,image)
                          
                          
def getvideos_shows(name,urlmain,page):##series
                if page>1:
                  #page-2
                 #http://akoam.com/cat/80/%D8%A7%D9%84%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%A7%D9%84%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9/page/3     
                  #url_page="http://akoam.com/cat/80/%D8%A7%D9%84%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%A7%D9%84%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9/page/"+str(page)+"/"
                  url_page=urlmain+'/page/'+str(page)+"/"
                else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
                #url_page='http://akoam.com/cat/80/%D8%A7%D9%84%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA_%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9'      
                print "url_page",url_page
                data=read_url3(url_page)
               
                if data is None:
                    return
                regxname='''<h2 class="sub_epsiode_title">(.*?)</h2>'''  
		regxlink='''<div class='inner_link inner_link_youtube inner_link_small' style='background-image: url((.*?));'><a target='_blank' class='sub_btn show' href='(.*?)'>'''
                regx='''<div class="subject_box shape">\s.*?<a href="(.*?)">\s.*?\s<img src="(.*?)" alt="اسم الموضوع">\s.*?<div class="subject_title ">\s.*?<h3>(.*?)</h3>\s.*?</div>'''
                
		links=re.findall(regx, data, re.S)
		
                print "links",len(links),links
                
                    
		
                for href,image,title in links:
                     
                          
                          
                          
                          addDir(title,href,203,image)
                addDir('next page',urlmain,202,'img/NEXT.png',page=page+1)                          
                          
                          
                          
                      
                                         
               
def getvideos_seasons(name,urlmain,page):##series
                if page>1:
                  #page-2
                  url_page=urlmain+'/page-'+str(page)+"/"
                  
                else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
                
                data=read_url(url_page)
                if data is None:
                    return
		
		series_f= re.findall('seasonoverviewlist.*?option>(.*?)</select>', data, re.S|re.I)
		if series_f:
			series = re.findall('value="(.*?)"\s>(.*?)<', series_f[0], re.S)
			if series:
				for (Url, Title) in series:
					
						
						addDir(decodeHtml(Title),Url,1,'',1)

                        else:
                              addDir("Error:script error",urlmain,1,'',1)
						
		else:				
                        addDir("Error:script error",urlmain,1,'',1)

def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        
        return query.hostname.replace("www.","") 

def gethosts_episodes(urlmain):##cinema and tv featured

                #urlmain='http://akoam.com/c/27304/%D8%A7%D9%84%D9%86%D8%B3%D8%AE%D8%A9-%D8%A7%D9%84%D8%A8%D9%84%D9%88%D8%B1%D8%A7%D9%8A-%D9%84%D9%81%D9%8A%D9%84%D9%85-%D8%A7%D9%84%D8%A3%D9%83%D8%B4%D9%86-%D9%88%D8%A7%D9%84%D8%AC%D8%B1%D9%8A%D9%85%D8%A9-%D9%88%D8%A7%D9%84%D8%A5%D8%AB%D8%A7%D8%B1%D8%A9-The-November-Man-2014-%D9%85%D8%AA%D8%B1%D8%AC%D9%85'
                print "urlmain",urlmain
                
                
                
               
                #urlmain=urlmain.replace(" ","%20")
                #urlmain='http://akoam.com/c/27431/????-???????-??????-Imagine-I-m-Beautiful-?????'
                data=read_url3(urlmain)
                if data is None:
                    return
                regx='''<IFRAME SRC="(.*?)" .*? ></IFRAME>'''
                regx='''<a target='.*?' class='.*?' href='(.*?)'>'''
                regx='''<IFRAME SRC="(.*?)" FRAMEBORDER=0'''
                regx2='''<iframe.*?src="(.*?)".*?></iframe>'''
                #regx3='''<iframe.*?src="(.*?)".*?></iframe>'''
                match1 = re.findall(regx, data, re.M | re.I)
                match2 = re.findall(regx2, data, re.M | re.I)
                i=0
               
               
                
                if len(match1)>0:
                   for href in match1:
                      
                       if 'arabytracking' in href:
                             continue
                       host=gethostname(href)
                       addDir(host,href,403,'')
                if len(match2)>0:
                   for href in match2:
                       if 'arabytracking' in href:
                             continue
                         
                       if not href.startswith("http"):
                          href="http:"+href
                          print "href",href
                       host=gethostname(href)
                       addDir(host,href,403,'')
                       
################################################common
def gethosts(urlmain):##cinema and tv featured

                #urlmain='http://akoam.com/c/27304/%D8%A7%D9%84%D9%86%D8%B3%D8%AE%D8%A9-%D8%A7%D9%84%D8%A8%D9%84%D9%88%D8%B1%D8%A7%D9%8A-%D9%84%D9%81%D9%8A%D9%84%D9%85-%D8%A7%D9%84%D8%A3%D9%83%D8%B4%D9%86-%D9%88%D8%A7%D9%84%D8%AC%D8%B1%D9%8A%D9%85%D8%A9-%D9%88%D8%A7%D9%84%D8%A5%D8%AB%D8%A7%D8%B1%D8%A9-The-November-Man-2014-%D9%85%D8%AA%D8%B1%D8%AC%D9%85'
                print "urlmain",urlmain
                
                urlmain=fixurl(urlmain)
                
               
                #urlmain=urlmain.replace(" ","%20")
                #urlmain='http://akoam.com/c/27431/فيلم-الدراما-الرائع-Imagine-I-m-Beautiful-مترجم'
                data=read_url6(urlmain)
                if data is None:
                    return
                #regx=regx='''</a><a target='_blank' class='ako-buttons-bg ako-watch-link border-sizing' href='(.*?)'>'''
                regx='''<a target='.*?' class='.*?' href='(.*?)'>'''
                regx='''style='(.*?)'>\s\.*?<a class='sub_btn show' target='_blank' href='(.*?)'>'''
                match1 = re.findall(regx, data, re.M | re.I)
                i=0
                print match1,match1[0]
               
                
                if len(match1)>0:
                   for image,href in match1:
                       i = i + 1
                       host = 'host' + str(i)
                       image=image.replace("background-image: url(","").replace(");","").strip()
                       print 'image',image
                       
                       
                       addDir(host,href,2,image)


                else:
                       

                        addDir("Error:script error or no hosts found",'Error:script error or no hosts found',1,'')
                        return

                                                        
import urlparse, urllib

def fixurl(url):
    # turn string into unicode
    if not isinstance(url,unicode):
        url = url.decode('utf8')

    # parse it
    parsed = urlparse.urlsplit(url)

    # divide the netloc further
    userpass,at,hostport = parsed.netloc.rpartition('@')
    user,colon1,pass_ = userpass.partition(':')
    host,colon2,port = hostport.partition(':')

    # encode each component
    scheme = parsed.scheme.encode('utf8')
    user = urllib.quote(user.encode('utf8'))
    colon1 = colon1.encode('utf8')
    pass_ = urllib.quote(pass_.encode('utf8'))
    at = at.encode('utf8')
    host = host.encode('idna')
    colon2 = colon2.encode('utf8')
    port = port.encode('utf8')
    path = '/'.join(  # could be encoded slashes!
        urllib.quote(urllib.unquote(pce).encode('utf8'),'')
        for pce in parsed.path.split('/')
    )
    query = urllib.quote(urllib.unquote(parsed.query).encode('utf8'),'=&?/')
    fragment = urllib.quote(urllib.unquote(parsed.fragment).encode('utf8'))

    # put it back together
    netloc = ''.join((user,colon1,pass_,at,host,colon2,port))
    return urlparse.urlunsplit((scheme,netloc,path,query,fragment))

def getmatch(match):
                if len(match)<1:
                        return None
                for href in match:
                    
                    
                    
                    
                     
                    server=href.split("/")[2].replace('www.',"").replace("embed.","").split(".")[0]
                    #if 'hqq' in server or "myvi" in server or 'videomeh' in server:
                            #return
                    return href               
def gethosts2(urlmain):##cinema and tv featured
               
                urlmain=fixurl(urlmain)
                print urlmain
               #sys.exit(0)
                data=read_url6(urlmain)
                
                
                if data is None:
                    return
                regx1='''<IFRAME.*?SRC="(.*?)".*?></IFRAME>'''  
                
                regx2='''<iframe width=".*?" height=".*?" frameborder=".*?" src="(.*?)".*?></iframe>'''
                
                #regx3='''<param name="movie" value="(.*?)"/>"'''
                regx3='''<param name="movie" value="(.*?)"/>'''
                regx4='''src="http://videomega.tv/(.*?)>'''
                regx5='''<iframe frameborder="0" width="0" height="0" src="(.*?)" allowfullscreen'''
                #regx='''<iframe width="600" height="480" frameborder="0" src="(.*?)" scrolling="no"></iframe>'''
		regx6='''<iframe src="(.*?)" scrolling="no" frameborder="0" width="700" height="430" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'''

                match1 = re.findall(regx1, data, re.S)
		
		
		url=getmatch(match1) 
                if url is None:
                      match2 = re.findall(regx2, data, re.S)
                      url=getmatch(match2)
                if url is None:
                      match3 = re.findall(regx3, data, re.S)
                      url=getmatch(match3)
                if url is None:
                      match4 = re.findall(regx4, data,re.M | re.I)
                      print 'match4',match4
                      if len(match4)>0:
                         url="http://videomega.tv/"+match4[0].replace('"','')
                      else:
                         url=None  
                         
                if url is None:
                      match5 = re.findall(regx5, data, re.S)
                      url=getmatch(match5)                         
                          
                if url is None:
                      match6= re.findall(regx6, data, re.M | re.I)
                      url=getmatch(match6)
                      print "url",url
                      #sys.exit(0)
                         
		if url is not None:
                       #match1 = re.findall(regx3, data, re.S)
                          if not url.startswith("http"):
                             url="http:"+url                                           
			  resolve_host2(url)
		else:
                      addDir("Error:no found host","",1,"")

                      
def resolve_host1(url):#last good-used with local resolver

        from urlresolver import resolve
        print 'url',url
        playlink(url)
        return
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            xbmc.Player().play(stream_link)
            sys.exit(0)   
	    listItem = xbmcgui.ListItem(path=str(stream_link))
	    xbmcplugin.setResolvedUrl(sys.argv[0], True, listItem)   
        else:
            addDir("Error,"+str(stream_link),"",9,"") 	    
def resolve_host2(url):#last good
       
        playlink(url)
        return
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            xbmc.Player().play(stream_link)
            sys.exit(0)
            
        else:
            addDir("Error,"+stream_link,"",9,"")                        
                      
                             
#######################################end common                                                        
                          
###############################local resolver
def resolve_thevideo(web_url):
            from t0mm0.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            import jsunpack


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': web_url
            }

            html = net.http_GET(web_url).content

            js = ''
            tries=1
            while not js and tries<=MAX_TRIES:
                r = re.findall(r'type="hidden"\s*name="(.+?)"\s*value="(.*?)"', html)
                data={}
                for name, value in r:
                    data[name] = value
                data[u"imhuman"] = "Proceed to video"; 
                r = re.findall(r"type:\s*'hidden',\s*id:\s*'([^']+).*?value:\s*'([^']+)", html)
                for name, value in r:
                    data[name] = value
                                                                                  
                cookies={}
                for match in re.finditer("\$\.cookie\('([^']+)',\s*'([^']+)",html):
                    key,value = match.groups()
                    cookies[key]=value
                cookies['ref_url']=web_url
                headers['Cookie']=urllib.urlencode(cookies)
    
                html = net.http_POST(web_url, data, headers=headers).content
                #print 'Try: %s/%s' % (tries, MAX_TRIES)
                r = re.search("<script type='text/javascript'>(eval\(function\(p,a,c,k,e,d\).*?)</script>",html,re.DOTALL)
                if r:
                    js = jsunpack.unpack(r.group(1))
                    break
                tries += 1
            else:
                raise Exception ('Unable to resolve TheVideo link. Player config not found.')
                
            r = re.findall(r"label:\\'([^']+)p\\',file:\\'([^\\']+)", js)
            if not r:
                raise Exception('Unable to locate link')
            else:
                max_quality=0
                for quality, stream_url in r:
                    if int(quality)>=max_quality:
                        best_stream_url = stream_url
                        max_quality = int(quality)
                return best_stream_url








			
def resolve_nowvideo(web_url):

        debug=True
        from t0mm0.common.net import Net
        net=Net()
        if debug:
            html = net.http_GET(web_url).content
            
            key = re.compile('flashvars.filekey=(.+?);').findall(html)
            ip_key = key[0]
            pattern = 'var %s="(.+?)".+?flashvars.file="(.+?)"'% str(ip_key)
            r = re.search(pattern,html, re.DOTALL)
            #print 'find key: '+str(r)
            if r:
                filekey, filename= r.groups()
                #print "FILEBLOBS=%s  %s"%(filename,filekey)
            else:
                r = re.search('file no longer exists',html)
                if r:
                    raise Exception ('File Not Found or removed')
            
            #get stream url from api
                
            api = 'http://www.nowvideo.sx/api/player.api.php?key=%s&file=%s' % (filekey, filename)
            print "api",api
            html = net.http_GET(api).content
            r = re.search('url=(.+?)&title', html)
            if r:
                stream_url = urllib.unquote(r.group(1))
            else:
                r = re.search('no longer exists',html)
                print html
                if r:
                    raise Exception ('File Not Found or removed')
                raise Exception ('Failed to parse url')
                
            return stream_url
def resolve_dailymotion(id):
    import json
    from t0mm0.common.net import Net
    net=Net()
    content =net.http_GET("http://www.dailymotion.com/embed/video/"+id).content
    if content.find('"statusCode":410') > 0 or content.find('"statusCode":403') > 0:
        xbmc.executebuiltin('XBMC.Notification(Info:,'+translation(30022)+' (DailyMotion)!,5000)')
        return ""
    
    else:
        get_json_code = re.compile(r'dmp\.create\(document\.getElementById\(\'player\'\),\s*([^);]+)').findall(content)[0]
        #print len(get_json_code)
        cc= json.loads(get_json_code)['metadata']['qualities']  #['380'][0]['url']
        #print cc
        if '1080' in cc.keys():
            #print 'found hd'
            return cc['1080'][0]['url']
        elif '720' in cc.keys():
            return cc['720'][0]['url']
        elif '480' in cc.keys():
            return cc['480'][0]['url']
        elif '380' in cc.keys():
            return cc['380'][0]['url']
        elif '240' in cc.keys():
            return cc['240'][0]['url']
        elif 'auto' in cc.keys():
            return cc['auto'][0]['url']
        else:
            xbmc.executebuiltin('XBMC.Notification(Info:, No playable Link found (DailyMotion)!,5000)')
        
def resolve_vodlocker(web_url):
        from t0mm0.common.net import Net
        net=Net()
        resp=net.http_GET(web_url)
        html=resp.content
        debug=True
        if debug:
                data={}; r=re.findall(r'type="hidden" name="(.+?)"\s* value="?(.+?)">',html); data['usr_login']=''
        	for name,value in r: data[name]=value
        	data['imhuman']='Proceed to video'; data['btn_download']='Proceed to video'
        	xbmc.sleep(2000)
        	html=net.http_POST(web_url,data).content
        	print html
        else :
                  
            return "unresolvable"
        r=re.search('file\s*:\s*"(http://.+?)"',html)
        if r:
            #stream_url=urllib.unquote_plus(r.group(1))
            stream_url=str(r.group(1))
            #print stream_url
        else:
            
            return "unresolvable"
        return stream_url
      
########################################################33			
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param



def addLink(name,url,mode,iconimage):
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	


def addDir(name,url,mode,iconimage,page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
def playlink(url):
          sources = []
          import urlresolver
          hosted_media = urlresolver.HostedMediaFile(url=url)
          sources.append(hosted_media)
          source = urlresolver.choose_source(sources)
          
          if source:
                  vidlink = source.resolve()

                  print "vidlink",vidlink
                  try:
                        xbmc.Player().play(vidlink)
                  except:
                        playlink2(url)
                        return
                  sys.exit(0)
	   
          else:
                 
                  playlink2(url)                
                
def playlink2(url):
                  import urlresolver2
                  vidlink = urlresolver2.resolve(url)

      
                  xbmc.Player().play(str(vidlink))
                  sys.exit(0)  
      
params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
elif mode==1:
        print ""+url
        gethosts(url)
elif mode==2:
        print ""+url
        gethosts2(url)                                     
elif mode==100:
        print ""+url
        getvideos_cinema(name,url,page)
        
elif mode==11:
        print ""+url
        getvideos_cinema(name,url,page)        
        
        
        
elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
	print ""+url
	
	search()
elif mode==200:
	print "mfaraj"+url
	getvideos_tvshows(name,url,page)
	
elif mode==202:
	print "mfaraj"+url
	getvideos_shows(name,url,page)	
	
	                                 
elif mode==204:
	print "mfaraj"+url
	getvideos_tvshows(name,url,page)	
	
elif mode==205:
	print "mfaraj"+url
	getvideos_shows(name,url,page)	

	
elif mode==201:
	getgenre('shows')
elif mode==202:
	print ""+url
	getA_Z('shows')
	
elif mode==203:
	getvideos_episodes(name,url,page)
elif mode==303:
      gethosts_episodes(url)
      
elif mode==300:
      gethosts_episodes(url)      

elif mode==10:
        print ""+url
        search()		
      
      
      
elif mode==403 :     
      resolve_host2(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
      
