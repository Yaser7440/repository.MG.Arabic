

#iStream Extension
#StreamingTime
#Copyright (C) 2017 mucky duck




from entertainment.plugnplay.interfaces import MovieSource
from entertainment.plugnplay import Plugin
from entertainment import common
import xbmc    
        
class streamingtime(MovieSource):
    implements = [MovieSource]
    
    name = 'StreamingTime'
    display_name = 'StreamingTime'
    base_url = 'http://www.streamingtime.net'
    User_Agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36'
    
    source_enabled_by_default = 'true'
    
    def GetFileHosts(self, url, list, lock, message_queue):
        
        from entertainment import requests
        import re
        
        headers = {'User-Agent':self.User_Agent}
        link = requests.get(url, headers=headers).content

        try:

            final_url = re.compile('<source src="(.+?)"').findall(link)[0]

        except:pass

        try:
            Q = re.compile('Resolution:</b>  (.+?)x').findall(link)[0]
        except:
            Q = '900'

        if int(Q) > 1281:
            res='1080P'

        elif int(Q) > 1000 and int(Q) < 1281:
            res='720P'

        elif int(Q) > 800 and int(Q) < 1000:
            res='HD'

        else:
            res='DVD'

        self.AddFileHost(list, res, final_url)
                



    def GetFileHostsForContent(self, title, name, year, season, episode, type, list, lock, message_queue):
        
        from entertainment import requests
        import re
        
        name = self.CleanTextForSearch(name.lower())

        headers = {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                   'Accept-Encoding':'gzip, deflate', 'Accept-Language':'en-US,en;q=0.8',
                   'Content-Type':'application/x-www-form-urlencoded',
                   'User-Agent':self.User_Agent, 'Origin':self.base_url, 'referer':'%s/' %self.base_url}

        post_url = '%s/search.php' %self.base_url
        search = {'searchterm':name}
        link = requests.post(post_url, data=search, headers=headers).content
        links = link.split('frontpage center">')

        for p in links:
            try:
                media_url = '%s/%s' %(self.base_url,re.compile('href="(.+?)"').findall(p)[0])
                media_title = re.compile('class="center movietitle">(.+?)</').findall(p)[0]
                if name in self.CleanTextForSearch(media_title.lower()):
                    if year in media_title:

                        self.GetFileHosts(media_url, list, lock, message_queue)
            except:pass
 
