

#iStream Extension
#HeyDL
#Copyright (C) 2017 mucky duck


from entertainment.plugnplay.interfaces import MovieSource
from entertainment.plugnplay import Plugin
from entertainment import common
import xbmc




class hevec(MovieSource):
    implements = [MovieSource]
    
    name = 'HeyDL'
    display_name = 'HeyDL'
    base_url ='https://heydl.com'
    User_Agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36'

    source_enabled_by_default = 'true'


    def GetFileHosts(self, url, list, lock, message_queue):

        from entertainment import requests
        import re

        headers = {'User-Agent':self.User_Agent}
        link = requests.get(url, headers=headers).content
        links = link.split('<hr/>')        
        
        for p in links:
           
            try:

                media_url = re.compile('href="([^"]+)"').findall(p)[0]
                check = re.compile('src="([^"]+)"').findall(p)[0]
                res = media_url.upper()

                if '/downloadicon' in check:

                    host = media_url.split('.')[1]
                    if 'DUBBED' in res:
                        host = host + ' Farsi Dubbed'
                        
                    if '4K' in res:
                        res='4K'
                    elif '3D' in res:
                        res='3D'
                    elif '1080' in res:
                        res='1080P'
                    elif '720' in res:
                        res='720P'
                    elif 'HD' in res:
                        res='HD'
                    elif 'DVD' in res:
                        res='DVD'
                    elif  '480' in res:
                        res='DVD'
                    elif '-TS-' in res:
                        res='CAM'
                    elif 'HDCAM' in res:
                        res='CAM'
                    elif 'HDTS' in res:
                        res='CAM'
                    elif 'CAM' in res:
                        res='CAM'
                    elif '360' in res:
                        res='SD'
                    else:
                        res='DVD'
                    
                    self.AddFileHost(list, res, media_url)

            except:pass




    def GetFileHostsForContent(self, title, name, year, season, episode, type, list, lock, message_queue):

        from entertainment import requests
        import re

        name = self.CleanTextForSearch(name.lower())
        headers = {'User-Agent':self.User_Agent}
        search = '%s/?s=%s' %(self.base_url,name.replace(' ','+'))
        link = requests.get(search,headers=headers).content
        links = link.split('post">')[1:]
   
        for p in links:
            try:

                media_url = re.compile('href="([^"]+)"').findall(p)[0]
                media_title = re.compile('</a>(.+?)</span><span').findall(p)[0]

                if name.lower() in self.CleanTextForSearch(media_title.lower()):
                    if year in media_title.lower():
                        self.GetFileHosts(media_url, list, lock, message_queue)

            except:pass

