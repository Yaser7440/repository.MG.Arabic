#!/usr/bin/python
# -*- coding: utf-8 -*-
try:import sys,syspath
except:pass
from yttools import *


def infolist():
  list1=[]
  
  list1.append(('FutureTV LaYoumal','UC22W9D8YHMYd8-Is7SoUFag'))
  list1.append((' LaYoumal II','UCQH0vhD4yny1ZE3eDzYVSXA'))
  
  
  return list1

################################################################333
list1=infolist()
process_mode(list1 )
xbmcplugin.endOfDirectory(int(sys.argv[1]))
