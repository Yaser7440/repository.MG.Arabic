# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys
import urllib,urllib2,re,os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse




addon_id='plugin.video.cimamix'
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/img/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, '/img/icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , '/img/fanart.jpg'))
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
baseurl='http://cimamix.net/'



def read_url(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', 'www.cimamix.net')
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
	return link

def patch_http_response_read(func):
    def inner(*args):
        try:
            return func(*args)
        except httplib.IncompleteRead, e:
            return e.partial

    return inner

def getCategories():
    addDir('[B][COLOR white]••جديد الأفلام••[/COLOR][/B]',baseurl,8,art +'/ADD.png',1)        
    addDir('[B][COLOR white]••افلام اجنبية••[/COLOR][/B]',baseurl+'/c/10/افلام_اجنبية/1.html',11,art+'/Other.png',1)
    addDir('[B][COLOR white]••افلام عربية••[/COLOR][/B]',baseurl+'/c/8/افلام_عربية/1.html',11,art+'/AR.png',1)
    addDir('[B][COLOR white]••افلام هندية••[/COLOR][/B]',baseurl+'t/c/11/افلام_هندية/1.html',11,art+'/BLLYOOD.png',1)
    addDir('[B][COLOR white]••افلام كرتون••[/COLOR][/B]',baseurl+'/c/12/افلام_كرتون/1.html',11,art+'/AAAA.png',1)
    addDir('[B][COLOR white]••عـــام••[/COLOR][/B]','url',5,art+'GEN.png',1)
    addDir('[B][COLOR red]••MG.Arabic••http://mg.esy.es/Kodi/••[/COLOR][/B]','','',art +'/fanart.jpg',1)
        
       
        
        
        
def GENRES():
   menuitems=[]
   #menuitems.append(("[B][COLOR white]••البحث••[/COLOR][/B]",'url',4, art + '/search.png','',1))
   #menuitems.append(("[B][COLOR white]••تصنيفات الافلام بالسنه••[/COLOR][/B]", 'url',12, art + '/YEARS.png','',1))
   menuitems.append(("[B][COLOR white]••افلام رعـب••[/COLOR][/B]",baseurl+'/tag/رعـب',11, art + 'Horror.png','',1))
   menuitems.append(("[B][COLOR white]••افلام اكشن••[/COLOR][/B]",baseurl+'/tag/اكشن',11,art +'/Action.png','',1))
   menuitems.append(("[B][COLOR wwhite]••افلام خيال علمي••[/COLOR][/B]",baseurl+'/tag/خيال+علمي',11,art +'/SienceFiction.png','',1))
   menuitems.append(("[B][COLOR wwhite]••افلام رومانسية••[/COLOR][/B]",baseurl+'/tag/رومانسية',11,art +'/Romantic.png','',1))
   menuitems.append(("[B][COLOR red]••MG.Arabic••http://mg.esy.es/Kodi/••[/COLOR][/B]",'','',art +'/fanart.jpg','',1))
   #menuitems.append(("[B][COLOR white]••افلام اسيويه••[/COLOR][/B]",baseurl+'/portal/category/asian-movies/',11,art +'/pro.gif','',1))
   for title, url, mode,pic,desc,page in menuitems:
       addDir1(title, url, mode, pic,desc,1) 
        
	 

      
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search CimaMix')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered
        
          
        getVideos("Search",url,0)
          
        
        

        
def getVideos(name1, urlmain,page):
               print "mahmou1",urlmain
               print "page",page
               
               if page>1 :
                  #http://el7l.tv/online2/415/%D8%A7%D9%81%D9%84%D8%A7%D9%85_%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9/3.html
                  url_page=urlmain[:-5]+"/"+str(page)+".html"
                  url_page=urlmain+'"/"/page/'+str(page)+".html"
                  
               else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 
               
               print content
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
               #content=content.split('<div class="subcategory">')[1]
             
               regx='''<a href="(.*?)">\s*<img src="(.*?)" width="218" .*? alt="(.*?)".*?/>''' 
               
 
	     	
               
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,image,title in match:
                        pic = ''
 
                        url=href
                        url=url.replace('artid','topic')
                        try:name=title.encode("utf-8")
                        except:name=title
                        addDir(name,url,2,image,page)
						
              
               addDir('next page>>',urlmain, 11,'http://www.caribbeanelections.com/images/newicons/media.png',str(page+1))
                 
               
def getrecent(name1, urlmain,page):
               print "mahmou1",urlmain
               print "page",page
               
               if page>1 :
                  url_page=urlmain+"/"+'?page/'+str(page)+".html"
                  
                  url_page=urlmain+'?p='+str(page)
                  
               else:
                #http://www.dardarkom.com/filme-enline/filme-gharbi/page/2/
                      url_page=urlmain
               print "url_page",url_page
               
               content = read_url(url_page)                 
               
               print content
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
               regx='''<a href="(.*?)">\s*<img src="(.*?)" width="218" .*? alt="(.*?)".*?/>''' 
	     	
               
               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               
               
               if not match :
                       return
               
               for href,image,title in match:
                        pic = ''
 
                        url=href
                        url=url.replace('artid','topic')
                        try:name=title.encode("utf-8")
                        except:name=title
                        addDir(name,url,2,image,page)
                        
               
               addDir('next page>>',urlmain, 8,'http://www.caribbeanelections.com/images/newicons/media.png',str(page+1))
                              
               
               
def getmatch(match):
                if len(match)<1:
                        return
                for href in match:
                    
                    
                    
                    
                     
                    server=href.split("/")[2].replace('www.',"").replace("embed.","").split(".")[0]
                    #if 'hqq' in server or "myvi" in server or 'videomeh' in server:
                            #return
                    addDir(server,href,7,'')
               
                
def get_serversc(url):
                url=url.replace("/f/","/play/")
	        data=read_url(url)
	        print data
                	
                
                regx1='''<IFRAME SRC="(.+?)".*?></IFRAME>'''
                regx2='''<iframe.*?src="(.+?)".*?></iframe>'''
                #regx3='''<iframe.*?src="(.+?)".*?></iframe>'''
                #regx4='''<iframe src='(.+?)' width='''
                match1 = re.findall(regx1,data, re.M|re.I)
                match2 = re.findall(regx2,data, re.M|re.I)
                print "match2",match2
                #match3 = re.findall(regx3,data, re.M|re.I)
                #match4 = re.findall(regx4,data, re.M|re.I)
                getmatch(match1)
                getmatch(match2)
                #getmatch(match3)
                #getmatch(match4)
        
                return
                


def resolve_host(url):

      import urlresolver
    #hosted_media = urlresolver.HostedMediaFile(url=url, title="host")
      stream_link = urlresolver.resolve(url)
      print "stream_link",stream_link
      if stream_link is None or "unresolvable" in stream_link:
            addDir("Error:unresolvable link","",1,"",1)
            return
      playlink(stream_link) 



def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
	
def addDir(name,url,mode,iconimage,page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir1(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
def playlink(url):
            xbmc.Player().play(url)
            sys.exit(0)

              
params=get_params()
url=None
name=None
mode=None
initial=None
max=None
rating=None
cast=None
year=None
genre=None
duration=None
writer=None
director=None
page=1
	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
	
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        page=1


		


print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
if mode==None or url==None or len(url)<1:
        getCategories()
       

elif mode==11:
        print ""+url
        getVideos(name,url,page)
        
elif mode==8:
        print ""+url        
        getrecent(name,url,page)
        
elif mode==2:
        print ""+url        
        get_serversc(url) 
        
        
elif mode==5:
        GENRES()

elif mode==3:
        print ""+url
        search(url)		

elif mode==7:
        resolve_host(url)
        
elif mode==40:
        playlink(url)        
xbmcplugin.endOfDirectory(int(sys.argv[1]))