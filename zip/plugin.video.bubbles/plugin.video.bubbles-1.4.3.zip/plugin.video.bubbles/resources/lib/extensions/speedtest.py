# -*- coding: utf-8 -*-

'''
	Bubbles Add-on
	Copyright (C) 2016 Bubbles

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import time
from resources.lib.externals.speedtest import speedtest
from resources.lib.extensions import interface
from resources.lib.extensions import tools
from resources.lib.extensions import convert
from resources.lib.extensions import network
from resources.lib.extensions import debrid
from resources.lib.modules import workers

class SpeedTester(object):

	Unknown = 'unknown'

	UpdateAsk = 'ask'
	UpdateBoth = 'both'
	UpdateManual = 'manual'
	UpdateAutomatic = 'automatic'
	UpdateDefault = UpdateAsk

	PhaseLatency = 'latency'
	PhaseDownload = 'download'
	PhaseUpload = 'upload'

	def __init__(self, phases):
		self.mPhases = phases
		self.mPhase = None

		self.mLatency = None
		self.mDownload = None
		self.mUpload = None

		self.mCurrent = 0
		self.mError = False

	def _validate(self):
		return True

	def _formatLatency(self, latency):
		if latency == None:
			return self.Unknown.capitalize()
		else:
			return '%.0f ms' % latency

	def _formatSpeed(self, speed):
		if speed == None:
			return self.Unknown.capitalize()
		else:
			return convert.ConverterSpeed(value = speed, unit = convert.ConverterSpeed.Bit).stringOptimal(unit = convert.ConverterSpeed.Bit, notation = convert.ConverterSpeed.SpeedLetter)

	def _testSelection(self):
		return None

	def _testLatency(self):
		return None

	def _testDownload(self):
		return None

	def _testUpload(self):
		return None

	def testLatency(self, format = False):
		try:
			self.mPhase = self.PhaseLatency
			latency = self._testLatency()
			self.mLatency = latency
			if format: latency = self._formatLatency(latency)
			return latency
		except:
			tools.Logger.error()
			self.mError = True
		return None

	def testDownload(self, format = False):
		try:
			self.mPhase = self.PhaseDownload
			download = self._testDownload()
			self.mDownload = download
			if format: download = self._formatSpeed(download)
			return download
		except:
			tools.Logger.error()
			self.mError = True
		return None

	def testUpload(self, format = False):
		try:
			self.mPhase = self.PhaseUpload
			upload = self._testUpload()
			self.mUpload = upload
			if format: upload = self._formatSpeed(upload)
			return upload
		except:
			tools.Logger.error()
			self.mError = True
		return None

	def test(self, format = True):
		self.mPhase = None
		self.mError = False
		self.mCurrent = 0
		result = {}

		if self.PhaseLatency in self.mPhases:
			self.mCurrent += 1
			result[self.PhaseLatency] = self.testLatency(format)
		if self.PhaseDownload in self.mPhases:
			self.mCurrent += 1
			result[self.PhaseDownload] = self.testDownload(format)
		if self.PhaseUpload in self.mPhases:
			self.mCurrent += 1
			result[self.PhaseUpload] = self.testUpload(format)

		return result

	@classmethod
	def select(self, update = UpdateDefault):
		items = [
			interface.Format.bold(33509),
			interface.Format.bold('Premiumize'),
			interface.Format.bold('RealDebrid'),
		]
		choice = interface.Dialog.select(title = 33030, items = items)
		if choice == 0: tester = SpeedTesterGlobal()
		elif choice == 1: tester = SpeedTesterPremiumize()
		elif choice == 2: tester = SpeedTesterRealDebrid()
		tester.show(update = update)

	def show(self, update = UpdateDefault):
		if not self._validate():
			return

		self._testSelection()

		self.mPhase = None
		self.mError = False
		if update == None:
			update = self.UpdateDefault

		title = 'Speed Test'
		message = 'Testing the internet connection'
		progressDialog = interface.Dialog.progress(title = title, message = message)

		dots = ''
		stringLatency = interface.Format.fontNewline() + '     Latency: '
		stringSpeedDownload = interface.Format.fontNewline() + '     Download Speed: '
		stringSpeedUpload = interface.Format.fontNewline() + '     Upload Speed: '

		thread = workers.Thread(self.test)
		thread.start()

		while True:
			try:
				if self.mError: break
				try:
					if interface.Dialog.aborted() == True: return None
					if progressDialog.iscanceled(): return None
				except:
					pass

				info = message
				if self.mPhase == self.PhaseLatency:
					info += ' latency'
				elif self.mPhase == self.PhaseDownload:
					info += ' download speed'
				elif self.mPhase == self.PhaseUpload:
					info += ' upload speed'
				info += '.'

				dots += '.'
				if len(dots) > 3: dots = ''

				if self.mPhase == self.PhaseLatency:
					if self.PhaseLatency in self.mPhases:
						info += stringLatency + dots
				elif self.mPhase == self.PhaseDownload:
					if self.PhaseLatency in self.mPhases:
						info += stringLatency + self._formatLatency(self.mLatency)
					if self.PhaseDownload in self.mPhases:
						info += stringSpeedDownload + dots
				elif self.mPhase == self.PhaseUpload:
					if self.PhaseLatency in self.mPhases:
						info += stringLatency + self._formatLatency(self.mLatency)
					if self.PhaseDownload in self.mPhases:
						info += stringSpeedDownload + self._formatSpeed(self.mDownload)
					if self.PhaseUpload in self.mPhases:
						info += stringSpeedUpload + dots

				lines = 4 - info.count(interface.Format.fontNewline())
				for i in range(max(0, lines)):
					info += interface.Format.fontNewline()

				try: progressDialog.update(int((max(0, self.mCurrent - 1) / len(self.mPhases)) * 100), info)
				except: pass

				if not thread.is_alive(): break
				if self.mError: break
				time.sleep(0.5)
			except:
				tools.Logger.error()

		try: progressDialog.close()
		except: pass

		if self.mError:
			interface.Dialog.confirm(title = title, message = 'The internet connection could currently not be tested. Please try again later.')
		else:
			option = 0
			speedString = self._formatSpeed(self.mDownload).lower()
			try: speed = float(speedString.replace('kbps', '').replace('mbps', '').replace('gbps', '').replace('tbps', '').replace('bps', ''))
			except: speed = None # Unknown speed
			if 'kbps' in speedString:
				option = 1
			elif 'mbps' in speedString:
				if speed >= 900: option = 56
				elif speed >= 800: option = 55
				elif speed >= 700: option = 54
				elif speed >= 600: option = 53
				elif speed >= 500: option = 52
				elif speed >= 450: option = 51
				elif speed >= 400: option = 50
				elif speed >= 350: option = 49
				elif speed >= 300: option = 48
				elif speed >= 250: option = 47
				elif speed >= 200: option = 46
				elif speed >= 190: option = 45
				elif speed >= 180: option = 44
				elif speed >= 170: option = 43
				elif speed >= 160: option = 42
				elif speed >= 150: option = 41
				elif speed >= 140: option = 40
				elif speed >= 130: option = 39
				elif speed >= 120: option = 38
				elif speed >= 110: option = 37
				elif speed >= 100: option = 36
				elif speed >= 95: option = 35
				elif speed >= 90: option = 34
				elif speed >= 85: option = 33
				elif speed >= 80: option = 32
				elif speed >= 75: option = 31
				elif speed >= 70: option = 30
				elif speed >= 65: option = 29
				elif speed >= 60: option = 28
				elif speed >= 55: option = 27
				elif speed >= 50: option = 26
				elif speed >= 45: option = 25
				elif speed >= 40: option = 24
				elif speed >= 35: option = 23
				elif speed >= 30: option = 22
				elif speed >= 25: option = 21
				elif speed >= 20: option = 20
				elif speed >= 19: option = 19
				elif speed >= 18: option = 18
				elif speed >= 17: option = 17
				elif speed >= 16: option = 16
				elif speed >= 15: option = 15
				elif speed >= 14: option = 14
				elif speed >= 13: option = 13
				elif speed >= 12: option = 12
				elif speed >= 11: option = 11
				elif speed >= 10: option = 10
				elif speed >= 9: option = 9
				elif speed >= 8: option = 8
				elif speed >= 7: option = 7
				elif speed >= 6: option = 6
				elif speed >= 5: option = 5
				elif speed >= 4: option = 4
				elif speed >= 3: option = 3
				elif speed >= 2: option = 2
				elif speed >= 1: option = 1
			elif 'gbps' in speedString:
				if speed >= 15: option = 0
				elif speed >= 10: option = 66
				elif speed >= 9: option = 65
				elif speed >= 8: option = 64
				elif speed >= 7: option = 63
				elif speed >= 6: option = 62
				elif speed >= 5: option = 61
				elif speed >= 4: option = 60
				elif speed >= 3: option = 59
				elif speed >= 2: option = 58
				elif speed >= 1: option = 57
			elif 'tbps' in speedString:
				option = 0
			elif 'bps' in speedString:
				option = 1

			updateManual = False
			updateAutomatic = False

			if update == self.UpdateManual:
				updateManual = True
			elif update == self.UpdateAutomatic:
				updateAutomatic = True
			elif update == self.UpdateBoth:
				updateManual = True
				updateAutomatic = True
			else:
				info = 'The internet connection was successfully tested:'
				if self.PhaseLatency in self.mPhases:
					info += stringLatency + self._formatLatency(self.mLatency)
				if self.PhaseDownload in self.mPhases:
					info += stringSpeedDownload + self._formatSpeed(self.mDownload)
				if self.PhaseUpload in self.mPhases:
					info += stringSpeedUpload + self._formatSpeed(self.mUpload)
				info += interface.Format.fontNewline() + 'Do you want to automatically optimize your bandwidth restrictions and hide the streams that are too large to stream over your connection?'
				answer = interface.Dialog.option(title = title, message = info, labelConfirm = 'Optimize Settings', labelDeny = 'Keep Settings')
				if answer:
					items = [
						interface.Format.bold('Manual: ') + 'Optimize the manual playback restriction',
						interface.Format.bold('Automatic: ') + 'Optimize the automatic playback restriction',
						interface.Format.bold('Both: ') + 'Optimize the manual and automatic playback restrictions',
						interface.Format.bold('Cancel: ') + 'Do not optimize the playback restriction',
					]
					choice = interface.Dialog.options(title = title, items = items)
					updateManual = choice == 0 or choice == 2
					updateAutomatic = choice == 1 or choice == 2

			if updateManual:
				tools.Settings.set(id = 'playback.manual.data.bandwidth.maximum', value = option)
			if updateAutomatic:
				tools.Settings.set(id = 'playback.automatic.data.bandwidth.maximum', value = option)
			if updateManual or updateAutomatic:
				interface.Dialog.notification(title = 'Bandwidth Optimized', message = 'Bandwidth Restriction Settings Optimized', icon = interface.Dialog.IconSuccess)

class SpeedTesterGlobal(SpeedTester):

	def __init__(self):
		SpeedTester.__init__(self, phases = [self.PhaseLatency, self.PhaseDownload, self.PhaseUpload])
		self.mTester = None
		self.mServer = None

	def _filter(self, items):
		result = []
		if isinstance(items, list):
			for item in items:
				result.extend(self._filter(item))
		elif isinstance(items, dict):
			if 'url' in items and 'name' in items:
				result.append(items)
			else:
				for item in items.itervalues():
					result.extend(self._filter(item))
		return result

	def _server(self):
		try:
			if not self.mTester:
				for i in range(5):
					# Sometimes error 503 ias returned. Try a few times.
					try: self.mTester = speedtest.Speedtest()
					except: time.sleep(1)
				if not self.mTester:
					self.mError = True
					return None

			if self.mServer:
				return self.mServer
			else:
				result = []
				servers = self.mTester.get_servers()
				servers = self._filter(servers)
				for server in servers:
					if 'new york' in server['name'].lower():
						result.append(server)
						break
				for server in servers:
					if 'london' in server['name'].lower():
						result.append(server)
						break
				for server in servers:
					if 'berlin' in server['name'].lower():
						result.append(server)
						break
				for server in servers:
					if 'tokyo' in server['name'].lower():
						result.append(server)
						break
				for server in servers:
					if 'moscow' in server['name'].lower():
						result.append(server)
						break
				if len(result) == 0:
					result = self._filter(self.mTester.get_closest_servers())
				if len(result) > 0:
					try:
						self.mServer = self.mTester.get_best_server(result)
						return self.mServer
					except:
						pass
				return None
		except:
			self.mError = True

	def _testLatency(self):
		try:
			server = self._server()
			if server and 'latency' in server:
				return server['latency']
			else:
				self.mError = True
		except:
			tools.Logger.error()
			self.mError = True
		return None

	def _testDownload(self):
		try:
			server = self._server()
			if server:
				return self.mTester.download()
			else:
				self.mError = True
		except:
			tools.Logger.error()
			self.mError = True
		return None

	def _testUpload(self):
		try:
			server = self._server()
			if server:
				return self.mTester.upload()
			else:
				self.mError = True
		except:
			tools.Logger.error()
			self.mError = True
		return None

class SpeedTesterDebrid(SpeedTester):

	# Not all hosters have the same download speed on debrid services (or at least on Premiumize). Or maybe this is just random?
	# The links are sorted from fastest to slowest.
	Links = [
		'http://datei.to/?0uLJGjFaQm',
		'http://uptobox.com/3fepsazhg98p',
		'http://www.mediafire.com/file/fxrjw6acjbtgsqr/bubbles.dat',
		'https://1fichier.com/?m204dputbb',
		'https://openload.co/f/n5ui1nNbaIg/bubbles.dat',
		'http://www.unibytes.com/lUYVrJ-z2kQLqw-Us4P3UgBB',
		'http://uplea.com/dl/A1F7482229F27BA',
	]

	LatencyTotal = 20 # How many time to do the latency test. Must be a lot, otherwise the average is not good.
	LatencyCount = 5 # The number of last tests to calculate the mean latency from.

	def __init__(self, link):
		SpeedTester.__init__(self, phases = [self.PhaseLatency, self.PhaseDownload])
		self.mLink = link
		self.mLinks = None

	def _testLatency(self):
		try:
			timer = tools.Time()
			latencies = []

			for i in range(self.LatencyTotal):
				networker = network.Networker(self.mLink)
				timer.restart()
				networker.headers()
				latencies.append(timer.elapsed(milliseconds = True))

				last = latencies[max(0, len(latencies) - self.LatencyCount):]
				self.mLatency = int(sum(last) / float(len(last)))

			return self.mLatency
		except:
			tools.Logger.error()

	def _testLink(self, link):
		return None

	def _testDownload(self):
		links = self.Links if self.mLinks == None else self.mLinks
		link = None
		for i in links:
			link = self._testLink(i)
			if not link == None:
				break
		if link == None:
			return None

		size = 0
		networker = network.Networker(link)
		timer = tools.Time()
		response = networker.request()
		timer.start()
		if response == None:
			return None
		while True:
			chunk = response.read()
			if chunk:
				size += len(chunk)
			else:
				break
		return int((size * 8) / float(timer.elapsed()))

class SpeedTesterPremiumize(SpeedTesterDebrid):

	Link = 'http://energycdn.com'

	LinkFile = 'http://mirror.nforce.com/pub/speedtests/10mb.bin'

	def __init__(self):
		SpeedTesterDebrid.__init__(self, self.Link)

	def _testSelection(self):
		if interface.Dialog.option(title = 33566, message = 33666, labelConfirm = 33668, labelDeny = 33667):
			self.mLinks = [self.LinkFile]

	def _testLink(self, link):
		if link == self.LinkFile:
			return link
		else:
			return debrid.Premiumize().add(link)

	def _validate(self):
		if debrid.Premiumize().accountValid():
			return True
		else:
			name = interface.Translation.string(33566)
			message = interface.Translation.string(33640) % name
			interface.Dialog.confirm(title = name, message = message)
			return False

class SpeedTesterRealDebrid(SpeedTesterDebrid):

	Link = 'http://real-debrid.com'

	def __init__(self):
		SpeedTesterDebrid.__init__(self, self.Link)

	def _testLink(self, link):
		return debrid.RealDebrid().add(link)

	def _validate(self):
		if debrid.RealDebrid().accountValid():
			return True
		else:
			name = interface.Translation.string(33567)
			message = interface.Translation.string(33640) % name
			interface.Dialog.confirm(title = name, message = message)
			return False
