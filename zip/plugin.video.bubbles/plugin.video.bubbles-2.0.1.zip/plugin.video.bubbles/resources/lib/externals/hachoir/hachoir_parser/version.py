__version__ = "1.3.4"
PACKAGE = "hachoir-parser"
WEBSITE = "http://bitbucket.org/haypo/hachoir/wiki/hachoir-parser"
LICENSE = 'GNU GPL v2'

