# -*- coding: utf-8 -*-
# Embedded file name: /media/hdd/Extensions/TSmedia/addons/arabic/plugin.video.aflamhd/default.py

try:import sys, syspath
except:pass
import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,xbmc,xbmcaddon,os
from addon.common.addon import Addon

addon_id = 'plugin.video.alshahed.tv'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
ADDON2=xbmcaddon.Addon(id='plugin.video.alshahed.tv')
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
base = 'http://alshahed.tv/'

def CATEGORIES():
        addDir('ديوان','http://alshahed.tv/category/diwan',1,icon,fanart)
        addDir('تقارير','http://alshahed.tv/category/reports',1,icon,fanart)
        addDir('لي متى','http://alshahed.tv/category/li-meta',1,icon,fanart)
        addDir('شباب اليوم','http://alshahed.tv/category/shabab',1,icon,fanart)
        addDir('gathering','http://alshahed.tv/category/gathering',1,icon,fanart)
        addDir('وسع صدرك','http://alshahed.tv/category/wase3',1,icon,fanart)
        addDir('برامج رمضان','http://alshahed.tv/category/%D8%B1%D9%85%D8%B6%D8%A7%D9%86-2015',1,icon,fanart)
        addDir('برامج اسبوعية','http://alshahed.tv/category/%D8%A8%D8%B1%D8%A7%D9%85%D8%AC-%D8%A3%D8%B3%D8%A8%D9%88%D8%B9%D9%8A%D9%87',1,icon,fanart)
        addDir('سفرتنا','http://alshahed.tv/category/%D8%A8%D8%B1%D8%A7%D9%85%D8%AC-%D8%A3%D8%B3%D8%A8%D9%88%D8%B9%D9%8A%D9%87/sofrtna',1,icon,fanart)
        addDir('المباركية','http://alshahed.tv/category/%D8%A8%D8%B1%D8%A7%D9%85%D8%AC-%D8%A3%D8%B3%D8%A8%D9%88%D8%B9%D9%8A%D9%87/almobarkiya',1,icon,fanart)     
        addDir('وجوه','http://alshahed.tv/category/%D8%A8%D8%B1%D8%A7%D9%85%D8%AC-%D8%A3%D8%B3%D8%A8%D9%88%D8%B9%D9%8A%D9%87/wogooh',1,icon,fanart)
       
        addLink('','url','mode',icon,fanart)
        return
        link = open_url(base)
        #match=re.compile('<a href="(.+?)" >(.+?)</a></li><li>').findall(link)
        #match=re.compile('<a href="(.+?)" title="(.+?)"> <img src="(.+?)" alt="(.+?)" class="img-responsive"/> </a>').findall(link)
        #match=re.compile('''id='.+?' class='.+?' >\s*<option value='.+?'>(.+?)</option>''').findall(link)
        for url,name in match:
                if 'category' in url:
                        addDir(name,url,1,icon,fanart)
               
def CATDOCS(url):

        link = open_url(url)
        #match=re.compile('<h2><a href="(.+?)" title="(.+?)">.+?</a></h2>.+?src="(.+?)"',re.DOTALL).findall(link)
        #match=re.compile('<img .+? src="(.+?)" class=".+?" alt="(.+?)" title="(.+?)" /><a href="(.+?)" title="(.+?)"><span>(.+?)</span></a>',re.DOTALL).findall(link)
        match=re.compile('<h3><a href="(.+?)">(.+?)</a></h3>.+?src="(.+?)"',re.DOTALL).findall(link)
        
        for url,name,thumb in match:
                name=name.replace('&#8211;','')
                #name=name.replace('(.+?)','')
                #name=name.replace('(.+?)','')
                
                addLink(name,url,2,thumb,fanart)
        try:
                #match=re.compile('<a href="(.+?)">Next</a></div>').findall(link)
                match=re.compile('class="next page-numbers" href="(.+?)"').findall(link)
                for url in match:
                        
                        addDir('Next Page >>>',url,1,icon,fanart)
                        #addDir('Next Page>>',nextpageurl,1,icon,fanart)
                        #match=re.compile('class="next page-numbers" href="(.+?)"').findall(link)
                        #url= match[0]
                        #addDir2('Next Page>>',url,1,icon,'',fanart)
        except: pass

def PLAYDOCS(url,name):
    try:
        link = open_url(url)
        #regx='''<iframe class='youtube-player'.+?src='http://www.youtube.com/embed/(.+?)?version=3.+?' frameborder='0' allowfullscreen='true'></iframe>'''
        #regx='''<iframe class='youtube-player'.+?src='http://www.youtube.com/embed/(.+?)?version=3.+?' frameborder='0' allowfullscreen='true'></iframe>'''
        #regx='''<iframe class='youtube-player' type='text/html' width='620' height='379' src='http://www.youtube.com/embed/qfLr9vveji4?version=3&#038;rel=1&#038;fs=1&#038;showsearch=0&#038;showinfo=1&#038;iv_load_policy=1&#038;wmode=transparent' frameborder='0' allowfullscreen='true'></iframe></span>'''
        regx='''<iframe id='1' .+?src='//www.youtube.com/embed/(.+?)?&rel=0' frameborder='0' allowfullscreen="true"></iframe>'''

        #regx='''<iframe title="2DPlayer" class="youtube-player".+?src="http://www.youtube.com/embed/(.+?)" frameborder="0" allowFullScreen></iframe>'''
        #regx='''"src="http://www.youtube.com/embed/(.+?)"'''
        match=re.compile(regx).findall(link)
        #match=re.compile('src="(.+?)"').findall(link)
        print "match",match
        #sys.exit(0)   

        playback_url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % match[0].replace("?","")    
        #playback_url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id
        #uurl = 'plugin://plugin.video.youtube/play/?video_id=%s' % youtubecode
        playlist = xbmc.PlayList(1)
        playlist.clear()
        listitem = xbmcgui.ListItem(name, iconImage=icon, thumbnailImage=icon)
        listitem.setInfo("Video", {"Title":name})
        listitem.setProperty('mimetype', 'video/x-msvideo')
        playlist.add(playback_url,listitem)
        xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
        xbmcPlayer.play(playlist)
        sys.exit(0)
    except:
        dialog = xbmcgui.Dialog()
        dialog.ok('alshahed.tv Documentaries','','alshahed.tv has been removed','')



    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

def notification(title, message, ms, nart):
    xbmc.executebuiltin("XBMC.notification(" + title + "," + message + "," + ms + "," + nart + ")")

def addDir(name,url,mode,iconimage,fanart,description=''):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addLink(name,url,mode,iconimage,fanart,description=''):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)

        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        
def open_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

def setView(content, viewType):
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON2.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON2.getSetting(viewType) )

params=get_params(); url=None; name=None; mode=None; site=None; iconimage=None
try: site=urllib.unquote_plus(params["site"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass

print "Site: "+str(site); print "Mode: "+str(mode); print "URL: "+str(url); print "Name: "+str(name)
print params

if mode==None or url==None or len(url)<1: CATEGORIES()
elif mode==1: CATDOCS(url)
elif mode==2: PLAYDOCS(url,name)

xbmcplugin.endOfDirectory(int(sys.argv[1]))

