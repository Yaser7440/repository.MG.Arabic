# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys
import urllib,urllib2,re,os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse
#from addon.common.net import Net
#from addon.common.addon import Addon
########################################
#------------------------------
from md_request import get_params
from md_request import uncensored
from md_request import OPEN_URL
from md_request import decodeHtml
from md_request import regex_get_all
from md_request import regex_from_to
from md_request import addDir
from md_request import addDir2
from md_request import resolve_host
from md_request import gethostname
from md_request import playlink
#------------------------------
from common import Addon
from md_view import setView
from addon.common.net import Net
#------------------------------

addon_id='plugin.video.aflamy'
addon = Addon(addon_id, sys.argv)
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/img/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, '/img/icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , '/img/fanart.jpg'))
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
baseurl='http://www.aflamy.com'


def getCategories():
    addDir('[B][COLOR white]البحث[/COLOR][/B]',baseurl+'/online/?s=',13,art +'/SEARCH.png',1)
    addDir('[B][COLOR white]••أخــر الاضافات••[/COLOR][/B]',baseurl+'/online/',11,art +'/LAST.png')
    addDir('[B][COLOR white]قوائم الافلام[/COLOR][/B]','url',8,art +'/mov.png',1)
    addDir('[B][COLOR white]قوائم المسلسلات[/COLOR][/B]','url',17,art +'/AR.png',1)                         
    addDir('[B][COLOR white]مسرحيات[/COLOR][/B]',baseurl+'/online/category/msr7yat/',18,art +'/masr7yat.gif',1)
    addDir('[B][COLOR white]مصارعه[/COLOR][/B]',baseurl+'/portal/category/wwe-mosr3a/',11,art +'/WWE.png',1)
    addDir('[B][COLOR white]كوره[/COLOR][/B]',baseurl+'/portal/category/football-koora/',11,art +'/kooora.gif',1)
    addDir('[B][COLOR white]اغاني[/COLOR][/B]',baseurl+'/online/category/clips-mp3-aghany/',18,art +'/v-clip.gif',1)
    addDir('[B][COLOR white]توك شو[/COLOR][/B]',baseurl+'/online/category/talk-show-online/',18,art +'/',1)
    #addDir('مسلسلات اسيوه',baseurl+'/portal/category/asian-series-arabic/',11,art +'/CARTOON.png',1)
    #addDir('فلاش انلين',baseurl+'/portal/category/online-flash-games/',11,art +'/CARTOON.png',1)
    #addDir(' 2014رمضان',baseurl+'/online/category/ramadan-series-2014/',11,art +'/CARTOON.png',1)
    #addDir('ابراج',baseurl+'/online/category/abraj/',11,art +'/CARTOON.png',1)
    #addDir('اخبار',baseurl+'/online/category/akhbar-news/',18,art +'/CARTOON.png',1)
            
def showmenuTV():
   menuitems=[]
   menuitems.append(("[B][COLOR white]البحث[/COLOR][/B]",'url',4, art + '/search.png','',1))
   menuitems.append(("[B][COLOR white]تصنيفات الافلام بالسنه[/COLOR][/B]", 'url',12, art + '/YEARS.png','',1))
   menuitems.append(("[B][COLOR white]مسلسلات عربي[/COLOR][/B]",baseurl+'/portal/category/moslslat-araby/',11,art +'/moslslat-araby.gif','',1))
   menuitems.append(("[B][COLOR white]مسلسلات تركي[/COLOR][/B]",baseurl+'/portal/category/moslslat-turkey/',11,art +'/turkey.gif','',1))
   menuitems.append(("[B][COLOR white]مسلسلات اسيويه[/COLOR][/B]",baseurl+'/portal/category/asian-seriess/',11,art +'/pro.gif','',1))
   menuitems.append(("[B][COLOR white]مسلسلات هنديه[/COLOR][/B]",baseurl+'/portal/category/hindi-series/',11,art +'/moslslat-araby.gif','',1))
   menuitems.append(("[B][COLOR white]مسلسلات مكسيكيه[/COLOR][/B]",baseurl+'/portal/category/mexican-series/',11,art +'/CARTOON.png','',1))
   menuitems.append(("[B][COLOR white]مسلسلات اجنبي[/COLOR][/B]",baseurl+'/portal/category/moslslat-ajnaby/',11,art +'/moslslat-agnaby.gif','',1))
   
   for title, url, mode,pic,desc,page in menuitems:
       addDir(title, url, mode, pic,desc,1) 
					
def showmenuMV():
   menuitems=[]
   menuitems.append(("[B][COLOR white]البحث[/COLOR][/B]",'url',4, art + '/search.png','',1))
   menuitems.append(("[B][COLOR white]تصنيفات الافلام بالسنه[/COLOR][/B]", 'url',12, art + '/YEARS.png','',1))
   menuitems.append(("[B][COLOR white]افلام اجنبيه[/COLOR][/B]",baseurl+'/online/category/aflam-ajnaby',11, art + '/aflam-agnby.gif','',1))
   menuitems.append(("[B][COLOR white]أفــلام عربية[/COLOR][/B]",baseurl+'/online/category/aflam-araby/',11,art +'/aflam-araby.gif','',1))
   menuitems.append(("[B][COLOR white]أفــلام هندية[/COLOR][/B]",baseurl+'/online/category/aflam-hindy/',11,art +'/aflam-hindy.gif','',1))
   menuitems.append(("[B][COLOR white]افلام ممنوعه من العرض[/COLOR][/B]",baseurl+'/portal/category/aflam-llekbar/',11,art +'/','',1))
   menuitems.append(("[B][COLOR white]أفــلام الانيمي[/COLOR][/B]",baseurl+'/portal/category/aflam-animy/',11,art +'/aflam-kartoon.gif','',1))
   menuitems.append(("[B][COLOR white]افلام اسيويه[/COLOR][/B]",baseurl+'/portal/category/asian-movies/',11,art +'/pro.gif','',1))
   
   for title, url, mode,pic,desc,page in menuitems:
       addDir(title, url, mode, pic,desc,1) 
	   
def searchmenuMV():
   menuitems=[]
   
   menuitems.append(("[B][COLOR white]افلام اجنبيه[/COLOR][/B]",baseurl+'/online/category/aflam-ajnaby/?s=',13, art + '/SEARCH.png','',1))
   menuitems.append(("[B][COLOR white]أفــلام عربية[/COLOR][/B]",baseurl+'/online/category/aflam-araby/?s=',13,art +'/SEARCH.png','',1))
   menuitems.append(("[B][COLOR white]أفــلام هندية[/COLOR][/B]",baseurl+'/online/category/aflam-hindy/?s=',13,art +'/SEARCH.png','',1))
   menuitems.append(("[B][COLOR white]افلام ممنوعه من العرض[/COLOR][/B]",baseurl+'/portal/category/aflam-llekbar/?s=',13,art +'/SEARCH.png','',1))
   menuitems.append(("[B][COLOR white]أفــلام الانيمي[/COLOR][/B]",baseurl+'/portal/category/aflam-animy/?s=',13,art +'/SEARCH.png','',1))
   menuitems.append(("[B][COLOR white]افلام اسيويه[/COLOR][/B]",baseurl+'/portal/category/asian-movies/?s=',13,art +'/SEARCH.png','',1))
   
   for title, url, mode,pic,desc,page in menuitems:
       addDir(title, url, mode, pic,desc,1) 

def YEARSmenuMV():
   menuitems=[]
   
   menuitems.append(("[B][COLOR white]افلام اجنبيه[/COLOR][/B]",'url',5, art + '/YEARS.png','',1))
   menuitems.append(("[B][COLOR white]أفــلام عربية[/COLOR][/B]",'url',9,art +'/YEARS.png','',1))
   menuitems.append(("[B][COLOR white]أفــلام هندية[/COLOR][/B]",'url',10,art +'/YEARS.png','',1))
   menuitems.append(("[B][COLOR white]افلام ممنوعه من العرض[/COLOR][/B]",'url',14,art +'/YEARS.png','',1))
   menuitems.append(("[B][COLOR white]أفــلام الانيمي[/COLOR][/B]",'url',15,art +'/YEARS.png','',1))
   menuitems.append(("[B][COLOR white]افلام اسيويه[/COLOR][/B]",'url',16,art +'/YEARS.png','',1))
   
   for title, url, mode,pic,desc,page in menuitems:
       addDir(title, url, mode, pic,desc,1)	   

	   
def YEARS(url):
       for i in range(2005,2018):
	   addDir(str(i),baseurl+'/online/category/aflam-ajnaby/?s='+str(i),11,'','',1)
def YEARSAR(url):
       for i in range(2005,2018):
	   addDir(str(i),baseurl+'/online/category/aflam-araby/?s='+str(i),11,'','',1)
def YEARSIN(url):
       for i in range(2005,2018):
	   addDir(str(i),baseurl+'/online/category/aflam-hindy/?s='+str(i),11,'','',1)
def YEARSGN(url):
       for i in range(2005,2018):
	   addDir(str(i),baseurl+'/portal/category/aflam-llekbar/?s='+str(i),11,'','',1)	   
def YEARSAN(url):
       for i in range(2005,2018):
	   addDir(str(i),baseurl+'/portal/category/aflam-animy/?s='+str(i),11,'','',1)	
def YEARSAS(url):
       for i in range(2005,2018):
	   addDir(str(i),baseurl+'/portal/category/asian-movies/?s='+str(i),11,'','',1)	   
def search(url):        
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search AflaMy')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')                  
        else:
             print "search error"        
        url= url+search_entered         
        getVideos(url)
        
        
def getVideos(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<article id="post-', '</article>')
	items = len(all_videos)
	for a in all_videos:
		name = regex_from_to(a, '<h1 class="post-title"><a href=".*?">', '</a></h1>').replace('<span>',"(").replace('</span>',")").replace('</h1>',"").replace('&#039;',"'").replace('&amp;',"&")
		url = regex_from_to(a, 'href="', '"')#.replace('.com/online',".pw/portal").replace('&amp;',"&")
		icon = regex_from_to(a, "src='", "'").replace('&#039;',"'").replace('&amp;',"&")
		desc = regex_from_to(a, '<h1 class="post-title"><a href=".*?">', '</a></h1>').replace('&#039;',"'").replace('&amp;',"&")
		genre =regex_from_to(a, '', '').replace('<br />','').replace('&#039;',"'").replace('&amp;',"&").replace('مترجم','').replace('فلم','')
		date = regex_from_to(a, 'datetime="', '"')
		rating = regex_from_to(a, '<i>', '</i>')
		credits = regex_from_to(a, '<label>Stars:</label>', '</div>').replace('&#039;',"'").replace('&amp;',"&")
		fanart = regex_from_to(a, "src='", "'").replace('&#039;',"'").replace('&amp;',"&")	
		addDir2('[B][COLOR white]%s[/COLOR][/B]'%decodeHtml(name),url,2,icon,fanart,decodeHtml(desc),'',date,'','','',items)		
	try:
		nextp=re.compile('<div class="pagenav clearfix">(.*?)</div>\s*</div>').findall(link)[0]
		Regex2 = re.compile('<a href="(.*?)".*?>(.+?)</a>',re.DOTALL).findall(str(nextp))
		for url,name in Regex2:
                 addDir('[B][COLOR red][%s] Page>>>[/COLOR][/B]'%name,url,11,'http://www.tachyonpunch.com/comics/images/next_icon.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')
                        
def getVideos2(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<article id="post-', '</article>')
	items = len(all_videos)
	for a in all_videos:
		name = regex_from_to(a, '<h1 class="post-title"><a href=".*?">', '</a></h1>').replace('<span>',"(").replace('</span>',")").replace('</h1>',"").replace('&#039;',"'").replace('&amp;',"&")
		url = regex_from_to(a, 'href="', '"')#.replace('.com/online',".pw/portal").replace('&amp;',"&")
		icon = regex_from_to(a, "src='", "'").replace('&#039;',"'").replace('&amp;',"&")
		desc = regex_from_to(a, '<h1 class="post-title"><a href=".*?">', '</a></h1>').replace('&#039;',"'").replace('&amp;',"&")
		genre =regex_from_to(a, '', '').replace('<br />','').replace('&#039;',"'").replace('&amp;',"&").replace('مترجم','').replace('فلم','')
		date = regex_from_to(a, 'datetime="', '"')
		rating = regex_from_to(a, '<i>', '</i>')
		credits = regex_from_to(a, '<label>Stars:</label>', '</div>').replace('&#039;',"'").replace('&amp;',"&")
		fanart = regex_from_to(a, "src='", "'").replace('&#039;',"'").replace('&amp;',"&")	
		addDir2('[B][COLOR white]%s[/COLOR][/B]'%decodeHtml(name),url,2,icon,fanart,decodeHtml(desc),'',date,'','','',items)		
	try:
		nextp=re.compile('<div class="pagenav clearfix">(.*?)</div>\s*</div>').findall(link)[0]
		Regex2 = re.compile('<a href="(.*?)".*?>(.+?)</a>',re.DOTALL).findall(str(nextp))
		for url,name in Regex2:
                 addDir('[B][COLOR red][%s] Page>>>[/COLOR][/B]'%name,url,18,'http://www.tachyonpunch.com/comics/images/next_icon.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')              
               
      


               
def getmatch(match):
                if len(match)<1:
                        return
                for href in match:
                    
                    
                    
                    
                     
                    server=href.split("/")[2].replace('www.',"").replace("embed.","").split(".")[0]
                    #if 'hqq' in server or "myvi" in server or 'videomeh' in server:
                            #return
                    addDir(server,href,7,'')
       
def get_servers(url):
	        data=OPEN_URL(url)
	       
                	
                #regx='''</span><a href='(.+?)' class='redirect_link'>'''
                #regx1='''<iframe src="(.+?)" scrolling="no" frameborder="0" width="700" height="430" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'''
                regx2='''<li><a href="(.+?)" target=_blank>\n<img src="(.+?)" ></img>'''
                #regx2='<a href="http://www.youtube2.org/online/?p=785&url=http://vidbull.com/embed-zbdm3g7mfwe8-720x405.html" target=_blank>'

                
                regx3='''<iframe .+? src="(.+?)" .+?></iframe>'''
                regx4='''<iframe .+? src="(.+?)" ></iframe>'''
                regx1='''<source type="video/mp4" src="(.+?)" /><a'''
                #regx5='''<IFRAME .+? SRC="(.+?)" .+?></IFRAME>'''
                regx='''<a href="http://aflamy.pw/portal/(.+?)">'''
                try:newurl ="http://aflamy.pw/portal/"+ re.findall(regx,data, re.M|re.I)[0]
                except:newurl=url
                if newurl:
                   
                   data=OPEN_URL(newurl)
                   
                   regx='''<iframe src="(.+?)".+?></iframe>'''
                   regx='''<iframe.+?src="(.+?)".+?></iframe>'''
                   try:
                     links=re.findall(regx,data, re.M|re.I)
                     for link in links:  
                        if 'youtube'  in link:
                            continue
                        if 'facebook'  in link:
                            continue
                        server=gethostname(link)                    
                        addDir(server,link,7,'')
                   except:
                           pass

                        
                   try:      
                    
                    regx='''href="https://openload.co/f/(.+?)">'''
                    stream_url="https://openload.co/f/"+re.findall(regx,data, re.M|re.I)[0]
                    server=gethostname(stream_url)                    
                    addDir(server,stream_url,7,'')
                   except:
                           pass
                   try:     
                      regx='''<a target="_blank" href="http://uptobox.com/(.+?)">'''
                      stream_url="http://uptobox.com/"+re.findall(regx,data, re.M|re.I)[0]
                      server=gethostname(stream_url)                    
                      addDir(server,stream_url,7,'')
                   except:
                           pass
                  
                   try:     
                      regx='''src=".+?//www.dailymotion.com/embed/video/(.+?)">'''
                      stream_url="http://www.dailymotion.com/embed/video/"+re.findall(regx,data, re.M|re.I)[0]
                      server=getHostName(stream_url)                    
                      addDir(server,stream_url,7,'')
                   except:
                           pass
						   


# def playlink(url):
            # print "m2",url
	    # listItem = xbmcgui.ListItem(path=str(url))
	    # xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listItem)

              
params=get_params(); url=None; name=None; mode=None; iconimage=None; description=None; site=None; query=None; type=None; page=1	
try:url=urllib.unquote_plus(params["url"])
except:pass
try:name=urllib.unquote_plus(params["name"])
except:pass
try:iconimage=urllib.unquote_plus(params["iconimage"])
except:pass
try:mode=int(params["mode"])
except:pass
try:description=urllib.unquote_plus(params["description"])
except:pass
try:query=urllib.unquote_plus(params["query"])
except:pass
try:type=urllib.unquote_plus(params["type"])
except:pass
try:page=int(params["page"])
except:pass


		


# print "Mode: "+str(mode)
# print "URL: "+str(url)
# print "Name: "+str(name)
# print "iconimage: "+str(iconimage)
# print "description: "+str(description)
# print "query: "+str(query)
# print "type: "+str(type)
# print "page: "+str(page)

if mode==None or url==None or len(url)<1: getCategories()       
elif mode==11: getVideos(url)
elif mode==18: getVideos2(url)         
elif mode==8: showmenuMV()
elif mode==17: showmenuTV()		
elif mode==5: YEARS(name)
elif mode==9: YEARSAR(name)
elif mode==10: YEARSIN(name) 
elif mode==14: YEARSGN(name)
elif mode==15: YEARSAN(name)
elif mode==16: YEARSAS(name)		
elif mode==12: YEARSmenuMV()        
elif mode==2: get_servers(url)        
elif mode==13: search(url)		
elif mode==4: searchmenuMV()       
elif mode==7: resolve_host(url)       
elif mode==40: playlink(url)        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
