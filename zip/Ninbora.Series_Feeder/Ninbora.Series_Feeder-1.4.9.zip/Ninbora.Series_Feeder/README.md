================================
Ninbora.Series_Feeder Kodi Addon
================================

About
-----
Feed series to Kodi from several sources

License
-------
This software is released under the [MIT license] [1].
[1]: http://opensource.org/licenses/MIT