# -*- coding: utf8 -*-
try:import sys, syspath
except:pass
import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,xbmc,xbmcaddon,os
from t0mm0.common.addon import Addon

addon_id = 'plugin.video.alfajertv'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
ADDON2=xbmcaddon.Addon(id='plugin.video.alfajertv')
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
base = 'http://www.alfajertv.com/'

baseurl = 'http://www.alfajertv.com/'
host='www.alfajertv.com'
####functions
def read_url2(url,host):
      #try:  
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', host)
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
        return link
      #except:
            #addDir("Download failed:"+str(e.reason),"","",'') 
def read_url(url):
     
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', host)
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
        return link
    
def readnet(url):
            from t0mm0.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      
def decodeHtml(text):
    text = text.replace('&auml;', 'ae').replace('&Auml;', 'Ae').replace('&ouml;', 'oe').replace('&ouml;', 'Oe').replace('&uuml;', 'ue')
    text = text.replace('&Uuml;', 'Ue').replace('&szlig;', 'ss').replace('&amp;', '&').replace('&quot;', '"').replace('&gt;', "'")
    text = text.replace('&#228;', 'ae').replace('&#246;', 'oe').replace('&#252;', 'ue').replace('&#223;', 'ss').replace('&#8230;', '...')
    text = text.replace('&#8222;', ',').replace('&#8220;', "'").replace('&#8216;', "'").replace('&#8217;', "'").replace('&#8211;', '-')
    text = text.replace('&#8230;', '...').replace('&#8217;', "'").replace('&#128513;', ':-)').replace('&#8221;', '"')
    text = text.replace('&#038;', '&').replace('&#039;', "'")
    text = text.replace('\\u00c4', 'Ae').replace('\\u00e4;', 'ae').replace('\\u00d6', 'Oe').replace('\\u00f6', 'oe')
    text = text.replace('\\u00dc', 'Ue').replace('\\u00fc', 'ue').replace('\\u00df', 'ss')
    text = text.replace('&#196;', 'Ae').replace('&#228;', 'ae').replace('&#214;', 'Oe').replace('&#246;', 'oe').replace('&#220;', 'Ue').replace('&#252;', 'ue')
    text = text.replace('<br />\n', '')
    return text 
def removeunicode(data):
             
             
            
              try:
                    type(data)
                    data=data.decode('unicode_escape').encode('ascii','replace').replace("?","").strip()
        
              except:
                    pass
              
              return data
              
def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        
        return query.hostname 
##########################################parsing tools
def showmenu():

                genreliste=[]
                
                genreliste.append(("Live TV-Gaza-Jordan", 'http://www.alfajertv.com/live/3907053.html',500,'img/search.png','',1))
                genreliste.append(("Live TV-west bank", 'http://www.alfajertv.com/live/3894317.html',500,'img/search.png','',1))
                genreliste.append(("Live TV-International", 'http://www.alfajertv.com/live/3894319.html',500,'img/search.png','',1))
                genreliste.append(("Fajr youtube", 'http://www.alfajertv.com/alfajertube',501,'img/1.png','',1))
                
                
		
                for title, url, mode,pic,desc,page in genreliste:
                    addDir(title, url, mode, pic,desc,1)

def years(url):
        for i in range(2002,2016):
             addDir(str(i),'http://projectfreetv.so/movies/search/'+str(i)+"/",100,'','',1)                 
                    
def genres(url):
      	addDir('Animation','http://projectfreetv.so/movies/free/animation/',100,'http://i45.tinypic.com/2d9u26c.jpg',1)
	addDir('Biography','http://projectfreetv.so/movies/free/biography/',100,'http://i28.tinypic.com/2di53py.jpg',1)
	addDir('Action','http://projectfreetv.so/movies/free/action/',100,'http://i44.tinypic.com/qsqluw.jpg',1)
	addDir('Crime','http://projectfreetv.so/movies/free/crime/',100,'http://i47.tinypic.com/3503oli.jpg',1)
	addDir('Adventure','http://projectfreetv.so/movies/free/adventure/',100,'http://i30.tinypic.com/2mrh5aq.jpg',1)
	addDir('Romance','http://projectfreetv.so/movies/free/romance/',100,'http://i47.tinypic.com/3503oli.jpg',1)
	addDir('Science-Fiction','http://projectfreetv.so/movies/free/sci-fi/',100,'http://i44.tinypic.com/23kd6rt.jpg',1)
	addDir('Comedy','http://projectfreetv.so/movies/free/comedy/',100,'http://i48.tinypic.com/jfhgco.jpg',1)
	addDir('Drama','http://projectfreetv.so/movies/free/drama/',100,'http://i39.tinypic.com/2a6qn9t.jpg',1)
	
        
        
                            
                    


def getA_Z(name='movies'):
		abc = ['#','0','1','2','3','4','5','6','7','8','9',"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'http://projectfreetv.so/watch-tv-series/#mctm-'+letter,200,'',1)
##################################
def livelinks(urlmain):

                print "page",urlmain
               
              
                url_page=urlmain
               
                data=readnet(url_page)
                #print "data",data
                data=data.split("function hls_live()")[1]
                
               
                if data is None:
                    return
               
                blocks=data.split('{"file"')
                i=0
               
                
                print "blocks",len(blocks)
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    print "block",block    
                    #href=re.findall('''<h2 onclick="window.location.href='(.*?)'">.*?</h2>''',block, re.M|re.I)[0]
                   
                    try:href=re.findall(':"(.*?)"',block, re.S)[0]
                    except:continue
                   
                    title="link"+str(i)
                   
                    
                    addDir(title,href,22,'','',1)
                              
def youtubecats(urlmain):

                print "page",urlmain
               
              
                url_page=urlmain
               
                data=readnet(url_page)
                #print "data",data
                data=data.split('class="default-margin-top videos-page">')[1]
                
               
                if data is None:
                    return
               
                blocks=data.split('class="main-block"')
                i=0
               
                
                print "blocks",len(blocks)
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    print "block",block    
                    #href=re.findall('''<h2 onclick="window.location.href='(.*?)'">.*?</h2>''',block, re.M|re.I)[0]
                    regx='''class="title"> <div class="line-hor"></div> <a href="(.*?)" title="(.*?)</a>'''
                    match=re.findall(regx,block, re.S)
                    print "match",len(match)
                    try:href=match[0][0]
                    except:continue
                    title=match[0][1]
                   
                    
                    addDir(title,href,502,'','',1)
def getvideos(name,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  #http://m2k.me/moviecategory.php?cid=23&page=2
                  url_page=urlmain+'?page='+str(page)+"/"
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                data=data.split('<a href="http://www.alfajertv.com/alfajertube">')[2]
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="row">')
                i=0
               
                print "blocks",len(blocks),blocks[1]
                
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    print "block",block
                    block=block.lower()
                    regx='''<img  src="(.*?)" class="'''

                    regx2='''<div class=".*?"> <a href="(.*?)" title="(.*?)"> <img src="(.*?)" alt='''
                    regx2='''<div class=".*?"> <a href="(.*?)" title="(.*?)"> <img src="(.*?)" alt='''
                    match=re.findall(regx2,block, re.M|re.I)
                    print 'match',match
                    try:
                      href=match[0][0]
                      title=match[0][1]                  
                      img=match[0][2] 
                    except:
                            continue
                    addDir(title,href,1,img,'',1)                        
               
                   
                #if len(blocks)>10:
                addDir("next page",urlmain,502,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,502,'','',str(page+1))

                    
###################################movies
			  
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered
        
          
        getmovies("Search",url,0)
def searchmovies(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search movies')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        
            
        
        
         
        url= url+search_entered
        
          
        getmovies2("Search",url,0)
def getmovies_search(name,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  #http://m2k.me/moviecategory.php?cid=23&page=2
                  url_page=urlmain+'page/'+str(page)+"/"
                  
                else:
                
                      url_page=urlmain
               
                data=readnet(url_page)
                data=data.split("<div id='dle-content'>")[1]
                
               
                if data is None:
                    return
               
                blocks=data.split('class="libre-movie libre-movie-block">')
                i=0
               
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    href=re.findall('''<h2 onclick="window.location.href='(.*?)'">.*?</h2>''',block, re.M|re.I)[0]
                    match=re.findall('data-src="(.*?)".*?alt="(.*?)" title=".*?"/>',block, re.M|re.I)

                    img=match[0][0]
                    title=match[0][1]
                   
                    href=href
                    try:title=title.encode("utf-8")
                    except:pass
                    addDir(title,href,11,img,'',1)
                        
               
                   
                
        
def getmovies(name,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  #http://m2k.me/moviecategory.php?cid=23&page=2
                  url_page=urlmain+'page/'+str(page)+"/"
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                data=data.split('<div class="title6" >')[1]
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="post excerpt ">')
                i=0
               
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    print "block",block
                    block=block.lower()
                    regx='''<img  src="(.*?)" class="'''

                    img=re.findall(regx,block, re.S)[0]
                    regx2='''<a href="(.*?)" title="(.*?)" rel="nofollow"'''
                    match=re.findall(regx2,block, re.M|re.I)
                    print 'match',match
                    href=match[0][0]
                    title=match[0][1]                  
                    
                    title=title.encode("utf-8")
                    addDir(title,href,1,img,'',1)                        
               
                   
                if len(blocks)>19:
                   addDir("next page",urlmain,100,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
def getmovies2(name,urlmain,page):##movies
                if page>1:
                  #/page/2/
                  url_page=urlmain+"page/"++str(page)
                  
                else:
                
                      url_page=urlmain
               
                data=readnet(url_page)
                #data=data.split('<ul class="lista-search">')[1]
                if data is None:
                    return
               
                blocks=data.split('<li class="tooltip3 mostrar_video"')
                i=0
               
                print "blocks",len(blocks)
                
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    image=re.findall("src='(.*?)'>",block, re.S)[0]
                    #href=re.findall('<a href="(.*?)" class',block, re.M|re.I)[0]
                    match=re.findall('data-src="(.*?)" width="185" height="250" alt="(.*?)" title=".*?"/>',block, re.S)
                    image=match[0][0]
                    title=match[0][1]
                   
                    try:title=title.encode("utf-8")
                    except:pass
                    if '../' in href:
                            href=href.replace('../','')
                    try:addDir(title,href,1,image,'',1)
                    except:continue
                        
               
                
                
                if len(blocks)>35:
                   addDir("next page",urlmain,105,'img/nextpage.jpg','',str(page+1))
                else:
                    addDir("Error:no results",urlmain,200,'','',str(page+1))
                    
###############################################tv shows
def search_series(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered

        getseasons_search("Search",url,0)

                    
def getseasons(name,urlmain,page):##series
                if page>1:
                  #/page/2/
                  url_page=urlmain+"page/"++str(page)
                  
                else:
                
                      url_page=urlmain
                 
                data=readnet(url_page)
                try:data=data.split('<div class="title6">')[1]
                except:pass
                print "url_page",url_page
              
                if data is None:
                    return

                seasons=re.findall('''<a href="(.*?)" >(.*?)</a>''',data, re.M|re.I)
                print 'seasons',seasons
                
                for href,name in seasons:
                    
                    
                    addDir(name,href,201,'','',1)
                        
               
def getseasons_search(name,urlmain,page):##series
                
                data=readnet(urlmain)
                try:data=data.split('<h2>Search results')[1]
                except:pass
               
              
                if data is None:
                    return
                regx='<a href="(.*?)"  rel="nofollow">(.*?)</a>'
                seasons=getgroups(data,regx,2)
               
                
                seasons=re.findall(regx,data, re.M|re.I)
                print 'seasons',seasons
                
                for href,name in seasons:
                    
                    
                    addDir(name,href,201,'','',1)
                                           
                                    
def getseries(name,urlmain,page):##series
                if page>1:
                  #/page/2/
                  url_page=urlmain+"page/"++str(page)
                  
                else:
                
                      url_page=urlmain
                
                data=readnet(url_page)
                data=getdata(data,'<h4 id="mctm-'+name+'"','<h4 id="mctm')
               
                try:data=data.split('<h4 id="mctm-'+name+'"')[1]
                except:pass
                print "url_page",url_page
              
                if data is None:
                    return
                
                match=re.findall('<li><a title="(.*?)" href="(.*?)">',data, re.M|re.I)

                i=0
               
                for title,href in match:
                    
                    addDir(title,href,2001,'','',1)
                        
               
                   
                if len(match)==0:
                    addDir("Error:no results",urlmain,200,'','',str(page+1))
                                        

def getepisodes(name,urlmain,page):##series
                if page>0:
                
                  url_page=urlmain+'&page='+str(page)
                  
                else:
                
                      url_page=urlmain
                
                data=readnet(urlmain)
                try:data=data.split("<tbody>")[1]
                except:pass
                print "url_page",url_page
                
              
                if data is None:
                    return
                
                blocks=data.split('<tr><th><div align="left">')
               
                i=0
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    regx='<a href="(.*?)">(.*?)</a>'
                    match=re.findall(regx,block, re.M|re.I)
                     
                    
                    href=match[0][0]
                    title=match[0][1]
                   
                    
                            
                   
                    addDir(title,href,1,'','',1)
                        
               
                   
                #if len(match)>0:
                  #addDir("next page",urlmain,200,'','',str(page+1))
                if len(match)==0:
                    addDir("Error:no results",urlmain,200,'','',str(page+1))
            

 


#######################################host resolving                                                    
def creatertmp(host,urlmain):
     #rtmp://streaming.hayyes.com/vod/<playpath>mp4:29/29303/29303_1_400k.mp4 <swfUrl>http://www.hayyes.com/sites/all/themes/hys/tpl/jw/jwplayer.flash.swf <pageUrl>http://www.hayyes.com/vod/aflam/7alawet-roo7
     url=host+'  swfUrl=http://www.hayyes.com/sites/all/themes/hys/tpl/jw/jwplayer.flash.swf pageUrl='+ urlmain
     return url

def gethosts(urlmain):##cinema and tv featured
                
                data=readnet(urlmain)
                if data is None:
                    return
               
                i=0
                regx='''<iframe width=.*?src="(.*?)".*?></iframe></p>'''
                try:link=re.findall(regx,data, re.M|re.I)[0]
                except:return
                print "link1",link
                videoid=link.split("embed/")[1]
                link='plugin://plugin.video.youtube/?action=play_video&videoid=%s' % videoid
                
                playlink(link)
                return
                for href,title in blocks:
                                      
                    
                    title=title.split("=")[1]
                    
                  
                    
                    addDir(title,href,21,'','',1)
                        
               
                   
                #if len(match)>0:
                  #addDir("next page",urlmain,200,'','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,200,'','',str(page+1))
		
		
                #playlink(link)
def gethosts_movies(urlmain):##cinema and tv featured

                print "urlmain",urlmain
                data=readnet(urlmain)
                try:data=data.split("<div class='panel-container'>")[1]
                except:pass
               
                
              
                if data is None:
                    return
                
                blocks=data.split('class="tab-buttons-panel"')
               
                i=0
               
                for block in blocks:
                    i=i+1
                    
                    block=block.lower()
                    regx1='''<iframe.*?src="(.*?)".*?></iframe>'''
                    regx2='''<iframe.*?src='(.*?)'.*?></iframe'''
                    #regx3='''<iframe width="600" height="330" scrolling="no" frameborder="0" src="http://videomega.tv/iframe.php?ref=Kjp0m2ECo44oCE2m0pjK&width=600&height=330" allowFullScreen></iframe>'''
                    match=re.findall(regx1,block, re.M|re.I)
                    match2=re.findall(regx2,block, re.M|re.I)
                   
                    
                     
                    print 'match',match
                    for href in match:
                      
                      host=gethostname(href)
                    
                            
                   
                      addDir(host,href,1,'','',1)
                    for href in match2:
                      
                      host=gethostname(href)
                    
                            
                   
                      addDir(host,href,1,'','',1)                              
def gethosts2(urlmain):##cinema and tv featured

                
                data=readnet(urlmain)
                
                if data is None:
                    return
                
                
                regx='<a rel="nofollow" href="(.*?)"><input type='
                link= re.findall(regx,data, re.M|re.I)[0]
                stream_url=resolve(link)
                playlink(stream_url)
	    
def resolve_host(url):#last good-used with local resolver
        if 'easyvid' in url:
                stream_url=gethosts2(url)
                playlink(stream_url)
                return 
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    listItem = xbmcgui.ListItem(path=str(stream_link))
	    xbmcplugin.setResolvedUrl(sys.argv[0], True, listItem)   
        else:
            addDir("Error,"+stream_link,"",9,"") 	    
def resolve_host2(url):#last good
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
   
	    listItem = xbmcgui.ListItem(path=str(stream_link))
	    xbmcplugin.setResolvedUrl(sys.argv[0], True, listItem)   
        else:
            addDir("Error,"+stream_link,"",9,"")
def playlink(url):
            print "m2",url
            xbmc.Player().play(url)
            sys.exit(0)
	    #listItem = xbmcgui.ListItem(path=str(url))
	    #xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listItem)

            
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param



def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
def getgroups(data, pattern, grupsNum = 1, ignoreCase = False):
        tab = []
        if ignoreCase:
            match = re.search(pattern, data, re.IGNORECASE)
        else:
            match = re.search(pattern, data)
        
        for idx in range(grupsNum):
            try:
                value = match.group(idx + 1)
            except:
                value = ''

            tab.append(value)

        return tab
def getdata(data, marker1, marker2, withMarkers = True, caseSensitive = True):
        if caseSensitive:
            idx1 = data.find(marker1)
        else:
            idx1 = data.lower().find(marker1.lower())
        if -1 == idx1:
            return (False, '')
        if caseSensitive:
            idx2 = data.find(marker2, idx1 + len(marker1))
        else:
            idx2 = data.lower().find(marker2.lower(), idx1 + len(marker1))
        if -1 == idx2:
            return (False, '')
        if withMarkers:
            idx2 = idx2 + len(marker2)
        else:
            idx1 = idx1 + len(marker1)
        return  data[idx1:idx2]

params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
elif mode==1:
        print ""+url
        gethosts(url)
elif mode==11:
        print ""+url
        gethosts_movies(url)        
elif mode==2:
        print ""+url
        resolve_host(url)
elif mode==21:
        print ""+url
        gethosts2(url)
        
elif mode==22:
        print ""+url
        playlink(url)          
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)
elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
	print ""+url
        search(url)
        
        
elif mode==5:
	print ""+url	
        genres(url)   	
elif mode==51:
	print ""+url	
        years(url)  	
	
elif mode==104:
	print ""+url
	
	searchmovies(url)
elif mode==105:
        print ""+url
        getmovies2(name,url,page)
elif mode==200:
	print "mfaraj"+url
	getseries(name,url,page)
	#getvideopage(url,page)
        getmovies2(name,url,page)
elif mode==2001:
	print "mfaraj"+url
	getseasons(name,url,page)
	#getvideopage(url,page)	
elif mode==201:
	getepisodes(name,url,page)
elif mode==202:
	print ""+url
	getA_Z('shows')
	
elif mode==203:
	print ""+url
        search_series(url)
elif mode==500:
        livelinks(url)
elif mode==501:
        youtubecats(url)                              
elif mode==502:
        getvideos(name,url,page)     
xbmcplugin.endOfDirectory(int(sys.argv[1]))
