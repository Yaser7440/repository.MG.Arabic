# -*- coding: utf8 -*-

import sys
import urllib,urllib2,re,os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re



############################################

####functions

    
def readnet(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      

              
def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        
        return query.hostname 
##########################################parsing tools
def showmenu():

                menuitems=[]
                
                menuitems.append(("Search ", 'http://faselhd.com/?s=',103,'special://home/addons/plugin.video.faselhd/img/search.png','',1))
                menuitems.append(("الافلام الاجنبيه", 'http://faselhd.com/movies/',100,'special://home/addons/plugin.video.faselhd/img/movies.png','',1))
               
                menuitems.append(("الافلام الاعلى مشاهده", 'http://faselhd.com/top/views/',100,'special://home/addons/plugin.video.faselhd/img/movies.png','',1))
                menuitems.append(("الافلام الاعلى تصويتا", 'http://faselhd.com/top/votes/',100,'special://home/addons/plugin.video.faselhd/img/movies.png','',1))
                menuitems.append(("الافلام العربيه", 'http://faselhd.com/arabic-movies/',100,'special://home/addons/plugin.video.faselhd/img/movies.png','',1))
                menuitems.append(("مسلسلات اجنبيه", 'http://faselhd.com/series-cats/gharbi-series/',200,'special://home/addons/plugin.video.faselhd/img/tv.png','',1))
                menuitems.append(("مسلسلات عربيه", 'http://faselhd.com/series-cats/arabic-series/',2000,'special://home/addons/plugin.video.faselhd/img/music.png','',1))
                
                
                
                
                
                
               
                
		
                for title, url, mode,pic,desc,page in menuitems:
                    addDir(title, url, mode, pic,desc,1)

            
                    
def genres(urlmain):

                data=readnet(urlmain)
               
                #data=data.split('id="movie_list"')[1]
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    



			
###################################movies
			  
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered
        
          
        getmovies("Search",url,0)
        getseasons("Search",url,0)
        


                        
               
                   
                
        
def getmovies(namemain,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  # http://tellymov.com/category/Movies/page2
                  
                     url_page=urlmain+'page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('<div class="page-box clearfix">')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="movie-wrap">')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)">'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    
                    regx='''<img src="(.*?)" alt="(.*?)" />'''
                    matches=re.findall(regx,block, re.M|re.I)
                    try:name=matches[0][1]
                    except:continue
                    img=matches[0][0]
                    if "?" in img:
                        img=img.split("?")[0].encode("utf-8")   
                    
                    
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:addDir(name,href,1,img,'',1)
                    except:pass
               
                   
                
                if not "search" in namemain.lower():
                    
                    addDir("next page",urlmain,100,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))

                    
###############################################tv shows

def getseries(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  # http://tellymov.com/category/Movies/page2
                  
                     url_page=urlmain+'page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('<div class="page-box clearfix">')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="movie-wrap">')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)">'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    
                    regx='''<img src="(.*?)" alt="(.*?)" />'''
                    matches=re.findall(regx,block, re.M|re.I)
                    img=matches[0][0]
                    name=matches[0][1]
                    if "?" in img:
                        img=img.split("?")[0].encode("utf-8")                      
                    
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:addDir(name,href,201,img,'',1)
                    except:pass
               
                   
                
                
                addDir("next page",urlmain,100,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,201,'','',str(page+1))
                                        
def getseries2(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  # http://tellymov.com/category/Movies/page2
                  
                     url_page=urlmain+'page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('<div class="page-box clearfix">')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="movie-wrap">')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)">'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    
                    regx='''<img src="(.*?)" alt="(.*?)" />'''
                    matches=re.findall(regx,block, re.M|re.I)
                    img=matches[0][0]
                    name=matches[0][1]
                    if "?" in img:
                        img=img.split("?")[0].encode("utf-8")                    
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:addDir(name,href,202,img,'',1)
                    except:pass
                    
               
                    
                
                
                addDir("next page",urlmain,100,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,201,'','',str(page+1))                    
def getseasons(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  # http://tellymov.com/category/Movies/page2
                  
                     url_page=urlmain+'page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="movie-wrap">')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)">'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    
                    regx='''<img src="(.*?)" alt="(.*?)" />'''
                    matches=re.findall(regx,block, re.M|re.I)
                    try:name=matches[0][1]
                    except:continue
                    img=matches[0][0]
                    
                    if "?" in img:
                        img=img.split("?")[0].encode("utf-8")                      
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name+"_season "+str(i-1)
                    try:addDir(name,href,202,img,'',1)
                    except:pass
               
                   
                
                
                #addDir("next page",urlmain,100,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,201,'','',str(page+1))
                        

                                           
                                    


def getepisodes(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  # http://tellymov.com/category/Movies/page2
                  
                     url_page=urlmain+'page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                regx='''<meta http-equiv="refresh" content="0;URL='(.*?)'" />'''
                href=re.findall(regx,data, re.M|re.I)[0]
                data=readnet(href)
               
                #try:data=data.split('<div class="page-header">')[1]
                #except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('style="bottom')
                i=0
                
                print "blocks",len(blocks)
                print "block",blocks
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''href="(.*?)"'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    
                    regx='''src="(.*?)'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                    name="Episode "+str(i-1)
                    if "?" in img:
                        img=img.split("?")[0].encode("utf-8")                    
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:addDir(name,href,1,img,'',1)
                    except:pass
               
                   
                
                
                addDir("next page",urlmain,100,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,201,'','',str(page+1))
            

 


#######################################host resolving                                                    




def gethosts(name,urlmain):##cinema and tv featured

                urlmain=urlmain
                data=readnet(urlmain)
                
                if True:
                 
                    
                   
                    regx='''file: "(.*?)", label: "(.*?)", type: "mp4"'''
                    match=re.findall(regx,data, re.M|re.I)
                    print "match",match
                    for href,name in match:
                        href=href.encode("utf-8")
                        addDir(name,href,3,'','',1)

                    
                    regx='''<iframe allowfullscreen="" frameborder="0" src="(.*?)" height="100%" width="100%"></iframe>'''
                    
                    try:
                        href=re.findall(regx,data, re.M|re.I)[0]
                    except:
                        regx='''<iframe width="640" height="360" src="(.*?)" frameborder="0" allowfullscreen></iframe></div>'''
                        href=re.findall(regx,data, re.M|re.I)[0]
                        import urlresolver
                        stream_link=urlresolver.resolve(href)
                        playlink(stream_link)
                        return
                        
                    data=readnet(href)
                    regx='''file: "(.*?)"'''
                    href=re.findall(regx,data, re.M|re.I)[0]
                    addDir("m3u8",href,3,'','',1)
                    return
 
                                          

	    

def playlink(url):
           
            xbmc.Player().play(url)
            sys.exit(0)            
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param



def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
elif mode==1:
        print ""+url
        gethosts(name,url)
elif mode==2:
        print ""+url
        resolve_host(url)        
elif mode==3:
        print ""+url
        playlink(url)
     
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)
elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
	print ""+url
        search(url)    
       


elif mode==200:

   getseries(name,url,page)
elif mode==2000:
  
   getseries2(name,url,page)	
elif mode==201:
	getseasons(name,url,page)
	#getvideopage(url,page)	
elif mode==202:
	getepisodes(name,url,page)


xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
