# -*- coding: utf8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse
import StringIO
import urllib2,urllib
import re
import httplib
import time

__settings__ = xbmcaddon.Addon(id='plugin.video.alqudseyes')
__icon__ = __settings__.getAddonInfo('icon')
__fanart__ = __settings__.getAddonInfo('fanart')
__language__ = __settings__.getLocalizedString
_thisPlugin = int(sys.argv[1])
_pluginName = (sys.argv[0])

def patch_http_response_read(func):
    def inner(*args):
        try:
            return func(*args)
        except httplib.IncompleteRead, e:
            return e.partial

    return inner
httplib.HTTPResponse.read = patch_http_response_read(httplib.HTTPResponse.read)


def CATEGORIES():
	addDir(' 2016 مسلسلات رمضان  ','http://46.101.61.161/series?sort=desc&category=78&sort_by=date&series=100&page=',2,'http://www.misr4news.com/wp-content/uploads/2016/05/1400868926_285-670x300.jpg')
	addDir('مسلسلات تركية ','http://46.101.61.161/series?sort=desc&category=19&sort_by=date&series=100&page=',2,'https://lh4.ggpht.com/vjAVmhpM6CxgtO0q_ldxFEg6wbHnp3dfPtb3L-4Y_lxBT7V1EtKC1B5137ZcNM6ekA')
	addDir('مسلسلات عربية ','http://46.101.61.161/series?sort=desc&category=20&sort_by=date&series=100&page=',2,'http://i.myegy.to/images/39dae8998f2f.original.png')
	addDir('مسلسلات مصرية ','http://46.101.61.161/series?sort=desc&category=21&sort_by=date&series=100&page=',2,'http://www.dreamboxgate.com/forum/imgcache/2014/394925_dreambox-sat.com.gif')
	addDir('مسلسلات سورية ','http://46.101.61.161/series?sort=desc&category=22&sort_by=date&series=100&page=',2,'http://is2.mzstatic.com/image/thumb/Purple6/v4/39/f0/71/39f071d2-5346-51e5-9b2a-3e82e0ecbf3a/source/512x512bb.jpg')
	addDir('مسلسلات لبنانية ','http://46.101.61.161/series?sort=desc&category=23&sort_by=date&series=100&page=',2,'http://www.rdccairo.org/gallery/unions/1375623498_hatemovich_lb.png')
	addDir('مسلسلات خليجية ','http://46.101.61.161/series?sort=desc&category=24&sort_by=date&series=100&page=',2,'https://i.ytimg.com/vi/SBzIxYvA1Jc/maxresdefault.jpg')
	addDir('مسلسلات كرتون ','http://46.101.61.161/series?sort=desc&category=25&sort_by=date&series=100&page=',2,'http://www.ce4arab.com/vb7/pub04900/84943.jpg')
	addDir('برامج ','http://46.101.61.161/series?sort=desc&category=26&sort_by=date&series=100&page=',2,'http://www.shorouknews.com/uploadedimages/Sections/ART/Radio-TV/original/DW%202082%203.jpg')
	addDir('مسلسلات رمضان 2011 ','http://46.101.61.161/series?sort=desc&category=27&sort_by=date&series=100&page=',2,'http://www.ofann.com/application/data/news/1312114509.33.jpg')
	addDir('مسلسلات رمضان 2012 ','http://46.101.61.161/series?sort=desc&category=28&sort_by=date&series=100&page=',2,'http://wain.me/wp-content/uploads/mbc_ramadan.jpg')
	addDir('مسلسلات رمضان 2014 ','http://46.101.61.161/series?sort=desc&category=30&sort_by=date&series=100&page=',2,'http://media.almasryalyoum.com/News/Large/2014/07/23/235963_0.jpg')
	addDir('مسلسلات مدبلجة ','http://46.101.61.161/series?sort=desc&category=29&sort_by=date&series=100&page=',2,'http://lodynet.com/wp-content/uploads/2015/08/%D9%85%D8%B3%D9%84%D8%B3%D9%84-%D8%BA%D9%8A%D8%AA.jpg')

	addDir('افلام دراما ','http://46.101.61.161/movies?sort=desc&category=2&sort_by=date&movies=100&page=',1,'http://1.bp.blogspot.com/-I5ghlXGDPD4/VixMNB6-mYI/AAAAAAAAAmU/DckIMlh2hd4/s1600-r/Sans%2Btitre-1.png')
	addDir('افلام كوميديا ','http://46.101.61.161/movies?sort=desc&category=3&sort_by=date&movies=100&page=',1,'https://www.iraq4share.com/wp/wp-content/uploads/2016/01/katkot-512x330.png')
	addDir('افلام رومانس وحب  ','http://46.101.61.161/movies?sort=desc&category=4&sort_by=date&movies=100&page=',1,'https://lh3.googleusercontent.com/W7Fb5NXbau5_OZaf5mr8KpqamyBlv3beynSLYlHILeKZ9-zNmWs4GTE6k3CSN0wwzmM=w124')
	addDir('افلام اكشن ومغامرات ','http://46.101.61.161/movies?sort=desc&category=5&sort_by=date&movies=100&page=',1,'http://46.101.61.161/images/movies/1460974788149834705-250x350.jpg?token=3dbdf8891dcc12d821955b66725b0b8b')
	addDir('مسرحيات','http://46.101.61.161/movies?sort=desc&category=6&sort_by=date&movies=100&page=',1,'http://www.decoratel.net/blog/wp-content/uploads/2013/10/TELON-APERTURA-DECORATEL-1.jpg')
	addDir('افلام اجتماعي','http://46.101.61.161/movies?sort=desc&category=7&sort_by=date&movies=100&page=',1,'special://home/addons/plugin.video.alqudseyes/img/1.png')
	addDir('افلام تركية ومدبلجة','http://46.101.61.161/movies?sort=desc&category=11&sort_by=date&movies=100&page=',1,'http://4arabz.tv/uploads/image/left_2.jpg')
	addDir('افلام الزمن القديم ','http://46.101.61.161/movies?sort=desc&category=13&sort_by=date&movies=100&page=',1,'http://www.arabseed.com/images/products_big/asd11x.jpg')
	addDir('افلام وثائقية ','http://46.101.61.161/movies?sort=desc&category=14&sort_by=date&movies=100&page=',1,'https://lh3.googleusercontent.com/6VvwYGY46aYJ2slU3UMNEcVM_6jx8NfGG0ZJYO7GZTMSKWn98yoEb5leD9PkFMQzsBgX=w300')
	addDir('افلام عادل امام ','http://46.101.61.161/movies?sort=desc&category=15&sort_by=date&movies=100&page=',1,'http://www.arab-films.net/wp-content/uploads/1-22.jpg')
	addDir('افلام سورية ','http://46.101.61.161/movies?sort=desc&category=16&sort_by=date&movies=100&page=',1,'http://f.bostah.com/styles/large/public/field/image/10484145_567713493350417_413506493592076112_n.jpg')
	addDir('افلام مصرية ','http://46.101.61.161/movies?sort=desc&category=17&sort_by=date&movies=100&page=',1,'http://www.eapress.eu/wordpress/wp-content/uploads/2015/07/logo_cinema.jpg')
	addDir('افلام هندية ','http://46.101.61.161/movies?sort=desc&category=18&sort_by=date&movies=100&page=',1,'http://www.dreamboxgate.com/forum/imgcache/2013/6/173722.jpg')



def listAlqudsFilmContent(url):

    try:
    	for i in range(1,6):
	    req = urllib2.Request(url+str(i))
	    response = urllib2.urlopen(req,timeout=1)
	    link=response.read()
	    target= re.findall(r'<article class="movie">(.*?)\s(.*?)<div class="grid-col">', link, re.DOTALL)

	    for items in target:
		for itr in items:
		   my_data = str(itr).split('</figure>')[0].split(' <figure class="movie-image">')
		   my_url = my_data[0].replace(' <a href="','').replace('">','').strip()

		   for i in my_data:
		       if ' <img src=' in i :
		            my_name =  i.split('alt="')[1].replace('">','').strip()
		            my_img =  i.split('alt="')[0].replace('<img src="','').replace('"','').strip()
			    print my_img

		            my_url =my_url.split('movies')
		            my_final_url = my_url[0]+'movies/watch'+my_url[1]
		            print my_name
		            print my_final_url
		            print my_img.strip()
			    addLink(my_name,my_final_url,3,my_img)
    except:
	pass

def listAlqudsSerieContent(url):
    try:
    	for i in range(1,6):
	    req = urllib2.Request(url+str(i))
	    response = urllib2.urlopen(req,timeout=1)
	    link=response.read()
	    target= re.findall(r'<article class="movie">(.*?)\s(.*?)<div class="grid-col">', link, re.DOTALL)

	    for items in target:
		for itr in items:
		   my_data = str(itr).split('</figure>')[0].split(' <figure class="movie-image">')
		   my_url = my_data[0].replace(' <a href="','').replace('">','').strip()

		   for i in my_data:
		       if ' <img src=' in i :
		            my_name =  i.split('alt="')[1].replace('">','').strip()
		            my_img =  i.split('alt="')[0].replace('<img src="','').replace('"','').strip()
			    try:
				name = str(name).split('<div')[0]
				
			    except:
				print 'exception caught'
			        pass
		            print my_name
		            print my_url
		            print my_img.strip()
			    addDir(my_name,my_url,4,my_img )
    except:
	pass

def getAlgudsSerie(url):

    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    target= re.findall(r'<div class="info-episodes">(.*?)\s(.*?)</div>', link, re.DOTALL)
    for items in target:
        for i in  items:
            if i !='':
                my_url_data = i.split('">')[0].replace('<h5><a href="','').strip()
                my_name_data = i.split('">')[1].replace('</a></h5>','').strip()
                my_url_data =my_url_data.split('series')
                my_final_url = my_url_data[0]+'series'+my_url_data[1]
                print my_name_data
                print my_final_url
		addLink(my_name_data,my_final_url,3,'')


def get_film_video_file(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    my_film =''
    target= re.findall(r'videoType:"HTML5",(.*?)\s(.*?)prerollAD:"yes",', link, re.DOTALL)
    for items in str(target).split(','):
        if "mp4:" in items:
            my_film= items.split('mp4:')[1].replace('"',"").strip()
    if my_film=='':
        target= re.findall(r'{ type: "video/mp4",(.*?)" }', link, re.DOTALL)

        my_film= target[0].split('src:')[1].replace('"',"").strip()

    
    listItem = xbmcgui.ListItem(path=str(my_film))
    xbmcplugin.setResolvedUrl(_thisPlugin, True, listItem)
	
			

                
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def addLink(name,url,mode,iconimage):
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

              
params=get_params()
url=None
name=None
mode=None


try:
    import json
except:
    import simplejson as json
	
	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        print ""+url
        listAlqudsFilmContent(url)
	
elif mode==2:
        print ""+url
        listAlqudsSerieContent(url)
elif mode==3:
        print ""+url
        get_film_video_file(url)
elif mode==4:
        print ""+url
        getAlgudsSerie(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
