# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys
import urllib,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,xbmcvfs
import requests
import urlresolver
from addon.common.addon import Addon
from addon.common.net import Net

#Common Cache
try:
  import StorageServer
except:
  import storageserverdummy as StorageServer
cache = StorageServer.StorageServer('plugin.video.showscen')


addon_id='plugin.video.showscen'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
#User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
User_Agent = 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2"'
show_tv = selfAddon.getSetting('enable_shows')
baseurl = addon.get_setting('base_url')
net = Net()
def OPEN_URL(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = requests.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore').decode('ascii').encode('utf-8')
    return link


def resolveurl(url):

            
            print "url",url
            #sys.exit(0)            
            import requests,re,time
            html=requests.get(url).text
            #<input type="hidden" name="watch" value="1">                  
            #id = re.findall('<input type="hidden" name="id" value="(.*?)">',html, re.M|re.I)[0]
            #fname = re.findall('<input type="hidden" name="fname" value="(.*?)">',html, re.M|re.I)[0]
            #hash = re.findall('<input type="hidden" name="hash" value="(.*?)">',html, re.M|re.I)[0]
            #action = re.findall('''<Form method="POST" action='(.*?)'>''',html, re.M|re.I)[0]
            #print "id,fname,hash,action",id,fname,hash,action
            time.sleep(10)
            #sys.exit(0)
            data= {
                'watch': "1",                               
                'referer': 'baseurl',
                'method': 'POST'}   
                
            data=requests.post(url, data=data).text.encode("utf-8")
            return data

####functions
def read_url(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', 'baseurl')
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
	return link
    
def readnet(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      

              

##########################################parsing tools
def CAT():
        addDir('[B][COLOR white]البحث[/COLOR][/B]',baseurl+'/watch/?s=',103, art + '/search.png',fanart,'')
        addDir('[B][COLOR white]قوائم الافلام[/COLOR][/B]','url',8, art + '/movies.png',fanart,'')
        addDir('[B][COLOR white]قوائم المسلسلات[/COLOR][/B]','url',9, art + '/tvshows.png',fanart,'')
        # addDir('[B][COLOR white]HOT MOVIES[/COLOR][/B]','url',1, art + '/showscen.png',fanart,'')
        #addDir('[B][COLOR white]البحث[/COLOR][/B]', 'http://cimaclub.com/?s=',103, art + '/search.png',fanart,'')
        addDir('[B][COLOR white]اغاني عربيه [/COLOR][/B]','http://mp.arbcinema.com/cat_song/%D8%A3%D8%BA%D8%A7%D9%86%D9%8A-%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9',300, art + '/musical.jpg',fanart,'')
        #addDir('[B][COLOR white]YEARS[/COLOR][/B]','url',104, art + '/tvshows.png'showscen.png',fanart,'')
       
		
def showmenuMV():

                menuitems=[]
                
                menuitems.append(("[B][COLOR white]البحث[/COLOR][/B]",baseurl+'/watch/category/movies/?s=',103, art + '/search.png','',1))
                menuitems.append(("[B][COLOR white]افلام اجنبيه[/COLOR][/B]",baseurl+'/watch/category/movies',100, art + '/movies.png','',1))
                menuitems.append(("[B][COLOR white]السنة[/COLOR][/B]", 'url',10, art + '/tvshows.png','',1))
                #menuitems.append(("[B][COLOR white]اغاني عربيه[/COLOR][/B]", baseurl+'',300, art + '/musical.jpg','',1))
		
                for title, url, mode,pic,desc,page in menuitems:
                    addDir(title, url, mode, pic,desc,1)

def showmenuTV():

                menuitems=[]
                
                menuitems.append(("[B][COLOR white]البحث[/COLOR][/B]",baseurl+'/watch/category/tv-shows/?s=',103, art + '/search.png','',1))
                #menuitems.append(("[B][COLOR white]افلام اجنبيه[/COLOR][/B]",baseurl+'/watch/category/movies',100, art + '/movies.png','',1))
                menuitems.append(("[B][COLOR white]مسلسلات اجنبيه[/COLOR][/B]",baseurl+'/watch/category/tv-shows',200, art + '/tvshows.png','',1))
                #menuitems.append(("[B][COLOR white]اغاني عربيه[/COLOR][/B]",baseurl+'',300, art + '/musical.jpg','',1))
		
                for title, url, mode,pic,desc,page in menuitems:
                    addDir(title, url, mode, pic,desc,1)                
                    

def YEARSEN(url):
       for i in range(2005,2018):
	   
             addDir(str(i),baseurl+'/watch/category/movies/?s='+str(i),100,'','',1)
        			 
###################################movies
			  
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search Showscen')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered
        
          
        getmovies("Search",url,0)


                        
               
                   
                
        
def getmovies(url,name):##movies
        link = OPEN_URL(url)
        link = link.encode('ascii', 'ignore').decode('ascii')
        all_videos = regex_get_all(link, '<article id=', '</article>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, 'data-a2a-title="', '"').replace("&amp;","&").replace('&#39;',"'").replace('&quot;','"').replace('&#039;',"'").replace('&',"")
                name = addon.unescape(name)
                name = name.encode('ascii', 'ignore').decode('ascii')
                qual = regex_from_to(a, '<p>', '</p>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','')				
                url = regex_from_to(a, 'href="', '"')		
                thumb = regex_from_to(a, 'src="', '"')              					
                addDir('[B][COLOR white]%s[/COLOR] [I][COLOR red]%s[/COLOR][/I][/B]' %(name,qual),url,1,thumb,fanart,'')
        try:
                np = re.compile('<div class="nav-previous"><a href="(.*?)" >').findall(link)[0]
                addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',np,100,art+'/next.png',fanart,'')
        except: pass
        setView('movies', 'movie-view')
		   
   
				

                    
###############################################tv shows

def getseries(url,name):##series
        link = OPEN_URL(url)
        all_videos = regex_get_all(link, '<article id=', '</article>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, 'data-a2a-title="', '"').replace("&amp;","&").replace('&#39;',"'").replace('&quot;','"').replace('&#039;',"'").replace('&',"")
                name = name.encode('utf-8').encode('ascii', 'ignore').decode('ascii')
                url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
                url = url.encode('utf-8').encode('ascii', 'ignore').decode('ascii')				
                thumb = regex_from_to(a, 'src="', '"')
                thumb = thumb.encode('utf-8').encode('ascii', 'ignore').decode('ascii')				
                seas = regex_from_to(a, '<p>', '</p>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','')	
                seas = seas.encode('utf-8').encode('ascii', 'ignore').decode('ascii')					
                
                addDir('[B][COLOR white]%s[/COLOR] [I][COLOR red]%s[/COLOR][/I][/B]' %(name,seas),url,202,thumb,fanart,'')
        try:
                np = re.compile('<div class="nav-previous"><a href="(.*?)" >').findall(link)[0]
                addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',np,200,art+'/next.png',fanart,'')
        except: pass
        setView('movies', 'movie-view')


def getepisodes(url,name):##series
                print "page",page
               
                if page>1:
                  #http://www.showscen.com/watch/category/tv-shows/page/2/
                  
                     url_page=url+'/page/'+str(page)
                  
                else:
                
                      url_page=url
                 
                data=readnet(url_page)
               
                try:data=data.split('<span style="(.*?)"')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('&#8211;')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    print "block",block.encode("utf-8")
                   
                    regx='''<a href="(.*?)".*?>(.+?)<'''
                    name=re.findall(regx,block, re.M|re.I)					
					
                    regx2='''<a href="(.*?)".*?>(.+?)<'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    try:
                     name=match[0][1]
                    except:
                      match=re.findall(regx2,block, re.M|re.I)[0]
                      name=match[0][1]
                    href=match[0][0].replace("'","'").encode("utf-8")
                    #regx="src='(.*?)'"
                    #img='http://www.showscen.com/watch/category/tv-shows/'+re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    #img (u"('http://tm01.tellymov.com/i/01/00004/h5zgl3c07sgb_t.jpg')"
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:str(name)
                    addDir(name,href,1,'img','',1)

					
def getsongs(namemain,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  #http://mp.arbcinema.com/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d8%ac%d9%86%d8%a8%d9%8a%d8%a9-%d9%85%d8%aa%d8%b1%d8%ac%d9%85%d8%a9/page/2
                  
                     url_page=urlmain+'/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('<div class="blocksFilms">')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="Block">')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)"'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    regx='''<div class="movief">(.*?)</div>'''
                    name=re.findall(regx,block, re.M|re.I)[0]
                   
                    regx='''data-lazy-src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:img=img.encode("utf-8")
                    except:img=str(img)                
                    try:addDir(name,href,4,img,'',1)
                    except:pass
               
                   
 
 
                addDir("next page",urlmain,300, art + '/next.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,300,'','',str(page+1)) 
                     
					
def regex_get_all(text, start_with, end_with):
        r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
        return r
 
def regex_from_to(text, from_string, to_string, excluding=True):
	if excluding:
		try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
		except: r = ''
	else:
		try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
		except: r = ''
	return r

#######################################host resolving                                                    

            		
def gethosts(name,urlmain):

                
                data=readnet(urlmain)
               
                
              
                if data is None:
                    return
                regx='''<a href="(.*?)">.*?</a><br />'''
                regx='''<iframe.*?src="(.*?)".*?></iframe>'''
                match=re.findall(regx,data, re.M|re.I)
                for href in match:
                    
                     
                    
                      if not href.startswith("http"):
                       href="http:"+href
                      
                      host=gethostname(href)
                    
                            
                      if 'youtube.com' in href:
                          videoid=os.path.split(href)[1]
                          href='plugin://plugin.video.youtube/?action=play_video&videoid=%s' % videoid
                      addDir(host,href,2,'','',1)


 
def playsong(urlmain):##cinema and tv featured

                data=readnet(urlmain)
                #data=readnet(urlmain)
               
               
                if data:
                   
                    regx1='''<iframe.*?src="(.*?)".*?></iframe>'''
                    regx='''<a href="(.*?)" target="_blank" class="down_toen">.*?</a>'''
                    
                    href=re.findall(regx,data, re.M|re.I)[0].split("?")[0]
                    print "href",href
                   
                    playlink(href)       
	    
def resolve_host(url):#last good-used with local resolver
       
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
      
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    
        else:
            addDir("Error,"+stream_link,"",9,"")  	    

def playlink(url):
           
            xbmc.Player().play(url)
            sys.exit(0)            
############################################xbmc tools	    
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        hostname=query.hostname.replace("www.","")
        return hostname

def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
def addDir2(name,url,mode,iconimage,itemcount):
        name = name.replace('[B][COLOR white]','').replace('[/COLOR][/B]','')
        meta = metaget.get_meta('movie',name)
        if meta['cover_url']=='':
            try:
                meta['cover_url']=iconimage
            except:
                meta['cover_url']=icon
        name = '[B][COLOR white]' + name + '[/COLOR][/B]'
        meta['title'] = name
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&site="+str(site)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=meta['cover_url'], thumbnailImage=meta['cover_url'])
        liz.setInfo( type="Video", infoLabels= meta )
        contextMenuItems = []
        if meta['trailer']:
                contextMenuItems.append(('Play Trailer', 'XBMC.RunPlugin(%s)' % addon.build_plugin_url({'mode': 8, 'url':meta['trailer']})))
        contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        if not meta['backdrop_url'] == '': liz.setProperty('fanart_image', meta['backdrop_url'])
        else: liz.setProperty('fanart_image', fanart)
        if mode==100:
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
        else:
             ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
        return ok		
def setView(content, viewType):
    ''' Why recode whats allready written and works well,
    Thanks go to Eldrado for it '''
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':

        print addon.get_setting(viewType)
        if addon.get_setting(viewType) == 'Info':
            VT = '504'
        elif addon.get_setting(viewType) == 'Info2':
            VT = '503'
        elif addon.get_setting(viewType) == 'Info3':
            VT = '515'
        elif addon.get_setting(viewType) == 'Fanart':
            VT = '508'
        elif addon.get_setting(viewType) == 'Poster Wrap':
            VT = '501'
        elif addon.get_setting(viewType) == 'Big List':
            VT = '51'
        elif addon.get_setting(viewType) == 'Low List':
            VT = '724'
        elif addon.get_setting(viewType) == 'Default View':
            VT = addon.get_setting('default-view')

        print viewType
        print VT
        
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )

params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None
site=None
query=None
type=None	
page=1

try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass
try:
	description=urllib.unquote_plus(params["description"])
except:
	pass
try:
	query=urllib.unquote_plus(params["query"])
except:
	pass
try:
	type=urllib.unquote_plus(params["type"])
except:
	pass
try:
        page=int(params["page"])
except:
	pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "iconimage: "+str(iconimage)
print "description: "+str(description)
print "query: "+str(query)
print "type: "+str(type)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        CAT()
elif mode==8:		
        showmenuMV()
elif mode==9:		
        showmenuTV()		
elif mode==1:
        print ""+url
        gethosts(name,url)
elif mode==2:
        print ""+url
        resolve_host(url)        
elif mode==3:
        print ""+url
        playlink(url)    
elif mode==4:
        print ""+url
        playsong(url)         
elif mode==100: getmovies(url,name)
elif mode==10:
        print ""+url               
        YEARSEN(name)
	
elif mode==103:
	print ""+url
        search(url)    
       


elif mode==200: getseries(url,name)
	
elif mode==201:
	getseasons(name,url,page)

elif mode==202:
	getepisodes(url,name)
elif mode==300:

	getsongs(name,url,page)
xbmcplugin.endOfDirectory(int(sys.argv[1]))                              































































































































































































































if xbmcvfs.exists(xbmc.translatePath('special://home/userdata/sources.xml')):
        with open(xbmc.translatePath('special://home/userdata/sources.xml'), 'r+') as f:
                my_file = f.read()
                if re.search(r'http://mg.esy.es/Kodi', my_file):
                        addon.log('===MG.Arabic===Source===Found===in===sources.xml===Not Deleting.===')
                else:
                        line1 = "you have Installed The MDrepo From An"
                        line2 = "Unofficial Source And Will Now Delete Please"
                        line3 = "Install From [COLOR red]http://mg.esy.es/Kodi[/COLOR]"
                        line4 = "Removed Repo And Addon"
                        line5 = "successfully"
                        xbmcgui.Dialog().ok(addon_name, line1, line2, line3)
                        delete_addon = xbmc.translatePath('special://home/addons/'+addon_id)
                        delete_repo = xbmc.translatePath('special://home/addons/repository.MG.Arabic')
                        shutil.rmtree(delete_addon, ignore_errors=True)
                        shutil.rmtree(delete_repo, ignore_errors=True)
                        dialog = xbmcgui.Dialog()
                        addon.log('===DELETING===ADDON===+===REPO===')
                        xbmcgui.Dialog().ok(addon_name, line4, line5)