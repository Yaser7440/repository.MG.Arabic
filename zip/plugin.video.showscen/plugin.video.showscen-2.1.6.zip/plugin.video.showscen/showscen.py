# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys
import base64,hashlib,os,random,re,shutil,string,urllib,urllib2
import xbmc,xbmcaddon,xbmcgui,xbmcplugin,xbmcvfs
import urlresolver
#------------------------------
from md_request import get_params
from md_request import uncensored
from md_request import OPEN_URL
from md_request import readnet2
from md_request import readnet
from md_request import decodeHtml
from md_request import gethostname
from md_request import regex_get_all
from md_request import regex_from_to
from md_request import addDir4
from md_request import addDir
from md_request import addDir2
from md_request import TRAILER
from md_request import resolve_host
from md_request import resolve_host2
from md_request import RESOLVE
#------------------------------
from common import Addon
from md_view import setView
from md_tools import md
try:
    from common import Addon
    from addon.common.net import Net
    from urlresolver import resolve
except:
    print 'Failed to import script.module.mg.arabic.common'
    xbmcgui.Dialog().ok("Showscen Import Failure", "Failed to import addon.common", "A component needed by Showscen is missing on your system")

#By. MG.Arabic http://mg.esy.es/Kodi/ (03/2017)
#Common Cache
import xbmcvfs
dbg = False # Set to false if you don't want debugging
#Common Cache
try:
  import StorageServer
except:
  import storageserverdummy as StorageServer
  cache = StorageServer.StorageServer('plugin.video.showscen')
DB = os.path.join(xbmc.translatePath("special://database"), 'showscen.db')
addon_id='plugin.video.showscen'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, art+'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, art+'fanart.jpg'))
User_Agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36'
show_fushaar = selfAddon.getSetting('enable_fushaar')
fushaar = selfAddon.getSetting('fushaar_url')
show_mov = addon.get_setting('enable_movies')
show_Series4Watch = addon.get_setting('enable_Series4Watch')
show_hdarab = addon.get_setting('enable_hdarab')
show_FooF = addon.get_setting('enable_FooF')
show_mus = addon.get_setting('enable_6arbyat')
baseurl = selfAddon.getSetting('ShowScen_url')
Series4Watch = selfAddon.getSetting('Series4Watch_url')
hdarab = selfAddon.getSetting('hdarab_url')
FooF = selfAddon.getSetting('FooF_url')
tarbyat = selfAddon.getSetting('6arbyat_url')
shahid4u = selfAddon.getSetting('shahid4u_url')
show_shahid4u = addon.get_setting('enable_shahid4u')
cera = selfAddon.getSetting('cera_url')
show_cera = addon.get_setting('enable_cera')




def CAT():
    if show_mov == 'true':addDir('[B][COLOR gold]••ShowsCen••[/COLOR][/B]','url',10,icon,fanart,'')
    if show_cera == 'true':addDir('[B][COLOR white]••Cera Online••[/COLOR][/B]','url',501,art+'mytvshows.png',fanart,'')    
    if show_Series4Watch == 'true':addDir('[B][COLOR purple]••هSeries4Watchه••[/COLOR][/B]','url',400,art+'series4watch.png',fanart,'')	
    if show_hdarab == 'true':addDir('[B][COLOR blue]••هHD-Arabه••[/COLOR][/B]','url',14,art+'hd-arab.png',fanart,'')
    if show_shahid4u== 'true':addDir('[B][COLOR purple]••هShahid4uه••[/COLOR][/B]','url',50,art+'shahid4u.png',fanart,'')	
    if show_FooF == 'true':addDir('[B][COLOR orange]••ه4ooFه••[/COLOR][/B]','url',30,art+'4oof.png',fanart,'')
    if show_mus == 'true':addDir('[B][COLOR tan]••ه6arbyatه••[/COLOR][/B]','url',300,art+'6arbyat.png',fanart,'')
    addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
    setView(addon_id, 'movies', 'movie-view')
    addon.end_of_directory()
	
def MV0():
     addDir('[B][COLOR white]••قوائم الافلام••[/COLOR][/B]','url',12,art+'mymovies.png',fanart,'')
     addDir('[B][COLOR white]••قوائم المسلسلات••[/COLOR][/B]','url',4,art+'mytvshows.png',fanart,'')
     addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
     setView(addon_id, 'movies', 'movie-view')
     addon.end_of_directory()	 
def MV():	
    addDir('[B][COLOR white]البحث[/COLOR][/B]','url',8,art+'search.png',fanart,'')
    addDir('[B][COLOR white]افلام اجنبيه[/COLOR][/B]',baseurl+'/watch/category/movies',1,art+'latest-movies.png',fanart,'')
    addDir('[B][COLOR white]السنة[/COLOR][/B]','url',11,art+'years.png',fanart,'')		
    addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
    setView(addon_id, 'movies', 'movie-view')
    addon.end_of_directory()	
def MV1():	
    addDir('[B][COLOR white]البحث[/COLOR][/B]','url',20,art+'search.png',fanart,'')
    addDir('[B][COLOR white]عــــام[/COLOR][/B]','url',9,art+'genres.png',fanart,'')
	#addDir('[B][COLOR white]تصنيف الافلام بالاحرف[/COLOR][/B]','url',21,art+'years.png',fanart,'')
    addDir('[B][COLOR white]جميع الافلام[/COLOR][/B]', hdarab + '/movies/',18,art+'mymovies.png',fanart,'')
    addDir('[B][COLOR white]الاكثر مشاهدة[/COLOR][/B]',hdarab + '/popular-movies/',18,art+'mymovies.png',fanart,'')
    addDir('[B][COLOR white]الافلام الاعلى تقييم[/COLOR][/B]',hdarab + '/imdb-top/',18,art+'mymovies.png',fanart,'')
	#addDir('[B][COLOR white]المسلسلات[/COLOR][/B]',hdarab + '/tvshows/',18,art+'mytvshows.png',fanart,'')
	#addDir('[B][COLOR white]عــــام[/COLOR][/B]','url',9,art+'genres.png',fanart,'')
	# addDir('[B][COLOR white]السنة[/COLOR][/B]','url',11,art+'years.png',fanart,'')
    addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
    setView(addon_id, 'movies', 'movie-view')
    addon.end_of_directory()		
def MV2():
     addDir('[B][COLOR white]••البحث••[/COLOR][/B]','url',506,art+'search.png',fanart,'')
     addDir('[B][COLOR white]••الافلام••[/COLOR][/B]',cera+'/movies-cinema-translated-arablionz-download-cima4u-watch-tvegy.html/',500,art+'mymovies.png',fanart,'')
     addDir('[B][COLOR white]••مسلسلات انمي••[/COLOR][/B]',cera+'/all-full-anime-series.html/',505,art+'mytvshows.png',fanart,'')
     addDir('[B][COLOR white]••المسلسلات••[/COLOR][/B]',cera+'/tv-series-translated-online.html/',502,art+'mytvshows.png',fanart,'')
     addDir('[B][COLOR white]••الحلقات الاسبوعية••[/COLOR][/B]',cera+'/series-download-watch-episodes-aflamhq-egfire-arablionz-translated-myegy.html/',500,art+'mytvshows.png',fanart,'')
     addDir('[B][COLOR white]••مسلسلات رمضان 2016••[/COLOR][/B]',cera+'/mosalsalat-ramadan-2016-watch-shahid-net-mbc-download-dailymotion-online/',505,art+'mytvshows.png',fanart,'')	 
     addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
     setView(addon_id, 'movies', 'movie-view')
     addon.end_of_directory()	
def Shahid4um():	
                addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
                addDir('[B][COLOR white]البحث[/COLOR][/B]','url',55,art+'search.png',fanart,'')				
                addDir('[B][COLOR white]سنـــة[/COLOR][/B]','url',56,art+'genres.png',fanart,'')
                addDir('[B][COLOR white]••كليبات••[/COLOR][/B]',shahid4u + '/category/اغانى/كليبات',52,art+'genres.png',fanart,'')
                addDir('[B][COLOR white]••رياضة••[/COLOR][/B]',shahid4u + '/category/رياضة',51,fanart,fanart,'')				
                genreliste=[
                ('/category/movies/افلام-عربى', '••افلام عربى••'),
                ('/category/movies/افلام-اجنبى', '••افلام اجنبى••'),
                ('/category/movies/افلام-هندى', '••افلام هندى••'),
                ('/category/افلام-تعرض-قريبا', '••افلام تعرض قريبا••'),
                ('/category/عروض-مصارعة', '••عروض مصارعة••'),
                ('/category/series/مسلسلات-عربى', 'مسلسلات عربى'),
                ('/category/series/مسلسلات-اجنبى', 'مسلسلات اجنبى'),
                ('/category/series/anime', 'مسلسلات انمي'),
                ('/category/series/مسلسلات-تركية', 'مسلسلات تركية'),
                ('/category/series/مسلسلات-كاملة', 'مسلسلات كاملة'),
                ('/category/ramadan/مسلسلات-رمضان-2016', 'رمضان 2016')]				
                #addDir("Search", shahid4u + '/?s=',3,'resources/search.png','',1)
                for url, title  in genreliste:
                    url= shahid4u + url
                    if '••' in title:
                      addDir('[B][COLOR white]%s[/COLOR][/B]' %title, url, 51,art+'musical.jpg','',1)
                    else:
                       addDir('[B][COLOR white]%s[/COLOR][/B]' %title, url,53,art+'musical.jpg','',1)
                       setView(addon_id, 'movies', 'movie-view')
                       addon.end_of_directory()	
	
def MVT():	
                addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
                addDir('[B][COLOR white]البحث[/COLOR][/B]','url',35,art+'search.png',fanart,'')				
                addDir('[B][COLOR white]عــــام[/COLOR][/B]','url',32,art+'genres.png',fanart,'')
                genreliste=[
				('/category/افلام/افلام-اجنبى', 'افلام اجنبية'),
				('/category/افلام/افلام-اجنبى/box-office', 'افلام بوكس اوفيس'),
				('/category/افلام/افلام-عربى', 'افلام عربي'),
				('/category/افلام/افلام-كارتون/كارتون-مدبلج', 'افلام كرتوني مدبلج'),
				('/category/افلام/افلام-هندى', 'افلام هندي'),
				('/category/افلام/افلام-كارتون', 'افلام انيمي و كرتون'),
				('/category/مسلسلات-اجنبى', 'مسلسلات اجنبى'),
				('/category/مسلسلات/مسلسلات-عربى', 'مسلسلات عربى')]
                
                #addDir("Search", tarbyat + '/search?q=',3,'resources/search.png','',1)
                for url, title  in genreliste:
                    url= FooF + url
                    if 'افلام' in title:
                      addDir('[B][COLOR white]%s[/COLOR][/B]' %title, url, 31,art+'musical.jpg','',1)
                    else:
                       addDir('[B][COLOR white]%s[/COLOR][/B]' %title, url,62,art+'musical.jpg','',1)
                       setView(addon_id, 'movies', 'movie-view')
                       addon.end_of_directory()	


def series4watch():	
                addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
                addDir('[B][COLOR white]البحث[/COLOR][/B]','url',407,art+'search.png',fanart,'')
                addDir('[B][COLOR white]سنـــة[/COLOR][/B]','url',403,art+'genres.png',fanart,'')
                addDir('[B][COLOR white]عــــام[/COLOR][/B]','url',401,art+'genres.png',fanart,'')
                genreliste=[
                ('/category/افلام-اجنبي/', 'افلام اجنبي'),
                ('/category/افلام-عربي/', 'افلام عربي'),
                ('/category/افلام-هندي/', 'افلام هندي'),
                ('/category/افلام-اسيوية/', 'افلام اسيوية'),
                ('/category/افلام-انيمي/', 'افلام انيمي'),
                ('/category/مسلسلات-اجنبي/', 'مسلسلات اجنبي'),
                ('/category/مسلسلات-عربي/', 'مسلسلات عربي'),
                ('/category/مسلسلات-تركي/', 'مسلسلات تركي'),
                ('/category/مسلسلات-انيمي/', 'مسلسلات انيمي'),
                ('/category/عروض-مصارعة/', 'عروض مصارعة')]

                
                #addDir("Search", tarbyat + '/search?q=',3,'resources/search.png','',1)
                for url, title  in genreliste:
                    url= Series4Watch + url
                    if 'افلام' in title:
                      addDir('[B][COLOR white]%s[/COLOR][/B]' %title, url, 402,art+'musical.jpg',art+'cover.png',1)
                    else:
                       addDir('[B][COLOR white]%s[/COLOR][/B]' %title, url,405,art+'musical.jpg',art+'cover.png',1)
                       setView(addon_id, 'movies', 'movie-view')
                       addon.end_of_directory()	
def GENREseries4watch(url):
	genres=['Action','Adventure','Animation','Biography','Comedy','Crime','Documentary','Drama','Family','Fantasy','HDTV','History','Horror','Music','Musical','Mystery','NA','Romance','Sci-Fi','Short','Sport','Supergirl','Talk-Show','Thriller','Trailer','War','Western']
        for g in genres:
                url= Series4Watch + '/genre/'+g.lower()+'/'
                print url
                addDir('[B][COLOR white]%s[/COLOR][/B]' %g,url,402,art+'genres.png',fanart)
                setView(addon_id, 'movies', 'movie-view')
                	
def AZHDARABMV(url):
       for i in range(2005,2018):	   
             addDir('[B][I][COLOR white]%s[/COLOR][/I][/B]'%str(i), Series4Watch + '/release-year/'+str(i)+'/',402,art+'years.png','',1)
             setView(addon_id, 'movies', 'movie-view')
	
				
def TV():
        #addDir('[B][COLOR white]Most Favorite[/COLOR][/B]',baseurl+'/movie/filter/series/favorite/all/all/all/all/all',2,icon,fanart,'')
        #addDir('[B][COLOR white]Most Ratings[/COLOR][/B]',baseurl+'/movie/filter/series/rating/all/all/all/all/all',2,icon,fanart,'')
        #addDir('[B][COLOR white]Most Viewed[/COLOR][/B]',baseurl+'/movie/filter/series/view/all/all/all/all/all',2,icon,fanart,'')
        #addDir('[B][COLOR white]Top IMDB[/COLOR][/B]',baseurl+'/watch/category/tv-shows',2,icon,fanart,'')
        #addDir('[B][COLOR white]Country[/COLOR][/B]',baseurl+'/movie/filter/series',10,icon,fanart,'')
        addDir('[B][COLOR white]البحث[/COLOR][/B]','url',13,art+'search.png',fanart,'')
        addDir('[B][COLOR white]مسلسلات اجنبيه[/COLOR][/B]',baseurl+'/watch/category/tv-shows',2,art+'mytvshows.png',fanart,'')
        #addDir('[B][COLOR white]Genre[/COLOR][/B]',baseurl+'/movie/filter/series',9,icon,fanart,'')
        #addDir('[B][COLOR white]Year[/COLOR][/B]',baseurl+'/movie/filter/series',11,icon,fanart,'')
        addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
        setView(addon_id, 'movies', 'movie-view')
        addon.end_of_directory()

def GENRE(url):
	genres=['Action-Movies','Adventure-Movies','Animation-Movies','Biography-Movies','Bollywood-Movies','Comedy-Movies','Crime-Movies','Documentary-Movies','Drama-Movies','Dual-Audio-Movies','Family-Movies','Fantasy-Movies','Film-Noir-Movies','Foreign-Movies','Hindi-Dubbed-Movies','History-Movies','Horror-Movies','Music-Movies','Musical-Movies','Mystery','Romance','Sci-Fi','Sport','Thriller','Tollywood','War','Western']
        for g in genres:
                url= hdarab + '/category/'+g.lower()+'/'
                print url
                addDir('[B][COLOR white]%s[/COLOR][/B]' %g,url,18,art+'genres.png',fanart)
                setView(addon_id, 'movies', 'movie-view')



def GENRE2(url):
	genres=['اكشن','اثارة','تاريخي','جريمة','حربي','خيال-علمي','دراما','رعب','رومانسي','رياضي','سيرة-ذاتية','عائلي','غموض','فانتازيا','كرتون','مغامرات','موسيقي','ويسترن']
        for g in genres:
                url= FooF + '/genre/'+g.lower()
                print url
                addDir('[B][COLOR white]%s[/COLOR][/B]' %g,url,31,art+'genres.png',fanart)
                setView(addon_id, 'movies', 'movie-view')

def COUNTRY(url):
        link = OPEN_URL(url)
        link = link.encode('ascii', 'ignore')
        match=re.compile('<input class="country-ids" value="(.*?)" name=".*?"\n.*?type="checkbox" >(.*?)</label>').findall(link)
        for url2,name in match:
                name = name.replace(' ','')
                if '/series' in url:
                        url2 = baseurl + '/movie/filter/series/latest/all/'+url2+'/all/all/all'
                        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url2,2,icon,fanart,'')
                else:
                        url2 = baseurl + '/movie/filter/movie/latest/all/'+url2+'/all/all/all'
                        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url2,1,icon,fanart,'')
                        setView(addon_id, 'movies', 'movie-view')
                        addon.end_of_directory()


def YEAR(url):
       for i in range(2005,2018):
	   
             addDir('[B][I][COLOR white]%s[/COLOR][/I][/B]'%str(i),baseurl+'/watch/category/movies/?s='+str(i),1,art+'years.png','',1)
             setView(addon_id, 'movies', 'movie-view')

def YEARMV1(url):
	genres=['#','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
        for g in genres:
                url= hdarab + '/movies-az-list/'+g.lower()+'/'
                print url
                addDir('[B][COLOR white]%s[/COLOR][/B]' %g,url,18,art+'genres.png',fanart)
                setView(addon_id, 'movies', 'movie-view')


def YEARShahid4u(url):
       for i in range(2005,2018):	   
             addDir('[B][I][COLOR white]%s[/COLOR][/I][/B]'%str(i), shahid4u + '/?s='+str(i),51,art+'years.png','',1)
             setView(addon_id, 'movies', 'movie-view')

			 
def INDEX(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<article id=', '</article>')
	for a in all_videos:
		name = regex_from_to(a, 'data-a2a-title="', '"').replace("مشاهدة مباشرة فيلم","").replace("&amp;","&").replace('&#39;',"'").replace('&quot;','"').replace('&#39;',"'")
		url = regex_from_to(a, '<a href="', '" rel="bookmark">').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')
		desc = regex_from_to(a, '<p>', '</p>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		genre = regex_from_to(a, '<span class="itemprop">', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		date = regex_from_to(a, '<span class="itemprop">', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		credits = regex_from_to(a, '<span class="itemprop">', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		fanart = regex_from_to(a, 'src="', '"').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')				
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,3,icon,fanart,desc,genre,date,credits)
	try:
		nextp=re.compile('<div class="nav-previous"><a href="(.*?)" >').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,1,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')


def INDEX2(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	all_videos = regex_get_all(link, '<article id=', '</article>')
	for a in all_videos:
		name = regex_from_to(a, 'data-a2a-title="', '"').replace("مشاهدة مباشرة فيلم","").replace("&amp;","&").replace('&#39;',"'").replace('&quot;','"').replace('مشاهدة مباشرة مسلسل',"")
		url = regex_from_to(a, '<a href="', '" rel="bookmark">').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')
		desc = regex_from_to(a, '<p>', '</p>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		genre = regex_from_to(a, '<span class="itemprop">', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		date = regex_from_to(a, '<span class="itemprop">', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		credits = regex_from_to(a, '<span class="itemprop">', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		fanart = regex_from_to(a, 'src="', '"').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')				
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,6,icon,fanart,desc,genre,date,credits)
	try:
		nextp=re.compile('<div class="nav-previous"><a href="(.*?)" >').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,2,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')

def INDEX3(url):
	link = OPEN_URL(url)
	
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<li class="movie-list-item">', '</div>\s*</article>\s*</li>')
	for a in all_videos:
		name = regex_from_to(a, '<h2 class="movie-title">', '</h2>')#.replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('&quot;','"').replace('&#39;',"'").replace('&#039;',"'")
		url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'data-src="', '"')#.replace("(","").replace("'","")
		desc = regex_from_to(a, '<h2 class="movie-title">', '</h2>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		genre =regex_from_to(a, '<p itemprop="description">', '</p>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		date = regex_from_to(a, '<div class="movie-year">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		credits = regex_from_to(a, '<span class="itemprop">', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		fanart = regex_from_to(a, 'src="', '"').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,19,icon,fanart,desc,genre,date,credits)
	try:
		nextp= hdarab + '/movies/'+ re.compile('<a href="(.*?)" rel="next">').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,18,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')
def INDEX4(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="moviefilm">', '</div>\s*</div>')
	for a in all_videos:
		name = regex_from_to(a, '<div class="movief"><a href=".*?>', '</a>').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('اون لاين','').replace('&#8217;',"").replace('&#8211;',"")
		url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')#.replace("(","").replace("'","")
		desc = regex_from_to(a, '<div class="movieDesc">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		genre =regex_from_to(a, '<div class="ribbon">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		date = regex_from_to(a, '<div class="movie-year">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		credits = regex_from_to(a, '<span class="itemprop">', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		fanart = regex_from_to(a, 'srcset="', '"').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,33,icon,fanart,desc,genre,date,credits)
	try:
		nextp=re.compile('<li><a href="(.*?)">الصفحة التالية &laquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,31,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')
def INDEXF4(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="moviefilm">', '</div>\s*</div>')
	for a in all_videos:
		name = regex_from_to(a, '<div class="movief"><a href=".*?>', '</a>').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('اون لاين','').replace('&#8217;',"").replace('&#8211;',"")
		url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')#.replace("(","").replace("'","")
		desc = regex_from_to(a, '<div class="movieDesc">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		genre =regex_from_to(a, '<div class="ribbon">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		date = regex_from_to(a, '<div class="movie-year">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		credits = regex_from_to(a, '<span class="itemprop">', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		fanart = regex_from_to(a, 'srcset="', '"').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,63,icon,fanart,desc,genre,date,credits)
	try:
		nextp=re.compile('<li><a href="(.*?)">الصفحة التالية &laquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,62,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')

def getlinkF(url):##FOOF 
    link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
    all_videos = regex_get_all(link, '<h2 class="module_title">', '</a>\s*</h2>')
    for a in all_videos:
        url = regex_from_to(a, 'href="', '"')
        INDEXF5(url)

	
def INDEXF5(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="moviefilm">', '</div>\s*</div>')
	for a in all_videos:
		name = regex_from_to(a, '<div class="movief"><a href=".*?>', '</a>').replace("</span>",":").replace("&amp;","&").replace('فيلم',"").replace('اون لاين','').replace('&#8217;',"").replace('&#8211;',"")
		url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')#.replace("(","").replace("'","")
		desc = regex_from_to(a, '<div class="movieDesc">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		genre =regex_from_to(a, '<div class="ribbon">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		date = regex_from_to(a, '<div class="movie-year">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		credits = regex_from_to(a, '<span class="itemprop">', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		fanart = regex_from_to(a, 'srcset="', '"').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,33,icon,fanart,desc,genre,date,credits)
	try:
		nextp=re.compile('<li><a href="(.*?)">الصفحة التالية &laquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,64,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')	
def INDEX5(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="movie">', '</a>')
	for a in all_videos:
		name = regex_from_to(a, 'alt="', '"').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('اون لاين','').replace('&#8217;',"").replace('&#8211;',"")
		url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')#.replace("(","").replace("'","")
		desc = regex_from_to(a, '<p>', '</p>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		genre =regex_from_to(a, '<i class="fa fa-film"></i>', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		date = regex_from_to(a, '</h2>', '</h2>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		credits = regex_from_to(a, '<i class="fa fa-star StarLabels"><span>', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		fanart = regex_from_to(a, 'src="', '"').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,404,icon,fanart,desc,genre,date,'[B][COLOR yellow]IMDB[/COLOR][/B]'+credits)
	try:
		nextp= re.compile('<li><a href="(.*?)">الصفحة التالية &laquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,402,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')
def INDEX6(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="movie">', '</a>')
	for a in all_videos:
		name = regex_from_to(a, 'alt="', '"').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('اون لاين','').replace('&#8217;',"").replace('&#8211;',"")
		url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')#.replace("(","").replace("'","")
		desc = regex_from_to(a, '<p>', '</p>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		genre =regex_from_to(a, '<i class="fa fa-film"></i>', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		date = regex_from_to(a, '</h2>', '</h2>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		credits = regex_from_to(a, '<i class="fa fa-star StarLabels"><span>', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		fanart = regex_from_to(a, 'src="', '"').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,404,icon,fanart,desc,genre,date,'[B][COLOR yellow]IMDB[/COLOR][/B]'+credits)
	try:
		nextp= re.compile('<li><a href="(.*?)">الصفحة التالية &laquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,405,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')
def INDEX8(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="moviefilm">', '</div>\s*</div>')
	for a in all_videos:
		name = regex_from_to(a, '<div class="movief"><a href=".*?>', '</a>').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('اون لاين','').replace('&#8217;',"").replace('&#8211;',"").replace('مشاهدة',"").replace('فيلم',"")
		url = regex_from_to(a, '<div class="movief"><a href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')#.replace("(","").replace("'","")
		desc = regex_from_to(a, '<div class="movieDesc">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		genre =regex_from_to(a, '<i class="fa fa-film"></i>', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		date = regex_from_to(a, '</h2>', '</h2>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		credits = regex_from_to(a, '<i class="fa fa-star StarLabels"><span>', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		fanart = regex_from_to(a, 'src="', '"').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url+'?watch=1',40,icon,fanart,desc,genre,date,credits)
	try:
		nextp= re.compile('<li><a href="(.*?)">.*? &laquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,51,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')

def INDEX9(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="moviefilm">', '</div>\s*</div>')
	for a in all_videos:
		name = regex_from_to(a, '<div class="movief"><a href=".*?>', '</a>').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('اون لاين','').replace('&#8217;',"").replace('&#8211;',"").replace('مشاهدة',"").replace('فيلم',"")
		url = regex_from_to(a, '<div class="movief"><a href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')#.replace("(","").replace("'","")
		desc = regex_from_to(a, '<div class="movieDesc">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		genre =regex_from_to(a, '<i class="fa fa-film"></i>', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		date = regex_from_to(a, '</h2>', '</h2>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		credits = regex_from_to(a, '<i class="fa fa-star StarLabels"><span>', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		fanart = regex_from_to(a, 'src="', '"').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,3,icon,fanart,desc,genre,date,credits)
	try:
		nextp= re.compile('<li><a href="(.*?)">.*? &laquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,52,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')

def INDEX10(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="moviefilm">', '</div>\s*</div>')
	for a in all_videos:
		name = regex_from_to(a, '<div class="movief"><a href=".*?>', '</a>').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('اون لاين','').replace('&#8217;',"").replace('&#8211;',"").replace('مشاهدة',"").replace('فيلم',"")
		url = regex_from_to(a, '<div class="movief"><a href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')#.replace("(","").replace("'","")
		desc = regex_from_to(a, '<div class="movieDesc">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		genre =regex_from_to(a, '<i class="fa fa-film"></i>', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		date = regex_from_to(a, '</h2>', '</h2>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		credits = regex_from_to(a, '<i class="fa fa-star StarLabels"><span>', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		fanart = regex_from_to(a, 'src="', '"').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,54,icon,fanart,desc,genre,date,credits)
	try:
		nextp= re.compile('<li><a href="(.*?)">.*? &laquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,53,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')

def INDEX11(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="moviefilm">', '</div>\s*</div>')
	for a in all_videos:
		name = regex_from_to(a, '<div class="movief"><a href=".*?>', '</a>').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('اون لاين','').replace('&#8217;',"").replace('&#8211;',"").replace('مشاهدة',"").replace('فيلم',"")
		url = regex_from_to(a, '<div class="movief"><a href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')#.replace("(","").replace("'","")
		desc = regex_from_to(a, '<div class="movieDesc">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		genre =regex_from_to(a, '<i class="fa fa-film"></i>', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		date = regex_from_to(a, '</h2>', '</h2>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		credits = regex_from_to(a, '<i class="fa fa-star StarLabels"><span>', '</span>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		fanart = regex_from_to(a, 'src="', '"').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url+'?watch=1',40,icon,fanart,desc,genre,date,credits)
	try:
		nextp= re.compile('<li><a href="(.*?)">.*? &laquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,54,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')	
def INDEX7(url):
                print "page",page
               
                if page>1:
                  #http://www.showscen.com/watch/category/tv-shows/page/2/
                  
                     url_page=url+'/page/'+str(page)
                  
                else:
                
                      url_page=url
                 
                data=readnet(url_page)
               
                try:data=data.split('<span style="(.*?)"')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('&#8211;')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    print "block",block.encode("utf-8")
                   
                    regx='''<a href="(.*?)".*?>(.+?)<'''
                    name=re.findall(regx,block, re.M|re.I)					
					
                    regx2='''<a href="(.*?)".*?>(.+?)<'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    try:
                     name=match[0][1]
                    except:
                      match=re.findall(regx2,block, re.M|re.I)[0]
                      name=match[0][1]
                    href=match[0][0].replace("'","'").encode("utf-8")
                    #regx="src='(.*?)'"
                    #img='http://www.showscen.com/watch/category/tv-shows/'+re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    #img (u"('http://tm01.tellymov.com/i/01/00004/h5zgl3c07sgb_t.jpg')"
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:str(name)
                    addDir(name,href,3,'img','',1)

def INDEX12(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<li class="moviefilm">', '</li>')
	for a in all_videos:
		name = regex_from_to(a, '<div class="movieDesc">', '</div>').replace("مشاهدة","").replace("فيلم","").replace('مترجم','').replace('&amp;','').replace('اون',"").replace("&#8217;","").replace("للاين","").replace("عالية","").replace("جودة","")
		url = regex_from_to(a, 'href="', '"')#.replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')
		desc = regex_from_to(a, '<div class="movieDesc">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		genre =regex_from_to(a, '<div class="ribbon">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		date = regex_from_to(a, '</h2>', '</h2>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		credits = regex_from_to(a, '<div class="imdbRating">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		fanart = regex_from_to(a, 'src="', '"').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,3,icon,fanart,desc,genre,date,'[B][COLOR yellow]IMDB[/COLOR][/B]'+credits)			
	try:
		nextp=re.compile('<li><a href="(.*?)">.*?&laquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,500,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')
def INDEX13(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<li class="moviefilm">', '</li>')
	for a in all_videos:
		name = regex_from_to(a, '<div class="movief"><a href=".*?>', '</a>').replace("مشاهدة","").replace("فيلم","").replace('مترجم','').replace('&amp;','').replace('اون',"").replace("&#8217;","").replace("للاين","").replace("عالية","").replace("جودة","")
		url = regex_from_to(a, 'href="', '"')#.replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')
		desc = regex_from_to(a, '<div class="movieDesc">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		genre =regex_from_to(a, '<div class="ribbon">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		date = regex_from_to(a, '</h2>', '</h2>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		credits = regex_from_to(a, '<div class="imdbRating">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		fanart = regex_from_to(a, 'src="', '"').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,503,icon,fanart,desc,genre,date,credits)
	try:
		nextp=re.compile('<li><a href="(.*?)">.*?&laquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,502,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')
def INDEX14(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<li class="moviefilm">', '</li>')
	for a in all_videos:
		name = regex_from_to(a, '<div class="ribbon">', '</div>').replace("مشاهدة","").replace("فيلم","").replace('مترجم','').replace('&amp;','').replace('اون',"").replace("&#8217;","").replace("للاين","").replace("عالية","").replace("جودة","")
		url = regex_from_to(a, 'href="', '"')#.replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')
		desc = regex_from_to(a, '<div class="movieDesc">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		genre =regex_from_to(a, '<div class="ribbon">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		date = regex_from_to(a, '</h2>', '</h2>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		credits = regex_from_to(a, '<div class="imdbRating">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		fanart = regex_from_to(a, 'src="', '"').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,504,icon,fanart,desc,genre,date,credits)
	try:
		nextp=re.compile('<li><a href="(.*?)">.*?&laquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,503,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')
def INDEX15(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<li class="moviefilm">', '</li>')
	for a in all_videos:
		name = regex_from_to(a, '<div class="ribbon">', '</div>').replace("مشاهدة","").replace("فيلم","").replace('مترجم','').replace('&amp;','').replace('اون',"").replace("&#8217;","").replace("للاين","").replace("عالية","").replace("جودة","")
		url = regex_from_to(a, 'href="', '"')#.replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')
		desc = regex_from_to(a, '<div class="movieDesc">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		genre =regex_from_to(a, '<div class="ribbon">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		date = regex_from_to(a, '</h2>', '</h2>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		credits = regex_from_to(a, '<div class="imdbRating">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		fanart = regex_from_to(a, 'src="', '"').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,3,icon,fanart,desc,genre,date,credits)
	try:
		nextp=re.compile('<link rel="next" href="(.*?)"/>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,504,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')
def INDEX16(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<li class="moviefilm">', '</li>')
	for a in all_videos:
		name = regex_from_to(a, '<div class="movieDesc">', '</div>').replace("مشاهدة","").replace("فيلم","").replace('مترجم','').replace('&amp;','').replace('اون',"").replace("&#8217;","").replace("للاين","").replace("عالية","").replace("جودة","")
		url = regex_from_to(a, 'href="', '"')#.replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')
		desc = regex_from_to(a, '<div class="movieDesc">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		genre =regex_from_to(a, '<div class="ribbon">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		date = regex_from_to(a, '</h2>', '</h2>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
		credits = regex_from_to(a, '<div class="imdbRating">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		fanart = regex_from_to(a, 'src="', '"').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,504,icon,fanart,desc,genre,date,credits)
	try:
		nextp=re.compile('<li><a href="(.*?)">.*?&laquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,505,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')	
def getsongsmain():

                genreliste=[('/aghany-songs/?page=1', 'احدث الأعمال الفنية'),
				('/cat/saudi-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb3\xd8\xb9\xd9\x88\xd8\xaf\xd9\x8a\xd8\xa9'),
				('/cat/kuwaiti-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x83\xd9\x88\xd9\x8a\xd8\xaa\xd9\x8a\xd8\xa9'),
				('/cat/bahraini-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xa8\xd8\xad\xd8\xb1\xd9\x8a\xd9\x86\xd9\x8a\xd8\xa9'),
				('/cat/uae-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xa7\xd9\x85\xd8\xa7\xd8\xb1\xd8\xa7\xd8\xaa\xd9\x8a\xd8\xa9'),
				('/cat/qatar-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x82\xd8\xb7\xd8\xb1\xd9\x8a\xd8\xa9'),
				('/cat/omani-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb9\xd9\x85\xd8\xa7\xd9\x86\xd9\x8a\xd8\xa9'),
				('/cat/yemeni-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x8a\xd9\x85\xd9\x86\xd9\x8a\xd8\xa9'),
				('/cat/iraqi-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb9\xd8\xb1\xd8\xa7\xd9\x82\xd9\x8a\xd8\xa9'),
				('/cat/lebanese-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x84\xd8\xa8\xd9\x86\xd8\xa7\xd9\x86\xd9\x8a\xd8\xa9'),
				('/cat/jordan-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xa7\xd8\xb1\xd8\xaf\xd9\x86\xd9\x8a\xd8\xa9'),
				('/cat/palestinian-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x81\xd9\x84\xd8\xb3\xd8\xb7\xd9\x8a\xd9\x86\xd9\x8a\xd8\xa9'),
				('/cat/syrian-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb3\xd9\x88\xd8\xb1\xd9\x8a\xd8\xa9'),
				('/cat/egyptian-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x85\xd8\xb5\xd8\xb1\xd9\x8a\xd8\xa9'),
				('/cat/sudanese-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb3\xd9\x88\xd8\xaf\xd8\xa7\xd9\x86\xd9\x8a\xd8\xa9'),
				('/cat/moroccan-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x85\xd8\xba\xd8\xb1\xd8\xa8\xd9\x8a\xd8\xa9'),
				('/cat/tunisian-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xaa\xd9\x88\xd9\x86\xd8\xb3\xd9\x8a\xd8\xa9'),
				('/cat/algerian-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xac\xd8\xb2\xd8\xa7\xd8\xa6\xd8\xb1\xd9\x8a\xd8\xa9 '),
				('/cat/libyan-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x84\xd9\x8a\xd8\xa8\xd9\x8a\xd8\xa9 '),
				('/cat/arabian-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb9\xd8\xb1\xd8\xa8\xd9\x8a\xd8\xa9'),
				('/cat/concerts/', '\xd8\xad\xd9\x81\xd9\x84\xd8\xa7\xd8\xaa \xd9\x88 \xd8\xac\xd9\x84\xd8\xb3\xd8\xa7\xd8\xaa '),
				('/hashtag/\xd8\xba\xd9\x8a\xd8\xb1_\xd9\x85\xd8\xad\xd8\xaf\xd8\xaf/', '\xd8\xba\xd9\x8a\xd8\xb1_\xd9\x85\xd8\xad\xd8\xaf\xd8\xaf'),
				('/hashtag/\xd9\x85\xd9\x87\xd8\xb1\xd8\xac\xd8\xa7\xd9\x86\xd8\xa7\xd8\xaa/', '\xd9\x85\xd9\x87\xd8\xb1\xd8\xac\xd8\xa7\xd9\x86\xd8\xa7\xd8\xaa'),
				('/hashtag/\xd8\xb4\xd9\x8a\xd9\x84\xd8\xa9/', '\xd8\xb4\xd9\x8a\xd9\x84\xd8\xa9'),
				('/hashtag/\xd8\xb3\xd9\x86\xd9\x82\xd9\x84/', '\xd8\xb3\xd9\x86\xd9\x82\xd9\x84'),
				('/hashtag/\xd8\xb3\xd8\xa7\xd9\x85\xd8\xb1\xd9\x8a\xd8\xa7\xd8\xaa/', '\xd8\xb3\xd8\xa7\xd9\x85\xd8\xb1\xd9\x8a\xd8\xa7\xd8\xaa'), 
				('/hashtag/\xd8\xb4\xd8\xb9\xd8\xa8\xd9\x8a\xd8\xa7\xd8\xaa/', '\xd8\xb4\xd8\xb9\xd8\xa8\xd9\x8a\xd8\xa7\xd8\xaa'),
				('/hashtag/\xd8\xb1\xd9\x8a\xd9\x85\xd9\x83\xd8\xb3\xd8\xa7\xd8\xaa/', '\xd8\xb1\xd9\x8a\xd9\x85\xd9\x83\xd8\xb3\xd8\xa7\xd8\xaa'), 
				('/hashtag/\xd8\xad\xd9\x81\xd9\x84\xd8\xa7\xd8\xaa/', '\xd8\xad\xd9\x81\xd9\x84\xd8\xa7\xd8\xaa'),
				('/hashtag/\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa/', '\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa'), 
				('/hashtag/\xd9\x88\xd8\xb7\xd9\x86\xd9\x8a\xd8\xa7\xd8\xaa/', '\xd9\x88\xd8\xb7\xd9\x86\xd9\x8a\xd8\xa7\xd8\xaa'),
				('/hashtag/\xd9\x85\xd9\x88\xd8\xb4\xd8\xad\xd8\xa7\xd8\xaa/', '\xd9\x85\xd9\x88\xd8\xb4\xd8\xad\xd8\xa7\xd8\xaa'),
				('/hashtag/\xd9\x85\xd9\x88\xd8\xa7\xd9\x88\xd9\x8a\xd9\x84/', '\xd9\x85\xd9\x88\xd8\xa7\xd9\x88\xd9\x8a\xd9\x84'),
				('/hashtag/\xd8\xac\xd9\x84\xd8\xb3\xd8\xa7\xd8\xaa/', '\xd8\xac\xd9\x84\xd8\xb3\xd8\xa7\xd8\xaa'),
				('/hashtag/\xd9\x82\xd8\xb5\xd8\xa7\xd8\xa6\xd8\xaf/', '\xd9\x82\xd8\xb5\xd8\xa7\xd8\xa6\xd8\xaf'),
				('/hashtag/اغاني_اطفال/', 'اطفال')]

                
                #addDir("Search", tarbyat + '/search?q=',3,'resources/search.png','',1)
                for url, title  in genreliste:
                    url= tarbyat + url
                    if 'اغاني' in title:
                      addDir('[B][COLOR white]%s[/COLOR][/B]' %title, url, 301,art+'musical.jpg','',1)
                    else:
                       addDir('[B][COLOR white]%s[/COLOR][/B]' %title, url,304,art+'musical.jpg','',1)
                       setView(addon_id, 'movies', 'movie-view')


def getartists(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<li class="col-md-4', '</i>')
	for a in all_videos:
		name = regex_from_to(a, "alt='", "'").replace("تحميل كاملة","")
		url = tarbyat + regex_from_to(a, "href='", "'").replace("&amp;","&")
		icon = tarbyat + regex_from_to(a, "src='", "'")
		#qual = regex_from_to(a, '<p>', '</p>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,302,icon,fanart,'')
	try:
		nextp= tarbyat + re.compile('<a href="(.*?)"><i class="fa fa-angle-left">').findall(link)[1]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,301,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')

def getalbams(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, "<div class='col-md-2'>", "<span class='siic3'>")
	for a in all_videos:
		name = regex_from_to(a, "alt='", "'").replace("تحميل كاملة","")
		url = tarbyat + regex_from_to(a, "href='", "'").replace("&amp;","&")
		icon = tarbyat + regex_from_to(a, "src='", "'")
		qual = regex_from_to(a, '<p>', '</p>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,303,icon,fanart,'')
	try:
		nextp= tarbyat + re.compile('<a href="(.*?)"><i class="fa fa-angle-left">').findall(link)[1]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,302,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')
	
def getsongs(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, "<li class='col-md-8", "</li>")
	for a in all_videos:
		name = regex_from_to(a, "<a href='.*?'>", "</a>").replace("تحميل كاملة","")
		url = tarbyat + regex_from_to(a, "href='", "'").replace("&amp;","&")
		icon = tarbyat + regex_from_to(a, "src='", "'")
		qual = regex_from_to(a, "<li class='col-md-4 col-xs-5'>", "</li>").replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,17,art+'musical.jpg',fanart,'')
	try:
		nextp= tarbyat + re.compile('<a href="(.*?)"><i class="fa fa-angle-left">').findall(link)[1]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,303,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')


def getnewsongs(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, "<li class='col-md-6 col-xs-7'>", "</li>")
	for a in all_videos:
		name = regex_from_to(a, "<a href='.*?'>", "</a>").replace("تحميل كاملة","")
		url = tarbyat + regex_from_to(a, "href='", "'").replace("&amp;","&")
		icon = tarbyat + regex_from_to(a, "src='", "'")
		qual = regex_from_to(a, "<li class='col-md-4 col-xs-5'>", "</li>").replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,17,art+'musical.jpg',fanart,'')
	try:
		nextp=re.compile('</li> <li><a href="(.*?)" rel="next">').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,304,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')



def getepisodes(url,name):##series
                print "page",page
               
                if page>1:
                  #http://www.showscen.com/watch/category/tv-shows/page/2/
                  
                     url_page=url+'/page/'+str(page)
                  
                else:
                
                      url_page=url
                 
                data=readnet(url_page)
               
                try:data=data.split('<span style="(.*?)"')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('&#8211;')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    print "block",block.encode("utf-8")
                   
                    regx='''<a href="(.*?)".*?>(.+?)<'''
                    name=re.findall(regx,block, re.M|re.I)					
					
                    regx2='''<a href="(.*?)".*?>(.+?)<'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    try:
                     name=match[0][1]
                    except:
                      match=re.findall(regx2,block, re.M|re.I)[0]
                      name=match[0][1]
                    href=match[0][0].replace("'","'").encode("utf-8")
                    #regx="src='(.*?)'"
                    #img='http://www.showscen.com/watch/category/tv-shows/'+re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    #img (u"('http://tm01.tellymov.com/i/01/00004/h5zgl3c07sgb_t.jpg')"
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:str(name)
                    addDir(name,href,3,'img','',1)







def LINKS(url):
                data=readnet(url)
               
                
              
                if data is None:
                    return
                regx='''<a href="(.*?)">.*?</a><br />'''
                regx='''<iframe.*?src="(.*?)".*?></iframe>'''
                match=re.findall(regx,data, re.M|re.I)
                for href in match:
                    
                     
                    
                      if not href.startswith("http"):
                       href="http:"+href
                      
                      host=gethostname(href)
                    
                            
                      # if 'youtube.com' in href:
                          # videoid=os.path.split(href)[1]
                          # href='plugin://plugin.video.youtube/?action=play_video&videoid=%s' % videoid
                      addDir(host,href,16,'','',1)
                      setView(addon_id, 'movies', 'movie-view')


def userscloud(url):
                data=readnet(url)
                if data:
                    regx='''<source src="(.*?)" type="video/mp4">'''                    
                    href=re.findall(regx,data, re.M|re.I)[0]
                   
                    resolve_host(href)





def playsong(url):##cinema and tv featured

                data=readnet(url)
               
               
               
                if data:
                   
                    regx1='''<iframe.*?src="(.*?)".*?></iframe>'''
                    regx='''<a href="(.*?)" target="_blank" class="down_toen">.*?</a>'''
                    
                    href=re.findall(regx,data, re.M|re.I)[0].split("?")[0]
                    print "href",href
                   
                    playlink(href)

def gethosts(urlmain):##cinema and tv featured
#href="http://www.arabshow.tv/the-forest/2/">
        data=readnet(urlmain)
        regx='<meta property="og:audio" content="(.*?)"/>'
        regx='<meta property="og:audio" content="(.*?)"/>'
        
        
        link=re.findall(regx,data, re.M|re.I)[0]
        playlink(link)

def getmatch(match):
                if len(match)<1:
                        return
                for href in match:
                    
                    
                    
                    
                     
                    server=href.split("/")[2].replace('www.',"").replace("embed.","").split(".")[0]
                    #if 'hqq' in server or "myvi" in server or 'videomeh' in server:
                            #return
                    addDir(server,href,5,'')		
def gethosts1(urlmain):##cinema and tv featured

                data=readnet2(urlmain)
	        print data
                	
                #regx='''</span><a href='(.+?)' class='redirect_link'>'''
                #regx1='''<iframe src="(.+?)" scrolling="no" frameborder="0" width="700" height="430" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'''
                regx2='''<iframe>.*?data-src="(.+?)".*?></iframe>'''
                
                regx3='''<iframe .+? src="(.+?)" .+?></iframe>'''
                regx4='''<iframe class="embed-responsive-item" data-src="(.+?)".*?></iframe>'''
                regx5='''<source src="(.*?)" type="video/mp4">'''
               
                #match1 = re.findall(regx1,data, re.M|re.I)
                match2 = re.findall(regx2,data, re.M|re.I)
                match3 = re.findall(regx3,data, re.M|re.I)
                match4 = re.findall(regx4,data, re.M|re.I)
                match5 = re.findall(regx5,data, re.M|re.I)
         
                #getmatch(match1)
                getmatch(match2)
                getmatch(match3)
                getmatch(match4)
                getmatch(match5)
               
                return

def getlink(url):##cinema and tv featured
#http://www.cimaflash.tv/file.php?f=11501&a=server&serverid=customcode2
        #url=url.replace("http://www.cimaflash.tv/film/","http://www.cimaflash.tv/play/")
        data = readnet2(url)
        #addon.log('#######################link = '+str(data))
        regx="post:'(.+?)',"
        id = re.findall(regx,data, re.M|re.I)[0].split("'")[0]
        print "id",id
        for i in range(1,6):
          url='http://www.4oof.com/wp-content/themes/twentyfifteen/servers/server.php?q='+id+'&i='+str(i)
          print url
          addDir('server'+str(i),url,40, 'img/server.png','','')
		  

			
def gethosts2(url):


                url=url.replace("t7melat.org/","t7melat.org/video/play/")
                data=readnet(url)
               
               
               
                if data:
                   
                    regx1='''<source src="(.*?)" type="application/x-mpegurl">'''
                    regx='''<source src="(.*?)" type="application/x-mpegurl">'''
                    
                    href=re.findall(regx,data, re.M|re.I)[0].split("?")[0]
                    
                   
                    playlink(href)
					
					
					
					
def gethosts3(url):
#http://www.series4watch.tv/wp-content/themes/online/servers/server.php?q=7165&i=1
        #url=url.replace("http://www.cimaflash.tv/film/","http://www.cimaflash.tv/play/")
        data = readnet2(url)
        #addon.log('#######################link = '+str(data))
        regx="rel='shortlink' href='.*?p=(.+?)'"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[0]
        print "id",id
        for i in range(1,6):
          url='http://www.series4watch.tv/wp-content/themes/online/servers/server.php?q='+id+'&i='+str(i)
          print url
          addDir('server'+str(i),url,40, 'img/server.png')

def LINKS2(url,description):
        split_head = re.split(r"\+", str(description), re.I)
        referer = split_head[0]
        coookie = split_head[1]
        headers = {'Referer': referer, 'Cookie': coookie, 'user-agent':User_Agent,'x-requested-with':'XMLHttpRequest'}
        link = requests.get(url, headers=headers, allow_redirects=False).text
        url = re.compile('"file":"(.*?)"').findall(link)[0]
        url = url.replace('&amp;','&').replace('\/','/')
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={"Title": name})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz) 
def SEARCHMV1(query):
	if query:
		search = query.replace(' ','+')
	else:
		keyb = xbmc.Keyboard('', 'Type in Query')
		keyb.doModal()
		if (keyb.isConfirmed()):
			search = keyb.getText().replace(' ','+')
			if search == '':
				xbmc.executebuiltin("XBMC.Notification([COLOR gold][B]Search MOVIES[/B][/COLOR],Aborting search,7000,"+icon+")")
				return
			else: pass
                url = hdarab + '/search/'+search
                INDEX3(url)


def SEARCHseries4watch(query):
	if query:
		search = query.replace(' ','+')
	else:
		keyb = xbmc.Keyboard('', 'Type in Query')
		keyb.doModal()
		if (keyb.isConfirmed()):
			search = keyb.getText().replace(' ','+')
			if search == '':
				xbmc.executebuiltin("XBMC.Notification([COLOR gold][B]Search MOVIES[/B][/COLOR],Aborting search,7000,"+icon+")")
				return
			else: pass
                url = Series4Watch + '/?s='+search
                INDEX5(url) 
		
def SEARCHTV(query,type):
	if query:
		search = query.replace(' ','+')
	else:
		keyb = xbmc.Keyboard('', 'Type in Query')
		keyb.doModal()
		if (keyb.isConfirmed()):
			search = keyb.getText().replace(' ','+')
			if search == '':
				xbmc.executebuiltin("XBMC.Notification([COLOR gold][B]Search MOVIES[/B][/COLOR],Aborting search,7000,"+icon+")")
				return
			else: pass
                url = baseurl + '/watch/category/tv-shows/?s='+search
                INDEX2(url)


		
def SEARCHMV2(query,type):
	if query:
		search = query.replace(' ','+')
	else:
		keyb = xbmc.Keyboard('', 'Type in Query')
		keyb.doModal()
		if (keyb.isConfirmed()):
			search = keyb.getText().replace(' ','+')
			if search == '':
				xbmc.executebuiltin("XBMC.Notification([COLOR gold][B]Search MOVIES[/B][/COLOR],Aborting search,7000,"+icon+")")
				return
			else: pass
                url = FooF + '/category/افلام/افلام-اجنبى/?s='+search
                INDEX4(url)

		
def SEARCHshahid4u(query,type):
	if query:
		search = query.replace(' ','+')
	else:
		keyb = xbmc.Keyboard('', 'Type in Query')
		keyb.doModal()
		if (keyb.isConfirmed()):
			search = keyb.getText().replace(' ','+')
			if search == '':
				xbmc.executebuiltin("XBMC.Notification([COLOR gold][B]Search MOVIES[/B][/COLOR],Aborting search,7000,"+icon+")")
				return
			else: pass
                url = shahid4u + '/?s='+search
                INDEX8(url)
		
def SEARCH(query):
	if query:
		search = query.replace(' ','+')
	else:
		keyb = xbmc.Keyboard('', 'Type in Query')
		keyb.doModal()
		if (keyb.isConfirmed()):
			search = keyb.getText().replace(' ','+')
			if search == '':
				xbmc.executebuiltin("XBMC.Notification([COLOR gold][B]Search MOVIES[/B][/COLOR],Aborting search,7000,"+icon+")")
				return
			else: pass
                url = baseurl+'/watch/category/movies/?s='+search
                INDEX(url)
	
def SEARCHcera(query,type):
	if query:
		search = query.replace(' ','+')
	else:
		keyb = xbmc.Keyboard('', 'Type in Query')
		keyb.doModal()
		if (keyb.isConfirmed()):
			search = keyb.getText().replace(' ','+')
			if search == '':
				xbmc.executebuiltin("XBMC.Notification([COLOR gold][B]Search MOVIES[/B][/COLOR],Aborting search,7000,"+icon+")")
				return
			else: pass
                url = cera+'/search/'+search
                INDEX12(url)

params=get_params(); url=None; name=None; mode=None; iconimage=None; description=None; query=None; type=None; page=1
# OpenELEQ: query & type-parameter (added 2 lines above)

try:url=urllib.unquote_plus(params["url"])
except:pass
try:name=urllib.unquote_plus(params["name"])
except:pass
try:iconimage=urllib.unquote_plus(params["iconimage"])
except:pass
try:mode=int(params["mode"])
except:pass
try:description=urllib.unquote_plus(params["description"])
except:pass
try:query=urllib.unquote_plus(params["query"])
except:pass
try:type=urllib.unquote_plus(params["type"])
except:pass
try:page=int(params["page"])
except:pass	
# OpenELEQ: query & type-parameter (added 8 lines above)

if mode==None or url==None or len(url)<1: CAT()
elif mode==1: INDEX(url)
elif mode==2: INDEX2(url)
elif mode==18: INDEX3(url)
elif mode==31: INDEX4(url)
elif mode==62: INDEXF4(url)
elif mode==63: getlinkF(url)
elif mode==64: INDEXF5(url)
elif mode==60: TRAILER(url)
elif mode==3: LINKS(url)
elif mode==5: RESOLVE(name,url)  
elif mode==4: TV()
elif mode==10: MV0()
elif mode==12: MV()
elif mode==14: MV1()
elif mode==30: MVT()
elif mode==400: series4watch()
elif mode==401: GENREseries4watch(url)
elif mode==402: INDEX5(url)
elif mode==403: AZHDARABMV(url)
elif mode==404: gethosts3(url)
elif mode==405: INDEX6(url)
elif mode==406: INDEX7(url)
elif mode==407: SEARCHseries4watch(query)
elif mode==7: LINKS2(url,description)
elif mode==8: SEARCH(query)
elif mode==13: SEARCHTV(query,type)
elif mode==20: SEARCHMV1(query)
elif mode==35: SEARCHMV2(query,type)
# OpenELEQ: query & type-parameter (added to line above)
elif mode==9: GENRE(url)
elif mode==32: GENRE2(url)
elif mode==10: COUNTRY(url)
elif mode==11: YEAR(url)
elif mode==21: YEARMV1(url)
elif mode==300: getsongsmain()
elif mode==301: getartists(url)
elif mode==302: getalbams(url)
elif mode==303: getsongs(url)
elif mode==304: getnewsongs(url)
elif mode==15: playsong(url)
elif mode==17: gethosts(url)
elif mode==19: gethosts1(url)
elif mode==33: getlink(url)
elif mode==34: gethosts2(url)
elif mode==6: getepisodes(url,name)
elif mode==16: resolve_host(url)
elif mode==22: resolve_host1(url)
elif mode==40: resolve_host2(url)
elif mode==50: Shahid4um()
elif mode==51: INDEX8(url)
elif mode==52: INDEX9(url)
elif mode==53: INDEX10(url)
elif mode==54: INDEX11(url)
elif mode==55: SEARCHshahid4u(query,type)
elif mode==56: YEARShahid4u(url)
elif mode==100: PLAYMOVIE(name,url,iconimage)
elif mode==102: TV1ARALAB_PLAY(name,url,iconimage)
elif mode==501: MV2()
elif mode==500: INDEX12(url)
elif mode==502: INDEX13(url)
elif mode==503: INDEX14(url)
elif mode==504: INDEX15(url)
elif mode==505: INDEX16(url)
elif mode==506: SEARCHcera(query,type)
xbmcplugin.endOfDirectory(int(sys.argv[1]))