# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys
import base64,hashlib,os,random,re,requests,shutil,string,urllib,urllib2
import xbmc,xbmcaddon,xbmcgui,xbmcplugin,xbmcvfs
from addon.common.addon import Addon
from addon.common.net import Net
import urlresolver

#By. MG.Arabic http://mg.esy.es/Kodi/ (03/2017)
#Common Cache
try:
  import StorageServer
except:
  import storageserverdummy as StorageServer
  cache = StorageServer.StorageServer('plugin.video.showscen')

addon_id='plugin.video.showscen'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, art+'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, art+'fanart.jpg'))
User_Agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36'
# show_tv = selfAddon.getSetting('enable_shows')
show_mov = addon.get_setting('enable_movies')
show_hdarab = addon.get_setting('enable_hdarab')
show_Albh = addon.get_setting('enable_3lbhnet')
show_thmelat = addon.get_setting('enable_t7melat')
show_mus = addon.get_setting('enable_6arbyat')
baseurl = selfAddon.getSetting('base_url')
arab = selfAddon.getSetting('arab_url')
Albh = selfAddon.getSetting('3lbh_url')
thmelat = selfAddon.getSetting('t7melat_url')
tarbyat = selfAddon.getSetting('6arbyat_url')

s = requests.session()
net = Net()


def CAT():
    if show_mov == 'true':addDir('[B][COLOR gold]••ShowsCen••[/COLOR][/B]','url',10,icon,fanart,'')
    # if show_tv == 'true':addDir('[B][COLOR white]••قوائم المسلسلات••[/COLOR][/B]','url',4,art+'mytvshows.png',fanart,'')    
    if show_hdarab == 'false':addDir('[B][COLOR darkblue]••هHD Arabه•• Not working yet[/COLOR][/B]','url',400,art+'hd-arab.png',fanart,'')	
    if show_Albh == 'true':addDir('[B][COLOR blue]••ه3lbh Netه••[/COLOR][/B]','url',14,art+'3lbh.png',fanart,'')	
    if show_thmelat == 'true':addDir('[B][COLOR orange]••هT7melatه••[/COLOR][/B]','url',30,art+'t7melat.png',fanart,'')
    if show_mus == 'true':addDir('[B][COLOR tan]••ه6arbyatه••[/COLOR][/B]','url',300,art+'6arbyat.png',fanart,'')
    addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
def MV0():
     addDir('[B][COLOR white]••قوائم الافلام••[/COLOR][/B]','url',12,art+'mymovies.png',fanart,'')
     addDir('[B][COLOR white]••قوائم المسلسلات••[/COLOR][/B]','url',4,art+'mytvshows.png',fanart,'')
     addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')	 
def MV():	
	addDir('[B][COLOR white]البحث[/COLOR][/B]','url',8,art+'search.png',fanart,'')
	addDir('[B][COLOR white]افلام اجنبيه[/COLOR][/B]',baseurl+'/watch/category/movies',1,art+'latest-movies.png',fanart,'')
	addDir('[B][COLOR white]السنة[/COLOR][/B]','url',11,art+'years.png',fanart,'')		
	addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')	
def MV1():	
	addDir('[B][COLOR white]البحث[/COLOR][/B]','url',20,art+'search.png',fanart,'')
	addDir('[B][COLOR white]عــــام[/COLOR][/B]','url',9,art+'genres.png',fanart,'')
	addDir('[B][COLOR white]السنة[/COLOR][/B]','url',21,art+'years.png',fanart,'')
	addDir('[B][COLOR white]جميع الافلام[/COLOR][/B]', Albh + '/movies?page=1',18,art+'mymovies.png',fanart,'')
	#addDir('[B][COLOR white]Country[/COLOR][/B]',baseurl+'/movie/filter/all',10,icon,fanart,'')
	#addDir('[B][COLOR white]البحث[/COLOR][/B]','url',20,art+'search.png',fanart,'')
	# addDir('[B][COLOR white]افلام اجنبيه[/COLOR][/B]',baseurl+'/watch/category/movies',1,art+'latest-movies.png',fanart,'')
	#addDir('[B][COLOR white]عــــام[/COLOR][/B]','url',9,art+'genres.png',fanart,'')
	# addDir('[B][COLOR white]السنة[/COLOR][/B]','url',11,art+'years.png',fanart,'')
	addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
def MVT():	
                addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
                addDir('[B][COLOR white]البحث[/COLOR][/B]','url',35,art+'search.png',fanart,'')				
                addDir('[B][COLOR white]عــــام[/COLOR][/B]','url',32,art+'genres.png',fanart,'')
                genreliste=[
				('/category/افلام-اجنبي/', 'افلام اجنبية'),
				('/category/افلام-اسيوية/', 'افلام اسيوية'),
				('/category/افلام-عربي/', 'افلام عربي'),
				('/category/افلام-مدبلجة/', 'افلام مدبلجة'),
				('/category/افلام-هندي/', 'افلام هندي'),
				('/category/انيمي-و-كرتون/', 'افلام انيمي و كرتون')]

                
                #addDir("Search", tarbyat + '/search?q=',3,'resources/search.png','',1)
                for url, title  in genreliste:
                    url= thmelat + url
                    if 'افلام' in title:
                      addDir2('[B][COLOR white]%s[/COLOR][/B]' %title, url, 31,art+'musical.jpg','',1)
                    else:
                       addDir2('[B][COLOR white]%s[/COLOR][/B]' %title, url,18,art+'musical.jpg','',1)	


def MVHDARAB():	
                addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
                addDir('[B][COLOR white]الترتيب بالاحرف[/COLOR][/B]','url',403,art+'search.png',fanart,'')				
                addDir('[B][COLOR white]عــــام[/COLOR][/B]','url',401,art+'genres.png',fanart,'')
                genreliste=[
				('/movies/', 'الافلام'),
				('/tvshows/', 'المسلسلات')]

                
                #addDir("Search", tarbyat + '/search?q=',3,'resources/search.png','',1)
                for url, title  in genreliste:
                    url= arab + url
                    if 'الافلام' in title:
                      addDir2('[B][COLOR white]%s[/COLOR][/B]' %title, url, 402,art+'musical.jpg',art+'cover.png',1)
                    else:
                       addDir2('[B][COLOR white]%s[/COLOR][/B]' %title, url,405,art+'musical.jpg',art+'cover.png',1)
def GENREHDARABMV(url):
	genres=['Action-Movies','Adventure-Movies','Animation-Movies','Biography-Movies','Bollywood-Movies','Comedy-Movies','Crime-Movies','Documentary-Movies','Drama-Movies','Dual-Audio-Movies','Family-Movies','Fantasy-Movies','Film-Noir-Movies','Foreign-Movies','Hindi-Dubbed-Movies','History-Movies','Horror-Movies','Music-Movies','Musical-Movies','Mystery','Romance','Sci-Fi','Sport','Thriller','Tollywood','War','Western']
        for g in genres:
                url= arab + '/category/'+g.lower()
                print url
                addDir2('[B][COLOR white]%s[/COLOR][/B]' %g,url,402,art+'genres.png',fanart)
def AZHDARABMV(url):
	genres=['#','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
        for g in genres:
                url= arab + '/movies-az-list/'+g
                print url
                addDir2('[B][COLOR white]%s[/COLOR][/B]' %g,url,402,art+'genres.png',fanart)

				
def TV():
        #addDir('[B][COLOR white]Most Favorite[/COLOR][/B]',baseurl+'/movie/filter/series/favorite/all/all/all/all/all',2,icon,fanart,'')
        #addDir('[B][COLOR white]Most Ratings[/COLOR][/B]',baseurl+'/movie/filter/series/rating/all/all/all/all/all',2,icon,fanart,'')
        #addDir('[B][COLOR white]Most Viewed[/COLOR][/B]',baseurl+'/movie/filter/series/view/all/all/all/all/all',2,icon,fanart,'')
        #addDir('[B][COLOR white]Top IMDB[/COLOR][/B]',baseurl+'/watch/category/tv-shows',2,icon,fanart,'')
        #addDir('[B][COLOR white]Country[/COLOR][/B]',baseurl+'/movie/filter/series',10,icon,fanart,'')
        addDir('[B][COLOR white]البحث[/COLOR][/B]','url',13,art+'search.png',fanart,'')
        addDir('[B][COLOR white]مسلسلات اجنبيه[/COLOR][/B]',baseurl+'/watch/category/tv-shows',2,art+'mytvshows.png',fanart,'')
        #addDir('[B][COLOR white]Genre[/COLOR][/B]',baseurl+'/movie/filter/series',9,icon,fanart,'')
        #addDir('[B][COLOR white]Year[/COLOR][/B]',baseurl+'/movie/filter/series',11,icon,fanart,'')
        addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')

def GENRE(url):
	genres=['Action','Adventure','Animation','Biography','Comedy','Crime','Documentary','Drama','Family','Fantasy','History','Horror','Music','Musical','Mystery','Romance','Sci-Fi','Sport','Thriller','War','Western']
        for g in genres:
                url= Albh + '/movies/geners/'+g.lower()
                print url
                addDir2('[B][COLOR white]%s[/COLOR][/B]' %g,url,18,art+'genres.png',fanart)


def GENRE2(url):
	genres=['box-office','اكشن','افلام-رعب','إثاره','دراما','افلام-رومانسية','الخيال-العلمي','افلام-الغموض','تاريخ','جريمة','افلام-الحروب','خيال','رياضة','عائلي','كوميديا','مغامرات']
        for g in genres:
                url= thmelat + '/type/'+g.lower()
                print url
                addDir2('[B][COLOR white]%s[/COLOR][/B]' %g,url,31,art+'genres.png',fanart)

def COUNTRY(url):
        link = OPEN_URL(url)
        link = link.encode('ascii', 'ignore')
        match=re.compile('<input class="country-ids" value="(.*?)" name=".*?"\n.*?type="checkbox" >(.*?)</label>').findall(link)
        for url2,name in match:
                name = name.replace(' ','')
                if '/series' in url:
                        url2 = baseurl + '/movie/filter/series/latest/all/'+url2+'/all/all/all'
                        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url2,2,icon,fanart,'')
                else:
                        url2 = baseurl + '/movie/filter/movie/latest/all/'+url2+'/all/all/all'
                        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url2,1,icon,fanart,'')


def YEAR(url):
       for i in range(2005,2018):
	   
             addDir2(str(i),baseurl+'/watch/category/movies/?s='+str(i),1,art+'years.png','',1)
def YEARMV1(url):
       for i in range(2005,2018):
	   
             addDir2(str(i), Albh + '/search?q='+str(i),18,art+'years.png','',1)
			 
def INDEX(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<article id=', '</article>')
	for a in all_videos:
		name = regex_from_to(a, 'data-a2a-title="', '"').replace("مشاهدة مباشرة فيلم","").replace("&amp;","&").replace('&#39;',"'").replace('&quot;','"').replace('&#39;',"'")
		url = regex_from_to(a, '<a href="', '" rel="bookmark">').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')
		qual = regex_from_to(a, '<p>', '</p>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir2('[B][COLOR white]%s[/COLOR][/B][B][I][COLOR red](%s)[/COLOR][/I][/B]' %(name,qual),url,3,icon,fanart,'')
	try:
		nextp=re.compile('<div class="nav-previous"><a href="(.*?)" >').findall(link)[0]
		addDir2('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,1,art+'/next.png',fanart,'')
	except: pass
	setView('movies', 'show-view')


def INDEX2(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	all_videos = regex_get_all(link, '<article id=', '</article>')
	for a in all_videos:
		name = regex_from_to(a, 'data-a2a-title="', '"').replace("مشاهدة مباشرة مسلسل","")
		url = regex_from_to(a, '<a href="', '" rel="bookmark">').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"') 
		dis = regex_from_to(a, '<p>', '</p>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','')
		#if 'Season' in name:
		addDir2('[B][COLOR white]%s[/COLOR][/B][B][I][COLOR red](%s)[/COLOR][/I][/B]' %(name,dis),url,6,icon,fanart,'')
	try:
		nextp=re.compile('<div class="nav-previous"><a href="(.*?)" >').findall(link)[0]
		addDir2('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,2,art+'/next.png',fanart,'')
	except: pass
	setView('tvshows', 'show-view')

def INDEX3(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="col-md-3 col-xs-12', '</ul>')
	for a in all_videos:
		name = regex_from_to(a, '<h4>', '</h4>').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('&quot;','"').replace('&#39;',"'").replace('&#039;',"'")
		url = Albh +regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = Albh +regex_from_to(a, "'", "'")#.replace("(","").replace("'","")
		qual = regex_from_to(a, '<p>', '</p>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir('[B][COLOR white]%s[/COLOR][/B][B][I][COLOR red](%s)[/COLOR][/I][/B]' %(name,qual),url,19,icon,fanart,'')
	try:
		nextp=re.compile('<a href="(.*?)" rel="next">').findall(link)[0]
		addDir2('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,18,art+'/next.png',fanart,'')
	except: pass
	setView('movies', 'show-view')
def INDEX4(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="movieB">', '</a>')
	for a in all_videos:
		name = regex_from_to(a, 'title="', '"').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('اون لاين','').replace('&#8217;',"").replace('&#8211;',"")
		url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')#.replace("(","").replace("'","")
		qual = regex_from_to(a, '<i class="fa fa-hdd-o"></i>', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir2('[B][COLOR white]%s[/COLOR][/B][B][I][COLOR red](%s)[/COLOR][/I][/B]' %(name,qual),url,33,icon,fanart,'')
	try:
		nextp=re.compile('<a rel="next" href="(.*?)" itemprop="name">').findall(link)[0]
		addDir2('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,31,art+'/next.png',fanart,'')
	except: pass
	setView('movies', 'show-view')
	
	
def INDEX5(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<li class="movie-list-item">', '</figure>')
	for a in all_videos:
		name = regex_from_to(a, 'alt="', '"').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('اون لاين','').replace('&#8217;',"").replace('&#8211;',"")
		url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'data-src="', '"')#.replace("(","").replace("'","")
		qual = regex_from_to(a, '<div class="movie-year">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir('[B][COLOR white]%s[/COLOR][/B][B][I][COLOR red](%s)[/COLOR][/I][/B]' %(name,qual),url,404,icon,fanart,'')
	try:
		nextp= arab + '/movies/'+re.compile('<a href="(.*?)" rel="next">').findall(link)[0]
		addDir2('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,402,art+'/next.png',fanart,'')
	except: pass
	setView('movies', 'show-view')
def INDEX6(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="movie-con">', '<figure>')
	for a in all_videos:
		name = regex_from_to(a, 'alt="', '"').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('اون لاين','').replace('&#8217;',"").replace('&#8211;',"")
		url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'data-src="', '"')#.replace("(","").replace("'","")
		qual = regex_from_to(a, '<div class="movie-year">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir2('[B][COLOR white]%s[/COLOR][/B][B][I][COLOR red](%s)[/COLOR][/I][/B]' %(name,qual),url,406,icon,fanart,'')
	try:
		nextp= arab + '/movies/'+re.compile('<a href="(.*?)" rel="next">').findall(link)[0]
		addDir2('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,405,art+'/next.png',fanart,'')
	except: pass
	setView('movies', 'show-view')

def INDEX7(url):
                print "page",page
               
                if page>1:
                  #http://www.showscen.com/watch/category/tv-shows/page/2/
                  
                     url_page=url+'/page/'+str(page)
                  
                else:
                
                      url_page=url
                 
                data=readnet(url_page)
               
                try:data=data.split('<span style="(.*?)"')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('&#8211;')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    print "block",block.encode("utf-8")
                   
                    regx='''<a href="(.*?)".*?>(.+?)<'''
                    name=re.findall(regx,block, re.M|re.I)					
					
                    regx2='''<a href="(.*?)".*?>(.+?)<'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    try:
                     name=match[0][1]
                    except:
                      match=re.findall(regx2,block, re.M|re.I)[0]
                      name=match[0][1]
                    href=match[0][0].replace("'","'").encode("utf-8")
                    #regx="src='(.*?)'"
                    #img='http://www.showscen.com/watch/category/tv-shows/'+re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    #img (u"('http://tm01.tellymov.com/i/01/00004/h5zgl3c07sgb_t.jpg')"
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:str(name)
                    addDir2(name,href,3,'img','',1)
	
def getsongsmain():

                genreliste=[('/aghany-songs/?page=1', 'احدث الأعمال الفنية'),
				('/cat/saudi-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb3\xd8\xb9\xd9\x88\xd8\xaf\xd9\x8a\xd8\xa9'),
				('/cat/kuwaiti-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x83\xd9\x88\xd9\x8a\xd8\xaa\xd9\x8a\xd8\xa9'),
				('/cat/bahraini-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xa8\xd8\xad\xd8\xb1\xd9\x8a\xd9\x86\xd9\x8a\xd8\xa9'),
				('/cat/uae-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xa7\xd9\x85\xd8\xa7\xd8\xb1\xd8\xa7\xd8\xaa\xd9\x8a\xd8\xa9'),
				('/cat/qatar-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x82\xd8\xb7\xd8\xb1\xd9\x8a\xd8\xa9'),
				('/cat/omani-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb9\xd9\x85\xd8\xa7\xd9\x86\xd9\x8a\xd8\xa9'),
				('/cat/yemeni-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x8a\xd9\x85\xd9\x86\xd9\x8a\xd8\xa9'),
				('/cat/iraqi-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb9\xd8\xb1\xd8\xa7\xd9\x82\xd9\x8a\xd8\xa9'),
				('/cat/lebanese-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x84\xd8\xa8\xd9\x86\xd8\xa7\xd9\x86\xd9\x8a\xd8\xa9'),
				('/cat/jordan-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xa7\xd8\xb1\xd8\xaf\xd9\x86\xd9\x8a\xd8\xa9'),
				('/cat/palestinian-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x81\xd9\x84\xd8\xb3\xd8\xb7\xd9\x8a\xd9\x86\xd9\x8a\xd8\xa9'),
				('/cat/syrian-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb3\xd9\x88\xd8\xb1\xd9\x8a\xd8\xa9'),
				('/cat/egyptian-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x85\xd8\xb5\xd8\xb1\xd9\x8a\xd8\xa9'),
				('/cat/sudanese-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb3\xd9\x88\xd8\xaf\xd8\xa7\xd9\x86\xd9\x8a\xd8\xa9'),
				('/cat/moroccan-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x85\xd8\xba\xd8\xb1\xd8\xa8\xd9\x8a\xd8\xa9'),
				('/cat/tunisian-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xaa\xd9\x88\xd9\x86\xd8\xb3\xd9\x8a\xd8\xa9'),
				('/cat/algerian-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xac\xd8\xb2\xd8\xa7\xd8\xa6\xd8\xb1\xd9\x8a\xd8\xa9 '),
				('/cat/libyan-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x84\xd9\x8a\xd8\xa8\xd9\x8a\xd8\xa9 '),
				('/cat/arabian-songs/', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb9\xd8\xb1\xd8\xa8\xd9\x8a\xd8\xa9'),
				('/cat/concerts/', '\xd8\xad\xd9\x81\xd9\x84\xd8\xa7\xd8\xaa \xd9\x88 \xd8\xac\xd9\x84\xd8\xb3\xd8\xa7\xd8\xaa '),
				('/hashtag/\xd8\xba\xd9\x8a\xd8\xb1_\xd9\x85\xd8\xad\xd8\xaf\xd8\xaf/', '\xd8\xba\xd9\x8a\xd8\xb1_\xd9\x85\xd8\xad\xd8\xaf\xd8\xaf'),
				('/hashtag/\xd9\x85\xd9\x87\xd8\xb1\xd8\xac\xd8\xa7\xd9\x86\xd8\xa7\xd8\xaa/', '\xd9\x85\xd9\x87\xd8\xb1\xd8\xac\xd8\xa7\xd9\x86\xd8\xa7\xd8\xaa'),
				('/hashtag/\xd8\xb4\xd9\x8a\xd9\x84\xd8\xa9/', '\xd8\xb4\xd9\x8a\xd9\x84\xd8\xa9'),
				('/hashtag/\xd8\xb3\xd9\x86\xd9\x82\xd9\x84/', '\xd8\xb3\xd9\x86\xd9\x82\xd9\x84'),
				('/hashtag/\xd8\xb3\xd8\xa7\xd9\x85\xd8\xb1\xd9\x8a\xd8\xa7\xd8\xaa/', '\xd8\xb3\xd8\xa7\xd9\x85\xd8\xb1\xd9\x8a\xd8\xa7\xd8\xaa'), 
				('/hashtag/\xd8\xb4\xd8\xb9\xd8\xa8\xd9\x8a\xd8\xa7\xd8\xaa/', '\xd8\xb4\xd8\xb9\xd8\xa8\xd9\x8a\xd8\xa7\xd8\xaa'),
				('/hashtag/\xd8\xb1\xd9\x8a\xd9\x85\xd9\x83\xd8\xb3\xd8\xa7\xd8\xaa/', '\xd8\xb1\xd9\x8a\xd9\x85\xd9\x83\xd8\xb3\xd8\xa7\xd8\xaa'), 
				('/hashtag/\xd8\xad\xd9\x81\xd9\x84\xd8\xa7\xd8\xaa/', '\xd8\xad\xd9\x81\xd9\x84\xd8\xa7\xd8\xaa'),
				('/hashtag/\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa/', '\xd9\x85\xd8\xb3\xd9\x84\xd8\xb3\xd9\x84\xd8\xa7\xd8\xaa'), 
				('/hashtag/\xd9\x88\xd8\xb7\xd9\x86\xd9\x8a\xd8\xa7\xd8\xaa/', '\xd9\x88\xd8\xb7\xd9\x86\xd9\x8a\xd8\xa7\xd8\xaa'),
				('/hashtag/\xd9\x85\xd9\x88\xd8\xb4\xd8\xad\xd8\xa7\xd8\xaa/', '\xd9\x85\xd9\x88\xd8\xb4\xd8\xad\xd8\xa7\xd8\xaa'),
				('/hashtag/\xd9\x85\xd9\x88\xd8\xa7\xd9\x88\xd9\x8a\xd9\x84/', '\xd9\x85\xd9\x88\xd8\xa7\xd9\x88\xd9\x8a\xd9\x84'),
				('/hashtag/\xd8\xac\xd9\x84\xd8\xb3\xd8\xa7\xd8\xaa/', '\xd8\xac\xd9\x84\xd8\xb3\xd8\xa7\xd8\xaa'),
				('/hashtag/\xd9\x82\xd8\xb5\xd8\xa7\xd8\xa6\xd8\xaf/', '\xd9\x82\xd8\xb5\xd8\xa7\xd8\xa6\xd8\xaf'),
				('/hashtag/اغاني_اطفال/', 'اطفال')]

                
                #addDir("Search", tarbyat + '/search?q=',3,'resources/search.png','',1)
                for url, title  in genreliste:
                    url= tarbyat + url
                    if 'اغاني' in title:
                      addDir2('[B][COLOR white]%s[/COLOR][/B]' %title, url, 301,art+'musical.jpg','',1)
                    else:
                       addDir2('[B][COLOR white]%s[/COLOR][/B]' %title, url,304,art+'musical.jpg','',1)

def getartists(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<li class="col-md-4', '</i>')
	for a in all_videos:
		name = regex_from_to(a, "alt='", "'").replace("تحميل كاملة","")
		url = tarbyat + regex_from_to(a, "href='", "'").replace("&amp;","&")
		icon = tarbyat + regex_from_to(a, "src='", "'")
		#qual = regex_from_to(a, '<p>', '</p>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir2('[B][COLOR white]%s[/COLOR][/B]' %name,url,302,icon,fanart,'')
	try:
		nextp= tarbyat + re.compile('<a href="(.*?)"><i class="fa fa-angle-left">').findall(link)[1]
		addDir2('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,301,art+'/next.png',fanart,'')
	except: pass
	setView('movies', 'show-view')

def getalbams(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, "<div class='col-md-2'>", "<span class='siic3'>")
	for a in all_videos:
		name = regex_from_to(a, "alt='", "'").replace("تحميل كاملة","")
		url = tarbyat + regex_from_to(a, "href='", "'").replace("&amp;","&")
		icon = tarbyat + regex_from_to(a, "src='", "'")
		qual = regex_from_to(a, '<p>', '</p>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir2('[B][COLOR white]%s[/COLOR][/B]' %name,url,303,icon,fanart,'')
	try:
		nextp= tarbyat + re.compile('<a href="(.*?)"><i class="fa fa-angle-left">').findall(link)[1]
		addDir2('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,302,art+'/next.png',fanart,'')
	except: pass
	setView('movies', 'show-view')
	
def getsongs(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, "<li class='col-md-8", "</li>")
	for a in all_videos:
		name = regex_from_to(a, "<a href='.*?'>", "</a>").replace("تحميل كاملة","")
		url = tarbyat + regex_from_to(a, "href='", "'").replace("&amp;","&")
		icon = tarbyat + regex_from_to(a, "src='", "'")
		qual = regex_from_to(a, "<li class='col-md-4 col-xs-5'>", "</li>").replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir2('[B][COLOR white]%s[/COLOR][/B]' %name,url,17,art+'musical.jpg',fanart,'')
	try:
		nextp= tarbyat + re.compile('<a href="(.*?)"><i class="fa fa-angle-left">').findall(link)[1]
		addDir2('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,303,art+'/next.png',fanart,'')
	except: pass
	setView('movies', 'show-view')


def getnewsongs(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, "<li class='col-md-6 col-xs-7'>", "</li>")
	for a in all_videos:
		name = regex_from_to(a, "<a href='.*?'>", "</a>").replace("تحميل كاملة","")
		url = tarbyat + regex_from_to(a, "href='", "'").replace("&amp;","&")
		icon = tarbyat + regex_from_to(a, "src='", "'")
		qual = regex_from_to(a, "<li class='col-md-4 col-xs-5'>", "</li>").replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir2('[B][COLOR white]%s[/COLOR][/B]' %name,url,17,art+'musical.jpg',fanart,'')
	try:
		nextp=re.compile('</li> <li><a href="(.*?)" rel="next">').findall(link)[0]
		addDir2('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,304,art+'/next.png',fanart,'')
	except: pass
	setView('movies', 'show-view')

	
key = '87wwxtp3dqii'
key2 = '7bcq9826avrbi6m49vd7shxkn985mhod'


def getepisodes(url,name):##series
                print "page",page
               
                if page>1:
                  #http://www.showscen.com/watch/category/tv-shows/page/2/
                  
                     url_page=url+'/page/'+str(page)
                  
                else:
                
                      url_page=url
                 
                data=readnet(url_page)
               
                try:data=data.split('<span style="(.*?)"')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('&#8211;')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    print "block",block.encode("utf-8")
                   
                    regx='''<a href="(.*?)".*?>(.+?)<'''
                    name=re.findall(regx,block, re.M|re.I)					
					
                    regx2='''<a href="(.*?)".*?>(.+?)<'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    try:
                     name=match[0][1]
                    except:
                      match=re.findall(regx2,block, re.M|re.I)[0]
                      name=match[0][1]
                    href=match[0][0].replace("'","'").encode("utf-8")
                    #regx="src='(.*?)'"
                    #img='http://www.showscen.com/watch/category/tv-shows/'+re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    #img (u"('http://tm01.tellymov.com/i/01/00004/h5zgl3c07sgb_t.jpg')"
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:str(name)
                    addDir2(name,href,3,'img','',1)







def LINKS(url,urlmain):
                data=readnet(urlmain)
               
                
              
                if data is None:
                    return
                regx='''<a href="(.*?)">.*?</a><br />'''
                regx='''<iframe.*?src="(.*?)".*?></iframe>'''
                match=re.findall(regx,data, re.M|re.I)
                for href in match:
                    
                     
                    
                      if not href.startswith("http"):
                       href="http:"+href
                      
                      host=gethostname(href)
                    
                            
                      if 'youtube.com' in href:
                          videoid=os.path.split(href)[1]
                          href='plugin://plugin.video.youtube/?action=play_video&videoid=%s' % videoid
                      addDir2(host,href,16,'','',1)

def RESOLVE(name,url):
  	       
        if 'thevideos.tv' in url:
                url = thevideos(url)
        if 'ok.ru' in url:
                url = resolve_host(url)
        if 'estream.to' in url:
                url = resolve_host(url)				
        if 'userscloud.com' in url:
                url = resolve_host(url)
        if 'vidbom.com' in url:
                url = resolve_host(url)				
        if 'videowood.tv' in url:
                url = resolve_host(url)
        if 'uptostream.com' in url:
                url = resolve_host(url)				
        if 'vidlocker' in url:
                url = vidlocker(url)				
        elif 'watchers.to' in url:
                url = resolve_host(url)
        elif 'openload.co' in url:
                url = resolve_host(url)
        elif 'videorev.cc' in url:
                url = resolve_host(url)
        elif 'hqq.tv' in url:
                url = resolve_host(url)	
        elif 'drive.google.com' in url:
                url = resolve_host(url)					
        elif 'google' in url:
                url = resolve_host(url)
        else:
                url = urlresolver.resolve(url)
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={'Title':description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(str(url))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
		
def resolve_host(url):#last good-used with local resolver
       
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
      
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    
        else:
            addDir("Error,"+stream_link,"",9,"")
def playlink(url):
           
            xbmc.Player().play(url)
            sys.exit(0)  

def thevideos(url):
        link = requests.get(url).text
        #script = re.findall("<script type='text/javascript'>(.*?)</script>", str(link), re.I|re.DOTALL)[0]
        #unpack = packer.unpack(script)
        try:
                url = re.findall('file:"(.*?)",label:".*?0p"', str(link), re.I|re.DOTALL)[-1]
        except:
                url = re.findall('file:"(.*?)",label:".*?0p"', str(link), re.I|re.DOTALL)[0]
        return url

def playsong(url):##cinema and tv featured

                data=readnet(url)
               
               
               
                if data:
                   
                    regx1='''<iframe.*?src="(.*?)".*?></iframe>'''
                    regx='''<a href="(.*?)" target="_blank" class="down_toen">.*?</a>'''
                    
                    href=re.findall(regx,data, re.M|re.I)[0].split("?")[0]
                    print "href",href
                   
                    playlink(href)

def gethosts(urlmain):##cinema and tv featured
#href="http://www.arabshow.tv/the-forest/2/">
        data=readnet(urlmain)
        regx='<meta property="og:audio" content="(.*?)"/>'
        regx='<meta property="og:audio" content="(.*?)"/>'
        
        
        link=re.findall(regx,data, re.M|re.I)[0]
        playlink(link)
		
def gethosts1(urlmain):##cinema and tv featured
#href="http://www.arabshow.tv/the-forest/2/">
        data=readnet(urlmain)
        regx='<source src="(.*?)" type="video/mp4"></source>'
        regx='<source src="(.*?)" type="video/mp4"></source>'
        
        
        link=re.findall(regx,data, re.M|re.I)[0]
        playlink(link)

def getlink(url):##cinema and tv featured

                data=readnet(url)
               
               
               
                if data:
                   
                    regx1='''<div class="download_li faster_l"><a href="(.*?)" target="_blank">'''
                    regx='''<div class="download_li faster_l"><a href="(.*?)" target="_blank">'''
                    
                    href=re.findall(regx,data, re.M|re.I)[0].split("?")[0]
                    #url=url.replace("t7melat.org/","t7melat.org/video/play/")
                   
                    gethosts2(href)
def gethosts2(url):


                url=url.replace("t7melat.org/","t7melat.org/video/play/")
                data=readnet(url)
               
               
               
                if data:
                   
                    regx1='''<source src="(.*?)" type="application/x-mpegurl">'''
                    regx='''<source src="(.*?)" type="application/x-mpegurl">'''
                    
                    href=re.findall(regx,data, re.M|re.I)[0].split("?")[0]
                    
                   
                    playlink(href)
					
					
					
					
def gethosts3(url):
                data=readnet(url)                              
                if data:
                   
                    regx1='''<iframe.*?data-src="(.*?)".*?></iframe>'''
                    regx='''<iframe.*?data-src="(.*?)".*?></iframe>'''
                    
                    href=re.findall(regx,data, re.M|re.I)[0].split("?")[0]
                    print "href",href
                   
                    playlink(href)
               
                
              
                # if data is None:
                    # return
                # regx='''<iframe.*?data-src="(.*?)".*?></iframe>'''
                # regx='''<iframe.*?data-src="(.*?)".*?></iframe>'''
                # match=re.findall(regx,data, re.M|re.I)
                # for href in match:
                    
                     
                    
                      # if not href.startswith("http"):
                       # href="http:"+href
                      
                      # host=gethostname(href)
                    
                            
                      
                      # addDir2(host,href,22,'','',1)
def readnet2(url):
        import requests
        data=requests.get(url, verify=False)
        return data.content					  
def resolve_host1(url):
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
   
	    playlink(stream_link)  
        else:
            addDir("Error,"+stream_link,"",9,"")					
def vidlocker(url):
        headers = {}
        headers['User-Agent'] = User_Agent
        link = requests.get(url, headers=headers, allow_redirects=False)
        try:
            link = re.findall(r'sources: \[\{file:"(.*?)"', str(link.text), re.I|re.DOTALL)[-1]
        except:
            link = re.findall(r'sources: \[\Boot{file:"(.*?)"', str(link.text), re.I|re.DOTALL)[0]
        return link
		
		
def LINKS2(url,description):
        split_head = re.split(r"\+", str(description), re.I)
        referer = split_head[0]
        coookie = split_head[1]
        headers = {'Referer': referer, 'Cookie': coookie, 'user-agent':User_Agent,'x-requested-with':'XMLHttpRequest'}
        link = requests.get(url, headers=headers, allow_redirects=False).text
        url = re.compile('"file":"(.*?)"').findall(link)[0]
        url = url.replace('&amp;','&').replace('\/','/')
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={"Title": name})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz) 
def SEARCHMV1(query,type):
	if query:
		search = query.replace(' ','+')
	else:
		keyb = xbmc.Keyboard('', 'Type in Query')
		keyb.doModal()
		if (keyb.isConfirmed()):
			search = keyb.getText().replace(' ','+')
			if search == '':
				xbmc.executebuiltin("XBMC.Notification([COLOR gold][B]Search MOVIES[/B][/COLOR],Aborting search,7000,"+icon+")")
				return
			else: pass
	url = Albh + '/search?q='+search
	print url
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	all_videos = regex_get_all(link, '<div class="col-md-3 col-xs-12', '</ul>')
	for a in all_videos:
		name = regex_from_to(a, '<h4>', '</h4>').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('&quot;','"').replace('&#39;',"'").replace('&#039;',"'")
		url = Albh + regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = Albh + regex_from_to(a, "'", "'")#.replace("(","").replace("'","")
		qual = regex_from_to(a, '<p>', '</p>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
	
		addDir2('[B][COLOR white]%s[/COLOR][/B][B][I][COLOR red](%s)[/COLOR][/I][/B]' %(name,qual),url,19,icon,fanart,'')
	# try:
		# nextp=re.compile('<a href="(.*?)" rel="next">').findall(link)[0]
		# addDir2('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,18,art+'/next.png',fanart,'')
	# except: pass
	# setView('movies', 'show-view')
def SEARCHTV(query,type):
	if query:
		search = query.replace(' ','+')
	else:
		keyb = xbmc.Keyboard('', 'Type in Query')
		keyb.doModal()
		if (keyb.isConfirmed()):
			search = keyb.getText().replace(' ','+')
			if search == '':
				xbmc.executebuiltin("XBMC.Notification([COLOR gold][B]Search MOVIES[/B][/COLOR],Aborting search,7000,"+icon+")")
				return
			else: pass
	url = baseurl+'/watch/category/tv-shows/?s='+search
	print url
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	all_videos = regex_get_all(link, '<article id=', '</article>')
	for a in all_videos:
		name = regex_from_to(a, 'data-a2a-title="', '"').replace("مشاهدة مباشرة مسلسل","").replace("&amp;","&").replace('&#39;',"'").replace('&quot;','"').replace('&#39;',"'")
		url = regex_from_to(a, '<a href="', '" rel="bookmark">').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')
		qual = regex_from_to(a, '<p>', '</p>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
	
		addDir2('[B][COLOR white]%s[/COLOR][/B]' %name,url,3,icon,fanart,'')
		
def SEARCHMV2(query,type):
	if query:
		search = query.replace(' ','+')
	else:
		keyb = xbmc.Keyboard('', 'Type in Query')
		keyb.doModal()
		if (keyb.isConfirmed()):
			search = keyb.getText().replace(' ','+')
			if search == '':
				xbmc.executebuiltin("XBMC.Notification([COLOR gold][B]Search MOVIES[/B][/COLOR],Aborting search,7000,"+icon+")")
				return
			else: pass
	url = thmelat + '/?s='+search
	print url
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	all_videos = regex_get_all(link, '<div class="movieB">', '</a>')
	for a in all_videos:
		name = regex_from_to(a, 'title="', '"').replace("مترجم","").replace("برنامج","").replace('فيلم',"").replace('&#8211;','').replace('&#39;',"").replace('اون لاين','').replace('&#8217;',"").replace('&#8211;',"")
		url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')#.replace("(","").replace("'","")
		qual = regex_from_to(a, '<i class="fa fa-hdd-o"></i>', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')		
		
		addDir2('[B][COLOR white]%s[/COLOR][/B]' %name,url,33,icon,fanart,'')
		
		
def SEARCH(query,type):
	if query:
		search = query.replace(' ','+')
	else:
		keyb = xbmc.Keyboard('', 'Type in Query')
		keyb.doModal()
		if (keyb.isConfirmed()):
			search = keyb.getText().replace(' ','+')
			if search == '':
				xbmc.executebuiltin("XBMC.Notification([COLOR gold][B]Search MOVIES[/B][/COLOR],Aborting search,7000,"+icon+")")
				return
			else: pass
	url = baseurl+'/watch/category/movies/?s='+search
	print url
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	all_videos = regex_get_all(link, '<article id=', '</article>')
	for a in all_videos:
		name = regex_from_to(a, 'data-a2a-title="', '"').replace("مشاهدة مباشرة فيلم","").replace("&amp;","&").replace('&#39;',"'").replace('&quot;','"').replace('&#39;',"'")
		url = regex_from_to(a, '<a href="', '" rel="bookmark">').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')
		qual = regex_from_to(a, '<p>', '</p>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','')
	
		addDir2('[B][COLOR white]%s[/COLOR][/B]' %name,url,3,icon,fanart,'')
# OpenELEQ: query & type-parameter (edited 27 lines above)

def regex_from_to(text, from_string, to_string, excluding=True):
	if excluding:
		try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
		except: r = ''
	else:
		try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
		except: r = ''
	return r


def regex_get_all(text, start_with, end_with):
	r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
	return r


def uncensored(a,b):
    addon.log(len(a))
    addon.log(len(b))
    n = -1
    fuckme=[]
    justshow=[]
    while True:
        
        if n == len(a)-1:
            break
        n +=1
       
        addon.log(n)
        d = int(''.join(str(ord(c)) for c in a[n]))
      
        e=int(''.join(str(ord(c)) for c in b[n]))
        justshow.append(d+e)
        fuckme.append(chr(d+e))
    #print justshow    
    return base64.b64encode(''.join(fuckme))



def random_generator(size=16, chars=string.ascii_letters + string.digits):
    return ''.join(random.choice(chars) for x in range(size))


def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param


def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==3 or mode==7:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok


def addLink(name,url,mode,iconimage,fanart,description=''):
	#u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
	#ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
	return ok

def addDir2(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name })
        liz.setProperty('fanart_image', fanart)        
        liz.setProperty("IsPlayable","true")	
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
def OPEN_URL(url):
	headers = {}
	headers['User-Agent'] = User_Agent
	link = s.get(url, headers=headers).text
	link = link.encode('utf-8')
	return link

def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        hostname=query.hostname.replace("www.","")
        return hostname
		
def readnet(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html

def setView(content, viewType):
    ''' Why recode whats allready written and works well,
    Thanks go to Eldrado for it '''
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':

        print addon.get_setting(viewType)
        if addon.get_setting(viewType) == 'Info':
            VT = '504'
        elif addon.get_setting(viewType) == 'Info2':
            VT = '503'
        elif addon.get_setting(viewType) == 'Info3':
            VT = '515'
        elif addon.get_setting(viewType) == 'Fanart':
            VT = '508'
        elif addon.get_setting(viewType) == 'Poster Wrap':
            VT = '501'
        elif addon.get_setting(viewType) == 'Big List':
            VT = '51'
        elif addon.get_setting(viewType) == 'Low List':
            VT = '724'
        elif addon.get_setting(viewType) == 'Default View':
            VT = addon.get_setting('default-view')

        print viewType
        print VT
        
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )


params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None
query=None
type=None
page=1
# OpenELEQ: query & type-parameter (added 2 lines above)

try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass
try:
	description=urllib.unquote_plus(params["description"])
except:
	pass
try:
	query=urllib.unquote_plus(params["query"])
except:
	pass
try:
	type=urllib.unquote_plus(params["type"])
except:
	pass
try:
        page=int(params["page"])
except:
	pass	
# OpenELEQ: query & type-parameter (added 8 lines above)

if mode==None or url==None or len(url)<1: CAT()
elif mode==1: INDEX(url)
elif mode==2: INDEX2(url)
elif mode==18: INDEX3(url)
elif mode==31: INDEX4(url)
elif mode==3: LINKS(name,url)
elif mode==5: RESOLVE(name,url)  
elif mode==4: TV()
elif mode==10: MV0()
elif mode==12: MV()
elif mode==14: MV1()
elif mode==30: MVT()
elif mode==400: MVHDARAB()
elif mode==401: GENREHDARABMV(url)
elif mode==402: INDEX5(url)
elif mode==403: AZHDARABMV(url)
elif mode==404: gethosts3(url)
elif mode==405: INDEX6(url)
elif mode==406: INDEX7(url)
elif mode==7: LINKS2(url,description)
elif mode==8: SEARCH(query,type)
elif mode==13: SEARCHTV(query,type)
elif mode==20: SEARCHMV1(query,type)
elif mode==35: SEARCHMV2(query,type)
# OpenELEQ: query & type-parameter (added to line above)
elif mode==9: GENRE(url)
elif mode==32: GENRE2(url)


elif mode==10: COUNTRY(url)
elif mode==11: YEAR(url)
elif mode==21: YEARMV1(url)
elif mode==300: getsongsmain()
elif mode==301: getartists(url)
elif mode==302: getalbams(url)
elif mode==303: getsongs(url)
elif mode==304: getnewsongs(url)
elif mode==15: playsong(url)
elif mode==17: gethosts(url)
elif mode==19: gethosts1(url)
elif mode==33: getlink(url)
elif mode==34: gethosts2(url)
elif mode==6: getepisodes(url,name)
elif mode==16: resolve_host(url)
elif mode==22: resolve_host1(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))



































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































# if xbmcvfs.exists(xbmc.translatePath('special://home/userdata/sources.xml')):
        # with open(xbmc.translatePath('special://home/userdata/sources.xml'), 'r+') as f:
                # my_file = f.read()
                # if re.search(r'http://muckys.mediaportal4kodi.ml', my_file):
                        # addon.log('===Muckys===Source===Found===in===sources.xml===Not Deleting.===')
                # else:
                        # line1 = "you have Installed The MDrepo From An"
                        # line2 = "Unofficial Source And Will Now Delete Please"
                        # line3 = "Install From [COLOR red]http://muckys.mediaportal4kodi.ml[/COLOR]"
                        # line4 = "Removed Repo And Addon"
                        # line5 = "successfully"
                        # xbmcgui.Dialog().ok(addon_name, line1, line2, line3)
                        # delete_addon = xbmc.translatePath('special://home/addons/'+addon_id)
                        # delete_repo = xbmc.translatePath('special://home/addons/repository.mdrepo')
                        # shutil.rmtree(delete_addon, ignore_errors=True)
                        # shutil.rmtree(delete_repo, ignore_errors=True)
                        # dialog = xbmcgui.Dialog()
                        # addon.log('===DELETING===ADDON===+===REPO===')
                        # xbmcgui.Dialog().ok(addon_name, line4, line5)




















































































































































































































































































































































































































































































































































































































































                        
