import os,xbmc

addon_path = xbmc.translatePath(os.path.join('special://home/addons', 'repository.MG.Arabic'))
addonxml=xbmc.translatePath(os.path.join('special://home/addons', 'repository.MG.Arabic','addon.xml'))




WRITEME='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<addon id="repository.MG.Arabic" name="..[COLOR red] MG Arabic[/COLOR]" version="3.0.1" provider-name="[COLOR red] MG Arabic[/COLOR]">
	<extension point="xbmc.addon.repository" name="MG Arabic">	
		<dir>
	        <info compressed="false">https://offshoregit.com/tvaresolvers/tva-common-repository/raw/master/addons.xml</info>
	        <checksum>https://offshoregit.com/tvaresolvers/tva-common-repository/raw/master/addons.xml.md5</checksum>
	        <datadir zip="true">https://offshoregit.com/tvaresolvers/tva-common-repository/raw/master/zips/</datadir>
	    </dir>			
		    <info compressed="false">https://raw.githubusercontent.com/Yaser7440/repository.MG.Arabic/master/addons.xml</info>
            <checksum>https://raw.githubusercontent.com/Yaser7440/repository.MG.Arabic/master/addons.xml.md5</checksum>
            <datadir zip="true">https://raw.githubusercontent.com/Yaser7440/repository.MG.Arabic/master/zip</datadir>
		
			
	</extension>
	<requires>
	<import addon="plugin.program.MG.AR.wizard" />
 </requires>
	<extension point="xbmc.addon.metadata">
		<summary>http://mg.esy.es/Kodi/</summary>
		<description>MG Arabic v3.0.1</description>
		<platform>all</platform>
	</extension>
</addon>
'''





if os.path.exists(addon_path) == False:
        os.makedirs(addon_path)


     
if os.path.exists(addonxml) == False:

    f = open(addonxml, mode='w')
    f.write(WRITEME)
    f.close()

    xbmc.executebuiltin('UpdateLocalAddons') 
    xbmc.executebuiltin("UpdateAddonRepos")
