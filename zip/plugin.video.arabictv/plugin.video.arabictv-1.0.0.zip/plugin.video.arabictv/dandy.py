import os,xbmc












if os.path.exists(addon_path) == False:
        os.makedirs(addon_path)


     
if os.path.exists(addonxml) == False:

    f = open(addonxml, mode='w')
    f.write(WRITEME)
    f.close()

    xbmc.executebuiltin('UpdateLocalAddons') 
    xbmc.executebuiltin("UpdateAddonRepos")
