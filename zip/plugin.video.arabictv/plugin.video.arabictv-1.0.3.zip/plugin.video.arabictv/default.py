# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Binky TV special thanks to original authors of the code
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Author: Dandymedia
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon,dandy
from addon.common.addon import Addon

addonID = 'plugin.video.arabictv'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')
fanart = local.getAddonInfo('fanart')
xbmc.executebuiltin('Container.SetViewMode(50)')

YOUTUBE_CHANNEL_ID_1 = "PLJ-qZvjnxPlRLXoSY233JNAyrZAe2t3Sr"
YOUTUBE_CHANNEL_ID_2 = "UCLmDjHLmnXB8cpnYJDUfKCA"
YOUTUBE_CHANNEL_ID_3 = "PLZHhFgNF6x35FUWu1a8qysaZhHm4lY3Nf"



# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

  
	
    plugintools.add_item( 
        #action="", 
        title="arabic live",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://i.imgsafe.org/a76f1562af.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="arabic movies",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://i.imgsafe.org/a77b2dd308.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="arabic music",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://i.imgsafe.org/a780e90c72.jpg",
        folder=True )   

    plugintools.add_item( 
        #action="", 
        title="[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]",
        url="",
        thumbnail="https://raw.githubusercontent.com/Yaser7440/repository.MG.Arabic/master/image/MG.Arabic.png",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[B][COLOR white]••3lbh.Net••[/COLOR][/B]",
        url="plugin://plugin.video.3lbh.Net/3lbh.Net.py",
        thumbnail="https://raw.githubusercontent.com/Yaser7440/repository.MG.Arabic/master/zip/plugin.video.3lbh.Net/resources/icon.png",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[B][COLOR white]••ShowsCen••[/COLOR][/B]",
        url="plugin://plugin.video.showscen/showscen.py",
        thumbnail="https://raw.githubusercontent.com/Yaser7440/repository.MG.Arabic/master/zip/plugin.video.showscen/resources/icon.png",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[B][COLOR white]••EL7L.CO••[/COLOR][/B]",
        url="plugin://plugin.video.EL7L/el7l.py",
        thumbnail="https://raw.githubusercontent.com/Yaser7440/repository.MG.Arabic/master/zip/plugin.video.EL7L/img/icon.png",
        folder=True )
    		
    plugintools.add_item( 
        #action="", 
        title="[B][COLOR white]••EasyCima••[/COLOR][/B]",
        url="plugin://plugin.video.easycima/easycima.py",
        thumbnail="https://raw.githubusercontent.com/Yaser7440/repository.MG.Arabic/master/zip/plugin.video.easycima/img/icon.png",
        folder=True )
		    		
    plugintools.add_item( 
        #action="", 
        title="[B][COLOR white]••6arbyat••[/COLOR][/B]",
        url="plugin://plugin.audio.6arbyat/default.py",
        thumbnail="https://raw.githubusercontent.com/Yaser7440/repository.MG.Arabic/master/zip/plugin.audio.6arbyat/resources/icon.png",
        folder=True )
				    		
    plugintools.add_item( 
        #action="", 
        title="[B][COLOR white]••ArabMovies••[/COLOR][/B]",
        url="plugin://plugin.video.arabmovies/default.py",
        thumbnail="https://raw.githubusercontent.com/Yaser7440/repository.MG.Arabic/master/zip/plugin.video.arabmovies/icon.png",
        folder=True )
						    		
    plugintools.add_item( 
        #action="", 
        title="[B][COLOR white]••CimaClub••[/COLOR][/B]",
        url="plugin://plugin.video.cimaclub/cimaclub.py",
        thumbnail="https://raw.githubusercontent.com/Yaser7440/repository.MG.Arabic/master/zip/plugin.video.cimaclub/img/icon.png",
        folder=True )
								    		
    plugintools.add_item( 
        #action="", 
        title="[B][COLOR white]••ArabLionz••[/COLOR][/B]",
        url="plugin://plugin.video.arablionz/default.py",
        thumbnail="https://raw.githubusercontent.com/Yaser7440/repository.MG.Arabic/master/zip/plugin.video.arablionz/icon.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[B][COLOR white]••ArabHd••[/COLOR][/B]",
        url="plugin://plugin.video.arabhd/arabhd.py",
        thumbnail="https://raw.githubusercontent.com/Yaser7440/repository.MG.Arabic/master/zip/plugin.video.arabhd/img/icon.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[B][COLOR white]••Aflamy••[/COLOR][/B]",
        url="plugin://plugin.video.aflamy/Aflamy.py",
        thumbnail="https://raw.githubusercontent.com/Yaser7440/repository.MG.Arabic/master/zip/plugin.video.aflamy/img/icon.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[B][COLOR white]••Anakbnet••[/COLOR][/B]",
        url="plugin://plugin.video.anakbnet/anakbnet.py",
        thumbnail="https://raw.githubusercontent.com/Yaser7440/repository.MG.Arabic/master/zip/plugin.video.anakbnet/img/icon.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[B][COLOR white]••Movizland••[/COLOR][/B]",
        url="plugin://plugin.video.movizland/movizland.py",
        thumbnail="https://raw.githubusercontent.com/Yaser7440/repository.MG.Arabic/master/zip/plugin.video.movizland/icon.png",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[B][COLOR white]••ArabMoviez.Org••[/COLOR][/B]",
        url="plugin://plugin.video.arab-moviezorg/arabmoviezorg.py",
        thumbnail="https://raw.githubusercontent.com/Yaser7440/repository.MG.Arabic/master/zip/plugin.video.arab-moviezorg/img/icon.png",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[B][COLOR white]••Shahid Arabic••[/COLOR][/B]",
        url="plugin://plugin.video.shahidmbcnet/default.py",
        thumbnail="https://raw.githubusercontent.com/Yaser7440/repository.MG.Arabic/master/zip/plugin.video.shahidmbcnet/icon.png",
        folder=True )	
    

   

run()		
