# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys
import urllib,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,xbmcvfs
import requests
import urlresolver
##################################
from md_request import get_params
from md_request import uncensored
from md_request import OPEN_URL
from md_request import readnet2
from md_request import readnet
from md_request import decodeHtml
from md_request import regex_get_all
from md_request import regex_from_to
from md_request import addDir4
from md_request import addDir
from md_request import resolve_host2
from md_request import playlink
#------------------------------
from md_view import setView
from md_tools import md
#------------------------------
try:
    from common import Addon
    from addon.common.net import Net
    from urlresolver import resolve
except:
    print 'Failed to import script.module.mg.arabic.common'
    xbmcgui.Dialog().ok("Cimaclub Import Failure", "Failed to import addon.common", "A component needed by Cimaclub is missing on your system")  	
dbg = False # Set to false if you don't want debugging 
#Common Cache
try:
  import StorageServer
except:
  import storageserverdummy as StorageServer
cache = StorageServer.StorageServer('plugin.video.cimaclub')
addon_id='plugin.video.cimaclub'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/img/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
show_tv = selfAddon.getSetting('enable_shows')
baseurl = selfAddon.getSetting('base_url')

baseurl = 'http://cimaclub.com'
####functions


def CAT():
         addDir('[B][COLOR white]البحث[/COLOR][/B]', 'http://cimaclub.com/?s=',103,art+'/search.png',fanart,'')
         addDir('[B][COLOR white]قوائم الافلام[/COLOR][/B]','url',8,art+'/movies.png',fanart,'')
         addDir('[B][COLOR white]قوائم المسلسلات[/COLOR][/B]','url',105,art+'/tvshows.png',fanart,'')
         addDir('[B][COLOR white]عروض أخرى [/COLOR][/B]','url',102,art+'/showscen.png',fanart,'')
                      

##########################################showscen
def ShowMov():

                menuitems=[]
                
                menuitems.append(("[B][COLOR white]البحث[/COLOR][/B]", baseurl+'/?s=',103,art+'/search.png','',1))
                menuitems.append(("[B][COLOR white]افلام اجنبيه[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]افلام عربيه[/COLOR][/B]",baseurl+'/category/افلام-عربي/',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]افلام انيميشن[/COLOR][/B]",baseurl+'/category/انيميشن/افلام-انيميشن/',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]افلام هندي[/COLOR][/B]",baseurl+'/category/افلام-هندي',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]افلام مدبلجه[/COLOR][/B]",baseurl+'/quality/مدبلج/',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]افلام اسيوية[/COLOR][/B]",baseurl+'/category/افلام-اسيوية',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]الاكثر مشاهدة[/COLOR][/B]",baseurl+'/most-views',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]الاحدث[/COLOR][/B]",baseurl+'/wp-content/themes/Cimaclub/filter/recent',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]المثبتة[/COLOR][/B]",baseurl+'/wp-content/themes/Cimaclub/filter/pin',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]الاكثر اعجابا[/COLOR][/B]",baseurl+'/wp-content/themes/Cimaclub/filter/mostlike',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]الاعلى تقيما[/COLOR][/B]",baseurl+'/wp-content/themes/Cimaclub/filter/toprating',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]تصنيفات الافلام الاجنبيه[/COLOR][/B]", 'url',101,art+'/movies.png','',1))
				
                for title, url, mode,pic,desc,page in menuitems:
                    addDir(title, url, mode, pic,desc,1)
					
def ShowTv():

                menuitems=[]
                
                menuitems.append(("[B][COLOR white]البحث[/COLOR][/B]",baseurl+'/?s=',103,art+'/search.png','',1))
                menuitems.append(("[B][COLOR white]مسلسلات اجنبي[/COLOR][/B]",baseurl+'/category/مسلسلات-اجنبي/',100,art+'/tvshows.png','',1))
                menuitems.append(("[B][COLOR white]مسلسلات عربي[/COLOR][/B]",baseurl+'/category/مسلسلات-عربي',100,art+'/tvshows.png','',1))
                menuitems.append(("[B][COLOR white]مسلسلات انيميشن[/COLOR][/B]",baseurl+'/category/انيميشن/مسلسلات-انيميشن',100,art+'/tvshows.png','',1))
                menuitems.append(("[B][COLOR white]مسلسلات كورية[/COLOR][/B]",baseurl+'/category/مسلسلات-كورية',100,art+'/tvshows.png','',1))
                menuitems.append(("[B][COLOR white]مسلسلات تركية[/COLOR][/B]",baseurl+'/category/مسلسلات-تركية',100,art+'/tvshows.png','',1))
                menuitems.append(("[B][COLOR white]رمضان 2016[/COLOR][/B]",baseurl+'/category/مسلسلات-عربي/مسلسلات-رمضان-2016',100,art+'/tvshows.png','',1))			
                for title, url, mode,pic,desc,page in menuitems:
                    addDir(title, url, mode, pic,desc,1)

					
def getgenre_movies(url):

                menuitems=[]
                
                menuitems.append(("[B][COLOR white]السنة[/COLOR][/B]",'url',104,art+'/search.png','',1))
                menuitems.append(("[B][COLOR white]اثارة[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=thriller',100,art+'/search.png','',1))
                menuitems.append(("[B][COLOR white]اكشين[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=action',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]انميشن[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=animation',100,art+'/tvshows.png','',1))
                menuitems.append(("[B][COLOR white]التاريخ[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=history',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]جريمة[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=crime',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]حرب[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=war',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]الخيال العلمي[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=sci-fi',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]دراما[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=drama',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]دراما كورية[/COLOR][/B]",baseurl+'/genre/دراما-كورية/',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]رعب[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=horror',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]قصة حب[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=romance',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]رياضة[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=sport',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]سيرة ذاتية[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=biography',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]عائلي[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=family',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]الغربي[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=western',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]الغموض[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=mystery',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]خيال[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=fantasy',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]أفلام قصيرة[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=short',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]كوميديا[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=comedy',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]مغامرة[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=adventure',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]موسيقى[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=music',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]وثائقي[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=documentary',100,art+'/musical.jpg','',1))				
                for title, url, mode,pic,desc,page in menuitems:
                    addDir(title, url, mode, pic,desc,1)					

					
def others(url):					

                menuitems=[]
                
                menuitems.append(("[B][COLOR white]عروض المصارعه[/COLOR][/B]",baseurl+'/category/المصارعه-wwe',100,art+'/search.png','',1))
                menuitems.append(("[B][COLOR white]وثائقيات[/COLOR][/B]",baseurl+'/category/افلام-وثائقية/',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]منوعات[/COLOR][/B]",baseurl+'/category/منوعات',100,art+'/tvshows.png','',1))
                menuitems.append(("[B][COLOR white]عروض تلفزيونيه[/COLOR][/B]",baseurl+'/category/مسرحيات-وعروض-تلفزيونيه',100,art+'/musical.jpg','',1))				
                for title, url, mode,pic,desc,page in menuitems:
                    addDir(title, url, mode, pic,desc,1)						


def getyears_movies(url):
        for i in range(1915,2018):
             addDir('[B][COLOR white]%s[/COLOR][/B]' %str(i),baseurl+'/category/افلام-اجنبي/?release-year='+str(i)+"/",100,'','',1)	
             setView(addon_id,'movies', 'movie-view')			 
###################################movies
			  
def search():
        keyb = xbmc.Keyboard('', 'Search MOVIES')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = baseurl+'/?s='+search
                getmovies(url)
                setView(addon_id,'movies', 'movie-view') 



def getmovies(url):##movies
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link,  '<div class="movie">', '<div class="posterContent">')
	items = len(all_videos)
	for a in all_videos:
		name = regex_from_to(a, '<h2>', '</h2>')
		url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')
		desc = regex_from_to(a, '<p>', '</p>').replace('&hellip;','')
		genre = regex_from_to(a, '<span class="itemprop">', '</span>')
		date = regex_from_to(a, '<h2 class="titleBack">', '</h2>')
		credits = regex_from_to(a, '<span class="itemprop">', '</span>')
		fanart = regex_from_to(a, 'src="', '"')				
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %decodeHtml(name),url,1,icon,fanart,desc,genre,decodeHtml(date),credits)
	try:
		nextp=re.compile('<li><a href="(.*?)">الصفحة التالية &laquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,100,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id,'movies', 'movie-view')

	



				

                    
###############################################tv shows

def getseries(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  #http://www.showscen.com/watch/category/tv-shows/page/2/
                  
                     url_page=urlmain+'/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('<article id="(.*?)')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="article-helper notloaded">')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)"'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    regx='''data-a2a-title="(.*?)">'''
                    name=re.findall(regx,block, re.M|re.I)[0]
                   
                    regx='''src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:str(name)
                    
                    try:img.encode("utf-8")
                    except:img=str(img)                    
                    addDir(name,href,202,img,'',1)
                    
               
                   
                
                
                addDir("next page",urlmain,200,art+'/next.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,200,'','',str(page+1))




 


#######################################host resolving                                                    




def gethosts(urlmain):##cinema and tv featured
                
        data=readnet(urlmain)
        #data=read_url(urlmain)
        #data=read_url(url)
        #http://www.movizcinma.com/wp-content/themes/series4watch/server1.php?server=1&p=24927
        
        regx="rel='shortlink' href='(.+?)'"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[1]
        print "id",id
        for i in range(1,7):
          url='http://cimaclub.com/wp-content/themes/Cimaclub/servers/server.php?q='+id+'&i='+str(i)
          print url
          addDir('[B][COLOR white][%s] SERVER[/COLOR][/B]' %str(i),url,2, 'img/server.png')
		  
def gethosts2(urlmain):

                
                data=readnet(urlmain)
	        print data
                	
                #regx='''</span><a href='(.+?)' class='redirect_link'>'''
                #regx1='''<iframe src="(.+?)" scrolling="no" frameborder="0" width="700" height="430" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'''
                regx2='''<IFRAME SRC="(.+?)".+?></IFRAME>'''
                
                regx3='''<iframe .+? src="(.+?)" .+?></iframe>'''
                regx4='''<iframe .+? src="(.+?)" ></iframe>'''
                match2 = re.findall(regx2,data, re.M|re.I)
                match3 = re.findall(regx3,data, re.M|re.I)
                match4 = re.findall(regx4,data, re.M|re.I)
                #match5 = re.findall(regx5,data, re.M|re.I)
         
                #getmatch(match1)
                getmatch(match2)
                getmatch(match3)
                getmatch(match4)
                #getmatch(match5)
               
                return


     
############################################xbmc tools	

params=get_params();url=None; name=None; mode=None; page=1

	
try:url=urllib.unquote_plus(params["url"])
except:pass
try:name=urllib.unquote_plus(params["name"])
except:pass
try:mode=int(params["mode"])
except:pass
try:page=int(params["page"])
except:pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
#################################man
if mode==None or url==None or len(url)<1: CAT()
elif mode==8: ShowMov()
elif mode==9: tarbyat()
elif mode==105: ShowTv()
###########################
elif mode==1: gethosts(url)
elif mode==10: gethosts2(url)		
elif mode==2: resolve_host2(url)
elif mode==3: playlink(url)  	
elif mode==100: getmovies(url)
elif mode==101: getgenre_movies('movies')	
elif mode == 102:others('movies')
elif mode==104: getyears_movies(name)		
########		
elif mode==103: search()    
elif mode==200: getseries(name,url,page)	
elif mode==201: getseasons(name,url,page)
elif mode==202: getepisodes(name,url,page)
xbmcplugin.endOfDirectory(int(sys.argv[1]))                              































































































































































































































if xbmcvfs.exists(xbmc.translatePath('special://home/userdata/sources.xml')):
        with open(xbmc.translatePath('special://home/userdata/sources.xml'), 'r+') as f:
                my_file = f.read()
                if re.search(r'http://mg.esy.es/Kodi', my_file):
                        addon.log('===MG.Arabic===Source===Found===in===sources.xml===Not Deleting.===')
                else:
                        line1 = "you have Installed The MDrepo From An"
                        line2 = "Unofficial Source And Will Now Delete Please"
                        line3 = "Install From [COLOR red]http://mg.esy.es/Kodi[/COLOR]"
                        line4 = "Removed Repo And Addon"
                        line5 = "successfully"
                        xbmcgui.Dialog().ok(addon_name, line1, line2, line3)
                        delete_addon = xbmc.translatePath('special://home/addons/'+addon_id)
                        delete_repo = xbmc.translatePath('special://home/addons/repository.MG.Arabic')
                        shutil.rmtree(delete_addon, ignore_errors=True)
                        shutil.rmtree(delete_repo, ignore_errors=True)
                        dialog = xbmcgui.Dialog()
                        addon.log('===DELETING===ADDON===+===REPO===')
                        xbmcgui.Dialog().ok(addon_name, line4, line5)