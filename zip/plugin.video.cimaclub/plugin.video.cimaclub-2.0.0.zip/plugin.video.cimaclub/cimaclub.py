# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys
import urllib,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,xbmcvfs
import requests
import urlresolver
from addon.common.addon import Addon
from addon.common.net import Net

dbg = False # Set to false if you don't want debugging
  
#Common Cache
try:
  import StorageServer
except:
  import storageserverdummy as StorageServer
cache = StorageServer.StorageServer('plugin.video.cimaclub')

addon_id='plugin.video.cimaclub'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/img/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
show_tv = selfAddon.getSetting('enable_shows')
baseurl = selfAddon.getSetting('base_url')
s = requests.session()
net = Net()
def OPEN_URL(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = requests.get(url, headers=headers).text
    link = link.encode('utf-8')
    return link
            

baseurl = 'http://cimaclub.com'
####functions

    
def readnet(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      

def CAT():
         addDir('[B][COLOR white]البحث[/COLOR][/B]', 'http://cimaclub.com/?s=',103,art+'/search.png',fanart,'')
         addDir('[B][COLOR white]قوائم الافلام[/COLOR][/B]','url',8,art+'/movies.png',fanart,'')
         addDir('[B][COLOR white]قوائم المسلسلات[/COLOR][/B]','url',105,art+'/tvshows.png',fanart,'')
         addDir('[B][COLOR white]عروض أخرى [/COLOR][/B]','url',102,art+'/showscen.png',fanart,'')
                      

##########################################showscen
def ShowMov():

                menuitems=[]
                
                menuitems.append(("[B][COLOR white]البحث[/COLOR][/B]", baseurl+'/?s=',103,art+'/search.png','',1))
                menuitems.append(("[B][COLOR white]افلام اجنبيه[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]افلام عربيه[/COLOR][/B]",baseurl+'/category/افلام-عربي/',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]افلام انيميشن[/COLOR][/B]",baseurl+'/category/انيميشن/افلام-انيميشن/',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]افلام هندي[/COLOR][/B]",baseurl+'/category/افلام-هندي',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]افلام مدبلجه[/COLOR][/B]",baseurl+'/quality/مدبلج/',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]افلام اسيوية[/COLOR][/B]",baseurl+'/category/افلام-اسيوية',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]الاكثر مشاهدة[/COLOR][/B]",baseurl+'/most-views',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]الاحدث[/COLOR][/B]",baseurl+'/wp-content/themes/Cimaclub/filter/recent',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]المثبتة[/COLOR][/B]",baseurl+'/wp-content/themes/Cimaclub/filter/pin',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]الاكثر اعجابا[/COLOR][/B]",baseurl+'/wp-content/themes/Cimaclub/filter/mostlike',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]الاعلى تقيما[/COLOR][/B]",baseurl+'/wp-content/themes/Cimaclub/filter/toprating',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]تصنيفات الافلام الاجنبيه[/COLOR][/B]", 'url',101,art+'/movies.png','',1))
				
                for title, url, mode,pic,desc,page in menuitems:
                    addDir(title, url, mode, pic,desc,1)
					
def ShowTv():

                menuitems=[]
                
                menuitems.append(("[B][COLOR white]البحث[/COLOR][/B]",baseurl+'/?s=',103,art+'/search.png','',1))
                menuitems.append(("[B][COLOR white]مسلسلات اجنبي[/COLOR][/B]",baseurl+'/category/مسلسلات-اجنبي/',100,art+'/tvshows.png','',1))
                menuitems.append(("[B][COLOR white]مسلسلات عربي[/COLOR][/B]",baseurl+'/category/مسلسلات-عربي',100,art+'/tvshows.png','',1))
                menuitems.append(("[B][COLOR white]مسلسلات انيميشن[/COLOR][/B]",baseurl+'/category/انيميشن/مسلسلات-انيميشن',100,art+'/tvshows.png','',1))
                menuitems.append(("[B][COLOR white]مسلسلات كورية[/COLOR][/B]",baseurl+'/category/مسلسلات-كورية',100,art+'/tvshows.png','',1))
                menuitems.append(("[B][COLOR white]مسلسلات تركية[/COLOR][/B]",baseurl+'/category/مسلسلات-تركية',100,art+'/tvshows.png','',1))
                menuitems.append(("[B][COLOR white]رمضان 2016[/COLOR][/B]",baseurl+'/category/مسلسلات-عربي/مسلسلات-رمضان-2016',100,art+'/tvshows.png','',1))			
                for title, url, mode,pic,desc,page in menuitems:
                    addDir(title, url, mode, pic,desc,1)

					
def getgenre_movies(url):

                menuitems=[]
                
                menuitems.append(("[B][COLOR white]السنة[/COLOR][/B]",'url',104,art+'/search.png','',1))
                menuitems.append(("[B][COLOR white]اثارة[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=thriller',100,art+'/search.png','',1))
                menuitems.append(("[B][COLOR white]اكشين[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=action',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]انميشن[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=animation',100,art+'/tvshows.png','',1))
                menuitems.append(("[B][COLOR white]التاريخ[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=history',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]جريمة[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=crime',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]حرب[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=war',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]الخيال العلمي[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=sci-fi',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]دراما[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=drama',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]دراما كورية[/COLOR][/B]",baseurl+'/genre/دراما-كورية/',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]رعب[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=horror',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]قصة حب[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=romance',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]رياضة[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=sport',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]سيرة ذاتية[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=biography',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]عائلي[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=family',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]الغربي[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=western',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]الغموض[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=mystery',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]خيال[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=fantasy',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]أفلام قصيرة[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=short',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]كوميديا[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=comedy',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]مغامرة[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=adventure',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]موسيقى[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=music',100,art+'/musical.jpg','',1))
                menuitems.append(("[B][COLOR white]وثائقي[/COLOR][/B]",baseurl+'/category/افلام-اجنبي/?genre=documentary',100,art+'/musical.jpg','',1))				
                for title, url, mode,pic,desc,page in menuitems:
                    addDir(title, url, mode, pic,desc,1)					

					
def others(url):					

                menuitems=[]
                
                menuitems.append(("[B][COLOR white]عروض المصارعه[/COLOR][/B]",baseurl+'/category/المصارعه-wwe',100,art+'/search.png','',1))
                menuitems.append(("[B][COLOR white]وثائقيات[/COLOR][/B]",baseurl+'/category/افلام-وثائقية/',100,art+'/movies.png','',1))
                menuitems.append(("[B][COLOR white]منوعات[/COLOR][/B]",baseurl+'/category/منوعات',100,art+'/tvshows.png','',1))
                menuitems.append(("[B][COLOR white]عروض تلفزيونيه[/COLOR][/B]",baseurl+'/category/مسرحيات-وعروض-تلفزيونيه',100,art+'/musical.jpg','',1))				
                for title, url, mode,pic,desc,page in menuitems:
                    addDir(title, url, mode, pic,desc,1)						


def getyears_movies(url):
        for i in range(1915,2018):
             addDir(str(i),baseurl+'/release-year/'+str(i)+"/",100,'','',1)					
###################################movies
			  
def search():
        keyb = xbmc.Keyboard('', 'Search MOVIES')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = baseurl+'/?s='+search
                getmovies(url)


                        
               
                   
                
        
def getmovies(url):##movies
        link = OPEN_URL(url)
        #link = link.encode('ascii', 'ignore').decode('ascii')
        all_videos = regex_get_all(link, '<div class="movie">', '<div class="posterContent">')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '<h2>', '</h2>').replace("فيلم ","").replace(" مترجم","").replace('&#038;','').replace('&#8217;','')
                #name = addon.unescape(name)
                #name = name.encode('utf-8')
                qual = regex_from_to(a, '<p>', '</p>').replace('مشاهدة وتحميل فيلم ','').replace('...','').replace('&#038;','')				
                url = regex_from_to(a, 'href="', '"')		
                thumb = regex_from_to(a, 'src="', '"')              					
                addDir('[B][COLOR white]%s[/COLOR][/B]:[B][I][COLOR red]%s[/COLOR][/I][/B]' %(name,qual),url,1,thumb,fanart,items)
        try:
                np = re.compile('<li><a href="(.*?)">الصفحة التالية &laquo;</a></li>').findall(link)[0]
                addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',np,100,art+'/next.png',fanart,'')
        except: pass
        setView('movies', 'movie-view')

				

                    
###############################################tv shows

def getseries(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  #http://www.showscen.com/watch/category/tv-shows/page/2/
                  
                     url_page=urlmain+'/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('<article id="(.*?)')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="article-helper notloaded">')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)"'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    regx='''data-a2a-title="(.*?)">'''
                    name=re.findall(regx,block, re.M|re.I)[0]
                   
                    regx='''src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:str(name)
                    
                    try:img.encode("utf-8")
                    except:img=str(img)                    
                    addDir(name,href,202,img,'',1)
                    
               
                   
                
                
                addDir("next page",urlmain,200,art+'/next.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,200,'','',str(page+1))




 


#######################################host resolving                                                    




def gethosts(urlmain):##cinema and tv featured
                
        data=readnet(urlmain)
        #data=read_url(urlmain)
        #data=read_url(url)
        #http://www.movizcinma.com/wp-content/themes/series4watch/server1.php?server=1&p=24927
        
        regx="rel='shortlink' href='(.+?)'"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[1]
        print "id",id
        for i in range(1,7):
          url='http://cimaclub.com/wp-content/themes/Cimaclub/servers/server.php?q='+id+'&i='+str(i)
          print url
          addDir('server'+str(i),url,2, 'img/server.png')
		  
def gethosts2(urlmain):

                
                data=readnet(urlmain)
	        print data
                	
                #regx='''</span><a href='(.+?)' class='redirect_link'>'''
                #regx1='''<iframe src="(.+?)" scrolling="no" frameborder="0" width="700" height="430" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'''
                regx2='''<IFRAME SRC="(.+?)".+?></IFRAME>'''
                
                regx3='''<iframe .+? src="(.+?)" .+?></iframe>'''
                regx4='''<iframe .+? src="(.+?)" ></iframe>'''
                match2 = re.findall(regx2,data, re.M|re.I)
                match3 = re.findall(regx3,data, re.M|re.I)
                match4 = re.findall(regx4,data, re.M|re.I)
                #match5 = re.findall(regx5,data, re.M|re.I)
         
                #getmatch(match1)
                getmatch(match2)
                getmatch(match3)
                getmatch(match4)
                #getmatch(match5)
               
                return


	    
	    
def resolve_host(url):
        
        from urlresolver import resolve
        data=readnet(url)
        reurl='''<iframe.*?src="(.*?)".*?></iframe>'''
        url=re.findall(reurl,data, re.M|re.I)[0].split("=")[0]
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    listItem = xbmcgui.ListItem(path=str(stream_link))
	    xbmcplugin.setResolvedUrl(sys.argv[0], True, listItem)   
        else:
            addDir("Error,"+stream_link,"",9,"") 	    
def resolve_host2(url):#last good
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(stream_link)  
        else:
            addDir("Error,"+stream_link,"",9,"")
def playlink(stream_link):
            
            xbmc.Player().play(stream_link)
            sys.exit(0)

###functions

def readnet(url):
        import requests
        data=requests.get(url, verify=False)
        return data.content
def readnet2(url):
            
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html	    
def removeunicode(data):
             
             
            
              try:
                    type(data)
                    data=data.decode('unicode_escape').encode('ascii','replace').replace("?","").strip()
        
              except:
                    pass
              
              return data
              
def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        
        return query.hostname             
############################################xbmc tools	
def regex_get_all(text, start_with, end_with):
        r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
        return r
 
def regex_from_to(text, from_string, to_string, excluding=True):
	if excluding:
		try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
		except: r = ''
	else:
		try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
		except: r = ''
	return r    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param

def getgroups(data, pattern, grupsNum = 1, ignoreCase = False):
        tab = []
        if ignoreCase:
            match = re.search(pattern, data, re.IGNORECASE)
        else:
            match = re.search(pattern, data)
        
        for idx in range(grupsNum):
            try:
                value = match.group(idx + 1)
            except:
                value = ''

            tab.append(value)

        return tab
def getdata(data, marker1, marker2, withMarkers = True, caseSensitive = True):
        if caseSensitive:
            idx1 = data.find(marker1)
        else:
            idx1 = data.lower().find(marker1.lower())
        if -1 == idx1:
            return (False, '')
        if caseSensitive:
            idx2 = data.find(marker2, idx1 + len(marker1))
        else:
            idx2 = data.lower().find(marker2.lower(), idx1 + len(marker1))
        if -1 == idx2:
            return (False, '')
        if withMarkers:
            idx2 = idx2 + len(marker2)
        else:
            idx1 = idx1 + len(marker1)
        return  data[idx1:idx2]
	
def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
def addDir2(name,url,mode,iconimage,itemcount):
        name = name.replace('[B][COLOR white]','').replace('[/COLOR][/B]','')
        meta = metaget.get_meta('movie',name)
        if meta['cover_url']=='':
            try:
                meta['cover_url']=iconimage
            except:
                meta['cover_url']=icon
        name = '[B][COLOR white]' + name + '[/COLOR][/B]'
        meta['title'] = name
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&site="+str(site)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=meta['cover_url'], thumbnailImage=meta['cover_url'])
        liz.setInfo( type="Video", infoLabels= meta )
        contextMenuItems = []
        if meta['trailer']:
                contextMenuItems.append(('Play Trailer', 'XBMC.RunPlugin(%s)' % addon.build_plugin_url({'mode': 8, 'url':meta['trailer']})))
        contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        if not meta['backdrop_url'] == '': liz.setProperty('fanart_image', meta['backdrop_url'])
        else: liz.setProperty('fanart_image', fanart)
        if mode==100:
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
        else:
             ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
        return ok		
def setView(content, viewType):
    ''' Why recode whats allready written and works well,
    Thanks go to Eldrado for it '''
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':

        print addon.get_setting(viewType)
        if addon.get_setting(viewType) == 'Info':
            VT = '504'
        elif addon.get_setting(viewType) == 'Info2':
            VT = '503'
        elif addon.get_setting(viewType) == 'Info3':
            VT = '515'
        elif addon.get_setting(viewType) == 'Fanart':
            VT = '508'
        elif addon.get_setting(viewType) == 'Poster Wrap':
            VT = '501'
        elif addon.get_setting(viewType) == 'Big List':
            VT = '51'
        elif addon.get_setting(viewType) == 'Low List':
            VT = '724'
        elif addon.get_setting(viewType) == 'Default View':
            VT = addon.get_setting('default-view')

        print viewType
        print VT
        
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )

params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
#################################man
if mode==None or url==None or len(url)<1:
        CAT()

elif mode==8:
        ShowMov()
elif mode==9:
		tarbyat()

elif mode==105:
        ShowTv()
###########################
		
elif mode==1:
        print ""+url
        gethosts(url)
elif mode==10:
        print ""+url
        gethosts2(url)		
elif mode==2:
        print ""+url
        resolve_host(url)
elif mode==20:
        print ""+url
        resolve_host2(url)
elif mode==3:
        print ""+url
        playlink(url)  	
elif mode==100: getmovies(url)
elif mode==101:
        print ""+url
        getgenre_movies('movies')	
elif mode == 102:
		print ""+url
		others('movies')
elif mode==104:
	print ""+url
	
	getyears_movies(name)		
########		
     

elif mode==103: search()    
elif mode==200:
        print ""+url
	getseries(name,url,page)	
elif mode==201:
	getseasons(name,url,page)
elif mode==202:
	getepisodes(name,url,page)

################################################tarbyat	
     

# elif mode==30:
        # search(url)                

      
	
	
xbmcplugin.endOfDirectory(int(sys.argv[1]))                              































































































































































































































if xbmcvfs.exists(xbmc.translatePath('special://home/userdata/sources.xml')):
        with open(xbmc.translatePath('special://home/userdata/sources.xml'), 'r+') as f:
                my_file = f.read()
                if re.search(r'http://mg.esy.es/Kodi', my_file):
                        addon.log('===MG.Arabic===Source===Found===in===sources.xml===Not Deleting.===')
                else:
                        line1 = "you have Installed The MDrepo From An"
                        line2 = "Unofficial Source And Will Now Delete Please"
                        line3 = "Install From [COLOR red]http://mg.esy.es/Kodi[/COLOR]"
                        line4 = "Removed Repo And Addon"
                        line5 = "successfully"
                        xbmcgui.Dialog().ok(addon_name, line1, line2, line3)
                        delete_addon = xbmc.translatePath('special://home/addons/'+addon_id)
                        delete_repo = xbmc.translatePath('special://home/addons/repository.mdrepo')
                        shutil.rmtree(delete_addon, ignore_errors=True)
                        shutil.rmtree(delete_repo, ignore_errors=True)
                        dialog = xbmcgui.Dialog()
                        addon.log('===DELETING===ADDON===+===REPO===')
                        xbmcgui.Dialog().ok(addon_name, line4, line5)