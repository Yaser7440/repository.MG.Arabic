txt='''%3Ciframe%20class%3D%22iframe_self%22%20src%3D%22htt
p%3A%2F%2Fvideoapi.my.mail.ru%2Fvideos%2Fembed%2Fmail%2Feuploader%2F_myvideo%2F1
115.html%22%20width%3D%22770%22%20height%3D%22380%22%20frameborder%3D%220%22%20w
ebkitallowfullscreen%3D%22true%22%20mozallowfullscreen%3D%22true%22%20frameborde
r%3D%220%22%20marginwidth%3D%220%22%20marginheight%3D%220%22%20scrolling%3D%22no
%22%20allowfullscreen%20%3E%3C%2Fiframe%3E'''
import urllib
try:
        name=urllib.unquote_plus(txt)
except:
        pass
print name    
    
