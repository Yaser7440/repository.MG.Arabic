# -*- coding: utf8 -*-

import sys
import urllib,urllib2,re,os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re



############################################

####functions

    
def readnet(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      

              
def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        hostname=query.hostname.replace("www.","")
        return hostname
##########################################parsing tools
def showmenu():

                menuitems=[]
                
                
                menuitems.append(("مسلسلات رمضان 2016", 'http://4arabz.tv/index.php?page=section&op=arg&id=23',200,'special://home/addons/plugin.video.4arabz/img/ramadan.png','',1))
               
                menuitems.append(("مسلسلات عربيه", 'http://4arabz.tv/index.php?page=section&op=arg&id=6',200,'special://home/addons/plugin.video.4arabz/img/arabicseries.png','',13))

                menuitems.append(("مسلسلات تركيه", 'http://4arabz.tv/index.php?page=section&op=arg&id=5',200,'special://home/addons/plugin.video.4arabz/img/turkyseries.png','',22))

                menuitems.append(("مسلسلات اجنبيه", 'http://4arabz.tv/index.php?page=section&op=arg&id=7',200,'special://home/addons/plugin.video.4arabz/img/englishseries.png','',22))

                menuitems.append(("مسلسلات مكسيكيه", 'http://4arabz.tv/index.php?page=section&op=arg&id=8',200,'special://home/addons/plugin.video.4arabz/img/maksikseries.png','',22))

                menuitems.append(("مسلسلات كرتون", 'http://4arabz.tv/index.php?page=section&op=arg&id=11',200,'special://home/addons/plugin.video.4arabz/img/cartoonseries.png','',22))
               
                menuitems.append(("برامج تلفزيونبه", 'http://4arabz.tv/index.php?page=section&op=arg&id=10',200,'special://home/addons/plugin.video.4arabz/img/tvprograms.png','',22))

                menuitems.append(("افلام هنديه", 'http://4arabz.tv/index.php?page=articles&op=arg&id=343',100,'special://home/addons/plugin.video.4arabz/img/hindifilms.png','',22))

                menuitems.append(("افلام عربيه", 'http://4arabz.tv/index.php?page=articles&op=arg&id=285',100,'special://home/addons/plugin.video.4arabz/img/arabicfilms.png','',22))

                menuitems.append(("افلام تركيه", 'http://4arabz.tv/index.php?page=articles&op=arg&id=279',100,'special://home/addons/plugin.video.4arabz/img/turkeyfilms.png','',22))
                
                
                menuitems.append(("افلام وثائقيه", 'http://4arabz.tv/index.php?page=articles&op=arg&id=121',100,'special://home/addons/plugin.video.4arabz/img/docfilms.png','',22))
               
                menuitems.append(("اكلات بالفيدو", 'http://4arabz.tv/index.php?page=articles&op=arg&id=282',100,'special://home/addons/plugin.video.4arabz/img/foodvideos.png','',22))

                menuitems.append(("مسلسلات تركيه", 'http://4arabz.tv/index.php?page=section&op=arg&id=5',200,'special://home/addons/plugin.video.4arabz/img/turkyseries.png','',22))

                
                menuitems.append(("مسلسلات مصريه", 'http://4arabz.tv/index.php?page=section&op=arg&id=14',200,'special://home/addons/plugin.video.4arabz/img/eygptdrama.png','',22))

                menuitems.append(("برامج تلفزيونيه رمضان", 'http://4arabz.tv/index.php?page=section&op=arg&id=20',200,'special://home/addons/plugin.video.4arabz/img/eygptdrama.png','',22))

                menuitems.append(("مسلسلات رمضان السوريه", 'http://4arabz.tv/index.php?page=section&op=arg&id=13',200,'special://home/addons/plugin.video.4arabz/img/syriandrama.png','',22))

                menuitems.append(("مسلسلات رمضان اللبنانيه", 'http://4arabz.tv/index.php?page=section&op=arg&id=16',200,'special://home/addons/plugin.video.4arabz/img/lebandrama.png','',22))
                                
                
               
                
		
                for title, url, mode,pic,desc,page in menuitems:
                   
                    addDir(title, url, mode, pic,desc,page)


			
###################################movies
			  
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url.replace("query",search_entered)
        
          
        getmovies("Search",url,0)


                        
               
                   
                
def getmovies(name,urlmain,page):##series
                print "page",page
                
                if page>1:
                  # http://www.drama2.tv/category/%d8%b1%d9%85%d8%b6%d8%a7%d9%86-2016/page/2/
                  
                     url_page=urlmain+'page/'+str(page)+"/"
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="clear">')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i<int(page):
                            continue
                   
                    regx='''<div class="title"><a href="(.*?)">(.*?)</a>'''
                    regx2='''<a href='(.*?)' title='(.*?)'>'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    try:
                     name=match[0][1]
                    except:
                      match=re.findall(regx2,block, re.M|re.I)
                      name=match[0][1]
                    href=match[0][0].replace("&amp;","&")
                    regx="src='(.*?)'"
                    img='http://4arabz.tv/'+re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    #img (u"('http://tm01.tellymov.com/i/01/00004/h5zgl3c07sgb_t.jpg')"
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    addDir(name,href.encode("utf-8"),1,img,'',1)
                    
                    
               
                   
                
                
                #addDir("next page",urlmain,200,'special://home/addons/plugin.video.4arabz/img/nextpage','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))        

                    
###############################################tv shows

def getseries(name,urlmain,page):##series
                print "page",page
                
                if page>1:
                  # http://www.drama2.tv/category/%d8%b1%d9%85%d8%b6%d8%a7%d9%86-2016/page/2/
                  
                     url_page=urlmain+'page/'+str(page)+"/"
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="clear">')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i<int(page):
                            continue
                   
                    regx='''<div class="title"><a href="(.*?)">(.*?)</a>'''
                    regx2='''<a href='(.*?)' title='(.*?)'>'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    try:
                     name=match[0][1]
                    except:
                      match=re.findall(regx2,block, re.M|re.I)
                      name=match[0][1]
                    href=match[0][0].replace("&amp;","&")
                    regx="src='(.*?)'"
                    img='http://4arabz.tv/'+re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    #img (u"('http://tm01.tellymov.com/i/01/00004/h5zgl3c07sgb_t.jpg')"
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    
                    addDir(name,href.encode("utf-8"),202,img,'',1)
                    
                    
               
                   
                
                
                #addDir("next page",urlmain,200,'special://home/addons/plugin.video.4arabz/img/nextpage','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))

                    
def getseasons(name,urlmain,page):##series
                if page>1:
                  #/page/2/
                  url_page=urlmain+"page/"++str(page)
                  
                else:
                
                      url_page=urlmain
                 
                data=readnet(url_page)
                try:data=data.split('<div class="title6">')[1]
                except:pass
                print "url_page",url_page
              
                if data is None:
                    return

                seasons=re.findall('''<a href="(.*?)" >(.*?)</a>''',data, re.M|re.I)
                print 'seasons',seasons
                
                for href,name in seasons:
                    
                    
                    addDir(name,href,202,'','',1)
                        

                                           
                                    


def getepisodes(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  # http://www.drama2.tv/category/%d8%b1%d9%85%d8%b6%d8%a7%d9%86-2016/page/2/
                  
                     url_page=urlmain+'page/'+str(page)+"/"
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('<div class="tpl_main">')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('<div class="clear">')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    regx='''<a href='(.*?)' title='(.*?)'>'''
                    regx2='''<a href='(.*?)' title='(.*?)'>'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    try:
                     name=match[0][1]
                    except:
                      match=re.findall(regx2,block, re.M|re.I)
                      name=match[0][1]
                    href=match[0][0].replace("&amp;","&").encode("utf-8")
                    regx="src='(.*?)'"
                    img='http://4arabz.tv/'+re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    #img (u"('http://tm01.tellymov.com/i/01/00004/h5zgl3c07sgb_t.jpg')"
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    addDir(name,href,1,img,'',1)
                    
               
                   
                
                
                #addDir("next page",urlmain,200,'special://home/addons/plugin.video.4arabz/img/nextpage','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))


 


#######################################host resolving                                                    




def gethosts(name,urlmain):##cinema and tv featured

                
                data=readnet(urlmain)
               
                
              
                if data is None:
                    return
                if 'http://video.limelight.com'  in data:
                        regx='''flashvars="autoplay=true&amp;startQuality=600&amp;playerForm=LVPPlayer&amp;mediaId=(.*?)"'''
                        mediaid=re.findall(regx,data, re.M|re.I)[0]
                        href='http://video.limelight.com/player/fp10loader.swf?mediaId='+mediaid
                        playlink(str(href))
                        return
                if "type : 'dailymotion'"  in data:
                        regx="video : '(.*?)'"
                        href=re.findall(regx,data, re.M|re.I)[0]
                        resolve_host(href)
                        return                          
                if "type : 'youtube'"  in data:
                        regx="video : '(.*?)'"
                        videoid=re.findall(regx,data, re.M|re.I)[0].split("=")[1]
                        href='plugin://plugin.video.youtube/?action=play_video&videoid=%s' % videoid
                        playlink(href)
                        return                             
                regx='''<iframe.*?src="(.*?)".*?></iframe>'''
                regx='''<iframe.*?src="(.*?)".*?></iframe>'''
                match=re.findall(regx,data, re.M|re.I)
                for href in match:
                    
                     
                    
                      if not href.startswith("http"):
                       href="http:"+href
                      if 'cloudfront' in href:
                          continue
                      host=gethostname(href)
                    

                      if 'youtube.com' in href:
                          videoid=os.path.split(href)[1]
                          href='plugin://plugin.video.youtube/?action=play_video&videoid=%s' % videoid
                      addDir(host,href,2,'','',1)
                                          

	    
def resolve_host(url):#last good-used with local resolver
       
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
      
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    
        else:
            addDir("Error,"+stream_link,"",9,"") 	    

def playlink(url):
           
            xbmc.Player().play(url)
            sys.exit(0)            
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param



def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
elif mode==1:
        print ""+url
        gethosts(name,url)
elif mode==2:
        print ""+url
        resolve_host(url)        
elif mode==3:
        print ""+url
        playlink(url)
     
elif mode==100:

	getmovies(name,url,page)        

elif mode==103:
	print ""+url
        search(url)    
       


elif mode==200:

	getseries(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)
	#getvideopage(url,page)	
elif mode==202:
	getepisodes(name,url,page)


xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
