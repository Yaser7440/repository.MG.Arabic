# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys
import base64,hashlib,os,random,re,shutil,string,urllib,urllib2,dandy
import xbmc,xbmcaddon,xbmcgui,xbmcplugin,xbmcvfs
import urlresolver
#------------------------------
from md_request import get_params
from md_request import uncensored
from md_request import OPEN_URL
from md_request import decodeHtml
from md_request import regex_get_all
from md_request import regex_from_to
from md_request import addDir4
from md_request import addDir
from md_request import addDir2
from md_request import playlink
#------------------------------
from common import Addon
from md_view import setView
from md_tools import md
try:
    from common import Addon
    from addon.common.net import Net
    from urlresolver import resolve
except:
    print 'Failed to import script.module.mg.arabic.common'
    xbmcgui.Dialog().ok("3lbh.Net Import Failure", "Failed to import addon.common", "A component needed by 3lbh.Net is missing on your system")

#By. MG.Arabic http://mg.esy.es/Kodi/ (07/2017)
#Common Cache
import xbmcvfs
dbg = False # Set to false if you don't want debugging
#Common Cache
try:
  import StorageServer
except:
  import storageserverdummy as StorageServer
  cache = StorageServer.StorageServer('plugin.video.3lbh.Net')
DB = os.path.join(xbmc.translatePath("special://database"), '3lbh.Net.db')
addon_id='plugin.video.3lbh.Net'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, art+'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, art+'fanart.jpg'))
User_Agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36'

Albh = selfAddon.getSetting('Albh_url')
show_Albh = addon.get_setting('enable_Albh')


def decodeurl(text):
    text = text.replace(' ','%20')
    return text

def CAT():
    if show_Albh == 'true':addDir('[B][COLOR white]••3lbh.Net[/COLOR][/B]','url',0,art+'icon.png',fanart,'')    
    addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
    setView(addon_id, 'movies', 'movie-view')
    addon.end_of_directory()
	
		
def MV2():
     addDir('[B][COLOR white]••مسلسلات عربية 2017••[/COLOR][/B]',Albh+'/aseries',1,art+'tvshows.png',fanart,'')
     addDir('[B][COLOR white]••مسلسلات اجنبية••[/COLOR][/B]',Albh+'/eseries',1,art+'tvshows.png',fanart,'') 
     addDir('[B][COLOR white]••احدث المسلسلات العربية••[/COLOR][/B]',Albh,4,art+'tvshows.png',fanart,'')
     addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
     setView(addon_id, 'movies', 'movie-view')
     addon.end_of_directory()		

def INDEX1(url):
        link = OPEN_URL(url)
        all_videos = regex_get_all(link, '<div class="col-md-3 col-xs-6', '</div>\s*</div>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, 'alt="', '"')
                url = Albh + regex_from_to(a, 'href="', '"')
                icon = Albh + regex_from_to(a, 'src="', '"')
                desc = regex_from_to(a, '<p>', '</p>')
                genre =regex_from_to(a, '<h3>', '</h3>').replace('<br />','')
                date = regex_from_to(a, '</h2>', '</h2>')
                credits = regex_from_to(a, '<div class="col-md-12 mEYE">\s*', '<i class="fa fa-eye">')
                fanart = Albh + regex_from_to(a, 'src="', '"')	

                if '/eseries' in url:
                           addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,3,icon,fanart,desc,genre,date,credits)
                else:
                           addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,fanart,desc,genre,date,credits)
        try:
                np = re.compile('<li><a href="(.*?)" rel="next">&raquo;</a></li>').findall(link)[0]
                addDir('[I][B][COLOR dodgerblue]Go To Next Page>>>[/COLOR][/B][/I]',np,1,art+'next.png',fanart,'')
        except:pass
        setView(addon_id, 'movies', 'movie-view')


def INDEX2(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<a class="col-md-3', '</div>\s*</a>')
	for a in all_videos:
		name = regex_from_to(a, '<i class="fa fa-play"></i>\s*', '\s*</div>')
		url = Albh + regex_from_to(a, ' href="', '"')
		icon = regex_from_to(a, 'src="', '"')
		desc = regex_from_to(a, '<i class="fa fa-play"></i>\s*', '\s*</div>')
		genre =regex_from_to(a, '<div class="ribbon">', '</div>').replace('<br />','')
		date = regex_from_to(a, '</h2>', '</h2>')
		credits = regex_from_to(a, '<div class="imdbRating">', '</div>')
		fanart = regex_from_to(a, 'src="', '"')
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,icon,fanart,desc,genre,date,credits)
	try:
		nextp=re.compile('<li><a href="(.*?)" rel="next">&raquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,2,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')
	



def INDEX3(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="col-md-3 col-xs-6', '</div>\s*</div>')
	for a in all_videos:
		name = regex_from_to(a, '<div class="sertitle">\s*', '\s*</div>')
		url = Albh + regex_from_to(a, 'href="', '"')
		icon = Albh + regex_from_to(a, 'src="', '"')
		desc = regex_from_to(a, '<p>', '</p>')
		genre =regex_from_to(a, '<h3>', '</h3>').replace('<br />','')
		date = regex_from_to(a, '</h2>', '</h2>')
		credits = regex_from_to(a, '<div class="col-md-12 mEYE">\s*', '<i class="fa fa-eye">')
		fanart = Albh + regex_from_to(a, 'src="', '"')		
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,fanart,desc,genre,date,credits)			
	try:
		nextp=re.compile('<li><a href="(.*?)" rel="next">&raquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,3,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')

def INDEX4(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="col-md-3 col-xs-6 pull-right cMovie">', '</div>\s*</div>')
	for a in all_videos:
		name = regex_from_to(a, 'alt="', '"').replace('<br />','')
		url = Albh + regex_from_to(a, 'href="', '"')
		icon = Albh + regex_from_to(a, 'src="', '"')
		desc = regex_from_to(a, '<p>', '</p>')
		genre =regex_from_to(a, '<h3>', '</h3>').replace('<br />','')
		date = regex_from_to(a, '</h2>', '</h2>')
		credits = regex_from_to(a, '<div class="col-md-12 mEYE">\s*', '<i class="fa fa-eye">')
		fanart = Albh + regex_from_to(a, 'src="', '"')		
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,icon,fanart,desc,genre,date,credits)			
	try:
		nextp=re.compile('<li><a href="(.*?)" rel="next">&raquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,4,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')	
	
def Albh1(url):
    OPEN = OPEN_URL(url)
    Regex = re.compile('<script type="text/javascript">(.+?)</script>',re.DOTALL).findall(OPEN)[0]
    Regex2 = re.compile('source:"(.*?)", label:"(.+?)"}',re.DOTALL).findall(str(Regex))	
    for url,name in Regex2:	
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,decodeurl(url),7,'',fanart,'')
    setView(addon_id, 'movies', 'movie-view')	
	


params=get_params(); url=None; name=None; mode=None; iconimage=None; description=None; query=None; type=None; page=1
# OpenELEQ: query & type-parameter (added 2 lines above)

try:url=urllib.unquote_plus(params["url"])
except:pass
try:name=urllib.unquote_plus(params["name"])
except:pass
try:iconimage=urllib.unquote_plus(params["iconimage"])
except:pass
try:mode=int(params["mode"])
except:pass
try:description=urllib.unquote_plus(params["description"])
except:pass
try:query=urllib.unquote_plus(params["query"])
except:pass
try:type=urllib.unquote_plus(params["type"])
except:pass
try:page=int(params["page"])
except:pass	
# OpenELEQ: query & type-parameter (added 8 lines above)

if mode==None or url==None or len(url)<1: CAT()

elif mode==0: MV2()
elif mode==1: INDEX1(url)
elif mode==2: INDEX2(url)
elif mode==3: INDEX3(url)
elif mode==4: INDEX4(url)
elif mode==5: Albh1(url)
elif mode==7: playlink(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))