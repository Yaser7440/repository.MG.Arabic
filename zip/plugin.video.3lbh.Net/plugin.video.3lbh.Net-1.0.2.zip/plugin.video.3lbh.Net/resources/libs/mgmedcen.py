# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys
import urllib,urllib2,re,os,string,shutil,requests,random,hashlib,base64
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re
try:
    from addon.common.addon import Addon
    from addon.common.net import Net
    from urlresolver import resolve
except:
    print 'Failed to import script.module.addon.common'
    xbmcgui.Dialog().ok("Showscen Import Failure", "Failed to import addon.common", "A component needed by Showscen is missing on your system")
  
#Common Cache
import xbmcvfs
dbg = False # Set to false if you don't want debugging
  
#Common Cache
try:
  import StorageServer
except:
  import storageserverdummy as StorageServer
cache = StorageServer.StorageServer('plugin.video.MG.MedCen')






addon_id='plugin.video.MG.MedCen'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + 'img'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
show_tv = selfAddon.getSetting('enable_shows')
baseurl = selfAddon.getSetting('base_url')
s = requests.session()
net = Net()



def resolveurl(url):

            
            print "url",url
            #sys.exit(0)            
            import requests,re,time
            html=requests.get(url).text
            #<input type="hidden" name="watch" value="1">                  
            #id = re.findall('<input type="hidden" name="id" value="(.*?)">',html, re.M|re.I)[0]
            #fname = re.findall('<input type="hidden" name="fname" value="(.*?)">',html, re.M|re.I)[0]
            #hash = re.findall('<input type="hidden" name="hash" value="(.*?)">',html, re.M|re.I)[0]
            #action = re.findall('''<Form method="POST" action='(.*?)'>''',html, re.M|re.I)[0]
            #print "id,fname,hash,action",id,fname,hash,action
            time.sleep(10)
            #sys.exit(0)
            data= {
                'watch': "1",                               
                'referer': 'http://cimaclub.com/',
                'method': 'POST'}   
                
            data=requests.post(url, data=data).text.encode("utf-8")
            return data
            

baseurl = 'http://cimaclub.com'
####functions

    
def readnet(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      

def CAT():
        addDir('[B][COLOR white]ShowsCen[/COLOR][/B]','url',8,'special://home/addons/plugin.video.MG.MedCen/img/showscen.png',fanart,'')
        addDir('[B][COLOR white]طربيات[/COLOR][/B]','url',9,'special://home/addons/plugin.video.MG.MedCen/img/6arbyat.png',fanart,'')
        # addDir('[B][COLOR white]HOT MOVIES[/COLOR][/B]','url',1,'special://home/addons/plugin.video.MG.MedCen/img/showscen.png',fanart,'')
        # addDir('[B][COLOR white]SEARCH[/COLOR][/B]','url',4,'special://home/addons/plugin.video.MG.MedCen/img/showscen.png',fanart,'')
        # addDir('[B][COLOR white]GENRE[/COLOR][/B]','url',5,'special://home/addons/plugin.video.MG.MedCen/img/showscen.png',fanart,'')
        # addDir('[B][COLOR white]YEAR[/COLOR][/B]','url',6,'special://home/addons/plugin.video.MG.MedCen/img/showscen.png',fanart,'')
        #addDir('[B][COLOR white]ShowsCen[/COLOR][/B]','url',8,'special://home/addons/plugin.video.MG.MedCen/img/showscen.png',fanart,'')              

##########################################showscen
def showscen():

                menuitems=[]
                
                menuitems.append(("البحث", 'http://www.showscen.com/watch/?s=',103,'special://home/addons/plugin.video.MG.MedCen/img/search.png','',1))
                menuitems.append(("افلام اجنبيه", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A',100,'special://home/addons/plugin.video.MG.MedCen/img/movies.png','',1))
                menuitems.append(("افلام عربيه", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%B9%D8%B1%D8%A8%D9%8A',100,'special://home/addons/plugin.video.MG.MedCen/img/tvshows.png','',1))
                menuitems.append(("افلام انيميشن", 'http://cimaclub.com/category/%D8%A7%D9%86%D9%8A%D9%85%D9%8A%D8%B4%D9%86/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D9%86%D9%8A%D9%85%D9%8A%D8%B4%D9%86',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("افلام هندي", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D9%87%D9%86%D8%AF%D9%8A',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("افلام مدبلجه", 'http://cimaclub.com/quality/%D9%85%D8%AF%D8%A8%D9%84%D8%AC',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("افلام اسيوية", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%B3%D9%8A%D9%88%D9%8A%D8%A9',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                #menuitems.append(("سلاسل الافلام", 'http://cimaclub.com/movies',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                #menuitems.append(("افلام للكبار فقظ", 'http://cimaclub.com/category/adult',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("تصنيفات الافلام الاجنبيه", 'url',101,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
				
                for title, url, mode,pic,desc,page in menuitems:
                    addDir(title, url, mode, pic,desc,1)
					
					
def getgenre_movies(url):

                menuitems=[]
                
                menuitems.append(("Thriller", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=thriller',100,'special://home/addons/plugin.video.MG.MedCen/img/search.png','',1))
                menuitems.append(("Action", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=action',100,'special://home/addons/plugin.video.MG.MedCen/img/movies.png','',1))
                menuitems.append(("Animation", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=animation',100,'special://home/addons/plugin.video.MG.MedCen/img/tvshows.png','',1))
                menuitems.append(("History", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=history',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("Crime", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=crime',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("War", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=war',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("Sci-Fi", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=sci-fi',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("Drama", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=drama',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("دراما كورية", 'http://cimaclub.com/genre/%D8%AF%D8%B1%D8%A7%D9%85%D8%A7-%D9%83%D9%88%D8%B1%D9%8A%D8%A9/',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("Horror", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=horror',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("Romance", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=romance',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("Sport", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=sport',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("Biography", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=biography',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("Family", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=family',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("Western", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=western',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("Mystery", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=mystery',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("Fantasy", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=fantasy',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("Short Films", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=short',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("Comedy", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=comedy',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("Adventure", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=adventure',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("Music", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=music',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))
                menuitems.append(("Documentary", 'http://cimaclub.com/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A/?genre=documentary',100,'special://home/addons/plugin.video.MG.MedCen/img/musical.jpg','',1))				
                for title, url, mode,pic,desc,page in menuitems:
                    addDir(title, url, mode, pic,desc,1)					

###################################movies
			  
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered
        
          
        getmovies("Search",url,0)


                        
               
                   
                
        
def getmovies(namemain,urlmain,page):##movies
                if page>1:
                  #/page/2/http://movizcinma.com/english-movies/2/
                  #     
                  url_page=urlmain+str(page)+"/"
                  url_page=urlmain+'/page/'+str(page)
                  #url_page=urlmain+"page/"+str(page)
                  #url_page=urlmain+'/page/'+str(page)
                  #url_page=urlmain+'"/""/"/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                data=readnet(url_page)
                                  
               
                if data is None:
                    return
                #print dataclass="vi-box-top"
                blocks=data.split('<div class="movie">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                   
                    
                    regx='''<a href="(.*?)">'''
                    
                    try:href=re.findall(regx,block, re.M|re.I)[0]
                    except:continue
                    
                    
                    regx='''<img.*?src="(.*?)".*?'''
                    try:img=re.findall(regx,block, re.M|re.I)[0]
                    except:img=''
                    print "img",img.strip()
                   
                    #regx='''<div class="small-play">'''
                    regx='''<img alt="(.*?)".*?'''
                    
                    try:name=re.findall(regx,block, re.M|re.I)[0]
                    except:name=os.path.split(href[:-1])[1]
                   
                                             
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    name=name.replace("&#8217;"," ") 
                    try:addDir(name,href,1,img,'',1)
                    except:continue
                print "page",page,len(blocks)
                
                if len(blocks)>10:
                   addDir("next page",urlmain,10000,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))                
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))

				

                    
###############################################tv shows

def getseries(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  #http://www.showscen.com/watch/category/tv-shows/page/2/
                  
                     url_page=urlmain+'/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('<article id="(.*?)')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="article-helper notloaded">')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)"'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    regx='''data-a2a-title="(.*?)">'''
                    name=re.findall(regx,block, re.M|re.I)[0]
                   
                    regx='''src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:str(name)
                    
                    try:img.encode("utf-8")
                    except:img=str(img)                    
                    addDir(name,href,202,img,'',1)
                    
               
                   
                
                
                addDir("next page",urlmain,200,'special://home/addons/plugin.video.MG.MedCen/img/next.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,200,'','',str(page+1))




 


#######################################host resolving                                                    




def gethosts(urlmain):##cinema and tv featured
                
        data=readnet(urlmain)
        #data=read_url(urlmain)
        #data=read_url(url)
        #http://www.movizcinma.com/wp-content/themes/series4watch/server1.php?server=1&p=24927
        
        regx="rel='shortlink' href='(.+?)'"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[1]
        print "id",id
        for i in range(1,7):
          url='http://cimaclub.com/wp-content/themes/Cimaclub/servers/server.php?q='+id+'&i='+str(i)
          print url
          addDir('server'+str(i),url,2, 'img/server.png')
		  
def gethosts2(urlmain):

                
                data=readnet(urlmain)
	        print data
                	
                #regx='''</span><a href='(.+?)' class='redirect_link'>'''
                #regx1='''<iframe src="(.+?)" scrolling="no" frameborder="0" width="700" height="430" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'''
                regx2='''<IFRAME SRC="(.+?)".+?></IFRAME>'''
                
                regx3='''<iframe .+? src="(.+?)" .+?></iframe>'''
                regx4='''<iframe .+? src="(.+?)" ></iframe>'''
                match2 = re.findall(regx2,data, re.M|re.I)
                match3 = re.findall(regx3,data, re.M|re.I)
                match4 = re.findall(regx4,data, re.M|re.I)
                #match5 = re.findall(regx5,data, re.M|re.I)
         
                #getmatch(match1)
                getmatch(match2)
                getmatch(match3)
                getmatch(match4)
                #getmatch(match5)
               
                return


	    
	    
def resolve_host(url):
        
        from urlresolver import resolve
        data=readnet(url)
        reurl='''<iframe.*?src="(.*?)".*?></iframe>'''
        url=re.findall(reurl,data, re.M|re.I)[0].split("=")[0]
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    listItem = xbmcgui.ListItem(path=str(stream_link))
	    xbmcplugin.setResolvedUrl(sys.argv[0], True, listItem)   
        else:
            addDir("Error,"+stream_link,"",9,"") 	    
def resolve_host2(url):#last good
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(stream_link)  
        else:
            addDir("Error,"+stream_link,"",9,"")
def playlink(stream_link):
            
            xbmc.Player().play(stream_link)
            sys.exit(0)

###functions

def readnet(url):
        import requests
        data=requests.get(url, verify=False)
        return data.content
def readnet2(url):
            
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html	    
def removeunicode(data):
             
             
            
              try:
                    type(data)
                    data=data.decode('unicode_escape').encode('ascii','replace').replace("?","").strip()
        
              except:
                    pass
              
              return data
              
def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        
        return query.hostname             
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param



def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=1):

        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
def getgroups(data, pattern, grupsNum = 1, ignoreCase = False):
        tab = []
        if ignoreCase:
            match = re.search(pattern, data, re.IGNORECASE)
        else:
            match = re.search(pattern, data)
        
        for idx in range(grupsNum):
            try:
                value = match.group(idx + 1)
            except:
                value = ''

            tab.append(value)

        return tab
def getdata(data, marker1, marker2, withMarkers = True, caseSensitive = True):
        if caseSensitive:
            idx1 = data.find(marker1)
        else:
            idx1 = data.lower().find(marker1.lower())
        if -1 == idx1:
            return (False, '')
        if caseSensitive:
            idx2 = data.find(marker2, idx1 + len(marker1))
        else:
            idx2 = data.lower().find(marker2.lower(), idx1 + len(marker1))
        if -1 == idx2:
            return (False, '')
        if withMarkers:
            idx2 = idx2 + len(marker2)
        else:
            idx1 = idx1 + len(marker1)
        return  data[idx1:idx2]
	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
#################################man
if mode==None or url==None or len(url)<1:
        CAT()

elif mode==8:
        showscen()
elif mode==9:
		tarbyat()


###########################
		
elif mode==1:
        print ""+url
        gethosts(url)
elif mode==10:
        print ""+url
        gethosts2(url)		
elif mode==2:
        print ""+url
        resolve_host(url)
elif mode==20:
        print ""+url
        resolve_host2(url)
elif mode==3:
        print ""+url
        playlink(url)  	
elif mode==100:
        print ""+url
        getmovies(name,url,page)
elif mode==101:
        print ""+url
        getgenre_movies('movies')	
########		
     

elif mode==103:
	print ""+url
        search(url)    
elif mode==200:
        print ""+url
	getseries(name,url,page)	
elif mode==201:
	getseasons(name,url,page)
elif mode==202:
	getepisodes(name,url,page)
elif mode==300:
	getsongs(name,url,page)
################################################tarbyat	
elif mode==10:
        print ""+url
        gethosts10(name,url)       
elif mode==20:
        print ""+url
        playlink20(url)
elif mode==30:
        search(url)                
elif mode==1003:
        print ""+url
        getartists(name,url,page)
elif mode==1000:
        print ""+url
        getsongs(name,url,page)        
elif mode==1001:
         print ""+url
         getsongs2(name,url,page)	
	
xbmcplugin.endOfDirectory(int(sys.argv[1]))                              































































































































































































































if xbmcvfs.exists(xbmc.translatePath('special://home/userdata/sources.xml')):
        with open(xbmc.translatePath('special://home/userdata/sources.xml'), 'r+') as f:
                my_file = f.read()
                if re.search(r'http://mg.esy.es/Kodi', my_file):
                        addon.log('===MG.Arabic===Source===Found===in===sources.xml===Not Deleting.===')
                else:
                        line1 = "you have Installed The MDrepo From An"
                        line2 = "Unofficial Source And Will Now Delete Please"
                        line3 = "Install From [COLOR red]http://mg.esy.es/Kodi[/COLOR]"
                        line4 = "Removed Repo And Addon"
                        line5 = "successfully"
                        xbmcgui.Dialog().ok(addon_name, line1, line2, line3)
                        delete_addon = xbmc.translatePath('special://home/addons/'+addon_id)
                        delete_repo = xbmc.translatePath('special://home/addons/repository.mdrepo')
                        shutil.rmtree(delete_addon, ignore_errors=True)
                        shutil.rmtree(delete_repo, ignore_errors=True)
                        dialog = xbmcgui.Dialog()
                        addon.log('===DELETING===ADDON===+===REPO===')
                        xbmcgui.Dialog().ok(addon_name, line4, line5)