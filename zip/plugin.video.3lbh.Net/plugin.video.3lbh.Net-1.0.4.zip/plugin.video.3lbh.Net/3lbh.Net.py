# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys
#import hashlib
import os,sys
#import random 
import re
#import shutil
#import string
import urllib
#import urllib2
import xbmc,xbmcaddon,xbmcgui,xbmcplugin

#------------------------------
from md_request import get_params
from md_request import uncensored
from md_request import OPEN_URL
from md_request import decodeHtml
from md_request import regex_get_all
from md_request import regex_from_to
from md_request import addDir
from md_request import playlink
#------------------------------
from common import Addon
from md_view import setView
from addon.common.net import Net
#------------------------------
#By. MG.Arabic http://mg.esy.es/Kodi/ (07/2017)



addon_id='plugin.video.3lbh.Net'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, art+'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, art+'fanart.jpg'))
User_Agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36'
Albh = selfAddon.getSetting('Albh_url')
show_Albh = addon.get_setting('enable_Albh')


def decodeurl(text):
    text = text.replace(' ','%20').replace('&#039;',"'")
    return text

def CAT():
    if show_Albh == 'true':addDir('[B][COLOR white]••3lbh.Net••[/COLOR][/B]','url',0,art+'icon.png',fanart,'')    
    addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
    addon.end_of_directory()
	
		
def MV2():
     addDir('[B][COLOR white]••افـــــلام••[/COLOR][/B]',Albh+'/movies',4,art+'tvshows.png',fanart,'')
     addDir('[B][COLOR white]••مسلسلات عربية 2017••[/COLOR][/B]',Albh+'/aseries',1,art+'tvshows.png',fanart,'')
     addDir('[B][COLOR white]••مسلسلات اجنبية••[/COLOR][/B]',Albh+'/eseries',1,art+'tvshows.png',fanart,'') 
     addDir('[B][COLOR white]••اخر الإضافات••[/COLOR][/B]',Albh,4,art+'tvshows.png',fanart,'')
     addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
     addon.end_of_directory()		

def INDEX1(url):
        link = OPEN_URL(url)
        all_videos = regex_get_all(link, '<div class="col-md-3 col-xs-6', '</div>\s*</div>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, 'alt="', '"').replace('&#039;',"'").replace('&amp;',"&")
                url = Albh + regex_from_to(a, 'href="', '"').replace('&#039;',"'").replace('&amp;',"&")
                icon = Albh + regex_from_to(a, 'src="', '"').replace('&#039;',"'").replace('&amp;',"&")
                desc = regex_from_to(a, '<p>', '</p>').replace('&#039;',"'").replace('&amp;',"&")
                rat = regex_from_to(a, '<div class="col-md-6 mIMDB">\s*', '<i class="fa fa-imdb">')				
                genre =regex_from_to(a, '<h3>', '</h3>').replace('<br />','').replace('&#039;',"'").replace('&amp;',"&")
                date = regex_from_to(a, '</h2>', '</h2>')
                credits = regex_from_to(a, '<div class="col-md-12 mEYE">\s*', '<i class="fa fa-eye">').replace('&#039;',"'").replace('&amp;',"&")
                fanart = Albh + regex_from_to(a, 'src="', '"').replace('&#039;',"'").replace('&amp;',"&")	

                if '/eseries' in url:
						   addDir2('[B][COLOR white]%s[/COLOR][/B]' %name,url,3,icon,fanart,desc,genre,date,'',credits,rat,items)
                else:
						   addDir2('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,fanart,desc,genre,date,'',credits,rat,items)
        try:
                np = re.compile('<li><a href="(.*?)" rel="next">&raquo;</a></li>').findall(link)[0]
                addDir('[I][B][COLOR dodgerblue]Go To Next Page>>>[/COLOR][/B][/I]',np,1,art+'next.png',fanart,'')
        except:pass
        setView(addon_id, 'movies', 'movie-view')


def INDEX2(url):
    link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
    all_videos = regex_get_all(link, '<div class="serinfo">', '</ul>\s*</div>')
    items = len(all_videos)
    for b in all_videos:
        desc = regex_from_to(b, '<p>', '</p>').replace('&#039;',"'").replace('&amp;',"&")
        rat = regex_from_to(b, '<ul class="col-md-6 pull-right">\s*<li>التقييم : <span>', '</').replace('&#039;',"'").replace('&amp;',"&")
        icon = Albh + regex_from_to(b, 'src="', '"').replace('&#039;',"'").replace('&amp;',"&")
        genre = regex_from_to(b, '<li>', '<h4>').replace('<span>',"").replace('</span>',"").replace('</li>',"").replace('<li>',"")
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<a class="col-md-3', '</div>\s*</a>')
	items = len(all_videos)
	for a in all_videos:
		name = regex_from_to(a, '<i class="fa fa-play"></i>\s*', '\s*</div>').replace('&#039;',"'").replace('&amp;',"&")
		url = Albh + regex_from_to(a, ' href="', '"')
		#desc = regex_from_to(a, '<i class="fa fa-play"></i>\s*', '\s*</div>').replace('&#039;',"'").replace('&amp;',"&")
		#genre =regex_from_to(a, '<div class="ribbon">', '</div>').replace('<br />','').replace('&#039;',"'").replace('&amp;',"&")
		date = regex_from_to(a, '<li>', '</span></li>\s*<li><h4>').replace('<span>',"")
		#icon = Albh + regex_from_to(a, 'src="', '"').replace('&#039;',"'").replace('&amp;',"&")
		credits = regex_from_to(a, '<div class="imdbRating">', '</div>').replace('&#039;',"'").replace('&amp;',"&")
		fanart = Albh + regex_from_to(a, 'src="', '"').replace('&#039;',"'").replace('&amp;',"&")
		addDir2('[B][COLOR white]%s[/COLOR][/B]'%name,url,102,icon,fanart,desc,genre,date,'',credits,rat,items)
	try:
		nextp=re.compile('<li><a href="(.*?)" rel="next">&raquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,2,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')
	



def INDEX3(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="container">', '</ul>\s*</div>')
	items = len(all_videos)
	for b in all_videos:
		desc = regex_from_to(b, '<p>', '</p>').replace('&#039;',"'").replace('&amp;',"&")	
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="col-md-3 col-xs-6', '</div>\s*</div>')
	items = len(all_videos)
	for a in all_videos:
		name = regex_from_to(a, '<div class="sertitle">\s*', '\s*</div>').replace('&#039;',"'").replace('&amp;',"&")
		url = Albh + regex_from_to(a, 'href="', '"').replace('&#039;',"'").replace('&amp;',"&")
		icon = Albh + regex_from_to(a, 'src="', '"').replace('&#039;',"'").replace('&amp;',"&")
		#desc = regex_from_to(a, '<p>', '</p>').replace('&#039;',"'").replace('&amp;',"&")
		genre =regex_from_to(a, '<h3>', '</h3>').replace('<br />','').replace('&#039;',"'").replace('&amp;',"&")
		date = regex_from_to(a, '</h2>', '</h2>')
		credits = regex_from_to(a, '<div class="col-md-12 mEYE">\s*', '<i class="fa fa-eye">').replace('&#039;',"'").replace('&amp;',"&")
		fanart = Albh + regex_from_to(a, 'src="', '"').replace('&#039;',"'").replace('&amp;',"&")		
		addDir2('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,icon,fanart,desc,genre,date,'',credits,'',items)		
	try:
		nextp=re.compile('<li><a href="(.*?)" rel="next">&raquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,3,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')

def INDEX4(url):
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="col-md-3 col-xs-6 pull-right cMovie">', '</div>\s*</div>')
	items = len(all_videos)
	for a in all_videos:
		name = regex_from_to(a, 'alt="', '"').replace('&#039;',"'").replace('&amp;',"&")
		url = Albh + regex_from_to(a, 'href="', '"').replace('&#039;',"'").replace('&amp;',"&")
		icon = Albh + regex_from_to(a, 'src="', '"').replace('&#039;',"'").replace('&amp;',"&")
		desc = regex_from_to(a, '<p>', '</p>').replace('&#039;',"'").replace('&amp;',"&")
		genre =regex_from_to(a, '<h3>', '</h3>').replace('<br />','').replace('&#039;',"'").replace('&amp;',"&")
		date = regex_from_to(a, '</h2>', '</h2>')
		rating = regex_from_to(a, '<div class="col-md-6 mIMDB">\s*', '<i class="fa fa-imdb">')
		credits = regex_from_to(a, '<div class="col-md-12 mEYE">\s*', '<i class="fa fa-eye">').replace('&#039;',"'").replace('&amp;',"&")
		fanart = Albh + regex_from_to(a, 'src="', '"').replace('&#039;',"'").replace('&amp;',"&")		
		addDir2('[B][COLOR white]%s[/COLOR][/B]'%name,url,102,icon,fanart,desc,genre,date,'',credits,rating,items)		
	try:
		nextp=re.compile('<li><a href="(.*?)" rel="next">&raquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,4,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')	
	
def Albh1(url):
    OPEN = OPEN_URL(url)
    Regex = re.compile('<script type="text/javascript">(.+?)</script>',re.DOTALL).findall(OPEN)[0]
    Regex2 = re.compile('source:"(.*?)", label:"(.+?)"}',re.DOTALL).findall(str(Regex))	
    for url,name in Regex2:	
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,decodeurl(url),7,'',fanart,'')
	
def LINKS2(url):
    OPEN = OPEN_URL(url)
    Regex = re.compile('<script type="text/javascript">(.+?)</script>',re.DOTALL).findall(OPEN)[0]
    Regex2 = re.compile('source:"(.*?)", label:"(.+?)"}',re.DOTALL).findall(str(Regex))	
    for url,name in Regex2:
        url = url.replace('&amp;','&').replace(' ','%20').replace('&#039;',"'").replace('\/','/')
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={"Title": name})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
		
def addDir2(name,url,mode,iconimage,fanart,description,genre,date,writer,director,rating,itemcount):
                u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)
                #u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&site="+str(site)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
                ok=True
                liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
                liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "Genre": genre, "First aired": date, "Director": director, "Writer": writer, "Rating": rating })
                liz.setProperty("Fanart_Image", fanart)
                if mode==102:
                        liz.setProperty("IsPlayable","true")
                        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
                else:
                        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
                return ok

params=get_params(); url=None; name=None; mode=None; iconimage=None; description=None; query=None; type=None; site=None; page=1
# OpenELEQ: query & type-parameter (added 2 lines above)

try:url=urllib.unquote_plus(params["url"])
except:pass
try:name=urllib.unquote_plus(params["name"])
except:pass
try:iconimage=urllib.unquote_plus(params["iconimage"])
except:pass
try:mode=int(params["mode"])
except:pass
try:description=urllib.unquote_plus(params["description"])
except:pass
try:query=urllib.unquote_plus(params["query"])
except:pass
try:type=urllib.unquote_plus(params["type"])
except:pass
try:page=int(params["page"])
except:pass	
# OpenELEQ: query & type-parameter (added 8 lines above)

if mode==None or url==None or len(url)<1: CAT()

elif mode==0: MV2()
elif mode==1: INDEX1(url)
elif mode==2: INDEX2(url)
elif mode==3: INDEX3(url)
elif mode==4: INDEX4(url)
elif mode==5: Albh1(url)
elif mode==102: LINKS2(url)
elif mode==7: playlink(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))