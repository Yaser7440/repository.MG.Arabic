#!/usr/bin/python
# -*- coding: utf-8 -*-
try:import sys,syspath
except:pass
from yttools import *


def infolist():
  list1=[]
 
  list1.append((' ام كلثوم 1','UC3sKOTz5mWAdQyLQBp-Weaw'))
  list1.append(('ام كلثوم 2','UCUz6CXO5XIYD_7wmlK8mZsA'))
  list1.append(('مسلسل ام كلثوم','UC9jQxEQNbYEHR4QgAl0ilPA'))
  list1.append(('محمد غبد الوهاب','UCY0JzWvCYtvw-mtp9Y9HBZg'))
  
  list1.append(('نجاة الصغيره','UCYCqf1AbgQw_V2ywcV9YXEg'))
  list1.append(('عبد الحليم حافظ','3abdelhalim7afez',1005))
  list1.append(('ورده الجزائريه','UCnNrFhZlFtOx_QrIXIka7Ig'))
  list1.append(('ذكرى','zekrachannel',1005))
  list1.append(('2ذكرى','UCgG9d5uhUNRWuChcUGmnQEQ')) 
  
  return list1

################################################################333
list1=infolist()
process_mode(list1 )
xbmcplugin.endOfDirectory(int(sys.argv[1]))


