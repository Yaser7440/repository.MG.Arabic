# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys, os, urllib
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re
import xbmcvfs
import requests
import urlresolver
##################################
from md_request import get_params
from md_request import OPEN_URL
from md_request import readnet2
from md_request import decodeHtml
from md_request import regex_get_all
from md_request import regex_from_to
from md_request import addDir
from md_request import addDir2
from md_request import RESOLVE
from md_request import playlink
#------------------------------
from md_view import setView
from md_tools import md
#------------------------------
try:
    from common import Addon
    from addon.common.net import Net
    from urlresolver import resolve
except:
    print 'Failed to import script.module.mg.arabic.common'
    xbmcgui.Dialog().ok("Arablionz Import Failure", "Failed to import addon.common", "A component needed by Arablionz is missing on your system")  

DB = os.path.join(xbmc.translatePath("special://database"), 'arablionz.db')

addon_id='plugin.video.arablionz'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/img/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
show_tv = selfAddon.getSetting('enable_shows')
baseurl = selfAddon.getSetting('base_url')

            

baseurl = 'http://arablionz.tv'
####functions
    

def CAT():
         addDir('[B][COLOR white]البحث[/COLOR][/B]',baseurl+ '/?s=',103,art+'search.png',fanart,'')
         addDir('[B][COLOR white]السنة[/COLOR][/B]','url',104,art+'years.png',fanart,'')		 
         addDir('[B][COLOR white]قوائم الافلام[/COLOR][/B]','url',8,art+'movies.png',fanart,'')
         addDir('[B][COLOR white]قوائم المسلسلات[/COLOR][/B]','url',105,art+'/tvshows.png',fanart,'')
         #addDir('[B][COLOR white]عروض أخرى [/COLOR][/B]','url',102,art+'/showscen.png',fanart,'')
                      

##########################################showscen
def ShowMov():
    addDir('[B][COLOR white]البحث[/COLOR][/B]',baseurl+ '/?s=',103,art+'search.png',fanart,'')
    addDir('[B][COLOR white]••عــــام••[/COLOR][/B]','url',101,art+'0.png',fanart,'')
    addDir('[B][COLOR white]••مواضيع مثبته••[/COLOR][/B]',baseurl+'/category/افلام/',100,art+'0.png',fanart,'')
    addDir('[B][COLOR white]••أفـــلام أجنبية••[/COLOR][/B]',baseurl+'/category/افلام/افلام-اجنبي/',100,art+'2.png',fanart,'')
    addDir('[B][COLOR white]••أفــلام عربية••[/COLOR][/B]',baseurl+'/category/افلام/افلام-عربي/',100,art+'5.png',fanart,'')
    addDir('[B][COLOR white]••بوليود••[/COLOR][/B]',baseurl+'/category/افلام/افلام-هندي/',100,art+'6.png',fanart,'')
    #addDir('[B][COLOR white]••أفلام أنمي أون لاين••[/COLOR][/B]','http://arablionz.tv/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d9%83%d8%b1%d8%aa%d9%88%d9%86%d9%8a/',11,'http://icons.iconarchive.com/icons/firstline1/movie-mega-pack-4/256/Sleeping-Beauty-1959-icon.png',1)

					
def ShowTv():
    addDir('[B][COLOR white]••مسلسلات عربية••[/COLOR][/B]',baseurl+'/category/مسلسلات/مسلسلات-عربي/',200,'img/7.png',1)
    addDir('[B][COLOR white]••مسلسلات اجنبية••[/COLOR][/B]',baseurl+'/category/مسلسلات/مسلسلات-اجنبي/',200,'img/3.png',1)
    addDir('[B][COLOR white]••جميع المسلسلات••[/COLOR][/B]',baseurl+'/category/مسلسلات/',200,'img/3.png',1)	
					
def getgenre_movies(url):
	genres=['box-office','اثارة','اكشن','انميشن','تاريخ','جريمة','حروب','خيال','دراما','افلام-رعب','رومانسي','رياضي','سيرة-ذاتية','عائلي','غموض','فانتازيا','كوميديا','مغامرات','موسيقي','وثائقي']
        for g in genres:
                url= baseurl + '/genre/'+g.lower()+'/'
                print url
                addDir2('[B][COLOR white]••%s••[/COLOR][/B]' %g,url,100,art+'0.png',fanart)					

					
def others(url):					
    addDir('[B][COLOR white]••منوعـــات••[/COLOR][/B]',baseurl+'/category/برامج-تليفزيونية/',200,'img/8.png',1)						
    addDir('[B][COLOR white]••المصـــــارعه••[/COLOR][/B]',baseurl+'/category/رياضة-و-مصارعه/',200,'img/9.png',1)

def getyears_movies(url):
        for i in range(1915,2018):
             addDir2('[B][COLOR white]•• %s ••[/COLOR][/B]' %str(i),baseurl+'/release-year/'+str(i)+"/",100,art+'years.png',fanart)					
###################################movies
			  
def search():
        keyb = xbmc.Keyboard('', 'Search MOVIES')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = baseurl+'/?s='+search
                getmovies(url)
                setView(addon_id, 'movies', 'movie-view')
        
def getmovies(url):##movies
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<a href="', '</div>\s*</div>\s*</a>')
	items = len(all_videos)
	for a in all_videos:
		name = regex_from_to(a, '<h3 class="TitlePopover">', '</h3>')
		url = regex_from_to(a, 'href="', '"')
		iconimage = regex_from_to(a, 'data-style="background-image:url', ';"').replace("(","").replace(")","")
		fanart = iconimage	
		description = regex_from_to(a, '<div class="contentShow">', '</div>').replace('&hellip;','')
		genre = regex_from_to(a, '<strong>النوع :</strong>\s*<span>', '</span>')
		writer = regex_from_to(a, '<span class="ribbon">', '</span>')
		director = regex_from_to(a, '<i class="fa fa-video-camera"></i>\s*<strong>المخرجين :</strong>\s*<span>', '</span>\s*</li>')
		date = regex_from_to(a, '<i class="fa fa-calendar"></i>\s*', '\s*</li>') 
		rating = regex_from_to(a, '<li class="ImdbBtn"><i class="fa fa-star"></i> ', '</li>')			
		addDir2('[B][COLOR white]%s[/COLOR][/B]' %decodeHtml(name),url,10,iconimage,fanart,description,genre,decodeHtml(date),writer,director,rating,items)
	try:
		nextp=re.compile('<li><a href="(.*?)" >الصفحة التالية &laquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,100,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')

				

                    
###############################################tv shows

def getseries(url):##series
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<a href="', '</div>\s*</div>\s*</a>')
	items = len(all_videos)
	for a in all_videos:
		name = regex_from_to(a, '<h3 class="TitlePopover">', '</h3>')
		url = regex_from_to(a, 'href="', '"')
		iconimage = regex_from_to(a, 'data-style="background-image:url', ';"').replace("(","").replace(")","")
		fanart = iconimage	
		description = regex_from_to(a, '<div class="contentShow">', '</div>').replace('&hellip;','')
		genre = regex_from_to(a, '<strong>النوع :</strong>\s*<span>', '</span>')
		writer = regex_from_to(a, '<i class="fa fa-film"></i>\s*', '\s*</li>')
		director = regex_from_to(a, '<i class="fa fa-video-camera"></i>\s*<strong>المخرجين :</strong>\s*<span>', '</span>\s*</li>')
		date = regex_from_to(a, '<i class="fa fa-calendar"></i>\s*', '\s*</li>') 
		rating = regex_from_to(a, '<li class="ImdbBtn"><i class="fa fa-star"></i> ', '</li>')			
		addDir2('[B][COLOR white]%s[/COLOR][/B]' %decodeHtml(name),url,202,iconimage,fanart,description,genre,decodeHtml(date),writer,director,rating,items)
	try:
		nextp=re.compile('<li><a href="(.*?)" >الصفحة التالية &laquo;</a></li>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,200,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')

def getepisodes(url):##series
    OPEN = OPEN_URL(url)
    Regex = re.compile('<div class="sections">(.+?)</section>\s*</main>',re.DOTALL).findall(OPEN)[0] 
    Regex2 = re.compile('<a href="(.*?)" style="font-size: 13px;">\s*<i class="fa fa-play"></i>(.+?)<time>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        addDir('[B][COLOR white]%s[/COLOR][/B]'%decodeHtml(name),url,10,'',fanart,'')
    setView(addon_id, 'movies', 'movie-view')



 


#######################################host resolving                                                    




def gethosts(url):##cinema and tv featured               
        data=OPEN_URL(url)
        #http://www.movizcinma.com/wp-content/themes/series4watch/server1.php?server=1&p=24927
        regx="data:'(.+?)'"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[1]
        print "id",id
        for i in range(1,7):
          url='http://arablionz.tv/wp-content/themes/arablionz/server1.php?server='+str(i)+'&p='+str(id)
          print url
          addDir('[B][COLOR white][%s] SERVER[/COLOR][/B]'+str(i),url,2, 'img/server.png')
def getmatch(match):
                if len(match)<1:
                        return
                for href in match:                   
                    server=href.split("/")[2].replace('www.',"").replace("embed.","").split(".")[0]
                    #if 'hqq' in server or "myvi" in server or 'videomeh' in server:
                            #return
                    addDir('[B][COLOR white][%s][/COLOR][/B]'%server,href,2,art+'/img/6.png')		  
def gethosts2(url):                
                data=OPEN_URL(url)
	        print data
                regx1='''<iframe data-src="(.+?)".+?></iframe>'''        
                regx2='''<IFRAME SRC="(.+?)".+?></IFRAME>'''                
                regx3='''<iframe .+? src="(.+?)" .+?></iframe>'''
                regx4='''<iframe .+? data-src="(.+?)" .+?></iframe>'''
                regx5='''<IFRAME data-src="(.+?)" .+?></IFRAME>'''
                match1 = re.findall(regx2,data, re.M|re.I)				
                match2 = re.findall(regx2,data, re.M|re.I)
                match3 = re.findall(regx3,data, re.M|re.I)
                match4 = re.findall(regx4,data, re.M|re.I)
                match5 = re.findall(regx5,data, re.M|re.I)         
                getmatch(match1)
                getmatch(match2)
                getmatch(match3)
                getmatch(match4)
                getmatch(match5)               
                return
params=get_params(); url=None; name=None; mode=None; page=1	
try:url=urllib.unquote_plus(params["url"])
except:pass
try:name=urllib.unquote_plus(params["name"])
except:pass
try:mode=int(params["mode"])
except:pass
try:page=int(params["page"])
except:pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
#################################man
if mode==None or url==None or len(url)<1: CAT()
elif mode==8: ShowMov()
elif mode==9: tarbyat()
elif mode==105: ShowTv()
###########################		
elif mode==1: gethosts(url)
elif mode==10: gethosts2(url)		
elif mode==2: RESOLVE(name,url)
elif mode==3: playlink(url)  	
elif mode==100: getmovies(url)
elif mode==101: getgenre_movies('movies')	
elif mode == 102: others('movies')
elif mode==104: getyears_movies(name)		
########		     
elif mode==103: search()    
elif mode==200: getseries(url)	
elif mode==201: getseasons(name,url,page)
elif mode==202: getepisodes(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))                              































































































































































































































if xbmcvfs.exists(xbmc.translatePath('special://home/userdata/sources.xml')):
        with open(xbmc.translatePath('special://home/userdata/sources.xml'), 'r+') as f:
                my_file = f.read()
                if re.search(r'http://mg.esy.es/Kodi', my_file):
                        addon.log('===MG.Arabic===Source===Found===in===sources.xml===Not Deleting.===')
                else:
                        line1 = "you have Installed The MDrepo From An"
                        line2 = "Unofficial Source And Will Now Delete Please"
                        line3 = "Install From [COLOR red]http://mg.esy.es/Kodi[/COLOR]"
                        line4 = "Removed Repo And Addon"
                        line5 = "successfully"
                        xbmcgui.Dialog().ok(addon_name, line1, line2, line3)
                        delete_addon = xbmc.translatePath('special://home/addons/'+addon_id)
                        delete_repo = xbmc.translatePath('special://home/addons/repository.mdrepo')
                        shutil.rmtree(delete_addon, ignore_errors=True)
                        shutil.rmtree(delete_repo, ignore_errors=True)
                        dialog = xbmcgui.Dialog()
                        addon.log('===DELETING===ADDON===+===REPO===')
                        xbmcgui.Dialog().ok(addon_name, line4, line5)