# Copyright (C) 2014 MG 
# Licensed under MIT license [http://opensource.org/licenses/MIT]

import shared
addon = shared.loadAddon()
addon.run()
