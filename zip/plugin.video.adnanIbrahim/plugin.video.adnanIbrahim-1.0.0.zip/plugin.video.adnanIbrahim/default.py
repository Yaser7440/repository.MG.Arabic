#!/usr/bin/python
# -*- coding: utf-8 -*-
try:import sys, syspath
except:pass
from yttools import *


def infolist():

 
  list1=[]
  list1.append(('حقيقة الاسلام','UCk0cf8Z-hkIPS4jQ5FgH_Qg'))
  list1.append(('روائع عدنان ابراهيم','UCfKnioL0F0AbFx2p1tiYllg')) 
  list1.append(('نوادر عدنان ابراهيم','UCu6UPlLDC4T7CT04Q5oTDgA'))
  list1.append(('نحو الافضل','UCXD3vGdRCMzJtVE5HAKEQVg'))
  list1.append(('مسلم بلا مذاهب','UCXcYTa_0cxNotMgAAGMQm8w'))
  list1.append(('قرار ازاله','UCuAsYA8YKcLaQa3KTrwd-vQ'))
  list1.append(('Islamic Facts','UCBwleGOj4nGbQ6c5-_DKTEA'))
  list1.append(('Noon Media','UCTIsnxBOAS2BiSe0PiH2ClA'))
  list1.append(('Adnan Ibrahim TV','UCvF3V7gifoSP3LlU-H802PQ'))
  
  list1.append(('Adnan Ibrahim I','UCN9ywC7Nw1y6-KZCF8Wbr-A'))
  list1.append(('Adnan Ibrahim II','UC01VTdHLwj6t2HmYqGaX2WA'))
  
  
  list1.append(('Adnan Ibrahim III','UCMkgz4L22HV3e-1yy9zlYPg'))
  list1.append(('Adnan Ibrahim IV','UCG-jOennaZ8sE91HIZeXg7w'))

  list1.append(('Adnan Ibrahim V','UC6MVcDUcQHZi5DAiZq92k2A'))
  list1.append(('Adnan Ibrahim VI','UCavMvE-0ZFgrOoNsj0u1z9A '))
  list1.append(('Adnan Ibrahim VIII','UCKdnIZd41G_L5bUKZYnGPow'))
  
 
  
  list1.append(('Adnan Ibrahim IX','UCCAMQQFauEzZ1hP4eAcvsaw'))
  return list1

################################################################333
list1=infolist()
process_mode(list1 )
xbmcplugin.endOfDirectory(int(sys.argv[1]))

