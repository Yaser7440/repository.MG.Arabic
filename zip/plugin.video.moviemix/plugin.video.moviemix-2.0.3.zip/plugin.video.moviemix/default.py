import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,xbmc,xbmcaddon,os,net,base64
from t0mm0.common.addon import Addon
from metahandler import metahandlers
net = net.Net()
addon_id = 'plugin.video.moviemix'
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
addon = Addon(addon_id, sys.argv)
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
nextp = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'next.png'))
metaset = selfAddon.getSetting('enable_meta')

def CATEGORIES():
	addDir('Latest','http://moviego.cc/xfsearch/Latest+Movies/',1,icon,fanart)
	addDir('Recent Additions','http://moviego.cc/movies/',1,icon,fanart)
	addDir('Top Movies','http://moviego.cc/top2016/',1,icon,fanart)
	addDir('Genres','http://moviego.cc/top2016/',4,icon,fanart)
	addDir('Years','http://moviego.cc/top2016/',5,icon,fanart)
	addDir('Search','http://moviego.cc/top2016/',3,icon,fanart)
             		
def GETMOVIES(url,name):
        api='http://moviego.cc/engine/ajax/getlink.php?id='
	metaset = selfAddon.getSetting('enable_meta')
	link = cleanHex(net.http_GET(url).content)
	match=re.compile('<div class="short_content">(.+?)<div class="short_overlay">',re.DOTALL).findall(link)
	itemcount=len(match)
        for data in match:
                page=re.compile('<a href="(.+?)">').findall(data)[0]
                name=re.compile('alt="(.+?)"').findall(data)[0]
                iconimage='http://moviego.cc'+re.compile('<img src="(.+?)"').findall(data)[0]
                pagenum=page.split('-')[0].split('/')[-1]
                addMeta(name,page,100,iconimage,itemcount,page,isFolder=False)
	if metaset=='true':
		setView('movies', 'MAIN')
	else: xbmc.executebuiltin('Container.SetViewMode(50)')

def PLAYLINK(name,url,iconimage,page):
        page = net.http_GET(page).content
        url=re.compile('src="(.+?)" allowfullscreen></iframe>').findall(page)[0]
        link = net.http_GET(url).content
        js=re.compile('<script type="text/javascript">(.+?)\)</script>').findall(link)[0]
        jsdone=jsunpack.unpack(js)
        url=re.compile('"file":"(.+?)","label"').findall(jsdone)[-1]
	ok=True
	liz=xbmcgui.ListItem(name, iconImage=iconimage,thumbnailImage=iconimage); liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	xbmc.Player().play(url, liz, False)
	return ok
	
def SEARCH():
        search_entered =''
        title='[COLOR gold]Movie Mix[/COLOR]'
        keyboard = xbmc.Keyboard(search_entered,title)
        keyboard.doModal()
        if keyboard.isConfirmed():
                search_entered = keyboard.getText().replace(' ','+')
        if len(search_entered)>1:
                url = 'http://moviego.cc/index.php?do=search&subaction=search&search_start=0&full_search=1&result_from=1&story='+search_entered+'&all_word_seach=1'
                GETSEARCHRESULTS(url)
        else:quit()

def GETSEARCHRESULTS(url):
        api='http://moviego.cc/engine/ajax/getlink.php?id='
	metaset = selfAddon.getSetting('enable_meta')
	link = cleanHex(net.http_GET(url).content)
	match=re.compile('<div class="short_content">(.+?)<div class="short_overlay">',re.DOTALL).findall(link)
	itemcount=len(match)
        for data in match:
                page=re.compile('<a href="(.+?)">').findall(data)[0]
                name=re.compile('<div class="short_header">(.+?)</div>',re.DOTALL).findall(data)[0].replace('\n','').replace('  ','')
                iconimage='http://moviego.cc/'+re.compile('<img src="(.+?)"').findall(data)[0]
                pagenum=page.split('-')[0].split('/')[-1]
                url=api+pagenum
                addMeta(name,url,100,iconimage,itemcount,page,isFolder=False)
	if metaset=='true':
		setView('movies', 'MAIN')
	else: xbmc.executebuiltin('Container.SetViewMode(50)')

def GENRES():
	genres=['Action','Adventure','Biography','Comedy','Crime','Documentary','Drama','Family','Fantasy','History','Horror','Musical','Mystery','Romance','Sci-Fi','Sport','Thriller','War','Western']
        for g in genres:
                url='http://moviego.cc/movies/movies_'+g.lower()+'/'
                print url
                addDir(g,url,1,icon,fanart)

       
def YEARS():
        years=['2016','2015','2014','2013','2012']
        for y in years:
                url='http://moviego.cc/xfsearch/'+y
                addDir(y,url,1,icon,fanart)
		 
def cleanHex(text):
        def fixup(m):
                text = m.group(0)
                if text[:3] == "&#x": return unichr(int(text[3:-1], 16)).encode('utf-8')
                else: return unichr(int(text[2:-1])).encode('utf-8')
        try :return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))
        except:return re.sub("(?i)&#\w+;", fixup, text.encode("ascii", "ignore").encode('utf-8'))

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
			       
	return param

def addDir(name,url,mode,iconimage,fanart,description=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def addLink(name,url,mode,iconimage,description=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description} )
	liz.setProperty('fanart_image', fanart)
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

def addMeta(name,url,mode,iconimage,itemcount,page='',isFolder=False):
	if metaset=='true':
	  if not 'COLOR' in name:
	    splitName=name.partition('(')
	    simplename=""
	    simpleyear=""
	    if len(splitName)>0:
		simplename=splitName[0]
		simpleyear=splitName[2].partition(')')
	    if len(simpleyear)>0:
		simpleyear=simpleyear[0]
	    meta = mg.get_meta('movie', name=simplename ,year=simpleyear)
	    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&page="+urllib.quote_plus(page)
	    ok=True
	    if meta['cover_url'] == '':iconimage=iconimage
	    else: iconimage=meta['cover_url']
	    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	    liz.setInfo( type="Video", infoLabels=meta )
	    contextMenuItems = []
	    if not meta['trailer']=='':contextMenuItems.append(('Trailer', 'XBMC.RunPlugin(%s)' % addon.build_plugin_url({'mode': 6, 'url':meta['trailer']})))
	    contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
	    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
	    if not meta['backdrop_url'] == '': liz.setProperty('fanart_image', meta['backdrop_url'])
	    else: liz.setProperty('fanart_image', fanart)
	    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder,totalItems=itemcount)
	    return ok
	else:
	    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&page="+urllib.quote_plus(page)
	    ok=True
	    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	    liz.setInfo( type="Video", infoLabels={ "Title": name } )
	    liz.setProperty('fanart_image', fanart)
	    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder)
	    return ok

def TRAILER(url):
        xbmc.executebuiltin("PlayMedia(%s)"%url)
        
def setView(content, viewType):
        if content:
                xbmcplugin.setContent(int(sys.argv[1]), content)
        if selfAddon.getSetting('auto-view')=='true':
                xbmc.executebuiltin("Container.SetViewMode(%s)" % selfAddon.getSetting(viewType) )

params=get_params(); url=None; name=None; mode=None; site=None; iconimage=None

try: site=urllib.unquote_plus(params["site"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: page=urllib.unquote_plus(params["page"])
except: pass
mg = eval(base64.b64decode('bWV0YWhhbmRsZXJzLk1ldGFEYXRhKHRtZGJfYXBpX2tleT0iZDk1NWQ4ZjAyYTNmMjQ4MGE1MTg4MWZlNGM5NmYxMGUiKQ=='))
if mode==None or url==None or len(url)<1: CATEGORIES()
elif mode==1: GETMOVIES(url,name)
elif mode==2: GETLINKS(url,name,iconimage)
elif mode==3: SEARCH()
elif mode==4: GENRES()
elif mode==5: YEARS()
elif mode==6: TRAILER(url)
elif mode==100: PLAYLINK(name,url,iconimage,page)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
