# -*- coding: utf-8 -*-
# Embedded file name: /media/hdd/Extensions/TSmedia/addons/arabic/plugin.video.aflamhd/default.py




try:import sys, syspath
except:pass
import os, sys
import httplib
import time
from urllib import urlencode
import urllib, urllib2, re, sys
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse
from addon.common.net import Net
from urlresolver import resolve
import StringIO

__settings__ = xbmcaddon.Addon(id='plugin.video.3sktv')
__icon__ = __settings__.getAddonInfo('icon')
__fanart__ = __settings__.getAddonInfo('fanart')
__language__ = __settings__.getLocalizedString
_thisPlugin = int(sys.argv[1])
_pluginName = sys.argv[0]
baseurl = 'http://3sk.tv/'

####functions

def read_url(url):
     
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	req.add_header('Host', 'www.3sk.tv')
	req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
	req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
	response = urllib2.urlopen(req)
	link=response.read()
        return link
    
def readnet2(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      

              
def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        
        return query.hostname 
##########################################parsing tools
def showmenu():

                #genreliste=[]
                addDir('••أخــر الاضافات••', 'http://www.3sk.tv/',220,'special://home/addons/plugin.video.3sktv/img/3.png','',1)
                addDir('مسلسلات كامله', 'http://3sk.tv/pdep55.html',200,'special://home/addons/plugin.video.3sktv/img/1.png','',1)
                addDir('مسلسلات متفرقه', 'http://3sk.tv/pdep55.html',5,'special://home/addons/plugin.video.3sktv/img/1.png','',1)
                addDir('افلام', 'http://3sk.tv/pdep42.html',100,'special://home/addons/plugin.video.3sktv/img/2.png','',1)
               
                #for title, url, mode,pic,desc,page in genreliste:
                    #addDir(title, url, mode, pic,desc,1)
###############################################tv shows
               
def GENRES(url):

                addDir('السلطامه كوسم', 'http://www.3sk.tv/vb/forumdisplay.php?f=756',201,'http://3sk.tv/ex/td/ks.png','',1)
                addDir('مسلسل حب أعمى Kara Sevda', 'http://www.3sk.tv/vb/forumdisplay.php?f=746',201,'http://3sk.tv/ex/td/ks.png','',1)
                addDir('مسلسل رائحة الفراولة', 'http://www.3sk.tv/vb/forumdisplay.php?f=736',201,'http://3sk.tv/ex/td/ck.png','',1)
                addDir('مسلسل الأزهار الحزينة', 'http://www.3sk.tv/vb/forumdisplay.php?f=739',201,'http://3sk.tv/ex/td/kc.png','',1)
                addDir('مسلسل حب للايجار', 'http://www.3sk.tv/vb/forumdisplay.php?f=729',201,'http://3sk.tv/ex/td/ka2.png','',1)
                addDir('مسلسل بنات الشمس', 'http://www.3sk.tv/vb/forumdisplay.php?f=725',201,'http://3sk.tv/ex/td/gk1.png','',1)
                addDir('وادي الذئاب', 'http://www.3sk.tv/vb/forumdisplay.php?f=554',201,'http://3sk.tv/ex/td/kvp.png','',1)
                addDir('الحلوات الصغيرات الكاذبات', 'http://www.3sk.tv/vb/forumdisplay.php?f=745',201,'http://3sk.tv/ex/td/ka2.png','',1)
                addDir('مسلسل اسمه سعادة', 'http://www.3sk.tv/vb/forumdisplay.php?f=742',201,'http://3sk.tv/ex/td/ka2.png','',1)
                addDir('علاقات معقدة', 'http://www.3sk.tv/vb/forumdisplay.php?f=740',201,'http://3sk.tv/ex/td/ia.png','',1)        
                
def getmovies(tname,urlmain,page):##series
                print "page",page
               
                if page>1:
                  # href="http://www.arabshow.tv/category/%d8%a3%d9%81%d9%84%d8%a7%d9%85-%d8%a3%d8%ac%d9%86%d8%a8%d9%8a%d8%a9-non-arabic-movies/page/2/"
                  #http://3sk.tv/pdep55-p2.html
                  parts=urlmain.split(".html")
                  url_page=parts[0]+'-p'+str(page)+".html"
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=read_url(url_page)
               #data=data.split('id="movie_list"')[1]
                
               
                if data is None:
                    return
                #print data
                blocks=data.split('<div class="article">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                    block=block.lower().replace("\n"," ")
                    regxhref='''<h2><i class="icon-link"></i><a href='(.*?)'>(.*?)</a></h2>'''
                    match=re.findall(regxhref,block, re.M|re.I)
                    name=match[0][1]
                    href=match[0][0]           
                    regximg='''<img src='(.*?)' height='250' width='175'/></a>'''
                    img=re.findall(regximg,block, re.M|re.I)[0]

                                           
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:addDir(name,href,21,img,'',1)
                    except:continue
                if "Search" in tname:
                        return               

                if len(blocks)>7:
                   addDir("next page",urlmain,200,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
                                        


def addvb(tname,urlmain,page):

               if page>1:
                  url_page=urlmain+'/page/'+str(page)+"/"
                  url_page=urlmain[:-5]+"/"+str(page)+".html"
               else:
                      url_page=urlmain
               print "url_page",url_page
               content = read_url(url_page)                 
               print content
               if content is None:
                  addDir('Error:download error','', 1,'',1)
                  return       
	       regx='''<a href="(.*?)">\s*<div class="pic">\s*<span class="qualitos">(.*?)</span>\s*<img src="(.*?)" alt="">'''	
               regx='''<img src="(.*?)">\s*</td> <td class="alt1Active" align="right" .*?>\s*<a href="(.*?)"><strong>(.*?)</strong></a>'''  

               regx='''<td class="alt2"><img src="(.*?)"></td>\s*<td class="alt1Active" align="right" id=".*?" .*?>\s*<a href="(.*?)"><strong>(.*?)</strong></a>''' 





               match = re.findall(regx,content, re.M|re.I)
               print "match",match
               if not match :
                       return
               for href,image,title in match:
                        pic = ''
                        url=href
                        url=url.replace('artid','topic')
                        try:name=title.encode("utf-8")
                        except:name=title
                        #title=title.replace("مشاهدة وتحميل فيلم","")
                        #title=title.replace("اون لاين","")
                        #addDir(name,url,201, image)
                        addDir(name,href,201,'','',1)
               addDir('next page>',urlmain,222,'http://ewastealternatives.org/sites/default/files/images/nextBUTTON.png',str(page+1))    
               
               

             
 
def addnew(tname,urlmain,page):##series
                print "page",page
               
                if page>1:

                  url_page=parts[0]+str(page)+".html"
                  url_page=parts[0]+'/?p'+str(page)+".html"
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=read_url(url_page)
               #data=data.split('id="movie_list"')[1]
                
               
                if data is None:
                    return
                #print data
                blocks=data.split('<div class="article">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                    block=block.lower().replace("\n"," ")
                    regxhref='''<h2><i class="icon-link"></i><a href='(.*?)'>(.*?)</a></h2>'''
                    match=re.findall(regxhref,block, re.M|re.I)
                    name=match[0][1]
                    href=match[0][0]           
                    regximg='''<img src='(.*?)' height='250' width='175'/></a>'''
                    img=re.findall(regximg,block, re.M|re.I)[0]

                                           
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:addDir(name,href,21,img,'',1)
                    except:continue
                if "Search" in tname:
                        return               

                if len(blocks)>7:
                   addDir("next page",urlmain,220,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
                                        

                                        









def search_series(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url.replace("query",search_entered)

        getseries("Search",url,0)

                    
def getseasons(name,urlmain,page):##series
                if page>1:
                  #/page/2/
                  url_page=urlmain+"page/"++str(page)
                  
                else:
                
                      url_page=urlmain
                 
                data=readnet(url_page)
                try:data=data.split('<div class="title6">')[1]
                except:pass
                print "url_page",url_page
              
                if data is None:
                    return

                seasons=re.findall('''<a href="(.*?)" >(.*?)</a>''',data, re.M|re.I)
                print 'seasons',seasons
                
                for href,name in seasons:
                    
                    
                    addDir(name,href,201,'','',1)
                        
               
def getseasons_search(name,urlmain,page):##series
                
                data=readnet(urlmain)
                try:data=data.split('<h2>Search results')[1]
                except:pass
               
              
                if data is None:
                    return
                regx='<a href="(.*?)"  rel="nofollow">(.*?)</a>'
                seasons=getgroups(data,regx,2)
               
                
                seasons=re.findall(regx,data, re.M|re.I)
                print 'seasons',seasons
                
                for href,name in seasons:
                    
                    
                    addDir(name,href,201,'','',1)
                                           
                                    
def getseries(tname,urlmain,page):##series
                print "page",page
               
                if page>1:
                  # href="http://www.arabshow.tv/category/%d8%a3%d9%81%d9%84%d8%a7%d9%85-%d8%a3%d8%ac%d9%86%d8%a8%d9%8a%d8%a9-non-arabic-movies/page/2/"
                  #http://3sk.tv/pdep55-p2.html
                  parts=urlmain.split(".html")
                  url_page=parts[0]+'-p'+str(page)+".html"
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=read_url(url_page)
               #data=data.split('id="movie_list"')[1]
                
               
                if data is None:
                    return
                #print data
                blocks=data.split('<div class="article">')
                i=0
                
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    
                    block=block.lower().replace("\n"," ")
                    regxhref='''<h2><i class="icon-link"></i><a href='(.*?)'>(.*?)</a></h2>'''
                    match=re.findall(regxhref,block, re.M|re.I)
                    name=match[0][1]
                    href=match[0][0]           
                    regximg='''<img src='(.*?)' height='250' width='175'/></a>'''
                    img=re.findall(regximg,block, re.M|re.I)[0]

                                           
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:addDir(name,href,201,img,'',1)
                    except:continue
                if "Search" in tname:
                        return               

                if len(blocks)>7:
                   addDir("next page",urlmain,200,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))
                                        

def getepisodes(name,urlmain,page):##series
                print "page",page
               

               
                data=read_url(urlmain)
                
               #data=data.split('id="movie_list"')[1]
                
               
                if data is None:
                    return
                #try:data=data.split('<div class="keremiya_part">')[1]
                #except:data=''

               
                if data:
                   
                    #block=block.lower()
                    regxhref='''<span>(.*?)</span>.*?<a href="(.*?)">'''
                    regxhref='''<a href="(.*?)"><span>(.*?)</span></a>'''
                    regx='<a href="(.*?)"><span>(.*?)</span></a>'
                    regx='<a href="(.*?)" id=".*?">(.*?)</a>'  
                    
                    match=re.findall(regx,data, re.M|re.I)
                    print "match",match
                    i=0
                    for href,name in match:         
                       
                    
                    
                               
                            i=i+1
                            name="episode "+ str(i)
                            href='http://www.3sk.tv/vb/'+href  
                            #try:name=name.encode("utf-8")
                            #except:pass
                            #print "href,name",href,name
                            addDir(str(name),href,21,'','',1)                        
               
                   
                


#######################################host resolving                                                    
def creatertmp(host,urlmain):
     #rtmp://streaming.hayyes.com/vod/<playpath>mp4:29/29303/29303_1_400k.mp4 <swfUrl>http://www.hayyes.com/sites/all/themes/hys/tpl/jw/jwplayer.flash.swf <pageUrl>http://www.hayyes.com/vod/aflam/7alawet-roo7
     url=host+'  swfUrl=http://www.hayyes.com/sites/all/themes/hys/tpl/jw/jwplayer.flash.swf pageUrl='+ urlmain
     return url

def gethosts(urlmain):##cinema and tv featured
#href="http://www.arabshow.tv/the-forest/2/">
        
        for i in range(1,5):
           href=urlmain+str(i)+"/"     
           addDir("server"+" "+str(i),href,21,'http://i.imgur.com/ZHHflBW.png','',1)
        

		
		
                #playG(link)
def gethosts_movies(urlmain):##cinema and tv featured

                
                data=readnet(urlmain)
                try:data=data.split("<div class='panel-container'>")[1]
                except:pass
               
                
              
                if data is None:
                    return
                
                blocks=data.split('class="tab-buttons-panel"')
               
                i=0
               
                for block in blocks:
                    i=i+1
                    
                    block=block.lower()
                    regx1='''<iframe.*?src="(.*?)".*?></iframe>'''
                    regx2='''<iframe.*?src='(.*?)'.*?></iframe'''
                    #regx3='''<iframe width="600" height="330" scrolling="no" frameborder="0" src="http://videomega.tv/iframe.php?ref=Kjp0m2ECo44oCE2m0pjK&width=600&height=330" allowFullScreen></iframe>'''
                    match=re.findall(regx1,block, re.M|re.I)
                    match2=re.findall(regx2,block, re.M|re.I)
                   
                    
                     
                   
                    
                    for href in match:
                      
                      host=gethostname(href)
                    
                            
                   
                      addDir(host,href,1,'','',1)
                    for href in match2:
                      
                      host=gethostname(href)
                    
                            
                   
                      addDir(host,href,1,'http://i.imgur.com/ZHHflBW.png','',1)
def get_servers(url):
    data = read_url(url)
    regx = '<a href="(.+?)" target="_blank"><img alt'
    regx='''<a href="(.+?)" target="_blank">.+?</a>'''
    match = re.findall(regx, data, re.M | re.I)
    print 'match', match
    
    i = 0
    for href in match:

        
        debug = True

        
        if not "/redirector.php" in href:
                continue
        i = i + 1
        server = 'server' + str(i)
        addDir(server, href, 2, 'http://i.imgur.com/ZHHflBW.png')                      
def gethosts2(urlmain):##cinema and tv featured
                data=readnet(urlmain)
                if data is None:
                    return
               
                i=0
                regx='''<iframe.*?src="(.*?)".*?></iframe>'''
                regx='''<iframe.*?src="(.*?)".*?></iframe></p>'''
                link=re.findall(regx,data, re.M|re.I)[0]
               
                stream_url=resolve(link)
                playlink(stream_url)
	    
def resolve_host(url):#last good-used with local resolver
        if True:
               regx='''<a href="(.*?)" target="_blank">'''
               data=read_url(url)
               link=re.findall(regx,data, re.M|re.I)[0]
               print "link",link
              
               if "mail" in link or "openload" in link or 'vid.ag' in link or "ok.ru" in link or "tune.pk" in link :
                   resolve_host2(link)
                   return
               data=readnet2(link)
               #data=data.split('class="dimPlayerBlock">')[1]
               regx='<iframe.*?src="(.*?)".*?></iframe>'
               regx2="<iframe.*?src='(.*?)'.*?></iframe>"
               
               try:host=re.findall(regx,data, re.M|re.I)[0]
               except:host=re.findall(regx2,data, re.M|re.I)[0]
               print "host",host
               if 'youtube' in host:
                       #//www.youtube.com/embed/a8oXHgw492M?rel=0&amp;fs=2&amp;wmode=transparent?rel=0&showinfo=0&wmode=transparent
                       video_id=os.path.split(host)[1].split("?")[0]
                       stream_link = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id
                       playlink(stream_link)
                       return
               if host:
                        if not host.startswith("http"):
                                host="http:"+host
                        from urlresolver import resolve
   
                        stream_link=str(resolve(host))
                        print stream_link
                        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
                            playlink(str(stream_link))
                            return
                            listItem = xbmcgui.ListItem(path=str(stream_link))
                            xbmcplugin.setResolvedUrl(sys.argv[0], True, listItem)   
                        else:
                            addDir("Error,"+stream_link,"",9,"") 	    
def resolve_host2(url):#last good
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
   
	    playlink(stream_link)
        else:
            addDir("Error,"+stream_link,"",9,"")
def playlink(stream_link):
            
            xbmc.Player().play(stream_link)
            sys.exit(0)


            
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param



def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
def getgroups(data, pattern, grupsNum = 1, ignoreCase = False):
        tab = []
        if ignoreCase:
            match = re.search(pattern, data, re.IGNORECASE)
        else:
            match = re.search(pattern, data)
        
        for idx in range(grupsNum):
            try:
                value = match.group(idx + 1)
            except:
                value = ''

            tab.append(value)

        return tab
def getdata(data, marker1, marker2, withMarkers = True, caseSensitive = True):
        if caseSensitive:
            idx1 = data.find(marker1)
        else:
            idx1 = data.lower().find(marker1.lower())
        if -1 == idx1:
            return (False, '')
        if caseSensitive:
            idx2 = data.find(marker2, idx1 + len(marker1))
        else:
            idx2 = data.lower().find(marker2.lower(), idx1 + len(marker1))
        if -1 == idx2:
            return (False, '')
        if withMarkers:
            idx2 = idx2 + len(marker2)
        else:
            idx1 = idx1 + len(marker1)
        return  data[idx1:idx2]

params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
elif mode==1:
        print ""+url
        gethosts(url)
elif mode==11:
        print ""+url
        gethosts_movies(url)        
elif mode==2:
        print ""+url
        resolve_host(url)
elif mode==21:
        print ""+url
        get_servers(url)
        
elif mode==22:
        print ""+url
        playlink(url)          
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)
elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
	print ""+url
        search(url)
        
        
elif mode==5:
	print ""+url	
        GENRES(url)   	
elif mode==51:
	print ""+url	
        years(url)  	
	
elif mode==104:
	print ""+url
	
	searchmovies(url)
elif mode==105:
        print ""+url
        getmovies2(name,url,page)
elif mode==200:
	print "mfaraj"+url
	getseries(name,url,page)
elif mode==220:
	print "mfaraj"+url		
	GENRES(url)
elif mode==222:
	print "mfaraj"+url	
        addvb(name,url,page)
elif mode==223:
	print "mfaraj"+url        
        addeposide(name,url,page)	
elif mode==2001:
	print "mfaraj"+url
	getseasons(name,url,page)
	#getvideopage(url,page)	
elif mode==201:
	getepisodes(name,url,page)
elif mode==202:
	print ""+url
	getA_Z('shows')
	
elif mode==203:
	print ""+url
        search_series(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
                              
