# -*- coding: utf8 -*-

import sys
import urllib,urllib2,re,os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re



############################################

####functions

    
def readnet(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      

              
def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        
        return query.hostname 
##########################################parsing tools


def showmenu():
        

        addDir('••كل المسلسلات••','http://www.sumeronline.com/series/',200,'img/0.png','',1)

	addDir('••مسلسلات تركيه جديده••','http://www.sumeronline.com/series/turkish/',200,'img/3.png','',1)
        
        addDir('••رمصان 2016••','http://www.sumeronline.com/series/%D8%B1%D9%85%D8%B6%D8%A7%D9%86-2016/',200,'img/9.png','',1)
        addDir('••رمضان 2015••','http://www.sumeronline.com/series/%D8%B1%D9%85%D8%B6%D8%A7%D9%86-2015/',200,'img/7.png','',1)

        addDir('••رمضان 2014••','http://www.sumeronline.com/series/%D8%B1%D9%85%D8%B6%D8%A7%D9%86-2014/',200,'img/6.png','',1)
                

def years(url):
        for i in range(2002,2017):
             #http://tellymov.com/s/year/2006   
             addDir(str(i),'http://tellymov.com/s/year/'+str(i),100,'','',1)                 
                    
def genres(urlmain):

                data=readnet(urlmain)
               
               
                
               
                if data is None:
                    return
               
                ##codes
        
        
                            
                    


def getA_Z(name='movies'):
		abc = ['#','0','1','2','3','4','5','6','7','8','9',"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

		for letter in abc:
                        
			  addDir(letter,'http://projectfreetv.so/watch-tv-series/#mctm-'+letter,100,'',1)
			
###################################movies
			  
def search(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered
        
          
        getmovies("Search",url,0)


                        
               
                   
                
        
def getmovies(namemain,urlmain,page):##movies
                print "page",page
               
                if page>1:
                 
                  
                     url_page=urlmain+'/page'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
               
                try:data=data.split('class="first-word"')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="videobox"')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)" class="title">(.*?)</a>'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    name=match[0][1]
                    href=match[0][0]
                    regx='''<div style="background: url((.*?)) no-repeat;">'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                    img=imgs[0][0].replace("('","").replace("')","")
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:addDir(name,href,1,img,'',1)
                    except:pass
               
                   
                
                
                addDir("next page",urlmain,100,'img/next.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))

                    
###############################################tv shows
def search_series(url):
        
        
         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search 1channel')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')  
                   
                   
        else:
             print "search error"
            
        
        
         
        url= url+search_entered

        getseries("Search",url,0)
def getseries(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                 
            
                     url_page=urlmain+'/page/'+str(page)+"/"
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                try:data=data.split('<div class="TabbedPanelsContentGroup">')[1]
                except:pass
               
                if data is None:
                    return
                
                blocks=data.split('</table></td>')
                i=0
                
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #block=block.lower()
                    regx='''<td.*?><a href="(.*?)"><img src="(.*?)" alt="(.*?)".*?/></a></td>'''
                    match=re.findall(regx,block, re.M|re.I)
                    try:href=match[0][0]
                    except:continue
                    img=match[0][1]
                    name=match[0][2]
                               
                    

                                             
                               
                    
                    name=name.encode("utf-8")
                    href=href.encode("utf-8")
                    img=img.encode("utf-8")
                    addDir(name,href,202,img,'',1)                        
               
                   
                
                                        
                   

                if len(match)==0:
                    addDir("Error:no results",urlmain,200,'','',str(page+1))
                                        
                    
def getseasons(name,urlmain,page):##series

                 
                data=readnet(url_page)
                try:data=data.split('<div class="title6">')[1]
                except:pass
                print "url_page",url_page
              
                if data is None:
                    return

                seasons=re.findall('''<a href="(.*?)" >(.*?)</a>''',data, re.M|re.I)
                
                
                for href,name in seasons:
                    
                    
                    addDir(name,href,202,'','',1)
                        

                                           
                                    


def getepisodes(name,urlmain,page):##series

                print "page",page
               
                if page>1:
                 
            
                     url_page=urlmain+'/page/'+str(page)+"/"
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet(url_page)
                try:data=data.split('<!-- InstanceBeginEditable name="EditRegion3" -->')[1]
                except:pass
               
                if data is None:
                    return
                
                blocks=data.split('border="0" bgcolor=')
                i=0
                
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    #block=block.lower()
                    regx='''td.*?><a href="(.*?)"><img src="(.*?)" alt="(.*?)".*?/></a></td>'''
                    match=re.findall(regx,block, re.M|re.I)
                    try:href=match[0][0]
                    except:continue
                    img=match[0][1]
                    name=match[0][2]
                               
                    

                                             
                               
                    
                    name=name.encode("utf-8")
                    name=name+"_"+href.encode("utf-8").replace(".html","")
                    if href.endswith("/"):
                      href=url_page+href.encode("utf-8")
                    else:
                       href=url_page+"/"+href.encode("utf-8") 
                    img=img.encode("utf-8")
                    
                    addDir(name,href,1,img,'',1)                        
               
                   
                
                                        
                   

                if len(match)==0:
                    addDir("Error:no results",urlmain,200,'','',str(page+1))
 


#######################################host resolving                                                    




def gethosts(name,urlmain):##cinema and tv featured

                
                data=readnet(urlmain)
                try:data=data.split("<div class='panel-container'>")[1]
                except:pass
               
                
              
                if data is None:
                    return
                regx='''<iframe name="main_video_player".*?src='(.*?)'.*?></iframe>'''
                try:
                    href=re.findall(regx,data, re.M|re.I)[0]
                    data=readnet(href)
                    #print "data",data.encode("utf-8")
                    regx="'file','(.*?)'"
                    href=re.findall(regx,data, re.M|re.I)[0].split("&")[0]
                    rtmp='rtmp://vod205.sonara.net/vod/media playpath='
                    playpath=href
                    swfUrl="swfUrl=http://www.sonara.net/mediaplayera/player.swf pageUrl="
                    pageUrl=urlmain
                    print "pageUrl",pageUrl
                    link=rtmp+playpath+swfUrl+pageUrl.encode("utf-8")
                    #rtmp='rtmp://vod205.sonara.net/vod/media playpath='+href+"swfUrl=http://www.sonara.net/mediaplayera/player.swf pageUrl="+ urlmain.encode("utf-8")
                    addDir('sonara',link,2,'','',1)
                except:
                     pass
                regx='''<iframe.*?src="(.*?)".*?></iframe>'''
                match=re.findall(regx,data, re.M|re.I)
                print "match",match
                
                for href in match:
                      if '&amp;' in href:
                          href=href.split('&amp;')[0]
                      if 'facebook' in href:
                          continue
                      host=gethostname(href)
                    
                            
                   
                      addDir(host,href,2,'','',1)
                   
                    
                     
                    
                    
                                          

	    
def resolve_host(url):#last good-used with local resolver
       
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
      
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    
        else:
            addDir("Error,"+stream_link,"",9,"") 	    

def playlink(url):
           
            xbmc.Player().play(url)
            sys.exit(0)            
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param


	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
elif mode==1:
        print ""+url
        gethosts(name,url)
elif mode==2:
        print ""+url
        resolve_host(url)        
elif mode==3:
        print ""+url
        playlink(url)
     
        
elif mode==100:
        print ""+url
        getmovies(name,url,page)
elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z('movies')
	
elif mode==103:
	print ""+url
        search(url)    
       


elif mode==200:

	getseries(name,url,page)
	
elif mode==201:
	getseasons(name,url,page)
	
elif mode==202:
	getepisodes(name,url,page)


xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
