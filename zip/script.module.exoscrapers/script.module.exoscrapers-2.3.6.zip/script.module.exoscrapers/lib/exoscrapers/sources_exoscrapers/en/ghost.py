# -*- coding: UTF-8 -*-

#  ..#######.########.#######.##....#..######..######.########....###...########.#######.########..######.
#  .##.....#.##.....#.##......###...#.##....#.##....#.##.....#...##.##..##.....#.##......##.....#.##....##
#  .##.....#.##.....#.##......####..#.##......##......##.....#..##...##.##.....#.##......##.....#.##......
#  .##.....#.########.######..##.##.#..######.##......########.##.....#.########.######..########..######.
#  .##.....#.##.......##......##..###.......#.##......##...##..########.##.......##......##...##........##
#  .##.....#.##.......##......##...##.##....#.##....#.##....##.##.....#.##.......##......##....##.##....##
#  ..#######.##.......#######.##....#..######..######.##.....#.##.....#.##.......#######.##.....#..######.

'''
    exoscrapers Project
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import urllib
from exoscrapers.modules import client
from exoscrapers.modules import jsunpack
from exoscrapers.modules import cleantitle
from exoscrapers.modules import source_utils
#from exoscrapers.modules import log_utils
from exoscrapers.modules import getSum

class source:
	def __init__(self):
		self.priority = 1
		self.language = ['en']
		self.domains = ['xn--ngbkt.com']
		self.base_link = 'http://xn--ngbkt.com'
		self.movie_link = '/%s/'
		self.episode_link = '/%s-%s/'
		#self.scraper = cfscrape.create_scraper()
		self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0', 'Referer': self.base_link}

	def movie(self, imdb, title, localtitle, aliases, year):
		try:
			title = cleantitle.geturl(title)
			url = self.base_link + self.movie_link % (title)
			return url
		except:
			source_utils.scraper_error('GHOST')
			return


	def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
		try:
			url = cleantitle.geturl(tvshowtitle)
			return url
		except:
			source_utils.scraper_error('GHOST')
			return


	def episode(self, url, imdb, tvdb, title, premiered, season, episode):
		try:
			if not url:
				return
			title = url
			season = '%01d' % int(season)
			episode = '%01d' % int(episode)
			se = 'season-%s-episode-%s' % (season, episode)
			url = self.base_link + self.episode_link % (title, se)
			return url
		except:
			source_utils.scraper_error('GHOST')
			return


	def sources(self, url, hostDict, hostprDict):
		try:
			sources = []
			hostDict = hostprDict + hostDict
			
			r = getSum.get(url)
			results = getSum.findEm(r, '<iframe src="(.+?)://(.+?)/(.+?)"')

			for http, host, url in results:
				host = host.replace('www.', '')
				url = '%s://%s/%s' % (http, host, url)
				#log_utils.log('url = %s' % url, log_utils.LOGDEBUG)
				html = getSum.get(url)
				r = getSum.findallIgnoreCase(html, 'JuicyCodes\.Run\("([^)]+)"\)')
				for jc in r:
					jc = jc.replace('"+"', '').decode('base64')
					jc = jsunpack.unpack(jc)
					jc = getSum.findThat(jc, 'file":"(.+?)","label":"(.+?)"')
					#log_utils.log('url = %s' % jc, log_utils.LOGDEBUG)
					
				


					for link, label in jc:
						quality, info = source_utils.get_release_quality(label, label)#[0]
						link += '|Range=bytes=0-&Referer=%s&User-Agent=%s' % (urllib.quote(client.agent()), url)
						#log_utils.log('link = %s' % link, log_utils.LOGDEBUG)
						sources.append({'source': host, 'quality': quality, 'info': info, 'language': 'ar', 'url': link,
									'direct': True, 'debridonly': False})

			return sources
		except:
			source_utils.scraper_error('GHOST')
			return sources

	def resolve(self, url):
		return url