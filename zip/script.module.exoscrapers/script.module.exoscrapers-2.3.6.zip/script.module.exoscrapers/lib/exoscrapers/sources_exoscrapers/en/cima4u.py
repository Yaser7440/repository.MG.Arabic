# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 07-23-2019 by MGArabic in Scrubs.
# Has shows but is shitty and limited.
#from exoscrapers.modules import log_utils


from exoscrapers.modules import getSum
from exoscrapers.modules import cleantitle
from exoscrapers.modules import source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['cima4u.io','live.cima4u.io']
        self.base_link = 'http://cima4u.io'
		
		

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            mtitle = cleantitle.get_url(title).replace('-','+').replace(':','').replace('&','+').replace("'",'+')
            mtitle = cleantitle.geturl(mtitle)
            url = self.base_link + '/?s=%s+%s' % (mtitle, year)
            #log_utils.log('url = %s' % url, log_utils.LOGDEBUG)
            return url
        except:
            source_utils.scraper_error('cima4u')
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url is None:
                return sources
            hostDict = hostDict + hostprDict

            r = getSum.get(url)
            results = getSum.findEm(r, 'class="MovieBlock".+?href="(.+?)"')
            for url in results:
				r = getSum.get(url)
				results = getSum.findEm(r, 'class="WatchNow">.+?href="(.+?html)"')
				for link in results:
					link = "https:" + link if not link.startswith('http') else link	
					r = getSum.get(link)
					data = getSum.findEm(r, 'data-link="(.+?)"')
					for video in data:
					
						video = 'http://live.cima4u.io/structure/server.php?id=%s' % video
						
						#log_utils.log('cima4u = %s' % video, log_utils.LOGDEBUG)
						r = getSum.get(video)
						results = getSum.findSum(r)
						for url in results:
						
						
						
							valid, host = source_utils.is_host_valid(url, hostDict)
							if valid:
								if host in str(sources):
									continue
								quality, info = source_utils.get_release_quality(url, url)
								
								sources.append({'source': host, 'quality': quality, 'language': 'ar', 'info': '', 'url': url, 'direct': False, 'debridonly': False})
						

								





            return sources
        except:
            source_utils.scraper_error('cima4u')
            return sources

    def resolve(self, url):	
            return url