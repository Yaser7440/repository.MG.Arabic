# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 07-23-2019 by MGArabic in Scrubs.
# Has shows but is shitty and limited.
#from exoscrapers.modules import log_utils
import urllib
from exoscrapers.modules import client
from exoscrapers.modules import getSum
from exoscrapers.modules import cleantitle
from exoscrapers.modules import source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['mycima.me']
        self.base_link = 'https://mycima.me'
		
		

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            mtitle = cleantitle.get_url(title).replace('-','+').replace(':','').replace('&','+').replace("'",'+')
            mtitle = cleantitle.geturl(mtitle)
            url = self.base_link + '/search/%s+%s' % (mtitle , year)
            #log_utils.log('url = %s' % url, log_utils.LOGDEBUG)
            return url
        except:
            source_utils.scraper_error('mycima')
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url is None:
                return sources
            hostDict = hostDict + hostprDict
            
            r = getSum.get(url)
            results = getSum.findall(r, 'class="BoxItem".+?href="(.+?)"')
            for url in results:

				r = getSum.get(url, Type='client')
				
				html = getSum.findall(r, '<ul class="WatchServersList">(.*?)class="LeftFrontProfileSidebar">')#[0]
				for links in html:
					results = getSum.findall(links, 'href="(.+?)"')
					for link in results:
						if 'uppom' in link:
							#log_utils.log('uppom = %s' % link , log_utils.LOGDEBUG)
							valid, host = source_utils.is_host_valid(link, hostDict)
							quality, info = source_utils.get_release_quality(link, link)
							link += '|Referer=%s&User-Agent=%s' % (urllib.quote(client.agent()), link)
							sources.append({'source': host, 'quality': quality, 'info': info, 'language': 'ar', 'url': link,
											'direct': True, 'debridonly': False})
						elif 'mycima.me' in link:
							#log_utils.log('mycima = %s' % link , log_utils.LOGDEBUG)
							r = getSum.get(link)
							streams = getSum.findall(r, 'sources\:\s*\[(.+?)\]\,')[0]
							streams = getSum.findall(streams, 'format:\s*[\'"](.+?)[\'"].+?src:\s*[\'"](.+?)[\'"]')

							for label, link in streams:
								quality = source_utils.get_release_quality(label, label)[0]
								link += '|User-Agent=%s&Referer=%s' % (urllib.quote(client.agent()), link)
								sources.append({'source': 'mycima', 'quality': quality, 'info': '', 'language': 'ar', 'url': link,
												'direct': True, 'debridonly': False})
						else:
							link = link
							#log_utils.log('link = %s' % link , log_utils.LOGDEBUG)
							valid, host = source_utils.is_host_valid(link, hostDict)
							if valid:
								quality, info = source_utils.get_release_quality(link, link)
								sources.append({'source': host, 'quality': quality, 'language': 'ar', 'info': info,
									                'url': link, 'direct': False, 'debridonly': False})
						
						

            return sources
        except:
            source_utils.scraper_error('mycima')
            return sources

    def resolve(self, url):	
            return url