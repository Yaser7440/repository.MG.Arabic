# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 07-23-2019 by MGArabic in Scrubs.
# Has shows but is shitty and limited.
#from exoscrapers.modules import log_utils


import urllib
from exoscrapers.modules import client
from exoscrapers.modules import getSum
from exoscrapers.modules import cleantitle
from exoscrapers.modules import source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['faselhd.live']
        self.base_link = 'https://www.faselhd.live'
		
		

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            mtitle = cleantitle.get_url(title).replace('-','+').replace(':','').replace('&','+').replace("'",'+')
            mtitle = cleantitle.geturl(mtitle)
            url = self.base_link + '/?s=%s+%s' % (mtitle, year)
            #log_utils.log('url = %s' % url, log_utils.LOGDEBUG)
            return url
        except:
            source_utils.scraper_error('FASELHD')
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url is None:
                return sources
            hostDict = hostDict + hostprDict

            r = getSum.get(url)
            results = getSum.findEm(r, 'class="postDiv".+?href="(.+?)"')
            for url in results:
				r = getSum.get(url)
				results = getSum.findEm(r, 'player_iframe.+?=\s(?:\"|\')(.+?)(?:&img|\')')
				for link in results:
					link = "https:" + link if not link.startswith('http') else link
					link = link.replace('\r','').replace('\n','').replace('nv2=true&','').replace('uid=0&','').replace('%3A%2F%2F','://').replace('%2F','/').replace('&img','')
					link = link.replace('https://www.faselhd.live/player/embed.php?url=','').replace('www.', '')					
					
					
					


					if 'faselhd' in link:
						d = getSum.get(link)
						videos = getSum.findEm(d, '(?:file:)\s*(?:\"|\')(.+?)(?:\"|\')')
						for video in videos:
							valid, host = source_utils.is_host_valid(video, hostDict)
							video = video.replace('https','http')
							video += '|Referer=%s&User-Agent=%s' % (urllib.quote(client.agent()), link)
							#log_utils.log('faseldom = %s' % video, log_utils.LOGDEBUG)
							sources.append({'source': host, 'quality': '1080p', 'language': 'ar', 'info': '', 'url': video, 'direct': True, 'debridonly': False})
						
					else:
					
						valid, host = source_utils.is_host_valid(link, hostDict)
						if valid:
							if host in str(sources):
								continue
							sources.append({'source': host, 'quality': '1080p', 'language': 'ar', 'info': '', 'url': link, 'direct': False, 'debridonly': False})
								





            return sources
        except:
            source_utils.scraper_error('FASELHD')
            return sources

    def resolve(self, url):	
            return url