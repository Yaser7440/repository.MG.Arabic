# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 07-23-2019 by MGArabic in Scrubs.
# Has shows but is shitty and limited.
#from exoscrapers.modules import log_utils


#import urllib
#from exoscrapers.modules import client
from exoscrapers.modules import getSum
from exoscrapers.modules import cleantitle
from exoscrapers.modules import source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['akwam.net']
        self.base_link = 'https://akwam.net'
		
		

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            mtitle = cleantitle.get_url(title).replace('-','+').replace(':','').replace('&','+').replace("'",'+')
            mtitle = cleantitle.geturl(mtitle)
            url = self.base_link + '/search?q=%s' % mtitle
            #log_utils.log('url = %s' % url, log_utils.LOGDEBUG)
            return url
        except:
            source_utils.scraper_error('AKWAM')
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url is None:
                return sources
            hostDict = hostDict + hostprDict

            r = getSum.get(url)
            results = getSum.findEm(r, 'class="entry-image".+?href="(.+?)"')
            for url in results:
				r = getSum.get(url)
				results = getSum.findEm(r, 'class="col-lg-3 col".+?href="http://lefturl.com/(.+?)"')
				for link in results:
					link = url.replace('movie','%s') % link
					link = link.replace('link','watch')
					
					d = getSum.get(link, Type='cfscrape')
					videos = getSum.findEm(d, '(?:iframe|source).+?(?:src)=(?:\"|\')(.+?)(?:\"|\')')
					for video in videos:
						quality = source_utils.check_url(video)
						host = video.split('//')[1].replace('www.', '')
						host = host.split('/')[0].lower()
						#valid, host = source_utils.is_host_valid(video, hostDict)
						#quality = source_utils.check_url(video)
						video = video.replace('https','http')
						#log_utils.log('AKWAM = %s' % video, log_utils.LOGDEBUG)
						sources.append({'source': host, 'quality': quality, 'info': '', 'language': 'ar', 'url': video,
											'direct': True, 'debridonly': False})
						





            return sources
        except:
            source_utils.scraper_error('AKWAM')
            return sources

    def resolve(self, url):	
            return url