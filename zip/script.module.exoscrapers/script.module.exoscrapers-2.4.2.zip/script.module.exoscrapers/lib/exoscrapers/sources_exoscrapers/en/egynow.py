# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 07-23-2019 by MGArabic in Scrubs.
# Has shows but is shitty and limited.



#from exoscrapers.modules import log_utils

from exoscrapers.modules import cleantitle
from exoscrapers.modules import source_utils
from exoscrapers.modules import getSum

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['tv.egynow.co']
        self.base_link = 'https://tv.egynow.co'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            mtitle = cleantitle.get_url(title).replace('-','+').replace(':','').replace('&','+').replace("'",'+')
            mtitle = cleantitle.geturl(mtitle)
            url = self.base_link + '/?s=%s+%s' % (mtitle, year)
            #log_utils.log('url = %s' % url, log_utils.LOGDEBUG)
            return url
        except:
            source_utils.scraper_error('EGYNOW')
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url is None:
                return sources
            hostDict = hostDict + hostprDict
            
            r = getSum.get(url)
            results = getSum.findEm(r, 'class="BlockItem".+?href="(.+?)"')
            for url in results:
				links = getSum.get(url)
				#log_utils.log('links = %s' % links, log_utils.LOGDEBUG)
				videos = getSum.findSum(links)
				for video in videos:
					if any(x in video.lower() for x in ['gounlimited', 'youtube']):
						continue
					valid, host = source_utils.is_host_valid(video, hostDict)
					if valid:
						if host in str(sources):
							continue
						quality, info = source_utils.get_release_quality(video, video)
						sources.append({'source': host, 'quality': quality, 'language': 'ar', 'info': info, 'url': video, 'direct': False, 'debridonly': False})

            return sources
        except:
            source_utils.scraper_error('EGYNOW')
            return sources

    def resolve(self, url):	
            return url