#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
from yttools import *


def infolist():
  list1=[]
 
  list1.append(('Maroon5','Maroon5VEVO',1005))
  return list1

################################################################333
list1=infolist()
process_mode(list1 )
xbmcplugin.endOfDirectory(int(sys.argv[1]))

