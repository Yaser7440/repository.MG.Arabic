# -*- coding: utf-8 -*- 

#
#      Copyright (C) 2017 Mucky Duck (class sucuri Derived from Lambda's client module)
#
#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.

#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.

#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <http://www.gnu.org/licenses/>.


import base64,cfscrape,re,requests
from incapsula import crack
import sys
import base64,hashlib,os,random,re,shutil,string,urllib,urllib2
import xbmc,xbmcaddon,xbmcgui,xbmcplugin,xbmcvfs


User_Agent = 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2'
scraper = cfscrape.create_scraper()

addon_id=''

art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, art+'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, art+'fanart.jpg'))

class sucuri:

        def __init__(self):
                self.cookie = None


        def get(self, result):

                try:

                    s = re.compile("S\s*=\s*'([^']+)").findall(result)[0]
                    s = base64.b64decode(s)
                    s = s.replace(' ', '')
                    s = re.sub('String\.fromCharCode\(([^)]+)\)', r'chr(\1)', s)
                    s = re.sub('\.slice\((\d+),(\d+)\)', r'[\1:\2]', s)
                    s = re.sub('\.charAt\(([^)]+)\)', r'[\1]', s)
                    s = re.sub('\.substr\((\d+),(\d+)\)', r'[\1:\1+\2]', s)
                    s = re.sub(';location.reload\(\);', '', s)
                    s = re.sub(r'\n', '', s)
                    s = re.sub(r'document\.cookie', 'cookie', s)
                    
                    cookie = '' ; exec(s)
                    self.cookie = re.compile('([^=]+)=(.*)').findall(cookie)[0]
                    self.cookie = '%s=%s' % (self.cookie[0], self.cookie[1])

                    return self.cookie

                except:
                        pass
s = requests.session()

def uncensored(a,b):
    addon.log(len(a))
    addon.log(len(b))
    n = -1
    fuckme=[]
    justshow=[]
    while True:
        
        if n == len(a)-1:
            break
        n +=1
       
        addon.log(n)
        d = int(''.join(str(ord(c)) for c in a[n]))
      
        e=int(''.join(str(ord(c)) for c in b[n]))
        justshow.append(d+e)
        fuckme.append(chr(d+e))
    #print justshow    
    return base64.b64encode(''.join(fuckme))
	
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param
	
def resolve_host(url):#last good-used with local resolver
       
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
      
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    
        else:
            addDir("Error,"+stream_link,"",9,"")
def resolve_host2(url):#last good-used with local resolver
        from urlresolver import resolve
        data=readnet2(url)
        #addon.log('#######################link = '+str(data))
        reurl='''<iframe.*?src="(.*?)".*?></iframe>'''
        url=re.findall(reurl,data, re.M|re.I)[0].split("=")[0]
        stream_link=str(resolve(url))#.replace("\/\/","//").replace("\/","/")
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    listItem = xbmcgui.ListItem(path=str(stream_link))
	    xbmcplugin.setResolvedUrl(sys.argv[0], True, listItem)   
        else:
            addDir("Error,"+stream_link,"",9,"")
def RESOLVE(name,url):
  	       
        if 'thevideos' in url:
                url = thevideos(url)
        if 'ok' in url:
                url = resolve_host(url)
        if 'estream' in url:
                url = resolve_host(url)				
        if 'vidbom' in url:
                url = playlink(url)				
        if 'videowood' in url:
                url = resolve_host(url)
        if 'uptostream' in url:
                url = resolve_host(url)				
        if 'vidlocker' in url:
                url = vidlocker(url)				
        if 'watchers' in url:
                url = resolve_host(url)
        if 'openload' in url:
                url = resolve_host(url)
        if 'videorev' in url:
                url = resolve_host(url)
        if 'hqq.tv' in url:
                url = resolve_host(url)	
        if 'drive.google.com' in url:
                url = resolve_host(url)					
        if 'google' in url:
                url = resolve_host(url)
        if 'youtube' in url:
                url = resolve_host(url)
        if 'raptu' in url:
                url = resolve_host(url)
        if 'downace' in url:
                url = resolve_host(url)
        if 'googlevideo' in url:
                url = resolve_host(url)
        elif 'userscloud' in url:
                url = resolve_host(url)				
        elif 'player' in url:
                url = resolve_host(url)				
        else:
                url = urlresolver.resolve(url)
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={'Title':description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(str(url))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
def vidlocker(url):
        headers = {}
        headers['User-Agent'] = User_Agent
        link = requests.get(url, headers=headers, allow_redirects=False)
        try:
            link = re.findall(r'sources: \[\{file:"(.*?)"', str(link.text), re.I|re.DOTALL)[-1]
        except:
            link = re.findall(r'sources: \[\Boot{file:"(.*?)"', str(link.text), re.I|re.DOTALL)[0]
        return link
		
		
def LINKS2(url,description):
        split_head = re.split(r"\+", str(description), re.I)
        referer = split_head[0]
        coookie = split_head[1]
        headers = {'Referer': referer, 'Cookie': coookie, 'user-agent':User_Agent,'x-requested-with':'XMLHttpRequest'}
        link = requests.get(url, headers=headers, allow_redirects=False).text
        url = re.compile('"file":"(.*?)"').findall(link)[0]
        url = url.replace('&amp;','&').replace('\/','/')
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={"Title": name})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz) 
def thevideos(url):
        link = requests.get(url).text
        #script = re.findall("<script type='text/javascript'>(.*?)</script>", str(link), re.I|re.DOTALL)[0]
        #unpack = packer.unpack(script)
        try:
                url = re.findall('file:"(.*?)",label:".*?0p"', str(link), re.I|re.DOTALL)[-1]
        except:
                url = re.findall('file:"(.*?)",label:".*?0p"', str(link), re.I|re.DOTALL)[0]
        return url
		
def playlink(url):
           
            xbmc.Player().play(url)
            sys.exit(0)
def random_generator(size=16, chars=string.ascii_letters + string.digits):
    return ''.join(random.choice(chars) for x in range(size))
def addLink(name,url,mode,iconimage,fanart,description=''):
	#u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
	#ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
	liz.setProperty("Fanart_Image", fanart)
	contextMenuItems = []
	if not meta['trailer']=='':contextMenuItems.append(('Trailer', 'XBMC.RunPlugin(%s)' % addon.build_plugin_url({'mode': 60, 'url':meta['trailer']})))
	contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
	liz.addContextMenuItems(contextMenuItems, replaceItems=True)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
	return ok
def addDir4(name,url,mode,iconimage,fanart,description,genre,date,credits):        
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)
        ok=True
        if date == '':
            date = None
        else:
            description += '\n\nDate: %s' %date
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "Genre": genre, "dateadded": date, "credits": credits })
        liz.setProperty("Fanart_Image", fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name })
        liz.setProperty('fanart_image', fanart)        
        liz.setProperty("IsPlayable","true")	
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir2(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==3 or mode==7 or mode==40:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
def TRAILER(url):
        xbmc.executebuiltin("PlayMedia(%s)"%url)









def decodeHtml(text):
    text = text.replace('مباشر عرب اتش', '').replace('..', '').replace('مباشرة', '').replace('عرب', '').replace('مشاهدة و تحميل فيلم', '').replace('مسلسل',"").replace('انمي',"").replace('برنامج',"")
    text = text.replace('مترجم اون لاين', '').replace('اون لاين', '').replace('دي', '').replace('مترجم', '').replace('مترجم', '').replace('مشاهدة ', '')
    text = text.replace('مشاهدة مباشرة فيلم', '').replace('فيلم ', '').replace('تحميل', '').replace('  ', '').replace('&#8217;', '').replace('اتش', '').replace('غير', '')
    text = text.replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','').replace("&amp;","&").replace('&#39;',"'").replace('&quot;','"').replace('مشاهدة مباشرة مسلسل',"")
    text = text.replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('اون لاين','').replace('&#8217;',"").replace('&#8211;',"")
    return text

def OPEN_URL1(url):
	headers = {}
	headers['User-Agent'] = User_Agent
	link = s.get(url, headers=headers).text
	link = link.encode('ascii', 'ignore').decode('ascii')
	return link
	
def OPEN_URL(url):
	headers = {}
	headers['User-Agent'] = User_Agent
	link = s.get(url, headers=headers).text
	link = link.encode('utf-8')
	return link
	
def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        hostname=query.hostname.replace("www.","")
        return hostname

def regex_from_to(text, from_string, to_string, excluding=True):
	if excluding:
		try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
		except: r = ''
	else:
		try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
		except: r = ''
	return r


def regex_get_all(text, start_with, end_with):
	r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
	return r
	
def readnet(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
			
def readnet2(url):
        import requests
        data=requests.get(url, verify=False)
        return data.content

		
		
def open_url(url, method='get', headers=None, cookies=None, params=None, data=None, redirects=True, verify=True, timeout=None):

        if headers == None:

                headers = {}
                headers['User-Agent'] = User_Agent

        link = getattr(scraper,method)(url, headers=headers, cookies=cookies, params=params, data=data, allow_redirects=redirects, verify=verify, timeout=timeout)

        try:
                su = sucuri().get(link.content)
                if su:
                        headers['Cookie'] = su

                        if not url[-1] == '/':
                                url = '%s/' %url

                        link = getattr(scraper,method)(url, headers=headers, cookies=cookies, params=params, data=data, allow_redirects=redirects, timeout=timeout)
        except:
                pass

        if '_Incapsula_' in link.content:

                link = crack(scraper, link)

        return link
