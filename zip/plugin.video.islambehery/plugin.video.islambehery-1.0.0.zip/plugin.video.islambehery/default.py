#!/usr/bin/python
# -*- coding: utf-8 -*-
try:import sys, syspath
except:pass
from yttools import *


def infolist():
  list1=[]
 
  list1.append(('اسلام بحيري','IslamBehery',1005)) 
  list1.append(('القاهره والناس','UCzWdc0aUo0IDk5ysLrt04hw'))
  return list1

################################################################333
list1=infolist()
process_mode(list1 )
xbmcplugin.endOfDirectory(int(sys.argv[1]))

