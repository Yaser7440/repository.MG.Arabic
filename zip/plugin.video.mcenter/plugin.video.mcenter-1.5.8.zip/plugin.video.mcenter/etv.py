import CommonFunctions as common
import requests
import pickle
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys, base64
import os.path
import socket
import struct
import time
from constant_strings import *

WINDOW = xbmcgui.Window(10000)
if WINDOW.getProperty("etv.resume"):
    resumeList = eval(WINDOW.getProperty("etv.resume"))
else:
    resumeList = {}

class FileDownloader:
    
    lastbyte = 0
    
    def __init__(self, movie, lastbyte=0):
        self.movie = movie
        xbmcgui.Dialog().notification(self.movie.title, 'Download started.')
        self.background = xbmcaddon.Addon().getSetting('download_in_background') == 'true'
        self.folder = xbmcaddon.Addon().getSetting('download_location')
        if not os.path.isdir(self.folder):
            os.makedirs(self.folder)
        self.rate = int(xbmcaddon.Addon().getSetting('download_chunk'))
        self.notify = xbmcaddon.Addon().getSetting('hide_download_notifications') == 'false'
        ext = '.' + movie.video.split('.')[-1]
        self.location = self.folder + movie.title.replace(' ', '') + ext
        self.lastbyte = lastbyte
        self.start_download(self.location)
            
    def start_download(self, download_location):
        
        if self.lastbyte == 0:
            r = requests.get(self.movie.video, stream=True,  verify=False, allow_redirects=True)
            if 'content-length' in r.headers:
                self.movie.total_size = int(r.headers['content-length'])
            else:
                self.movie.total_size = 900000000
        else:
            r = self.resume_download(self.movie.video, self.lastbyte)
    
        if r.status_code == 200:
            CHUNK_SIZE = 8192
            bytes_read = self.lastbyte
            last_notification = 0
            
            #download subtitles
            
            
            ext = '.' + self.movie.subtitle.split('.')[-1]
            
            print "copy subs ?"
            print self.movie.subtitle
            print self.folder + self.movie.title.replace(' ', '') + ext
            
            xbmcvfs.copy(self.movie.subtitle, self.folder + self.movie.title.replace(' ', '') + ext)
            
            #download movie in chunks
            with open(download_location, 'wb') as f:
                itrcount=1
                for chunk in r.iter_content(CHUNK_SIZE):
                    itrcount=itrcount+1
                    f.write(chunk)
                    bytes_read += len(chunk)
                    if self.notify and ((100*bytes_read/self.movie.total_size) > (self.rate + last_notification)):
                        xbmcgui.Dialog().notification(self.movie.title, str(100*bytes_read/self.movie.total_size)+'% downloaded.')
                        last_notification = 100*bytes_read/self.movie.total_size
                    if (itrcount % 10000) == 0:
                        self.lastbyte = bytes_read
                        if xbmcvfs.exists(download_options):
                            options = pickle.load(open(download_options, 'rb'))
                        else: options = {}
                        options['ongoing'] = (self.movie, self.lastbyte)
                        pickle.dump(options, open(download_options, 'wb'), -1)
        elif r.status_code == 206:
            CHUNK_SIZE = 8192
            bytes_read = self.lastbyte
            last_notification = 0
            with open(download_location, 'ab') as f:
                itrcount=1
                for chunk in r.iter_content(CHUNK_SIZE):
                    itrcount=itrcount+1
                    f.write(chunk)
                    bytes_read += len(chunk)
                    if self.notify and ((100*bytes_read/self.movie.total_size) > (self.rate + last_notification)):
                        xbmcgui.Dialog().notification(self.movie.title, str(100*bytes_read/self.movie.total_size)+'% downloaded.')
                        last_notification = 100*bytes_read/self.movie.total_size
                    if (itrcount % 10000) == 0:
                        self.lastbyte = bytes_read
                        if xbmcvfs.exists(download_options):
                            options = pickle.load(open(download_options, 'rb'))
                        else: options = {}
                        options['ongoing'] = (self.movie, self.lastbyte)
                        pickle.dump(options, open(download_options, 'wb'), -1)
        r.close()
        if xbmcvfs.exists(download_options):
            options = pickle.load(open(download_options, 'rb'))
        else: options = {}
        del options['ongoing']
        
        self.movie.video = download_location
        if 'downloaded' not in options:
            options['downloaded'] = [self.movie]
        else:
            options['downloaded'].append(self.movie)
        pickle.dump(options, open(download_options, 'wb'), -1)
        xbmcgui.Dialog().notification(self.movie.title, 'Download complete.')
        
    def resume_download(self, fileurl, resume_byte_pos):
        resume_header = {'Range': 'bytes=%d-' % resume_byte_pos}
        return requests.get(fileurl, headers=resume_header, stream=True,  verify=False, allow_redirects=True)

class Movie:
    pass

def logMsg(msg, level = 1):
    doDebugLog = True
    if doDebugLog == True or level == 0:
        xbmc.log("ETV MediaCenter --> " + msg)
        
def get_api_link(function):
    return base_api_link+function

def first_login():
    input_user_id = xbmcgui.Dialog().input(ADDON.getLocalizedString(30123))
    input_password = xbmcgui.Dialog().input(ADDON.getLocalizedString(30124), '', option = xbmcgui.ALPHANUM_HIDE_INPUT)
    xbmcaddon.Addon().setSetting('user_id',input_user_id)
    xbmcaddon.Addon().setSetting('user_password',input_password)
    return input_user_id,input_password
    
def login_db(service=False):
    user_id = xbmcaddon.Addon().getSetting('user_id')
    password = xbmcaddon.Addon().getSetting('user_password')
    device_id = get_device_id()
    
    if not user_id or not password:
        if service:
            return False
        else:
            user_id,password = first_login()
        
    payload = {'user_id':user_id, 'user_password':password, 'wifi_mac':device_id}
    r = requests.post(get_api_link('logInUser'), data=payload)
    status = r.json()['code']

    if status == 0:
        #login successfull
        WINDOW.setProperty('etv-apikey',r.json()['apiKey'])
        #set user as online in API
        requests.post(get_api_link('setOnlineStatus'), data={'user_id':user_id, 'is_online':'1'})
        return True
    else:
        #login failed - show error based on error code
        print "login status --> " + str(status)
        if status == 1: msg = ADDON.getLocalizedString(30119) #incorrect username
        elif status == 2: msg = ADDON.getLocalizedString(30120) #incorrect password
        elif status == 3: msg = ADDON.getLocalizedString(30121) #not authorized
        elif status == 4: msg = ADDON.getLocalizedString(30122) #expired account
        else: msg = ADDON.getLocalizedString(30118)
        #show error dialog and delete credentials in config
        xbmcgui.Dialog().ok(ADDON.getLocalizedString(30118),msg)
        xbmcaddon.Addon().setSetting('user_id','')
        xbmcaddon.Addon().setSetting('user_password','')
        xbmcaddon.Addon().setSetting('device_id','')
        WINDOW.clearProperty('etv-apikey')
        return False
        
def getApiKey():
    apikey = WINDOW.getProperty('etv-apikey')
    if not apikey:
        login_db()
        apikey = WINDOW.getProperty('etv-apikey')
    return apikey

def get_sections(apikey=None):
    '''returns a list of section name strings'''
    if not apikey: apikey = getApiKey()
    sections = section_list
    if apikey: return sections
    else: return None

def get_movies(section_index, apikey=None):
    '''returns a list of Movie objects'''
    
    movie_list = []
    
    if int(section_index) == -1: #favorites
        movie_list = get_favorites()
        view_id = xbmcaddon.Addon().getSetting('viewmode_favorites')
        
    elif int(section_index) == -2: #downloaded
        movie_list = get_downloaded()
        view_id = xbmcaddon.Addon().getSetting('viewmode_downloaded')
    else:
        
        if WINDOW.getProperty("etv.section." + str(section_index)):
            #get movie list from cache
            logMsg("get Movielist from cache")
            cache = eval(WINDOW.getProperty("etv.section." + str(section_index)))
            for movie in cache:
                movie_list.append(populate_movie(movie))
            view_id = None
        else:
            #get movie list from api
            logMsg("get Movielist from API")
            cacheList=[]
            if not apikey: apikey = getApiKey()
            payload = {'movie_type':int(section_index), 'apiKey':apikey}
            r = requests.post(get_api_link('getVideoList'), data=payload)
            if 'movie_list' not in r.json():
                if os.path.exists(apikey_path):
                    os.remove(apikey_path)
                payload = {'movie_type':int(section_index), 'apiKey':apikey}
                r = requests.post(get_api_link('getVideoList'), data=payload)
            for movie in r.json()['movie_list']:
                    movie_list.append(populate_movie(movie, apikey))
                    WINDOW.setProperty("etv." + str(movie["idx"]), repr(movie))
                    cacheList.append(movie)
            view_id = None
            WINDOW.setProperty("etv.section." + str(section_index), repr(cacheList))

    return (movie_list,view_id)

def get_favorites():
    '''returns a list of Movie objects'''
    
    movie_list = []
    if os.path.isfile(favorites_path):
        movie_list = pickle.load(open(favorites_path, 'rb'))
    return movie_list

def get_downloaded():
    '''returns a list of Movie objects'''
    movie_list = []
    if os.path.isfile(download_options):
        movie_list = pickle.load(open(download_options, 'rb'))['downloaded']
    return movie_list
    
def populate_movie(info, apikey=None):
    '''given a movie info dict, returns a populated Movie object'''
    movie = Movie()
    movie.video = info.get('video_link','')
    if movie.video and ("youtube.com" in movie.video or "youtu.be" in movie.video): movie.video = get_youtube_playurl(movie.video)
    movie.video1080 = info.get('video_link_1080','')
    if movie.video1080 and ("youtube.com" in movie.video1080 or "youtu.be" in movie.video1080): movie.video1080 = get_youtube_playurl(movie.video1080)
    movie.subtitle = info.get('subtitle_link','')
    movie.subtitle1080 = info.get('subtitle_link_1080','')
    movie.trailer = info.get('trailer_link','')
    if movie.trailer and ("youtube.com" in movie.trailer or "youtu.be" in movie.trailer): movie.trailer = get_youtube_playurl(movie.trailer)
    movie.title = info.get('video_name','')
    movie.genre = info.get('video_type','')
    movie.smallart = info.get('small_poster_link','')
    movie.bigart = info.get('big_poster_link','')
    movie.plot = info.get('short_story','')
    movie.rating = info.get('rating','')
    movie.height = info.get('resolution','')
    movie.premiered = info.get('year','')
    movie.duration = info.get('runtime','')
    movie.dateadded = info.get('reg_date','')
    movie.section = info.get('movie_type','')
    movie.id = info['idx']

    return movie
        
def list_folders(addon_handle, sections):
    set_online_status('1')
    base_url = 'plugin://plugin.video.mcenter/'
    default_icon = xbmcaddon.Addon().getAddonInfo('path')+'/resources/media/folders.png'
    for i, section in enumerate(sections):
        li = xbmcgui.ListItem(section, iconImage=default_icon)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=base_url+'?screen=2&section=%d'%i, listitem=li, isFolder=True)
    li = xbmcgui.ListItem(ADDON.getLocalizedString(30050), iconImage=default_icon)#favorites
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=base_url+'?screen=3&section=-1', listitem=li, isFolder=True)
    li = xbmcgui.ListItem(ADDON.getLocalizedString(30051), iconImage=default_icon)#downloaded
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=base_url+'?screen=3&section=-2', listitem=li, isFolder=True)
    li = xbmcgui.ListItem(xbmc.getLocalizedString(10004), iconImage=default_icon)#settings
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=base_url+'?screen=5', listitem=li, isFolder=True)
    view_id = xbmcaddon.Addon().getSetting('viewmode_sections')
    xbmc.executebuiltin('Container.SetViewMode('+view_id+')')
    xbmcplugin.endOfDirectory(addon_handle, updateListing=True)
           
def sort_menu(addon_handle, section_index, sort_criteria):
    base_url = 'plugin://plugin.video.mcenter/?section=%s'%section_index
    default_icon = xbmcaddon.Addon().getAddonInfo('path')+'/resources/media/folders.png'
    allowed = True
    if os.path.isfile(credentials_path):
        credentials = pickle.load(open(credentials_path, 'rb'))
    else:
        credentials = []
    
    if str(section_index) in credentials:
        attempt = xbmcgui.Dialog().input('Password protected section', option = xbmcgui.ALPHANUM_HIDE_INPUT)
        allowed = (attempt == credentials[str(section_index)])
    if allowed:
        
        for i, criterion in enumerate(sort_criteria):
            li = xbmcgui.ListItem(criterion[0], iconImage=default_icon)
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=base_url+'&screen=3&sort_by=%s'%i, listitem=li, isFolder=True)
        
        #genres
        li = xbmcgui.ListItem(xbmc.getLocalizedString(135), iconImage=default_icon)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=base_url+'&screen=4', listitem=li, isFolder=True)    
        
        #search
        li = xbmcgui.ListItem(xbmc.getLocalizedString(137), iconImage=default_icon)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=base_url+'&screen=8', listitem=li, isFolder=True)
        
        li = xbmcgui.ListItem(section_list[section_index], iconImage=default_icon)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=base_url+'&screen=3&sort_by=0', listitem=li, isFolder=True)
        
        view_id = xbmcaddon.Addon().getSetting('viewmode_subsections')
        xbmc.executebuiltin('Container.SetViewMode('+view_id+')')
        xbmcplugin.endOfDirectory(addon_handle, updateListing=True)
    else:
        xbmcgui.Dialog().ok('Password protected section', 'Sorry, wrong password.')
    
def sort_movies(movie_list, criterion):
    if criterion != 'dateadded':#the server returns movies sorted by date added
        movie_list.sort(key=lambda movie:movie.__dict__[criterion])

    if criterion == 'rating' or criterion == 'premiered':
        movie_list.reverse()
    return movie_list
    
def list_movies(addon_handle, movie_list, view_id='500'):
    base_url='plugin://plugin.video.mcenter/?screen=9'
    movie_dict = {}
    for movie in movie_list:
        movie_dict[int(movie.id)] = movie 
        li = xbmcgui.ListItem(movie.title, iconImage=movie.smallart)
        li.setArt({'fanart':movie.bigart, 'thumb':movie.smallart, 'poster':movie.smallart})
        try: #prevent some bad data from crashing the script
            li.setInfo('video', {'rating':movie.rating, 'year':int(movie.premiered[:4]), 'dateadded':movie.dateadded, \
                        'genre':movie.genre, 'duration':movie.duration, 'plot':movie.plot, 'title':movie.title, \
                        'sorttitle':movie.title, 'originaltitle':movie.title})
        except ValueError:
            li.setInfo('video', {'rating':movie.rating, 'dateadded':movie.dateadded, \
                        'genre':movie.genre, 'duration':movie.duration, 'plot':movie.plot, 'title':movie.title})
        li.setProperty('IsPlayable', 'true')
        url = base_url + '&section=%s&movie_id=%s'%(movie.section, movie.id)
        li.addContextMenuItems([('Play actions', 'RunPlugin(%s)' %url)])
        li.addStreamInfo("video", {'duration': movie.duration})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    xbmc.executebuiltin('Container.SetViewMode('+view_id+')')
    xbmcplugin.endOfDirectory(addon_handle, updateListing=True)
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_VIDEO_TITLE)
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_VIDEO_RUNTIME)
        
def genres_menu(addon_handle, section_index, genre_list):
    base_url = 'plugin://plugin.video.mcenter/?screen=3&sort_by=0&section=%s'%section_index
    default_icon = xbmcaddon.Addon().getAddonInfo('path')+'/resources/media/folders.png'
    for i, genre in enumerate(genre_list):
        li = xbmcgui.ListItem(genre[0]+'        '+genre[1], iconImage=default_icon)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=base_url+'&genre=%s'%i, listitem=li, isFolder=True)
    view_id = xbmcaddon.Addon().getSetting('viewmode_genres')
    xbmc.executebuiltin('Container.SetViewMode('+view_id+')')
    xbmcplugin.endOfDirectory(addon_handle, updateListing=True)
    
def search(section_index, genre=None, query=None):
    '''returns a list of movie objects sorted by release date'''
    results = []
    if genre:
        movies = get_movies(section_index)[0]
        for movie in movies:
            if genre[1].decode('utf8') in movie.genre:
                results.append(movie)
    elif query:
        movies = get_movies(section_index)[0]
        for movie in movies:
            searchable = [movie.title]
            for field in searchable:
                if query.lower() in field.encode('utf8').lower():
                    results.append(movie)
    return sort_movies(results, 'premiered')

def list_play_options(addon_handle, section_index, movie_id):
    
    xbmc.executebuiltin( "ActivateWindow(busydialog)" )
    
    if WINDOW.getProperty("etv.resume"):
        resumestatus = eval(WINDOW.getProperty("etv.resume"))
    else: resumestatus = {}
    
    original_listitem_url = xbmc.getInfoLabel("ListItem.FileNameAndPath")
    movie = eval(WINDOW.getProperty("etv." + str(movie_id)))
    movie = populate_movie(movie)
    resume = xbmc.getCondVisibility("ListItem.IsResumable")
    favorited = False
    favorites = get_favorites()
    for item in favorites:
        if item.id == movie.id:
            favorited = True
            duplicate = item
    
    dialog = xbmcgui.Dialog()
    play_choices = []
    choice = -1
    
    play_choices.append(ADDON.getLocalizedString(30125)) # play video
    
    if movie.video1080:
        play_choices.append(ADDON.getLocalizedString(30101)) #show 1080p play link if 1080 video
    else:
        play_choices.append("[COLOR=CCCCCCFF]" + ADDON.getLocalizedString(30102)+"[/COLOR]") #no 1080p present
    
    play_choices.append(ADDON.getLocalizedString(30103)) #trailer
    play_choices.append(ADDON.getLocalizedString(30104)) #download
    #show add/remove favorite button
    if favorited: play_choices.append(ADDON.getLocalizedString(30106))
    else: play_choices.append(ADDON.getLocalizedString(30105))

    if not resume:
        #show dialog with play choices
        xbmc.executebuiltin( "Dialog.Close(busydialog)" )
        choice = dialog.select('', play_choices)
    
        #1080p chosen but no 1080 available, show dialog again
        if play_choices[choice] == "[COLOR=CCCCCCFF]" + ADDON.getLocalizedString(30102)+"[/COLOR]":
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            list_play_options(addon_handle, section_index, movie_id)
        
        #remove from favourites
        if play_choices[choice] == ADDON.getLocalizedString(30106):
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            favorites.remove(duplicate)
            pickle.dump(favorites,open(favorites_path, 'wb'), -1)
        
        #add to favourites
        if play_choices[choice] == ADDON.getLocalizedString(30105):
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            favorites.append(movie)
            pickle.dump(favorites,open(favorites_path, 'wb'), -1)
        
        #play trailer
        if play_choices[choice] == ADDON.getLocalizedString(30103):
            li = xbmcgui.ListItem(movie.title, iconImage=movie.smallart)
            li.setPath (movie.trailer)
            li.setArt({'fanart':movie.bigart, 'thumb':movie.smallart, 'poster':movie.smallart, 'banner':movie.smallart,\
                    'clearart':movie.smallart, 'clearlogo':movie.smallart})
            li.setInfo('video', {'rating':movie.rating, 'premiered':movie.premiered, 'dateadded':movie.dateadded, \
                            'genre':movie.genre, 'duration':movie.duration, 'plot':movie.plot, 'title': "Trailer"})
            li.setProperty('IsPlayable', 'true')
            li.setProperty('file', movie.trailer)
            li.setProperty("original_listitem_url",movie.trailer)            
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
            
        #download movie
        if play_choices[choice] == ADDON.getLocalizedString(30104):
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            download_movie(movie)
            
    #play 1080 video if selected or if 1080 video in resume
    if (play_choices and play_choices[choice] == ADDON.getLocalizedString(30101)) or (resume and movie.video1080 and resumeList.get(movie.id,"") == movie.video1080):
        movie.video = movie.video1080
        if movie.subtitle1080: movie.subtitle = movie.subtitle1080

    #play movie
    if (play_choices and play_choices[choice] in [ADDON.getLocalizedString(30125),ADDON.getLocalizedString(30101)]) or resume:
        
        #create listitem
        li = xbmcgui.ListItem(movie.title, iconImage=movie.smallart)
        li.setPath (movie.video)
        li.setArt({'fanart':movie.bigart, 'thumb':movie.smallart, 'poster':movie.smallart, 'banner':movie.smallart,\
                'clearart':movie.smallart, 'clearlogo':movie.smallart})
        li.setInfo('video', {'rating':movie.rating, 'premiered':movie.premiered, 'dateadded':movie.dateadded, \
                        'genre':movie.genre, 'duration':movie.duration, 'plot':movie.plot})
        li.setProperty('IsPlayable', 'true')
        li.setProperty('file', movie.video)
        li.setProperty("original_listitem_url",original_listitem_url)

        WINDOW.setProperty(movie.video + '-etvplay', str(movie.id))
        WINDOW.setProperty(movie.video + '-etvsubtitles', movie.subtitle)
        Playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        Playlist.clear()
        
        #play movie...
        if resume:
            xbmc.executebuiltin( "Dialog.Close(busydialog)" )
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
        else:
            resumestatus[movie.id] = movie.video
            intro = ''
            section = int(section_index)
            if section <= 2:
                intro = intro_path + 'general_intro.mp4'
                for index,genre in enumerate(genre_list[5:]):
                    if genre[1].decode('utf8') in movie.genre:
                        intro = intro_path + intros_list[index]
            elif section <= 4:
                intro = intro_path + 'cartoon.mp4'
            elif section == 5:
                intro = intro_path + 'red_carpet.mp4'
            elif section == 6:
                intro = intro_path + 'docum.mp4'
            elif section <= 9:
                intro = intro_path + 'general_intro.mp4'
            elif section == 10:
                intro = intro_path + 'red_carpet.mp4'
            if not xbmcvfs.exists(intro):
                intro = intro_path + 'general_intro.mp4'
            li_intro = xbmcgui.ListItem("ETV Intro", iconImage=os.path.join(ADDON_PATH,'icon.png'))
            li_intro.setArt({'fanart':os.path.join(ADDON_PATH,'fanart.jpg'), 'thumb':os.path.join(ADDON_PATH,'icon.png')})
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            Playlist.add(intro,li_intro)
            Playlist.add(movie.video, li)
            xbmc.Player().play(Playlist)
  
def download_movie(movie):
    if os.path.isfile(download_options):
        options = pickle.load(open(download_options, 'rb'))
    else:
        options = {'never_downloaded':True}
    
    if not xbmcaddon.Addon().getSetting('last_download') or not xbmcvfs.exists(xbmcaddon.Addon().getSetting('download_location')):
        #there has not been any download before
        if xbmcgui.Dialog().yesno(ADDON.getLocalizedString(30104), line1=ADDON.getLocalizedString(30107)):
            xbmcaddon.Addon().openSettings()
        
    if not get_downloadlimit() >= 3:
        num_downloads = get_downloadlimit() + 1
        datetoday = xbmc.getInfoLabel("System.Date(ddmmyyyy)")
        xbmcaddon.Addon().setSetting('last_download','%s-%s' %(datetoday,num_downloads))
        if movie.video1080:
            #prefer 1080p video for download
            movie.video = movie.video1080
            if movie.subtitle1080: movie.subtitle = movie.subtitle1080
        #initiating it in an assignment prevents kodi from locking up during the download
        download = FileDownloader(movie, 0)
            
    else:
        #download limit reached
        xbmcgui.Dialog().ok(ADDON.getLocalizedString(30108),ADDON.getLocalizedString(30109))

def get_downloadlimit():
    datetoday = xbmc.getInfoLabel("System.Date(ddmmyyyy)")
    last_download = xbmcaddon.Addon().getSetting('last_download')
    if datetoday in last_download:
        num_downloads = int(last_download.split("-")[1])
    else: num_downloads = 0
    return num_downloads
        
def change_section_password(section_index):
    
    input_user_id = xbmcgui.Dialog().input(ADDON.getLocalizedString(30123))
    input_password = xbmcgui.Dialog().input(ADDON.getLocalizedString(30124), '', option = xbmcgui.ALPHANUM_HIDE_INPUT)
    user_id = xbmcaddon.Addon().getSetting('user_id')
    user_password = xbmcaddon.Addon().getSetting('user_password')
    section_password = xbmcaddon.Addon().getSetting('section_password_%s'%(section_index))
    
    if input_user_id == user_id and input_password == user_password:
        #only continue if correct ETV credentials are entered
        if not section_password:
            section_password = xbmcgui.Dialog().input(ADDON.getLocalizedString(30113), option = xbmcgui.ALPHANUM_HIDE_INPUT)
            if input_user_id == user_id and input_password == user_password:
                xbmcaddon.Addon().setSetting('section_password_%s'%(section_index), section_password)
                if section_password:
                    xbmcgui.Dialog().ok(ADDON.getLocalizedString(30114), ADDON.getLocalizedString(30115))
        else:
            if (input_user_id == credentials['login'][0]) and (input_password == credentials['login'][1]):
                xbmcaddon.Addon().setSetting('section_password_%s'%(section_index), '')
                xbmcgui.Dialog().ok(ADDON.getLocalizedString(30114), ADDON.getLocalizedString(30114))
    else:
        xbmcgui.Dialog().ok(ADDON.getLocalizedString(30116), ADDON.getLocalizedString(30117))
            
def backup_favorites():
    if not os.path.isdir(backup_path):
        os.makedirs(backup_path) 
    if xbmcvfs.exists(favorites_path):
        favorites = pickle.load(open(favorites_path, 'rb'))
        pickle.dump(favorites, open(backup_path+'favorites.pkl', 'wb'), -1)
    if xbmcvfs.exists(download_options):
        options = pickle.load(open(download_options, 'rb'))
        pickle.dump(options, open(backup_path+'download_options.pkl', 'wb'), -1)
    xbmcgui.Dialog().ok('Success', 'Favorites backed up to '+backup_path)
    
def restore_favorites():
    if xbmcvfs.exists(backup_path+'favorites.pkl'):
        favorites = pickle.load(open(backup_path+'favorites.pkl', 'rb'))
        pickle.dump(favorites, open(favorites_path, 'wb'), -1)
    if xbmcvfs.exists(backup_path+'download_options.pkl'):
        options = pickle.load(open(backup_path+'download_options.pkl', 'rb'))
        pickle.dump(options, open(download_options, 'wb'), -1)
    xbmcgui.Dialog().ok('Success', 'Favorites restored from '+backup_path)

def get_youtube_playurl(youtube_url):
    youtube_id = youtube_url.split('/')[3]
    url = 'plugin://plugin.video.youtube/play/?video_id=%s' % youtube_id
    return url
    
def get_device_mac():
    device_mac = ''
    device_mac = xbmc.getInfoLabel('Network.MacAddress')
    while (device_mac == xbmc.getLocalizedString(503)) or (device_mac.decode('utf8') == u'\u0645\u0634\u063a\u0648\u0644'):
        device_mac = xbmc.getInfoLabel('Network.MacAddress')
        xbmc.sleep(250)
    logMsg('Getting MAC address successful: '+ device_mac,0)
    return device_mac

def get_device_id():
    device_id = xbmcaddon.Addon().getSetting('device_id')
    if device_id:
        return base64.b64decode(device_id)
    else:
        device_id = get_device_mac()
        xbmcaddon.Addon().setSetting('device_id', base64.b64encode(device_id))
        return device_id  
    
def set_online_status(status):
    payload = {'user_id':xbmcaddon.Addon().getSetting('user_id'),'is_online':status, 'apiKey':xbmcaddon.Addon().getSetting('apikey')}
    r = requests.post(get_api_link('setOnlineStatus'), data=payload)
       
