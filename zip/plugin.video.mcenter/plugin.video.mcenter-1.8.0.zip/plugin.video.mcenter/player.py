# -*- coding: utf-8 -*-

import re
import sys
import time
import xbmc, xbmcgui, xbmcaddon
WINDOW = xbmcgui.Window( 10000 )

class player(xbmc.Player):
        
    def __init__ (self):
        xbmc.Player.__init__(self)

    def onPlayBackStarted(self):
        for i in range(20):
            if self.isPlayingVideo(): break
            xbmc.sleep(250)
        try: playingfile = self.getPlayingFile()
        except: playingfile = None
        if playingfile:
            etvsubs = WINDOW.getProperty(playingfile + "-etvsubtitles")
            if etvsubs: self.setSubtitles(etvsubs)

    def onPlayBackStopped(self):
        pass

    def onPlayBackEnded(self):
        pass

