import os
import xbmc, xbmcvfs, xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_ICON = ADDON.getAddonInfo('icon')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path').decode("utf-8")
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_DATA_PATH = xbmc.translatePath("special://profile/addon_data/%s/" % ADDON_ID).decode("utf-8")

sort_criteria = [(ADDON.getLocalizedString(30044),'premiered'), (ADDON.getLocalizedString(30045),'dateadded'), (ADDON.getLocalizedString(30046),'rating')]

genre_list = [('G Rating', '\xd9\x85\xd9\x86\xd8\xa7\xd8\xb3\xd8\xa8 \xd9\x84\xd8\xac\xd9\x85\xd9\x8a\xd8\xb9 \xd8\xa7\xd9\x84\xd8\xa3\xd8\xb9\xd9\x85\xd8\xa7\xd8\xb1'), ('PG Rating', '\xd9\x84\xd8\xac\xd9\x85\xd9\x8a\xd8\xb9 \xd8\xa7\xd9\x84\xd8\xa3\xd8\xb9\xd9\x85\xd8\xa7\xd8\xb1 \xd8\xa8\xd8\xa5\xd8\xb4\xd8\xb1\xd8\xa7\xd9\x81 \xd8\xb9\xd8\xa7\xd8\xa6\xd9\x84\xd9\x8a'), ('PG-13 Rating', '\xd8\xa8\xd8\xa5\xd8\xb1\xd8\xb4\xd8\xa7\xd8\xaf \xd8\xb9\xd8\xa7\xd8\xa6\xd9\x84\xd9\x8a \xd9\x84\xd9\x85\xd9\x86 \xd9\x87\xd9\x85 \xd8\xaf\xd9\x88\xd9\x86 13 \xd8\xb3\xd9\x86\xd8\xa9'), ('R Rating', '\xd8\xba\xd9\x8a\xd8\xb1 \xd8\xb9\xd8\xa7\xd8\xa6\xd9\x84\xd9\x8a'), ('NC-17 Rating', 'NC-17 \xd8\xa7\xd9\x84\xd8\xaa\xd9\x82\xd9\x8a\xd9\x8a\xd9\x85'), ('Action', '\xd8\xa7\xd9\x83\xd8\xb4\xd9\x86'), ('Adventure', '\xd9\x85\xd8\xba\xd8\xa7\xd9\x85\xd8\xb1\xd8\xa9'), ('Biography', '\xd8\xb3\xd9\x8a\xd8\xb1\xd8\xa9 \xd8\xb0\xd8\xa7\xd8\xaa\xd9\x8a\xd9\x87'), ('Comedy', '\xd9\x83\xd9\x88\xd9\x85\xd9\x8a\xd8\xaf\xd9\x8a'), ('Crime', '\xd8\xac\xd8\xb1\xd9\x8a\xd9\x85\xd8\xa9'), ('Documentary', '\xd9\x88\xd8\xab\xd8\xa7\xd8\xa6\xd9\x82\xd9\x8a'), ('Drama', '\xd8\xaf\xd8\xb1\xd8\xa7\xd9\x85\xd8\xa7'), ('Family', '\xd9\x81\xd9\x8a\xd9\x84\xd9\x85 \xd8\xb9\xd8\xa7\xd8\xa6\xd9\x84\xd9\x8a'), ('Fantasy', '\xd8\xae\xd9\x8a\xd8\xa7\xd9\x84\xd9\x8a'), ('History', '\xd8\xaa\xd8\xa7\xd8\xb1\xd9\x8a\xd8\xae\xd9\x8a'), ('Horror', '\xd8\xb1\xd8\xb9\xd8\xa8'), ('Music', '\xd9\x85\xd9\x88\xd8\xb3\xd9\x8a\xd9\x82\xd9\x89'), ('Mystery', '\xd8\xba\xd9\x85\xd9\x88\xd8\xb6'), ('Romance', '\xd8\xb1\xd9\x88\xd9\x85\xd8\xa7\xd9\x86\xd8\xb3\xd9\x8a'), ('Sci-Fi', '\xd8\xae\xd9\x8a\xd8\xa7\xd9\x84 \xd8\xb9\xd9\x84\xd9\x85\xd9\x8a'), ('Sport', '\xd8\xb1\xd9\x8a\xd8\xa7\xd8\xb6\xd8\xa9'), ('Thriller', '\xd8\xa5\xd8\xab\xd8\xa7\xd8\xb1\xd8\xa9'), ('War', '\xd8\xad\xd8\xb1\xd8\xa8'), ('Western', '\xd8\xba\xd8\xb1\xd8\xa8\xd9\x8a')]
intros_list = ['action.mp4', 'action.mp4', 'red_carpet.mp4', 'red_carpet.mp4', 'thriller.mp4', 'docum.mp4', 'moon.mp4', 'general_intro.mp4', 'moon.mp4', 'general_intro.mp4', 'horror.mp4', 'general_intro.mp4', 'thriller.mp4', 'general_intro.mp4', 'moon.mp4', 'general_intro.mp4', 'thriller.mp4', 'war.mp4', 'red_carpet.mp4']
section_list =[ ADDON.getLocalizedString(30000), ADDON.getLocalizedString(30002), ADDON.getLocalizedString(30003), ADDON.getLocalizedString(30004), ADDON.getLocalizedString(30005), ADDON.getLocalizedString(30006), ADDON.getLocalizedString(30007), ADDON.getLocalizedString(30008), ADDON.getLocalizedString(30010), ADDON.getLocalizedString(30011)]

base_api_link = 'http://portosaleksa.com/vodplay/api/'

if xbmcvfs.exists('/storage/emulated'):
    base_dir = '/storage/emulated/legacy/Android/data/'
    intro_path = base_dir + 'intro/'
elif xbmcvfs.exists('/mnt/sdcard/Android/data/'):
    base_dir = '/mnt/sdcard/Android/data/'
    intro_path = base_dir + 'intro/'
else:
    base_dir = ADDON_DATA_PATH
    intro_path = os.path.join(ADDON_PATH,'resources','intro/')
    if not xbmcvfs.exists(ADDON_DATA_PATH): 
        xbmcvfs.mkdir(ADDON_DATA_PATH)
    
#playercore_path = base_dir+'org.xbmc.kodi/files/.kodi/userdata/playercorefactory.xml'
cookie_path = os.path.join(base_dir,'favorites','cookie.pkl')
credentials_path = os.path.join(base_dir,'favorites','cred.pkl')
favorites_path = os.path.join(base_dir,'favorites','favorites.pkl')
if not xbmcvfs.exists(base_dir+'favorites/'): 
    xbmcvfs.mkdir(base_dir+'favorites/')
temp_path = os.path.join(base_dir,'favorites','temp.pkl')
backup_path = '/storage/external_storage/sda1/favorites/'
download_options = os.path.join(base_dir,'favorites','download_options.pkl')
id_path = base_dir+'id/id.txt'