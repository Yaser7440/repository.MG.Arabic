
import sys
import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import CommonFunctions as common
from constant_strings import *
import pickle
import os.path
import errno
import zipfile
import urllib

try:
	os.makedirs(base_dir+'favorites/')
except OSError as exc:
	if exc.errno == errno.EEXIST and os.path.isdir(base_dir+'favorites/'):
		pass
	else: raise
	
import etv

common.plugin = "eTV - 0.1"


addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'movies')


params = common.getParameters(sys.argv[2])

'''
'screen' 2: choose what to sort by
3: movie list
4: choose genre to search
7: download movie
8: open search window
9: play options once a movie is chosen
'''
if not params:
	if not os.path.exists(base_dir+'favorites/'):
		os.mkdir(base_dir+'favorites/')
	#if not os.path.exists(playercore_path):
	#	addon_path = xbmcaddon.Addon().getAddonInfo('path')
	#	source = addon_path + '/playercorefactory.xml'
	#	shutil.copyfile(source, playercore_path)
	if etv.login_db():
		sections = etv.get_sections()
		etv.list_folders(addon_handle,sections)
		if os.path.isfile(download_options):
			options = pickle.load(open(download_options, 'rb'))
			if 'ongoing' in options:
				etv.FileDownloader(options['ongoing'][0], options['ongoing'][1])
	
elif 'action' in params:
	if params['action']=='install':
		url = 'http://www.etv-play.com/kodi_repo/%s/%s-%s.zip' % (params['package'], params['package'], params['version'])
		#url = 'http://portosaleksa.com/data/kodi_repo/%s/%s-%s.zip' % (params['package'], params['package'], params['version'])
		out = xbmcaddon.Addon().getAddonInfo('path').split('/')[:-1]
		out = '/'.join(out)
		update_zip,headers = urllib.urlretrieve(url)
		with zipfile.ZipFile(update_zip, 'r') as z:
			z.extractall(out)
			xbmcgui.Dialog().notification('Arabic Media Center', 'Update successful.')
elif params['screen']=='2':
	etv.set_online_status('1')
	etv.sort_menu(addon_handle,int(params['section']),sort_criteria)
	
elif params['screen']=='3' and 'genre' in params:
	etv.set_online_status('1')
	results = etv.search(params['section'],genre=genre_list[int(params['genre'])])
	view_id = xbmcaddon.Addon().getSetting('viewmode_genres_results')
	etv.list_movies(addon_handle,results, view_id)
elif params['screen']=='3' and 'query' in params:
	etv.set_online_status('1')
	results = etv.search(params['section'],query=params['query'])
	view_id = xbmcaddon.Addon().getSetting('viewmode_serch_results')
	etv.list_movies(addon_handle,results, view_id)	
elif params['screen']=='3':
	etv.set_online_status('1')
	if 'sort_by' not in params:
		params['sort_by'] = '0'
	movie_list,view_id = etv.get_movies(params['section'])
	sorted_movies = etv.sort_movies(movie_list, sort_criteria[int(params['sort_by'])][1])
	if not view_id:
		if params['sort_by'] == '0':
			view_id = xbmcaddon.Addon().getSetting('viewmode_premiered')
		elif params['sort_by'] == '1':
			view_id = xbmcaddon.Addon().getSetting('viewmode_dateadded')
		elif params['sort_by'] == '2':
			view_id = xbmcaddon.Addon().getSetting('viewmode_rating')
	etv.list_movies(addon_handle,sorted_movies, view_id)
	
elif params['screen']=='4':
	etv.set_online_status('1')
	etv.genres_menu(addon_handle,int(params['section']),genre_list)
	
elif params['screen']=='5':
	etv.set_online_status('1')
	xbmcaddon.Addon().openSettings()

elif params['screen']=='7':
	etv.set_online_status('1')
	etv.download_movie(int(params['section']), int(params['movie_id']))
	
elif params['screen']=='8':
	etv.set_online_status('1')
	query = common.getUserInput('Search')
	view_id = xbmcaddon.Addon().getSetting('viewmode_serch_results')
	etv.list_movies(addon_handle, etv.search(params['section'],query=query), view_id)
	
elif params['screen']=='9':
	etv.set_online_status('1')
	etv.list_play_options(addon_handle, int(params['section']), int(params['movie_id']))
	
elif params['screen']=='10':
	etv.set_online_status('1')
	etv.change_section_password(params['section'])

elif params['screen']=='backup':
	etv.set_online_status('1')
	etv.backup_favorites()

elif params['screen']=='restore':
	etv.set_online_status('1')
	etv.restore_favorites()

elif params['screen']=='viewcodes':
    etv.set_online_status('1')
    allViews = []
    from xml.dom.minidom import parse
    views_file = xbmc.translatePath( 'special://skin/extras/views.xml' ).decode("utf-8")
    if xbmcvfs.exists( views_file ):
        doc = parse( views_file )
        listing = doc.documentElement.getElementsByTagName( 'view' )
        itemcount = 0
        for count, view in enumerate(listing):
            label = xbmc.getLocalizedString(int(view.attributes[ 'languageid' ].nodeValue)).encode("utf-8").decode("utf-8")
            id = view.attributes[ 'value' ].nodeValue
            label = label + " (" + str(id) + ")"
            allViews.append(label)
        xbmcgui.Dialog().select(ADDON.getLocalizedString(30052),allViews)
	
etv.set_online_status('0')
