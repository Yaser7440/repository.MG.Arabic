#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import xbmc, xbmcgui, xbmcvfs, xbmcaddon
import etv
import player
import json

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_ICON = ADDON.getAddonInfo('icon')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path').decode("utf-8")
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_DATA_PATH = xbmc.translatePath("special://profile/addon_data/%s" % ADDON_ID).decode("utf-8")
cachePath = os.path.join(ADDON_DATA_PATH,"resume.json")
WINDOW = xbmcgui.Window( 10000 )

class Main:
    
    player = player.player()
    
    def __init__(self):
        
        #get resume status from cache
        if xbmcvfs.exists(cachePath):
            f = xbmcvfs.File(cachePath)
            data = f.read()
            WINDOW.setProperty("etv.resume", data)
            f.close()
        
        #pre-cache the movie lists
        if etv.login_db():
            sections = etv.get_sections()
            for i, section in enumerate(sections):
                movie_list,view_id = etv.get_movies(i)
        
        while not xbmc.abortRequested:
                        
            # do nothing
            xbmc.sleep(150)
                

xbmc.log('Arabic Mediacenter version %s started' % ADDON_VERSION)
Main()

#save resume status to file
if not xbmcvfs.exists(ADDON_DATA_PATH + os.sep):
    xbmcvfs.mkdir(ADDON_DATA_PATH)
    
f = xbmcvfs.File(cachePath,'w')
f.write(WINDOW.getProperty("etv.resume"))
f.close()
        
xbmc.log('Arabic Mediacenter version %s stopped' % ADDON_VERSION)
