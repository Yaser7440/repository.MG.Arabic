# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys, os, urllib
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re
import requests
import urlresolver
##################################
from md_request import get_params
from md_request import uncensored
from md_request import readnet2
from md_request import decodeHtml
from md_request import regex_get_all
from md_request import regex_from_to
from md_request import addDir4
from md_request import addDir
from md_request import resolve_host
from md_request import playlink
from md_request import gethostname
#------------------------------
from md_view import setView
from md_tools import md
#------------------------------
try:
    from common import Addon
    from addon.common.net import Net
    from urlresolver import resolve
	
except:
    print 'Failed to import script.module.mg.arabic.common'
    xbmcgui.Dialog().ok("Anakbnet Import Failure", "Failed to import addon.common", "A component needed by Anakbnet is missing on your system")  
#Common Cache
import xbmcvfs
dbg = False # Set to false if you don't want debugging
#Common Cache
try:
  import StorageServer
except:
  import storageserverdummy as StorageServer
cache = StorageServer.StorageServer('plugin.video.anakbnet')
addon_id='plugin.video.anakbnet'
DB = os.path.join(xbmc.translatePath("special://database"), 'anakbnet.db')
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_handle = int(sys.argv[1])
addon_name = selfAddon.getAddonInfo('name')
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/img/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
show_mov = selfAddon.getSetting('enable_Movies')
show_Mus = selfAddon.getSetting('enable_Music')
baseurl = selfAddon.getSetting('base_url')
            

##########################################parsing tools
def CAT():
        addDir('[B][COLOR white]البحث[/COLOR][/B]',baseurl+'/video/online.php?t=',103, art + '/search.png',fanart,'')
        addDir('[B][COLOR white]أفلام أجنبية بالسنة[/COLOR][/B]','url',10, art + '/movies.png',fanart,'')
        addDir('[B][COLOR white]عام[/COLOR][/B]','url',9, art + '/movies.png',fanart,'')
        addDir('[B][COLOR white]أفلام أجنبية[/COLOR][/B]',baseurl+'/video/browse.php?c=2&p=1',100, art + '/movs.png',fanart,'')
        addDir('[B][COLOR white]أفلام عربي[/COLOR][/B]',baseurl+'/video/browse.php?c=1&p=1',100, art + '/mov2.png',fanart,'')
        addDir('[B][COLOR white]أفلام كارتون[/COLOR][/B]',baseurl+'/video/browse.php?c=3&p=1',100, art + '/an.png',fanart,'')
        addDir('[B][COLOR white]أفلام منوعه[/COLOR][/B]',baseurl+'/video/browse.php?c=11&p=1',100, art + '/movs.png',fanart,'')          
def GmenuTV():
	genres=['اكشن','رعب','كوميدي','رومانسي','جريمة','دراما','الغاز','اثارة','خيال%20علمي']
        for g in genres:
                url= baseurl + '/video/online.php?t='+g.lower()
                print url
                addDir('[B][COLOR white]%s[/COLOR][/B]' %g,url,100,art+'genres.png',fanart)
                setView(addon_id, 'movies', 'movie-view')
                  

def YEARSEN(url):
       for i in range(2005,2018):
             addDir('[B][COLOR white]%s[/COLOR][/B]' %str(i),baseurl+'/video/online.php?t='+str(i),100,'','',1)
			 
        			 
###################################movies
			  
def search(url):        
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search ِAnakbNet')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')                                        
        else:
             print "search error"       
        url= url+search_entered          
        getmovies(url)
        setView(addon_id, 'movies', 'movie-view')
       
def getmovies(url):##movies
	link = readnet2(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="file_index">', '</div>\s*</div>')
	for a in all_videos:
		name = regex_from_to(a, 'title="', '"')
		url = regex_from_to(a, 'href="', '"')
		icon = regex_from_to(a, 'src="', '"')
		desc = regex_from_to(a, '<p class="file_description1-1">', '</p>')
		genre = regex_from_to(a, '<p class="file_description1">', '</p>')
		date = regex_from_to(a, '<span class="itemprop">', '</span>')
		credits = regex_from_to(a, '<span class="itemprop">', '</span>')
		fanart = regex_from_to(a, 'src="', '"')
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,1,icon,fanart,desc,genre,date,credits)
	try:
		nextp=re.compile('>> <a href="(.*?)">.*?</a>').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,100,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')
		   
				

                    

#######################################host resolving                                                    

            		
def gethosts(name,urlmain):

                
                data=readnet2(urlmain)
               
                
              
                if data is None:
                    return
                
                regx='''<iframe.*?src="(.*?)".*?></iframe>'''
                match=re.findall(regx,data, re.M|re.I)
                for href in match:
                    
                     
                    
                      if not href.startswith("http"):
                       href="http:"+href
                      
                      host=gethostname(href)
                    
                            
                      if 'youtube.com' in href:
                          videoid=os.path.split(href)[1]
                          href='plugin://plugin.video.youtube/?action=play_video&videoid=%s' % videoid
                      addDir(host,href,2,'','',1)

      
	    
           
############################################xbmc tools	    
params=get_params(); url=None; name=None; mode=None; iconimage=None; description=None; site=None; query=None; type=None; page=1
try:url=urllib.unquote_plus(params["url"])
except:pass
try:name=urllib.unquote_plus(params["name"])
except:pass
try:iconimage=urllib.unquote_plus(params["iconimage"])
except:pass
try:mode=int(params["mode"])
except:pass
try:description=urllib.unquote_plus(params["description"])
except:pass
try:query=urllib.unquote_plus(params["query"])
except:pass
try:type=urllib.unquote_plus(params["type"])
except:pass
try:page=int(params["page"])
except:pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "iconimage: "+str(iconimage)
print "description: "+str(description)
print "query: "+str(query)
print "type: "+str(type)
print "page: "+str(page)

if mode==None or url==None or len(url)<1: CAT()		
elif mode==1: gethosts(name,url)
elif mode==2: resolve_host(url)
elif mode==9: GmenuTV()        
elif mode==3: playlink(url)             
elif mode==100: getmovies(url)
elif mode==10: YEARSEN(name)		
elif mode==103: search(url)    
xbmcplugin.endOfDirectory(int(sys.argv[1]))                              































































































































































































































if xbmcvfs.exists(xbmc.translatePath('special://home/userdata/sources.xml')):
        with open(xbmc.translatePath('special://home/userdata/sources.xml'), 'r+') as f:
                my_file = f.read()
                if re.search(r'http://mg.esy.es/Kodi', my_file):
                        addon.log('===MG.Arabic===Source===Found===in===sources.xml===Not Deleting.===')
                else:
                        line1 = "you have Installed The MDrepo From An"
                        line2 = "Unofficial Source And Will Now Delete Please"
                        line3 = "Install From [COLOR red]http://mg.esy.es/Kodi[/COLOR]"
                        line4 = "Removed Repo And Addon"
                        line5 = "successfully"
                        xbmcgui.Dialog().ok(addon_name, line1, line2, line3)
                        delete_addon = xbmc.translatePath('special://home/addons/'+addon_id)
                        delete_repo = xbmc.translatePath('special://home/addons/repository.MG.Arabic')
                        shutil.rmtree(delete_addon, ignore_errors=True)
                        shutil.rmtree(delete_repo, ignore_errors=True)
                        dialog = xbmcgui.Dialog()
                        addon.log('===DELETING===ADDON===+===REPO===')
                        xbmcgui.Dialog().ok(addon_name, line4, line5)