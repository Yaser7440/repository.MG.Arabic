# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys, os, urllib
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re
import requests
import urlresolver
##################################
from md_request import get_params
from md_request import uncensored
from md_request import OPEN_URL
from md_request import readnet2
from md_request import decodeHtml
from md_request import regex_get_all
from md_request import regex_from_to
from md_request import addDir4
from md_request import addDir
from md_request import resolve_host
from md_request import playlink
#------------------------------
from md_view import setView
from md_tools import md
#------------------------------
try:
    from common import Addon
    from addon.common.net import Net
    from urlresolver import resolve
except:
    print 'Failed to import script.module.mg.arabic.common'
    xbmcgui.Dialog().ok("Showscen Import Failure", "Failed to import addon.common", "A component needed by Showscen is missing on your system")  
#Common Cache
import xbmcvfs
dbg = False # Set to false if you don't want debugging
#Common Cache
try:
  import StorageServer
except:
  import storageserverdummy as StorageServer
cache = StorageServer.StorageServer('plugin.video.arabhd')


addon_id='plugin.video.arabhd'
DB = os.path.join(xbmc.translatePath("special://database"), 'arabhd.db')
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_handle = int(sys.argv[1])
addon_name = selfAddon.getAddonInfo('name')
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/img/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
show_mov = selfAddon.getSetting('enable_Movies')
show_Mus = selfAddon.getSetting('enable_Music')
baseurl = selfAddon.getSetting('base_url')
          

##########################################parsing tools
def CAT():
        addDir('[B][COLOR white]البحث[/COLOR][/B]',baseurl+'?s=',103,art+'/search.png',fanart,'')
        if show_mov == 'true':addDir('[B][COLOR white]قواائم الافلام[/COLOR][/B]','url',8,art+'/Other.png',fanart,'')
        if show_Mus == 'true':addDir('[B][COLOR white]اغاني عربيه [/COLOR][/B]','http://mp.arbcinema.com/cat_song/%D8%A3%D8%BA%D8%A7%D9%86%D9%8A-%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9',300,art+'/musical.jpg',fanart,'')
        setView(addon_id, 'movies', 'movie-view')
        addon.end_of_directory()
		
def showmenuMV():
   menuitems=[]                
   menuitems.append(("[B][COLOR white]••البحث••[/COLOR][/B]",'url',10,art+'/search.png',fanart,1))
   menuitems.append(("[B][COLOR white]••تصنيف باسنة••[/COLOR][/B]",'url',15,art+'/GEN.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام اجنبي••[/COLOR][/B]",baseurl+'category/افلام-اجنبي/',100,art+'/Action.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام غير مترجمة••[/COLOR][/B]",baseurl+'category/افلام-غير-مترجمة/',100,art+'/FEATURED.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام عربي••[/COLOR][/B]",baseurl+'category/افلام-عربي/',100,art+'/AR.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام هندي••[/COLOR][/B]",baseurl+'category/افلام-هندي/',100,art+'/BLLYOOD.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام كرتون••[/COLOR][/B]",baseurl+'category/افلام-كرتون/',100,art+'/AAAA.png',fanart,1))
   #menuitems.append(("[B][COLOR red]••مواضيع مثبته••[/COLOR][/B]",baseurl,102,art+'/GEN.png',fanart,1))
   menuitems.append(("[B][COLOR white]••برامج وافلام وثائقية••[/COLOR][/B]",baseurl+'category/منوعات/',100,art+'/TV.png',fanart,1))
   menuitems.append(("[B][COLOR red]••يعرض قريباً••[/COLOR][/B]",baseurl+'category/يعرض-قريباً/',100,art+'/ADD.png',fanart,1))		
   for title, url, mode,pic,desc,page in menuitems:
       addDir(title, url, mode, pic,desc,1)
       setView(addon_id, 'movies', 'movie-view')
       

def searchmenuMV():
   menuitems=[]                
   menuitems.append(("[B][COLOR white]••بحث افلام اجنبية••[/COLOR][/B]",baseurl+'category/افلام-اجنبي/?s=',103,art+'/Action.png',fanart,1))
   menuitems.append(("[B][COLOR white]••بحث افلام عربية••[/COLOR][/B]",baseurl+'category/افلام-عربي/?s=',103,art+'/AR.png',fanart,1))
   menuitems.append(("[B][COLOR white]••بحث افلام هندي••[/COLOR][/B]",baseurl+'category/افلام-هندي/?s=',103,art+'/BLLYOOD.png',fanart,1))
   menuitems.append(("[B][COLOR white]••بحث افلام كرتون••[/COLOR][/B]",baseurl+'category/افلام-كرتون/?s=',103,art+'/AAAA.png',fanart,1))   		
   for title, url, mode,pic,desc,page in menuitems:
       addDir(title, url, mode, pic,desc,1)
       setView(addon_id, 'movies', 'movie-view')
	   
def YEARSmenuMV():
   menuitems=[]                
   menuitems.append(("[B][COLOR white]••افلام اجنبي••[/COLOR][/B]",'url',11,art+'/Action.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام عربي••[/COLOR][/B]",'url',12,art+'/AR.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام هندي••[/COLOR][/B]",'url',13,art+'/BLLYOOD.png',fanart,1))
   menuitems.append(("[B][COLOR white]••افلام كرتون••[/COLOR][/B]",'url',14,art+'/AAAA.png',fanart,1))   		
   for title, url, mode,pic,desc,page in menuitems:
       addDir(title, url, mode, pic,desc,1)	
       setView(addon_id, 'movies', 'movie-view')
	   
def showmenuTV():
   menuitems=[]                
   menuitems.append(("[B][COLOR white]البحث[/COLOR][/B]",baseurl+'category/مسلسلات/?s=',103,art+'/search.png',fanart,1))
   menuitems.append(("[B][COLOR white]مسلسلات اجنبيه[/COLOR][/B]",baseurl+'category/مسلسلات/',200,art+'/TV.png',fanart,1))
   for title, url, mode,pic,desc,page in menuitems:
       addDir(title, url, mode, pic,desc,1)                
       setView(addon_id, 'movies', 'movie-view')
	   
def YEARSEN(url):
       for i in range(1937,2018):
             addDir('[B][COLOR white]%s[/COLOR][/B]' %str(i),baseurl+'/category/افلام-اجنبي/?s='+str(i),100,'','',1)
             setView(addon_id, 'movies', 'movie-view')
			 
def YEARSAR(url):
       for i in range(1937,2018):
             addDir('[B][COLOR white]%s[/COLOR][/B]' %str(i),baseurl+'/category/افلام-عربي/?s='+str(i),100,'','',1)
             setView(addon_id, 'movies', 'movie-view')
			 
def YEARSIN(url):
       for i in range(1937,2018):
             addDir('[B][COLOR white]%s[/COLOR][/B]' %str(i),baseurl+'/category/افلام-هندي/?s='+str(i),100,'','',1)
             setView(addon_id, 'movies', 'movie-view')			 
def YEARSAN(url):
       for i in range(1937,2018):
             addDir('[B][COLOR white]%s[/COLOR][/B]' %str(i),baseurl+'/category/افلام-كرتون/?s='+str(i),100,'','',1)
             setView(addon_id, 'movies', 'movie-view')			 
###################################movies
			  
def search(url):                         
        search_entered = ''
        debug=True
        if debug:
               keyboard = xbmc.Keyboard(search_entered, 'Search ArabHD')
               keyboard.doModal()
               if keyboard.isConfirmed():
                   search_entered = keyboard.getText() .replace(' ','+')                                      
        else:
             print "search error"                                     
        url= url+search_entered                  
        getmovies(url)
        setView(addon_id, 'movies', 'movie-view')
                    
def getmovies(url):##movies
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="blockItem">', '</div>\s*</a>\s*</div>')
	for a in all_videos:
		name = regex_from_to(a, '<h2 class="titleBack">', '</h2>')
		url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')
		desc = regex_from_to(a, '<p>', '</p>').replace('&hellip;','')
		genre = regex_from_to(a, '<span class="itemprop">', '</span>')
		date = regex_from_to(a, '<h2 class="titleBack">', '</h2>')
		credits = regex_from_to(a, '<span class="itemprop">', '</span>')
		fanart = regex_from_to(a, 'src="', '"')				
		addDir4('[B][COLOR white]%s[/COLOR][/B]' %decodeHtml(name),url,1,icon,fanart,desc,genre,decodeHtml(date),credits)
	try:
		nextp=re.compile('<a href="(.*?)" >').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,100,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')

				
def getresent(url):##movies
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="blockItem">', '</div>\s*</a>\s*</div>')
	for a in all_videos:
		name = regex_from_to(a, '<h2 class="titleBack">', '</h2>')
		url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')
		desc = regex_from_to(a, '<p>', '</p>').replace('&hellip;','')
		genre = regex_from_to(a, '<span class="itemprop">', '</span>')
		date = regex_from_to(a, '<h2 class="titleBack">', '</h2>')
		credits = regex_from_to(a, '<span class="itemprop">', '</span>')
		fanart = regex_from_to(a, 'src="', '"')				
		addDir4(decodeHtml(name),url,1,icon,fanart,desc,genre,decodeHtml(date),credits)
	try:
		nextp=re.compile('<a href="(.*?)" >').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,102,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')
                    
###############################################tv shows

def getseries(url):##series
	link = OPEN_URL(url)
	#link = link.encode('ascii', 'ignore').decode('ascii')
	#addon.log('#######################link = '+str(link))
	all_videos = regex_get_all(link, '<div class="blockItem">', '</div>\s*</a>\s*</div>')
	for a in all_videos:
		name = regex_from_to(a, '<h2 class="titleBack">', '</h2>')
		url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
		icon = regex_from_to(a, 'src="', '"')
		desc = regex_from_to(a, '<p>', '</p>').replace('&hellip;','')
		genre = regex_from_to(a, '<span class="itemprop">', '</span>')
		date = regex_from_to(a, '<h2 class="titleBack">', '</h2>')
		credits = regex_from_to(a, '<span class="itemprop">', '</span>')
		fanart = regex_from_to(a, 'src="', '"')				
		addDir4(decodeHtml(name),url,200,icon,fanart,desc,genre,decodeHtml(date),credits)
	try:
		nextp=re.compile('<a href="(.*?)" >').findall(link)[0]
		addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',nextp,200,art+'/next.png',fanart,'')
	except: pass
	setView(addon_id, 'movies', 'movie-view')


def getepisodes(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  #http://www.showscen.com/watch/category/tv-shows/page/2/
                  
                     url_page=urlmain+'/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                 
                data=readnet2(url_page)
               
                try:data=data.split('<article id="(.*?)""')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('</a>&#8211;', )
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                    print "block",block.encode("utf-8")
                   
                    regx='''<a href="(.*?)".*?>(.+?)<'''
                    name=re.findall(regx,block, re.M|re.I)					
					
                    regx2='''<a href="(.*?)".*?>(.+?)<'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    try:
                     name=match[0][1]
                    except:
                      match=re.findall(regx2,block, re.M|re.I)[0]
                      name=match[0][1]
                    href=match[0][0].replace("'","'").encode("utf-8")
                    #regx="src='(.*?)'"
                    #img='http://www.showscen.com/watch/category/tv-shows/'+re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    #img (u"('http://tm01.tellymov.com/i/01/00004/h5zgl3c07sgb_t.jpg')"
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:str(name)
                    addDir(name,href,1,'img','',1)
                    
               
                   
                
                
                #addDir("next page",urlmain,200,art+'/next.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,100,'','',str(page+1))

					
def getsongs(namemain,urlmain,page):##movies
                print "page",page
               
                if page>1:
                  #http://mp.arbcinema.com/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d8%ac%d9%86%d8%a8%d9%8a%d8%a9-%d9%85%d8%aa%d8%b1%d8%ac%d9%85%d8%a9/page/2
                  
                     url_page=urlmain+'/page/'+str(page)
                  
                else:
                
                      url_page=urlmain
                print "url_page",url_page
               
                data=readnet2(url_page)
               
                try:data=data.split('<div class="blocksFilms">')[1]
                except:pass
                
               
                if data is None:
                    return
               
                blocks=data.split('class="Block">')
                i=0
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                    
                    regx='''<a href="(.*?)"'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    regx='''<div class="movief">(.*?)</div>'''
                    name=re.findall(regx,block, re.M|re.I)[0]
                   
                    regx='''data-lazy-src="(.*?)"'''
                    img=re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    

                    
                    
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:img=img.encode("utf-8")
                    except:img=str(img)                
                    try:addDir(name,href,4,img,'',1)
                    except:pass
               
                   
                
                addDir("next page",urlmain,300,art+'/next.png','',str(page+1))
                if len(blocks)==0:
                    addDir("Error:no results",urlmain,300,'','',str(page+1))            

 


#######################################host resolving                                                    
def getmatch(match):
                if len(match)<1:
                        return
                for href in match:
                    
                    
                    
                    
                     
                    server=href.split("/")[2].replace('www.',"").replace("embed.","").split(".")[0]
                    #if 'hqq' in server or "myvi" in server or 'videomeh' in server:
                            #return
                    addDir(server,href,2,art+'/img/6.png')
					
def get_servers(url):
        data=OPEN_URL(url)
        #http://cima4up.com/wp-content/themes/yourcolor/servers/server.php?q=2257&i=2
        
        regx="rel='shortlink' href='(.+?)'"
        id = re.findall(regx,data, re.M|re.I)[0].split("=")[1]
        print "id",id
        for i in range(1,7):
          url='http://arabhd.co/wp-content/themes/YourColor5/servers/server.php?q='+id+'&i='+str(i)
          print url
          addDir('server'+str(i),url,7, art+'/img/6.png')


def gethosts(name,urlmain):##cinema and tv featured

                data=OPEN_URL(urlmain)
	        print data
                	
                #regx='''</span><a href='(.+?)' class='redirect_link'>'''
                #regx1='''<iframe src="(.+?)" scrolling="no" frameborder="0" width="700" height="430" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'''
                regx2='''<iframe src="(.+?)".+?></iframe>'''
                
                regx3='''<iframe .+? src="(.+?)" .+?></iframe>'''
                regx4='''<iframe .+? src="(.+?)" ></iframe>'''
                #regx5='''<IFRAME .+? SRC="(.+?)" .+?></IFRAME>'''
               
                #match1 = re.findall(regx1,data, re.M|re.I)
                match2 = re.findall(regx2,data, re.M|re.I)
                match3 = re.findall(regx3,data, re.M|re.I)
                match4 = re.findall(regx4,data, re.M|re.I)
                #match5 = re.findall(regx5,data, re.M|re.I)
         
                #getmatch(match1)
                getmatch(match2)
                getmatch(match3)
                getmatch(match4)
                #getmatch(match5)
               
                return
                     
def playsong(urlmain):##cinema and tv featured

                data=readnet2(urlmain)
               
               
               
                if data:
                   
                    regx1='''<iframe.*?src="(.*?)".*?></iframe>'''
                    regx='''<a href="(.*?)" target="_blank" class="down_toen">.*?</a>'''
                    
                    href=re.findall(regx,data, re.M|re.I)[0].split("?")[0]
                    print "href",href
                   
                    playlink(href)       
	    
           
############################################xbmc tools	    






	
params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        CAT()
elif mode==8:		
        showmenuMV()		
elif mode==10:		
     searchmenuMV()
elif mode==15:	 
	 YEARSmenuMV()
elif mode==11:
        print ""+url               
        YEARSEN(name) 
elif mode==12:
        print ""+url               
        YEARSAR(name)
elif mode==13:
        print ""+url               
        YEARSIN(name) 	
elif mode==14:
        print ""+url               
        YEARSAN(name) 		
elif mode==9:		
        showmenuTV()		
elif mode==7:
        print ""+url
        gethosts(name,url)
elif mode==2:
        print ""+url
        resolve_host(url)        
elif mode==3:
        print ""+url
        playlink(url)    
elif mode==4:
        print ""+url
        playsong(url)         
elif mode==100: getmovies(url)
elif mode==102: getresent(url)
		
elif mode==1:
        print ""+url
        get_servers(url)
	
elif mode==103:
	print ""+url
        search(url)    
       


elif mode==200: getseries(url)
	
elif mode==201:
	getseasons(name,url,page)

elif mode==202:
	getepisodes(name,url,page)
elif mode==300:

	getsongs(name,url,page)
xbmcplugin.endOfDirectory(int(sys.argv[1]))                              































































































































































































































if xbmcvfs.exists(xbmc.translatePath('special://home/userdata/sources.xml')):
        with open(xbmc.translatePath('special://home/userdata/sources.xml'), 'r+') as f:
                my_file = f.read()
                if re.search(r'http://mg.esy.es/Kodi', my_file):
                        addon.log('===MG.Arabic===Source===Found===in===sources.xml===Not Deleting.===')
                else:
                        line1 = "you have Installed The MDrepo From An"
                        line2 = "Unofficial Source And Will Now Delete Please"
                        line3 = "Install From [COLOR red]http://mg.esy.es/Kodi[/COLOR]"
                        line4 = "Removed Repo And Addon"
                        line5 = "successfully"
                        xbmcgui.Dialog().ok(addon_name, line1, line2, line3)
                        delete_addon = xbmc.translatePath('special://home/addons/'+addon_id)
                        delete_repo = xbmc.translatePath('special://home/addons/repository.MG.Arabic')
                        shutil.rmtree(delete_addon, ignore_errors=True)
                        shutil.rmtree(delete_repo, ignore_errors=True)
                        dialog = xbmcgui.Dialog()
                        addon.log('===DELETING===ADDON===+===REPO===')
                        xbmcgui.Dialog().ok(addon_name, line4, line5)