#!/usr/bin/python
# -*- coding: utf-8 -*-
try:import sys,syspath
except:pass
from yttools import *


def infolist():
  list1=[]
  list1.append(('AndreRieu TV','AndreRieuTV',1005))
  list1.append(('The King Of Waltz','UC4e9tzha5zK09lws80U6Tvw'))
  list1.append(('Fan club','UCLfej0eScLEq1K2y93TJltA'))
  list1.append(('Andre rieu 2','UCTTfAqOZAoo8xN2OB0s2uTA'))
  list1.append(('Andre rieu 3','UC3LMGc6XbJvzSkuKT9jeQOA'))
  
  list1.append(('Andre rieu 4','UCdiq1ZLNZ3fxoVPqqqvBq1w'))
  
  list1.append(('AndreRieu 5','DrakeSparrow',1005))
  list1.append(('Live webcam','7P8SPmR3M8Y',1007))
  
  return list1

################################################################333
list1=infolist()
process_mode(list1 )
xbmcplugin.endOfDirectory(int(sys.argv[1]))
