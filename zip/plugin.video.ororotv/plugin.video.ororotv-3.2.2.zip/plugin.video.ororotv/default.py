# -*- coding: utf-8 -*-

'''
    Ororo TV Addon
    Copyright (C) 2014 ororo.tv

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,threading,datetime,time,base64,xbmc,xbmcplugin,xbmcgui,xbmcaddon,xbmcvfs,itertools
from operator import itemgetter
try:    import json
except: import simplejson as json
try:    import CommonFunctions
except: import commonfunctionsdummy as CommonFunctions
try:    import StorageServer
except: import storageserverdummy as StorageServer
from metahandler import metahandlers
from metahandler import metacontainers
# from resources.lib.libraries.client import OroroAPI
from ororoAPI import OroroAPI
from contextMenu import contextMenu
from subtitles import subtitles

action              = None
common              = CommonFunctions
metaget             = metahandlers.MetaData(preparezip=False)
language            = xbmcaddon.Addon().getLocalizedString
setSetting          = xbmcaddon.Addon().setSetting
getSetting          = xbmcaddon.Addon().getSetting
addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")
addonFullId         = addonName + addonVersion
addonDesc           = language(30450).encode("utf-8")

cache               = StorageServer.StorageServer(addonFullId,1).cacheFunction
cache2              = StorageServer.StorageServer(addonFullId,24).cacheFunction
cache3              = StorageServer.StorageServer(addonFullId,720).cacheFunction

addonIcon           = os.path.join(addonPath,'icon.png')
addonFanart         = os.path.join(addonPath,'fanart.jpg')
addonArt            = os.path.join(addonPath,'resources/art')
addonDownloads      = os.path.join(addonPath,'resources/art/Downloads.png')
addonGenres         = os.path.join(addonPath,'resources/art/Genres.png')
addonNext           = os.path.join(addonPath,'resources/art/Next.png')
dataPath            = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
viewData            = os.path.join(dataPath,'views.cfg')
offData             = os.path.join(dataPath,'offset.cfg')
subData             = os.path.join(dataPath,'subscriptions2.cfg')
favData             = os.path.join(dataPath,'favourites2.cfg')

user                = getSetting("user")
password            = getSetting("password")

API                 = OroroAPI(user, password)

class main:
    def __init__(self):
        global action, content_type
        index().container_data()
        params = {}
        splitparams = sys.argv[2][sys.argv[2].find('?') + 1:].split('&')

        for param in splitparams:
            if (len(param) > 0):
                splitparam = param.split('=')
                key = splitparam[0]
                try:    value = splitparam[1].encode("utf-8")
                except: value = splitparam[1]
                params[key] = value

        try:        action = urllib.unquote_plus(params["action"])
        except:     action = None
        try:        name = urllib.unquote_plus(params["name"])
        except:     name = None
        try:        url = urllib.unquote_plus(params["url"])
        except:     url = None
        try:        page = urllib.unquote_plus(params["page"])
        except:     page = 1
        try:        content_type = urllib.unquote_plus(params["content_type"])
        except:     content_type = None
        try:        image = urllib.unquote_plus(params["image"])
        except:     image = None
        try:        query = urllib.unquote_plus(params["query"])
        except:     query = None
        try:        title = urllib.unquote_plus(params["title"])
        except:     title = None
        try:        year = urllib.unquote_plus(params["year"])
        except:     year = None
        try:        imdb = urllib.unquote_plus(params["imdb"])
        except:     imdb = None
        try:        genre = urllib.unquote_plus(params["genre"])
        except:     genre = None
        try:        plot = urllib.unquote_plus(params["plot"])
        except:     plot = None
        try:        show = urllib.unquote_plus(params["show"])
        except:     show = None
        try:        season = urllib.unquote_plus(params["season"])
        except:     season = None
        try:        episode = urllib.unquote_plus(params["episode"])
        except:     episode = None
        try:        id = urllib.unquote_plus(params["id"])
        except:     id = None
        try:        lang = urllib.unquote_plus(params["lang"])
        except:     lang = None

        if action == None:                          root().get()
        elif action == 'root_movies':               root().get("movies")
        elif action == 'root_shows':                root().get("shows")
        elif action == 'root_search':               root().search()
        elif action == 'item_play':                 contextMenu(index).item_play()
        elif action == 'item_random_play':          contextMenu(index).item_random_play()
        elif action == 'item_queue':                contextMenu(index).item_queue()
        elif action == 'item_play_from_here':       contextMenu(index).item_play_from_here(url)
        elif action == 'favourite_add':             contextMenu(index).favourite_add(favData, id, name, url, image, imdb, year)
        elif action == 'favourite_from_search':     contextMenu(index).favourite_from_search(favData, id, name, url, image, imdb, year)
        elif action == 'favourite_delete':          contextMenu(index).favourite_delete(favData, name, url)
        elif action == 'favourite_moveUp':          contextMenu(index).favourite_moveUp(favData, name, url)
        elif action == 'favourite_moveDown':        contextMenu(index).favourite_moveDown(favData, name, url)
        elif action == 'playlist_open':             contextMenu(index).playlist_open()
        elif action == 'settings_open':             contextMenu(index).settings_open()
        elif action == 'addon_home':                contextMenu(index).addon_home()
        elif action == 'view_tvshows':              contextMenu(index).view('tvshows')
        elif action == 'view_movies':               contextMenu(index).view('movies')
        elif action == 'view_seasons':              contextMenu(index).view('seasons')
        elif action == 'view_episodes':             contextMenu(index).view('episodes')
        elif action == 'metadata_tvshows':          contextMenu(index).metadata('tvshow', name, url, imdb, '', '')
        elif action == 'metadata_tvshows2':         contextMenu(index).metadata2('tvshow', imdb, '', '')
        elif action == 'metadata_movies2':          contextMenu(index).metadata2('movie', imdb, '', '')
        elif action == 'metadata_seasons':          contextMenu(index).metadata2('season', imdb, season, '')
        elif action == 'metadata_episodes':         contextMenu(index).metadata2('episode', imdb, season, episode)
        elif action == 'playcount_tvshows':         contextMenu(index).playcount('tvshow', imdb, '', '')
        elif action == 'playcount_seasons':         contextMenu(index).playcount('season', imdb, season, '')
        elif action == 'playcount_episodes':        contextMenu(index).playcount('episode', imdb, season, episode)
        elif action == 'library_add':               contextMenu(index).library_add(subData, id, name, url, image, imdb, year)
        elif action == 'library_from_search':       contextMenu(index).library_from_search(subData, id, name, url, image, imdb, year)
        elif action == 'library_delete':            contextMenu(index).library_delete(subData, name, url)
        elif action == 'library_update':            contextMenu(index).library_update(subData)
        elif action == 'library_service':           contextMenu(index).library_update(subData, silent=True)
        elif action == 'download':                  contextMenu(index).download(name, url)

        elif action == 'shows_favourites':          favourites().shows()
        elif action == 'shows_subscriptions':       subscriptions().shows()

        elif action == 'shows':                     index().shows()
        elif action == 'movies':                    index().movies()

        elif action == 'movies_title':              index().movies(page=page)
        elif action == 'movies_added':              index().movies('added', page=page)
        elif action == 'movies_release':            index().movies('release', page=page)
        elif action == 'movies_rating':             index().movies('rating', page=page)
        elif action == 'movies_genre':              index().movies('genre', genre, page=page)
        elif action == 'movies_search':             index().movies('search', query, page=page)
        elif action == 'genres_movies':             index().pageList(index().get_genres(index().get_movies()), 'movies')

        elif action == 'shows_title':               index().shows('title')
        elif action == 'shows_release':             index().shows('release')
        elif action == 'shows_rating':              index().shows('rating')
        elif action == 'shows_search':              index().shows('search', query)
        elif action == 'shows_genre':               index().shows('genre', genre)
        elif action == 'genres_shows':              index().pageList(index().get_genres(index().get_shows()), 'shows')

        elif action == 'seasons':                   index().seasons(id)
        elif action == 'episodes':                  index().episodes(id, season)

        elif action == 'play':                      player().run(id, name, url)
        elif action == 'clear_cache':               index().clearCache()

        elif action == 'search':                    subtitles().search(index)
        elif action == 'download_subtitle':         subtitles().download_subtitle(url, lang)

        if action is None:
            pass
        elif action.startswith('shows'):
            xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
            index().container_view('tvshows', {'skin.confluence' : 500})
        elif action.startswith('seasons'):
            xbmcplugin.setContent(int(sys.argv[1]), 'seasons')
            index().container_view('seasons', {'skin.confluence' : 500})
        elif action.startswith('episodes'):
            xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
            index().container_view('episodes', {'skin.confluence' : 504})
        elif action.startswith('movies'):
            xbmcplugin.setContent(int(sys.argv[1]), 'movies')
            index().container_view('movies', {'skin.confluence' : 500})
        xbmcplugin.setPluginFanart(int(sys.argv[1]), addonFanart)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return

class uniqueList(object):
    def __init__(self, list):
        uniqueSet = set()
        uniqueList = []
        for n in list:
            if n not in uniqueSet:
                uniqueSet.add(n)
                uniqueList.append(n)
        self.list = uniqueList

class Thread(threading.Thread):
    def __init__(self, target, *args):
        self._target = target
        self._args = args
        threading.Thread.__init__(self)
    def run(self):
        self._target(*self._args)

class player(xbmc.Player):
    def __init__ (self):
        self.folderPath = xbmc.getInfoLabel('Container.FolderPath')
        self.PseudoTVRunning = index().getProperty('PseudoTVRunning')
        self.loadingStarting = time.time()
        xbmc.Player.__init__(self)

    def run(self, id, name, url, imdb='0'):
        self.video_info(id, name, imdb)

        if self.folderPath.startswith(sys.argv[0]) or self.PseudoTVRunning == 'True':
            item = xbmcgui.ListItem(path=url)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        else:
            try:
                file = self.name + '.strm'
                file = file.translate(None, '\/:*?"<>|')
                if content_type == "movies":
                    meta = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["title", "genre", "year", "rating", "director", "trailer", "tagline", "plot", "plotoutline", "originaltitle", "lastplayed", "playcount", "writer", "studio", "mpaa", "country", "imdbnumber", "runtime", "votes", "fanart", "thumbnail", "file", "sorttitle", "resume", "dateadded"]}, "id": 1}' % (self.year, str(int(self.year)+1), str(int(self.year)-1)))
                    meta = unicode(meta, 'utf-8', errors='ignore')
                    meta = json.loads(meta)
                    meta = meta['result']['movies']
                    self.meta = [i for i in meta if i['file'].endswith(file)][0]
                    meta = {'title': self.meta['title'], 'originaltitle': self.meta['originaltitle'], 'year': self.meta['year'], 'genre': str(self.meta['genre']).replace("[u'", '').replace("']", '').replace("', u'", ' / '), 'director': str(self.meta['director']).replace("[u'", '').replace("']", '').replace("', u'", ' / '), 'country': str(self.meta['country']).replace("[u'", '').replace("']", '').replace("', u'", ' / '), 'rating': self.meta['rating'], 'votes': self.meta['votes'], 'mpaa': self.meta['mpaa'], 'duration': self.meta['runtime'], 'trailer': self.meta['trailer'], 'writer': str(self.meta['writer']).replace("[u'", '').replace("']", '').replace("', u'", ' / '), 'studio': str(self.meta['studio']).replace("[u'", '').replace("']", '').replace("', u'", ' / '), 'tagline': self.meta['tagline'], 'plotoutline': self.meta['plotoutline'], 'plot': self.meta['plot']}
                    poster = self.meta['thumbnail']

                else:
                    meta = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": {"filter":{"and": [{"field": "season", "operator": "is", "value": "%s"}, {"field": "episode", "operator": "is", "value": "%s"}]}, "properties": ["title", "plot", "votes", "rating", "writer", "firstaired", "playcount", "runtime", "director", "productioncode", "season", "episode", "originaltitle", "showtitle", "lastplayed", "fanart", "thumbnail", "file", "resume", "tvshowid", "dateadded", "uniqueid"]}, "id": 1}' % (self.season, self.episode))
                    meta = unicode(meta, 'utf-8', errors='ignore')
                    meta = json.loads(meta)
                    meta = meta['result']['episodes']
                    self.meta = [i for i in meta if i['file'].endswith(file)][0]
                    meta = {'title': self.meta['title'], 'tvshowtitle': self.meta['showtitle'], 'season': self.meta['season'], 'episode': self.meta['episode'], 'writer': str(self.meta['writer']).replace("[u'", '').replace("']", '').replace("', u'", ' / '), 'director': str(self.meta['director']).replace("[u'", '').replace("']", '').replace("', u'", ' / '), 'rating': self.meta['rating'], 'duration': self.meta['runtime'], 'premiered': self.meta['firstaired'], 'plot': self.meta['plot']}
                    poster = self.meta['thumbnail']
            except:
                meta = {'label': self.name, 'title': self.name}
                poster = ''

            item = xbmcgui.ListItem(path=url, iconImage="DefaultVideo.png", thumbnailImage=poster)
            item.setInfo( type="Video", infoLabels= meta )
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

        for i in range(0, 250):
            try: self.totalTime = self.getTotalTime()
            except: self.totalTime = 0
            if not self.totalTime == 0: continue
            xbmc.sleep(1000)
        if self.totalTime == 0: return

        while True:
            try: self.currentTime = self.getTime()
            except: break
            xbmc.sleep(1000)

    def video_info(self, id, name, imdb):
        if content_type == "movies":
            self.name = name
            self.content = 'movie'
            self.title = self.name.rsplit(' (', 1)[0].strip()
            self.year = '%04d' % int(self.name.rsplit(' (', 1)[-1].split(')')[0])
            if imdb == '0': imdb = metaget.get_meta('movie', self.title, year=str(self.year))['imdb_id']
            self.imdb = re.sub('[^0-9]', '', imdb)
            self.subtitle = subtitles().autodownload_subtitles(index, id, name, 'movie')
        else:
            self.name = name
            self.content = 'episode'
            self.show = self.name.rsplit(' ', 1)[0]
            if imdb == '0': imdb = metaget.get_meta('tvshow', self.show)['imdb_id']
            self.imdb = re.sub('[^0-9]', '', imdb)
            self.season = '%01d' % int(name.rsplit(' ', 1)[-1].split('S')[-1].split('E')[0])
            self.episode = '%01d' % int(name.rsplit(' ', 1)[-1].split('E')[-1])
            self.subtitle = subtitles().autodownload_subtitles(index, id, name, 'tvshow')

    def container_refresh(self):
        try:
            params = {}
            query = self.folderPath[self.folderPath.find('?') + 1:].split('&')
            for i in query: params[i.split('=')[0]] = i.split('=')[1]
            if not params["action"].endswith('_search'): index().container_refresh()
        except:
            pass

    def offset_add(self):
        try:
            file = xbmcvfs.File(offData)
            read = file.read()
            file.close()
            write = [i.strip('\n').strip('\r') for i in read.splitlines(True) if i.strip('\r\n')]
            write.append('"%s"|"%s"|"%s"' % (self.name, self.imdb, self.currentTime))
            write = '\r\n'.join(write)
            file = xbmcvfs.File(offData, 'w')
            file.write(str(write))
            file.close()
        except:
            return

    def offset_delete(self):
        try:
            file = xbmcvfs.File(offData)
            read = file.read()
            file.close()
            write = [i.strip('\n').strip('\r') for i in read.splitlines(True) if i.strip('\r\n')]
            write = [i for i in write if not '"%s"|"%s"|"' % (self.name, self.imdb) in i]
            write = '\r\n'.join(write)
            file = xbmcvfs.File(offData, 'w')
            file.write(str(write))
            file.close()
        except:
            return

    def offset_read(self):
        try:
            self.offset = '0'
            file = xbmcvfs.File(offData)
            read = file.read()
            file.close()
            read = [i for i in read.splitlines(True) if '"%s"|"%s"|"' % (self.name, self.imdb) in i][0]
            self.offset = re.compile('".+?"[|]".+?"[|]"(.+?)"').findall(read)[0]
        except:
            return

    def change_watched(self):
        if content_type == "movies":
            try:
                xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.SetMovieDetails", "params": {"movieid" : %s, "playcount" : 1 }, "id": 1 }' % str(self.meta['movieid']))
            except:
                metaget.change_watched(self.content, '', self.imdb, season='', episode='', year='', watched=7)
        else:
            try:
                xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.SetEpisodeDetails", "params": {"episodeid" : %s, "playcount" : 1 }, "id": 1 }' % str(self.meta['episodeid']))
            except:
                metaget.change_watched(self.content, '', self.imdb, season=self.season, episode=self.episode, year='', watched=7)

    def resume_playback(self):
        offset = float(self.offset)
        if not offset > 0: return
        minutes, seconds = divmod(offset, 60)
        hours, minutes = divmod(minutes, 60)
        offset_time = '%02d:%02d:%02d' % (hours, minutes, seconds)
        yes = index().yesnoDialog('%s %s' % (language(30350).encode("utf-8"), offset_time), '', self.name, language(30351).encode("utf-8"), language(30352).encode("utf-8"))
        if yes: self.seekTime(offset)

    def onPlayBackStarted(self):
        try: self.setSubtitles(self.subtitle)
        except: pass

        if self.PseudoTVRunning == 'True': return

        if getSetting("playback_info") == 'true':
            elapsedTime = '%s %.2f seconds' % (language(30319).encode("utf-8"), (time.time() - self.loadingStarting))
            index().infoDialog(elapsedTime, header=self.name)

        if getSetting("resume_playback") == 'true':
            self.offset_read()
            self.resume_playback()

    def onPlayBackEnded(self):
        if self.PseudoTVRunning == 'True': return
        self.change_watched()
        self.offset_delete()
        self.container_refresh()

    def onPlayBackStopped(self):
        if self.PseudoTVRunning == 'True': return
        if self.currentTime / self.totalTime >= .9:
            self.change_watched()
        self.offset_delete()
        self.offset_add()
        self.container_refresh()


class index:
    def clearCache(self):
        try:
            StorageServer.StorageServer(addonFullId,1).delete("%")
            StorageServer.StorageServer(addonFullId,24).delete("%")
            StorageServer.StorageServer(addonFullId,720).delete("%")
            self.okDialog("The commoncache has been cleared.", "")
        except:
            self.okDialog("The commoncache could not be cleared. Please try again.", "")

    def infoDialog(self, str, header=addonName):
        try: xbmcgui.Dialog().notification(header, str, addonIcon, 3000, sound=False)
        except: xbmc.executebuiltin("Notification(%s,%s, 3000, %s)" % (header, str, addonIcon))

    def okDialog(self, str1, str2, header=addonName):
        xbmcgui.Dialog().ok(header, str1, str2)

    def selectDialog(self, list, header=addonName):
        select = xbmcgui.Dialog().select(header, list)
        return select

    def yesnoDialog(self, str1, str2, header=addonName, str3='', str4=''):
        answer = xbmcgui.Dialog().yesno(header, str1, str2, '', str4, str3)
        return answer

    def getProperty(self, str):
        property = xbmcgui.Window(10000).getProperty(str)
        return property

    def setProperty(self, str1, str2):
        xbmcgui.Window(10000).setProperty(str1, str2)

    def clearProperty(self, str):
        xbmcgui.Window(10000).clearProperty(str)

    def addon_status(self, id):
        check = xbmcaddon.Addon(id=id).getAddonInfo("name")
        if not check == addonName: return True

    def container_refresh(self):
        xbmc.executebuiltin("Container.Refresh")

    def container_data(self):
        if not xbmcvfs.exists(dataPath):
            xbmcvfs.mkdir(dataPath)
        if not xbmcvfs.exists(favData):
            file = xbmcvfs.File(favData, 'w')
            file.write('')
            file.close()
        if not xbmcvfs.exists(subData):
            file = xbmcvfs.File(subData, 'w')
            file.write('')
            file.close()
        if not xbmcvfs.exists(viewData):
            file = xbmcvfs.File(viewData, 'w')
            file.write('')
            file.close()
        if not xbmcvfs.exists(offData):
            file = xbmcvfs.File(offData, 'w')
            file.write('')
            file.close()

    def container_view(self, content, viewDict):
        try:
            skin = xbmc.getSkinDir()
            file = xbmcvfs.File(viewData)
            read = file.read().replace('\n','')
            file.close()
            view = re.compile('"%s"[|]"%s"[|]"(.+?)"' % (skin, content)).findall(read)[0]
            xbmc.executebuiltin('Container.SetViewMode(%s)' % str(view))
        except:
            try:
                id = str(viewDict[skin])
                xbmc.executebuiltin('Container.SetViewMode(%s)' % id)
            except:
                pass

    def rootList(self, rootList):
        total = len(rootList)
        for i in rootList:
            try:
                name = language(i['name']).encode("utf-8")
                image = '%s/%s' % (addonArt, i['image'])
                action = i['action']
                u = '%s?action=%s' % (sys.argv[0], action)

                cm = []
                cm.append((language(30425).encode("utf-8"), 'RunPlugin(%s?action=library_update)' % (sys.argv[0])))

                item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=image)
                item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "Plot": addonDesc } )
                item.setProperty("Fanart_Image", addonFanart)
                item.addContextMenuItems(cm, replaceItems=False)
                if action == "clear_cache":
                    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=False)
                else:
                    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)
            except:
                pass

    def get_genres(self, list):
        workaround = [] #used to track already existing genres in genres array

        genres = []
        for content in list:
            for genre in content['genres']:
                if genre not in workaround:
                    genres.append({'name': genre, 'image': addonGenres.encode('utf-8')})
                    workaround.append(genre)

        return genres

    def pageList(self, pageList, content_type):
        if pageList == None: return

        total = len(pageList)
        for i in pageList:
            try:
                name, image = i['name'], i['image']
                sysname, sysimage = urllib.quote_plus(name), urllib.quote_plus(image)

                u = '%s?action=%s_genre&genre=%s' % (sys.argv[0], content_type, sysname)

                item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=image)
                item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "Plot": addonDesc } )
                item.setProperty("Fanart_Image", addonFanart)
                item.addContextMenuItems([], replaceItems=False)
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)
            except:
                pass

    def downloadList(self):
        u = getSetting("downloads")
        if u == '': return
        name, image = language(30363).encode("utf-8"), addonDownloads

        item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=image)
        item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "Plot": addonDesc } )
        item.setProperty("Fanart_Image", addonFanart)
        item.addContextMenuItems([], replaceItems=False)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,isFolder=True)


    def fetch_movies(self):
        list = []
        try:
            movies = json.loads(API.movies_list())
            for raw_movie in movies['movies']:
                subtitles = []
                for subtitle in raw_movie['subtitles']:
                    subtitles.append({
                        'lang': subtitle['lang'],
                        'url': API.protocol + API.url + subtitle['url']
                    })

                movie = {
                    'id': raw_movie['id'],
                    'name': '%s (%s)' % (raw_movie['name'], raw_movie['year']),
                    'url': API.api_with_credentials_url() + '/movies/%d' % raw_movie['id'],
                    'download_url': API.protocol + API.api_url() + '/movies/%d' % raw_movie['id'],
                    'poster': API.protocol + API.url + raw_movie['poster_thumb'],
                    'imdb_id': raw_movie['imdb_id'],
                    'imdb_rating': raw_movie['imdb_rating'],
                    'updated_at': raw_movie['updated_at'],
                    'genre': ', '.join(raw_movie['array_genres']),
                    'genres': raw_movie['array_genres'],
                    'year': raw_movie['year'],
                    'desc': raw_movie['desc'],
                    'subtitles': subtitles
                }

                list.append(movie)
        except:
            pass

        return list

    def get_movies(self):
        return cache(self.fetch_movies)

    def movies(self, sort_by='title', search_query=None, page=1):
        movie_list = self.get_movies()

        if sort_by =='release':
            movie_list = sorted(movie_list, key=itemgetter('year'), reverse=True)
        if sort_by == 'added':
            movie_list = sorted(movie_list, key=itemgetter('updated_at'), reverse=True)
        if sort_by == 'rating':
            movie_list = sorted(movie_list, key=itemgetter('imdb_rating'), reverse=True)
        if sort_by == 'genre':
            movie_list = [i for i in movie_list if search_query in i['genres']]
        if sort_by == 'search':
            if search_query is None:
                search_query = common.getUserInput(language(30362).encode("utf-8"), '')
            if not (search_query is None or search_query == ''):
                search_query = search_query.split(' ')
                movie_list = [i for i in movie_list if all(x.lower() in i['name'].lower() for x in search_query)]


        self.movieList(movie_list, None, "_title", page)

    def movieList(self, movieList, X, list, page=1):
        if movieList == None: return
        page = int(page)
        numResults = 15
        if not page == 1: start = int((numResults * page) - numResults)
        else: start = 0
        end = int(start + numResults)

        getmeta = False
        # getmeta = getSetting("meta")
        #if action == 'movies_search': getmeta = ''

        import math
        total = len(movieList)
        #end = total
        numPages = int(math.ceil(total / float(numResults)))
        nextPage = page + 1

        for i in range(start, end):
            try:
                name = movieList[i]['name']
                url = movieList[i]['url']#API.protocol + API.api_url() + '/movies/%d' % movieList[i]['id']
                download_url = movieList[i]['download_url']
                image = movieList[i]['poster']
                year = movieList[i]['year']
                imdb = movieList[i]['imdb_id']
                genre = movieList[i]['genre']
                plot = movieList[i]['desc']
                if plot == '': plot = addonDesc
                if genre == '': genre = ' '
                title = name.rsplit(' (', 1)[0].strip()

                sysid = movieList[i]['id'] #urllib.quote_plus(movieList[i]['id'])
                sysname, sysurl, sysimage, sysyear, sysimdb, sysgenre, sysplot, sysdownloadurl = urllib.quote_plus(name), urllib.quote_plus(url), urllib.quote_plus(image), urllib.quote_plus(year), urllib.quote_plus(imdb), urllib.quote_plus(genre), urllib.quote_plus(plot), urllib.quote_plus(download_url)
                u = '%s?action=play&id=%s&name=%s&url=%s&content_type=movies&imdb=%s&year=%s&t=%s' % (sys.argv[0], sysid, sysname, sysurl, sysimdb, sysyear, datetime.datetime.now().strftime("%Y%m%d%H%M%S%f"))

                if getmeta == 'true':
                    #if imdb == '0': imdb = metaget.get_meta('movie', title, year=str(year))['imdb_id']
                    #meta = metaget.get_meta('movie', title, imdb_id=imdb)
                    meta = metaget.get_meta('movie', title, year=str(year))

                    imdb = meta['imdb_id']
                    #meta.update({'playcount': 0, 'overlay': 0})
                    playcountMenu = language(30407).encode("utf-8")
                    if meta['overlay'] == 6: playcountMenu = language(30408).encode("utf-8")
                    metaimdb = urllib.quote_plus(re.sub('[^0-9]', '', meta['imdb_id']))
                    trailer, poster = urllib.quote_plus(meta['trailer_url']), meta['cover_url']
                    #if banner == '': banner = poster
                    #if banner == '': banner = image
                    if trailer == '': trailer = sysurl
                    if poster == '': poster = image
                else:
                    meta = {'label': title, 'title': title, 'year': year, 'imdb_id' : imdb, 'genre' : genre, 'plot': plot}
                    trailer, poster = sysurl, image
                if getmeta == 'true' and getSetting("fanart") == 'true':
                    fanart = meta['backdrop_url']
                    if fanart == '': fanart = addonFanart
                else:
                    fanart = addonFanart


                meta.update({'art(poster)': poster})

                cm = []
                cm.append((language(30401).encode("utf-8"), 'RunPlugin(%s?action=item_play)' % (sys.argv[0])))
                cm.append((language(30434).encode("utf-8"), 'Action(Info)'))

                if getmeta == 'true' and list != "_search": cm.append((language(30415).encode("utf-8"), 'RunPlugin(%s?action=metadata_movies2&imdb=%s)' % (sys.argv[0], metaimdb)))
                #cm.append((language(30435).encode("utf-8"), 'RunPlugin(%s?action=view_movies)' % (sys.argv[0])))
                cm.append((language(30409).encode("utf-8"), 'RunPlugin(%s?action=settings_open)' % (sys.argv[0])))
                cm.append((language(30410).encode("utf-8"), 'RunPlugin(%s?action=playlist_open)' % (sys.argv[0])))
                cm.append((language(30411).encode("utf-8"), 'RunPlugin(%s?action=addon_home)' % (sys.argv[0])))
                cm.append((language(30406).encode("utf-8"), 'RunPlugin(%s?action=download&name=%s&url=%s)' % (sys.argv[0], sysname, sysdownloadurl)))
                item = xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=poster)
                item.setInfo( type="Video", infoLabels = meta )
                item.setProperty("IsPlayable", "true")
                item.setProperty("Video", "true")
                item.setProperty("art(poster)", poster)
                item.setProperty("Fanart_Image", fanart)
                item.addContextMenuItems(cm, replaceItems=True)
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=numResults,isFolder=False)
            except:
                pass

        if page != numPages and numPages > 1:
            name, page, image = language(30361).encode("utf-8"), page, addonNext
            page = int(page + 1)

            if list == "":
                sysurl = urllib.quote_plus(X)
                u = '%s?action=movies%s&page=%d&url=%s' % (sys.argv[0], list, page, sysurl)
            elif list == "_search":
                query = urllib.quote_plus(X)
                u = '%s?action=movies%s&page=%d&query=%s' % (sys.argv[0], list, page, query)
            else: u = '%s?action=movies%s&page=%d' % (sys.argv[0], list, page)

            item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=image)
            item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "Plot": addonDesc } )
            item.setProperty("Fanart_Image", addonFanart)
            item.addContextMenuItems([], replaceItems=False)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,isFolder=True)

    def request_shows(self):
        list = []
        try:
            shows = json.loads(API.shows_list())

            for raw_show in shows['shows']:
                show = {
                    'id': raw_show['id'],
                    'name': raw_show['name'],
                    'url': '%d/%s' % (raw_show['id'], raw_show['name']), # not rly used. just workaround.
                    'image': API.protocol + API.url + raw_show['poster_thumb'],
                    'year': raw_show['year'],
                    'imdb': raw_show['imdb_id'],
                    'genre': ', '.join(raw_show['array_genres']),
                    'genres': raw_show['array_genres'],
                    'plot': raw_show['desc'],
                    'title': raw_show['name'],
                    'newest_video': raw_show['newest_video'],
                    'imdb_rating': raw_show['imdb_rating']
                }

                list.append(show)
        except:
            pass

        return list

    def get_shows(self):
        return cache(self.request_shows)

    def sort_shows(self, shows, sort_by='title', search_query=None):
        show_list = shows

        if sort_by =='release':
            show_list = sorted(show_list, key=itemgetter('newest_video'), reverse=True)
        if sort_by == 'title':
            show_list = sorted(show_list, key=itemgetter('name'))
        if sort_by == 'rating':
            show_list = sorted(show_list, key=itemgetter('imdb_rating'), reverse=True)
        if sort_by == 'genre':
            show_list = [i for i in show_list if search_query in i['genres']]
        if sort_by == 'search':
            if search_query is None:
                search_query = common.getUserInput(language(30362).encode("utf-8"), '')
            if not (search_query is None or search_query == ''):
                search_query = search_query.split(' ')
                show_list = [i for i in show_list if all(x.lower() in i['name'].lower() for x in search_query)]

        return show_list

    def shows(self, sort_by='title', search_query=None):
        show_list = self.get_shows()
        show_list = self.sort_shows(show_list, sort_by, search_query)
        self.showList(show_list)

    def showList(self, showList):
        if showList == None: return

        # getmeta = getSetting("meta")
        getmeta = False

        file = xbmcvfs.File(favData)
        favRead = file.read()
        file.close()
        file = xbmcvfs.File(subData)
        subRead = file.read()
        file.close()

        total = len(showList)

        for show in showList:
            try:
                sysname = urllib.quote_plus(show['name'])
                sysurl = urllib.quote_plus(show['url'])
                sysimage = urllib.quote_plus(show['image'])
                sysyear = urllib.quote_plus(show['year'])
                sysimdb = urllib.quote_plus(show['imdb'])
                sysgenre = urllib.quote_plus(show['genre'])
                sysplot = urllib.quote_plus(show['plot'])

                u = '%s?action=seasons&id=%s' % (sys.argv[0], show['id'])

                if getmeta == 'true':
                    meta = metaget.get_meta('tvshow', sysname)#show['title'])
                    imdb = meta['imdb_id']
                    meta.update({'playcount': 0, 'overlay': 0})
                    playcountMenu = language(30407).encode("utf-8")
                    if meta['overlay'] == 6: playcountMenu = language(30408).encode("utf-8")
                    metaimdb = urllib.quote_plus(re.sub('[^0-9]', '', meta['imdb_id']))
                    poster, banner = meta['cover_url'], meta['banner_url']
                    if banner == '': banner = poster
                    if banner == '': banner = image
                    if poster == '': poster = image
                else:
                    meta = {'label': show['title'], 'title': show['title'], 'tvshowtitle': show['title'], 'year' : show['year'], 'imdb_id' : show['imdb'], 'genre' : show['genre'], 'plot': show['plot']}
                    poster, banner = show['image'], show['image']
                if getmeta == 'true' and getSetting("fanart") == 'true':
                    fanart = meta['backdrop_url']
                    if fanart == '': fanart = addonFanart
                else:
                    fanart = addonFanart

                meta.update({'art(banner)': banner, 'art(poster)': poster})
                cm = []
                cm.append((language(30401).encode("utf-8"), 'RunPlugin(%s?action=item_play)' % (sys.argv[0])))
                cm.append((language(30413).encode("utf-8"), 'Action(Info)'))
                if action == 'shows_favourites':
                    if getmeta == 'true': cm.append((language(30415).encode("utf-8"), 'RunPlugin(%s?action=metadata_tvshows&name=%s&url=%s&imdb=%s)' % (sys.argv[0], sysname, sysurl, metaimdb)))
                    #if getmeta == 'true': cm.append((playcountMenu, 'RunPlugin(%s?action=playcount_tvshows&imdb=%s)' % (sys.argv[0], metaimdb)))
                    if not '"%s"' % show['url'] in subRead: cm.append((language(30423).encode("utf-8"), 'RunPlugin(%s?action=library_add&id=%sname=%s&imdb=%s&url=%s&image=%s&year=%s)' % (sys.argv[0], show['id'], sysname, sysimdb, sysurl, sysimage, sysyear)))
                    else: cm.append((language(30424).encode("utf-8"), 'RunPlugin(%s?action=library_delete&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
                    cm.append((language(30429).encode("utf-8"), 'RunPlugin(%s?action=view_tvshows)' % (sys.argv[0])))
                    if getSetting("fav_sort") == '2': cm.append((language(30419).encode("utf-8"), 'RunPlugin(%s?action=favourite_moveUp&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
                    if getSetting("fav_sort") == '2': cm.append((language(30420).encode("utf-8"), 'RunPlugin(%s?action=favourite_moveDown&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
                    cm.append((language(30421).encode("utf-8"), 'RunPlugin(%s?action=favourite_delete&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
                elif action == 'shows_subscriptions':
                    if getmeta == 'true': cm.append((language(30415).encode("utf-8"), 'RunPlugin(%s?action=metadata_tvshows&name=%s&url=%s&imdb=%s)' % (sys.argv[0], sysname, sysurl, metaimdb)))
                    #if getmeta == 'true': cm.append((playcountMenu, 'RunPlugin(%s?action=playcount_tvshows&imdb=%s)' % (sys.argv[0], metaimdb)))
                    if not '"%s"' % show['url'] in subRead: cm.append((language(30423).encode("utf-8"), 'RunPlugin(%s?action=library_add&id=%s&name=%s&imdb=%s&url=%s&image=%s&year=%s)' % (sys.argv[0], show['id'], sysname, sysimdb, sysurl, sysimage, sysyear)))
                    else: cm.append((language(30424).encode("utf-8"), 'RunPlugin(%s?action=library_delete&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
                    cm.append((language(30425).encode("utf-8"), 'RunPlugin(%s?action=library_update)' % (sys.argv[0])))
                    if not '"%s"' % show['url'] in favRead: cm.append((language(30417).encode("utf-8"), 'RunPlugin(%s?action=favourite_add&name=%s&imdb=%s&url=%s&image=%s&year=%s)' % (sys.argv[0], sysname, sysimdb, sysurl, sysimage, sysyear)))
                    else: cm.append((language(30418).encode("utf-8"), 'RunPlugin(%s?action=favourite_delete&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
                    cm.append((language(30429).encode("utf-8"), 'RunPlugin(%s?action=view_tvshows)' % (sys.argv[0])))
                    cm.append((language(30409).encode("utf-8"), 'RunPlugin(%s?action=settings_open)' % (sys.argv[0])))
                elif action.startswith('shows_search'):
                    cm.append((language(30423).encode("utf-8"), 'RunPlugin(%s?action=library_from_search&name=%s&imdb=%s&url=%s&image=%s&year=%s)' % (sys.argv[0], sysname, sysimdb, sysurl, sysimage, sysyear)))
                    cm.append((language(30417).encode("utf-8"), 'RunPlugin(%s?action=favourite_from_search&name=%s&imdb=%s&url=%s&image=%s&year=%s)' % (sys.argv[0], sysname, sysimdb, sysurl, sysimage, sysyear)))
                    cm.append((language(30429).encode("utf-8"), 'RunPlugin(%s?action=view_tvshows)' % (sys.argv[0])))
                    cm.append((language(30409).encode("utf-8"), 'RunPlugin(%s?action=settings_open)' % (sys.argv[0])))
                    cm.append((language(30410).encode("utf-8"), 'RunPlugin(%s?action=playlist_open)' % (sys.argv[0])))
                    cm.append((language(30411).encode("utf-8"), 'RunPlugin(%s?action=addon_home)' % (sys.argv[0])))
                else:
                    if getmeta == 'true': cm.append((language(30415).encode("utf-8"), 'RunPlugin(%s?action=metadata_tvshows2&imdb=%s)' % (sys.argv[0], metaimdb)))
                    if not '"%s"' % show['url'] in subRead: cm.append((language(30423).encode("utf-8"), 'RunPlugin(%s?action=library_add&id=%s&name=%s&imdb=%s&url=%s&image=%s&year=%s)' % (sys.argv[0], show['id'], sysname, sysimdb, sysurl, sysimage, sysyear)))
                    else: cm.append((language(30424).encode("utf-8"), 'RunPlugin(%s?action=library_delete&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
                    if not '"%s"' % show['url'] in favRead: cm.append((language(30417).encode("utf-8"), 'RunPlugin(%s?action=favourite_add&id=%d&name=%s&imdb=%s&url=%s&image=%s&year=%s)' % (sys.argv[0], show['id'], sysname, sysimdb, sysurl, sysimage, sysyear)))
                    else: cm.append((language(30418).encode("utf-8"), 'RunPlugin(%s?action=favourite_delete&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
                    cm.append((language(30429).encode("utf-8"), 'RunPlugin(%s?action=view_tvshows)' % (sys.argv[0])))
                    cm.append((language(30409).encode("utf-8"), 'RunPlugin(%s?action=settings_open)' % (sys.argv[0])))
                    cm.append((language(30410).encode("utf-8"), 'RunPlugin(%s?action=playlist_open)' % (sys.argv[0])))
                    cm.append((language(30411).encode("utf-8"), 'RunPlugin(%s?action=addon_home)' % (sys.argv[0])))

                if action == 'shows_search':
                    if ('"%s"' % show['url'] in favRead and '"%s"' % show['url'] in subRead): suffix = '|F|S| '
                    elif '"%s"' % show['url'] in favRead: suffix = '|F| '
                    elif '"%s"' % show['url'] in subRead: suffix = '|S| '
                    else: suffix = ''
                    show['name'] = suffix + show['name']

                item = xbmcgui.ListItem(show['name'], iconImage="DefaultVideo.png", thumbnailImage=poster)
                item.setInfo( type="Video", infoLabels = meta )
                item.setProperty("IsPlayable", "true")
                item.setProperty("Video", "true")
                item.setProperty("Fanart_Image", fanart)
                item.addContextMenuItems(cm, replaceItems=True)
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)
            except:
                pass

    def get_seasons(self, show_id):
        list = []
        show = json.loads(API.show(show_id))

        try:
            for i in xrange(show['show']['seasons']):
                season = i + 1
                list.append({'name': 'Season %d' % season, 'season': season, 'sort': '%10d' % season, 'imdb': show['show']['imdb_id'], 'title': show['show']['name'], 'show_id': show_id, 'poster': API.protocol + API.url + show['show']['poster']})
        except:
            pass #FIXME: catch exceptions and do something!

        list = sorted(list, key=itemgetter('sort'))
        return list

    def seasons(self, show_id):
        seasons_list = cache(self.get_seasons, show_id)
        self.seasonList(seasons_list)

    def seasonList(self, seasonList):
        if seasonList == None: return
        getmeta = getSetting('meta')
        # getmeta = False
        try:
            # year, imdb, genre, plot, show = seasonList[0]['year'], seasonList[0]['imdb'], seasonList[0]['genre'], seasonList[0]['plot'], seasonList[0]['show']
            imdb = seasonList[0]['imdb']
            show = seasonList[0]['title']
            show_id = seasonList[0]['show_id']
            plot = addonDesc
            genre = ' '


            if getmeta == 'true':
                seasons = []
                for i in seasonList: seasons.append(i['season'])
                season_meta = metaget.get_seasons(show, imdb, seasons)
                meta = metaget.get_meta('tvshow', show, imdb_id=imdb)
                banner = meta['banner_url']
            else:
                meta = {'tvshowtitle': show, 'imdb_id' : imdb, 'genre' : genre, 'plot': plot}
                banner = ''
            if getSetting("meta") == 'true' and getSetting("fanart") == 'true':
                fanart = meta['backdrop_url']
                if fanart == '': fanart = addonFanart
            else:
                fanart = addonFanart
        except:
            return

        total = len(seasonList)
        for i in range(0, int(total)):
            try:
                name = seasonList[i]['name']
                season = seasonList[i]['season']
                image = seasonList[i]['poster']
                u = '%s?action=episodes&id=%s&season=%i' % (sys.argv[0], show_id, season)

                if getSetting("meta") == 'true':
                    meta.update({'playcount': 0, 'overlay': 0})
                    #meta.update({'playcount': season_meta[i]['playcount'], 'overlay': season_meta[i]['overlay']})
                    #poster = season_meta[i]['cover_url']
                    playcountMenu = language(30407).encode("utf-8")
                    if season_meta[i]['overlay'] == 6: playcountMenu = language(30408).encode("utf-8")
                    metaimdb, metaseason = urllib.quote_plus(re.sub('[^0-9]', '', str(season_meta[i]['imdb_id']))), urllib.quote_plus(str(season_meta[i]['season']))
                    poster = image
                    banner = poster
                else:
                    poster, banner = image, image

                meta.update({'label': name, 'title': name, 'art(season.banner)': banner, 'art(season.poster': poster})

                cm = []
                cm.append((language(30401).encode("utf-8"), 'RunPlugin(%s?action=item_play)' % (sys.argv[0])))
                cm.append((language(30404).encode("utf-8"), 'RunPlugin(%s?action=item_queue)' % (sys.argv[0])))
                #cm.append((language(30413).encode("utf-8"), 'Action(Info)'))
                if getSetting("meta") == 'true': cm.append((language(30415).encode("utf-8"), 'RunPlugin(%s?action=metadata_seasons&imdb=%s&season=%s)' % (sys.argv[0], metaimdb, metaseason)))
                #if getSetting("meta") == 'true': cm.append((playcountMenu, 'RunPlugin(%s?action=playcount_seasons&imdb=%s&season=%s)' % (sys.argv[0], metaimdb, metaseason)))
                cm.append((language(30430).encode("utf-8"), 'RunPlugin(%s?action=view_seasons)' % (sys.argv[0])))
                cm.append((language(30409).encode("utf-8"), 'RunPlugin(%s?action=settings_open)' % (sys.argv[0])))
                cm.append((language(30410).encode("utf-8"), 'RunPlugin(%s?action=playlist_open)' % (sys.argv[0])))
                cm.append((language(30411).encode("utf-8"), 'RunPlugin(%s?action=addon_home)' % (sys.argv[0])))

                item = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=poster)
                item.setInfo( type="Video", infoLabels = meta )
                item.setProperty("IsPlayable", "true")
                item.setProperty("Video", "true")
                item.setProperty("Fanart_Image", fanart)
                item.addContextMenuItems(cm, replaceItems=True)
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)
            except:
                pass

    def request_episodes(self, show_id, season):
        list = []

        try:
            show = json.loads(API.show(show_id))
            for episode in show['show']['episodes']:
                if episode['season'] == int(season):
                    episode['ororo_video_url'] = API.api_with_credentials_url() + '/videos/%d' % episode['id']
                    episode['download_url'] = API.protocol + API.api_url() + '/videos/%d' % episode['id']
                    episode['name'] = show['show']['name'] + ' S' + '%02d' % int(season) + 'E' + '%02d' % int(episode['number'])

                    subtitles = []
                    for subtitle in episode['subtitles']:
                        subtitles.append({
                            'lang': subtitle['lang'],
                            'url': API.protocol + API.url + subtitle['url']
                        })

                    list.append(
                        {
                            'id': episode['id'],
                            'name': episode['name'],
                            'url': episode['ororo_video_url'],
                            'download_url': episode['download_url'],
                            'image': ' ',
                            'date': 'year',
                            'year': 'year',
                            'imdb': show['show']['imdb_id'],
                            'tvdb': '0',
                            'genre': 'genre',
                            'plot': episode['plot'],
                            'title': episode['title'],
                            'show': show['show']['name'],
                            'show_alt': show['show']['name'],
                            'season': episode['season'],
                            'episode': episode['number'],
                            'subtitles': subtitles,
                            'sort': '%10d' % int(episode['number'])
                        }
                    )

            list = sorted(list, key=itemgetter('sort'))
        except:
            pass

        return list

    def get_episodes(self, show_id, season):
        return cache(self.request_episodes, show_id, season)

    def episodes(self, show_id, season):
        episodes = self.get_episodes(show_id, season)
        self.episodeList(episodes)

    def episodeList(self, episodeList):
        if episodeList == None: return

        getmeta = getSetting("meta")
        # getmeta = False
        if action == 'episodes_calendar': getmeta = ''

        total = len(episodeList)
        for i in episodeList:
            try:
                name, url, image, date, year, imdb, genre, plot, title, show, season, episode = i['name'], i['url'], i['image'], i['date'], i['year'], i['imdb'], i['genre'], i['plot'], i['title'], i['show'], i['season'], i['episode']
                download_url = i['download_url']
                if plot == '': plot = addonDesc
                if genre == '': genre = ' '

                sysid = i['id']
                sysname = urllib.quote_plus(name)
                systitle = urllib.quote_plus(title)
                sysimdb = urllib.quote_plus(imdb)
                sysyear = urllib.quote_plus(year)
                sysseason = season
                sysepisode = episode
                sysshow = urllib.quote_plus(show)
                sysurl = urllib.quote_plus(url)
                sysdownloadurl = urllib.quote_plus(download_url)
                u = '%s?action=play&id=%s&name=%s&url=%s&content_type=shows&imdb=%s&year=%s&t=%s' % (sys.argv[0], sysid, sysname, sysurl, sysimdb, sysyear, datetime.datetime.now().strftime("%Y%m%d%H%M%S%f"))

                if getmeta == 'true':
                    if imdb == '0': imdb = metaget.get_meta('tvshow', show)['imdb_id']
                    imdb = re.sub('[^0-9]', '', imdb)
                    meta = metaget.get_episode_meta(title, imdb, season, episode)
                    meta.update({'tvshowtitle': show})
                    if meta['title'] == '': meta.update({'title': title})
                    if meta['episode'] == '': meta.update({'episode': episode})
                    if meta['premiered'] == '': meta.update({'premiered': date})
                    if meta['plot'] == '': meta.update({'plot': plot})
                    playcountMenu = language(30407).encode("utf-8")
                    if meta['overlay'] == 6: playcountMenu = language(30408).encode("utf-8")
                    metaimdb, metaseason, metaepisode = urllib.quote_plus(re.sub('[^0-9]', '', str(meta['imdb_id']))), urllib.quote_plus(str(meta['season'])), urllib.quote_plus(str(meta['episode']))
                    label = str(meta['season']) + 'x' + '%02d' % int(meta['episode']) + ' . ' + meta['title']
                    if action == 'episodes_subscriptions': label = show + ' - ' + label
                    poster = meta['cover_url']
                    if poster == '': poster = image
                else:
                    meta = {'label': title, 'title': title, 'tvshowtitle': show, 'season': season, 'episode': episode, 'imdb_id' : imdb, 'year' : year, 'premiered' : date, 'genre' : genre, 'plot': plot}
                    label = season + 'x' + '%02d' % int(episode) + ' . ' + title
                    if action == 'episodes_subscriptions': label = show + ' - ' + label
                    poster = image
                if getmeta == 'true' and getSetting("fanart") == 'true':
                    fanart = meta['backdrop_url']
                    if fanart == '': fanart = addonFanart
                else:
                    fanart = addonFanart

                cm = []
                cm.append((language(30405).encode("utf-8"), 'RunPlugin(%s?action=item_queue)' % (sys.argv[0])))
                cm.append((language(30406).encode("utf-8"), 'RunPlugin(%s?action=download&name=%s&url=%s)' % (sys.argv[0], sysname, sysdownloadurl)))
                cm.append((language(30403).encode("utf-8"), 'RunPlugin(%s?action=item_play_from_here&url=%s)' % (sys.argv[0], sysurl)))
                cm.append((language(30414).encode("utf-8"), 'Action(Info)'))
                if getmeta == 'true': cm.append((language(30415).encode("utf-8"), 'RunPlugin(%s?action=metadata_episodes&imdb=%s&season=%s&episode=%s)' % (sys.argv[0], metaimdb, metaseason, metaepisode)))
                if getmeta == 'true': cm.append((playcountMenu, 'RunPlugin(%s?action=playcount_episodes&imdb=%s&season=%s&episode=%s)' % (sys.argv[0], metaimdb, metaseason, metaepisode)))
                cm.append((language(30431).encode("utf-8"), 'RunPlugin(%s?action=view_episodes)' % (sys.argv[0])))
                cm.append((language(30410).encode("utf-8"), 'RunPlugin(%s?action=playlist_open)' % (sys.argv[0])))
                cm.append((language(30411).encode("utf-8"), 'RunPlugin(%s?action=addon_home)' % (sys.argv[0])))

                item = xbmcgui.ListItem(label, iconImage="DefaultVideo.png", thumbnailImage=poster)
                item.setInfo( type="Video", infoLabels = meta )
                item.setProperty("IsPlayable", "true")
                item.setProperty("Video", "true")
                item.setProperty("Fanart_Image", fanart)
                item.addContextMenuItems(cm, replaceItems=True)
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=False)
            except:
                pass


class subscriptions:
    def __init__(self):
        self.list = []

    def shows(self):
        file = xbmcvfs.File(subData)
        read = file.read()
        file.close()

        match = re.compile('"(.+?)"[|]"(.+?)"[|]"(.+?)"[|]"(.+?)"[|]"(.+?)"[|]"(.+?)"').findall(read)
        for id, name, year, imdb, url, image in match:
            self.list.append({'id': id, 'name': name, 'url': url, 'image': image, 'year': year, 'imdb': imdb, 'genre': '', 'plot': ''})
        self.list = sorted(self.list, key=itemgetter('name'))
        index().showList(self.list)

class favourites:
    def __init__(self):
        self.list = []

    def shows(self):
        file = xbmcvfs.File(favData)
        read = file.read()
        file.close()

        match = re.compile('"(.+?)"[|]"(.+?)"[|]"(.+?)"[|]"(.+?)"[|]"(.+?)"[|]"(.+?)"').findall(read)
        for id, name, year, imdb, url, image in match:
            if getSetting("fav_sort") == '1':
                try: status = metaget.get_meta('tvshow', name, imdb_id=imdb)['status']
                except: status = ''
            else:
                status = ''
            self.list.append({'id': id, 'name': name, 'url': url, 'image': image, 'year': year, 'imdb': imdb, 'genre': '', 'plot': '', 'status': status})

        if getSetting("fav_sort") == '0':
            self.list = sorted(self.list, key=itemgetter('name'))
        elif getSetting("fav_sort") == '1':
            filter = []
            self.list = sorted(self.list, key=itemgetter('name'))
            filter += [i for i in self.list if not i['status'] == 'Ended']
            filter += [i for i in self.list if i['status'] == 'Ended']
            self.list = filter

        index().showList(self.list)

class root:
    def __init__(self):
        if user == '' or password == '': self.openSettings(addonId)
    def get(self, content_type=None):
        rootList = []
        if content_type == "movies":
            rootList.append({'name': 30501, 'image': 'Title.png', 'action': 'movies_title'})
            rootList.append({'name': 30500, 'image': 'Added.png', 'action': 'movies_added'})
            rootList.append({'name': 30502, 'image': 'Release.png', 'action': 'movies_release'})
            rootList.append({'name': 30503, 'image': 'Rating.png', 'action': 'movies_rating'})
            rootList.append({'name': 30504, 'image': 'Genres.png', 'action': 'genres_movies'})
            rootList.append({'name': 30507, 'image': 'Search.png', 'action': 'movies_search'})
        elif content_type == "shows":
            rootList.append({'name': 30501, 'image': 'Title.png', 'action': 'shows_title'})
            rootList.append({'name': 30502, 'image': 'Release.png', 'action': 'shows_release'})
            rootList.append({'name': 30503, 'image': 'Rating.png', 'action': 'shows_rating'})
            rootList.append({'name': 30504, 'image': 'Genres.png', 'action': 'genres_shows'})
            rootList.append({'name': 30505, 'image': 'Favourites.png', 'action': 'shows_favourites'})
            rootList.append({'name': 30506, 'image': 'Subscriptions.png', 'action': 'shows_subscriptions'})
            rootList.append({'name': 30507, 'image': 'Search.png', 'action': 'shows_search'})
        else:
            rootList.append({'name': 30508, 'image': 'Movies.png', 'action': 'root_movies'})
            rootList.append({'name': 30509, 'image': 'Shows.png', 'action': 'root_shows'})
            rootList.append({'name': 30515, 'image': 'Subscriptions.png', 'action': 'clear_cache'})
        index().rootList(rootList)
        index().downloadList()

    def openSettings(self, id=addonId):
        try:
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            xbmc.executebuiltin('Addon.OpenSettings(%s)' % id)
            #xbmc.executebuiltin('SetFocus(%i)' % (2 + 200))
            #xbmc.executebuiltin('SetFocus(%i)' % (3 + 100))
            xbmc.executebuiltin("XBMC.Container.Update(addons://sources/video/,replace)")
        except:
            return

main()
