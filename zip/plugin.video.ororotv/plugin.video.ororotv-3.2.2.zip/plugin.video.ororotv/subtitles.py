# -*- coding: utf-8 -*-

'''
    Copyright (C) 2015 ororo.tv

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import urllib,urllib2,re,os,threading,datetime,time,base64,xbmcaddon,xmlrpclib, xbmc, xbmcplugin, xbmcgui, sys

getSetting          = xbmcaddon.Addon().getSetting
__addon__           = xbmcaddon.Addon()
__scriptid__        = __addon__.getAddonInfo('id')
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (__scriptid__))

class subtitles:
    def get_params(self, string=""):
      param=[]
      if string == "":
        paramstring=sys.argv[2]
      else:
        paramstring=string
      if len(paramstring)>=2:
        params=paramstring
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
          params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
          splitparams={}
          splitparams=pairsofparams[i].split('=')
          if (len(splitparams))==2:
            param[splitparams[0]]=splitparams[1]

      return param

    def autodownload_subtitles(self, index, id, name, contentType):
        if not getSetting("subtitles") == 'true': return

        PreferredSub = xbmc.convertLanguage(getSetting('sublang1'), xbmc.ISO_639_1)

        if contentType == 'movie': # current content type is movie
            movie_list = index().get_movies()
            for movie in movie_list:
                if movie['id'] == int(id):
                    for subtitle in movie['subtitles']:
                        if subtitle['lang'] == PreferredSub:
                            return subtitle['url']

        else:
            tvshow_data = re.search('^(.+) S(\d+)E(\d+)$', name)
            episode = tvshow_data.group(3)
            season = tvshow_data.group(2)
            show_name = tvshow_data.group(1)


            shows = index().get_shows()
            current_show = index().sort_shows(shows, 'search', show_name)[0]
            if current_show == None: return
            episodes = index().get_episodes(current_show['id'], int(season))
            current_episode = episodes[int(episode) - 1]
            for subtitle in current_episode['subtitles']:
                if subtitle['lang'] == PreferredSub:
                    return subtitle['url']


    def search(self, index):
        params = self.get_params()

        if params['action'] == 'search' or params['action'] == 'manualsearch':
            item = {}
            item['temp']               = False
            item['rar']                = False
            item['mansearch']          = False
            item['year']               = xbmc.getInfoLabel("VideoPlayer.Year")                          # Year
            item['season']             = xbmc.getInfoLabel("VideoPlayer.Season")                        # Season
            item['episode']            = xbmc.getInfoLabel("VideoPlayer.Episode")                       # Episode
            item['tvshow']             = xbmc.getInfoLabel("VideoPlayer.TVshowtitle")                   # Show
            item['title']              = xbmc.getInfoLabel("VideoPlayer.OriginalTitle")                 # try to get original title
            item['file_original_path'] = xbmc.Player().getPlayingFile().decode('utf-8')                 # Full path of a playing file
            item['3let_language']      = [] #['scc','eng']


            if item['tvshow'] == '': # current content type is movie
                id = re.search('\/(\d+)', item['file_original_path']).group(1)
                movie_list = index().get_movies()

                for movie in movie_list:
                    if movie['id'] == int(id):
                        for subtitle in movie['subtitles']:
                            url = 'plugin://%s/?action=download_subtitle&url=%s&lang=%s' % (__scriptid__, subtitle['url'], subtitle['lang'])
                            listitem = xbmcgui.ListItem(label=subtitle['lang'], label2=movie['name'], thumbnailImage=subtitle['lang'])
                            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=False)
                        xbmcplugin.endOfDirectory(int(sys.argv[1]))
            else:
                item['episode'] = int(item['episode'])
                shows = index().get_shows()
                current_show = index().sort_shows(shows, 'search', item['tvshow'])[0]
                if current_show == None: return
                episodes = index().get_episodes(current_show['id'], item['season'])
                current_episode = episodes[item['episode'] - 1]
                for subtitle in current_episode['subtitles']:
                    url = 'plugin://%s/?action=download_subtitle&url=%s&lang=%s' % (__scriptid__, subtitle['url'], subtitle['lang'])
                    listitem = xbmcgui.ListItem(label=subtitle['lang'], label2=item['tvshow'], thumbnailImage=subtitle['lang'])
                    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=False)
                xbmcplugin.endOfDirectory(int(sys.argv[1]))


    def download_subtitle(self, url, lang):
        request = urllib2.Request(url)
        request.add_header('User-Agent', 'Kodi (%s)' % xbmcaddon.Addon().getAddonInfo("version"))
        f = urllib2.urlopen(request)
        subtitle = xbmc.translatePath('special://temp/')
        subtitle = os.path.join(subtitle, 'TemporarySubs.%s.srt' % lang)
        content = f.read()
        file = open(subtitle, 'wb')
        file.write(content)
        file.close()

        listitem = xbmcgui.ListItem(label=subtitle)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
