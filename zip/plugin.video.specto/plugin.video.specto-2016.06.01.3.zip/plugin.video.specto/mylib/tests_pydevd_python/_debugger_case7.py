def Call():
    variable_for_test_1 = 10
    variable_for_test_2 = 20
    variable_for_test_3 = 30
    
if __name__ == '__main__':
    Call()
    print('TEST SUCEEDED!')
