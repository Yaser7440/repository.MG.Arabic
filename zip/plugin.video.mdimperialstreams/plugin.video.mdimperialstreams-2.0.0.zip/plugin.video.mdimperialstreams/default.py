import hashlib,os,random,re,requests,shutil,string,sys,urllib
import xbmc,xbmcaddon,xbmcgui,xbmcplugin,xbmcvfs
from addon.common.addon import Addon
from metahandler import metahandlers
from resources.lib import jsunpack
import urlresolver


#Imperial Streams Add-on Created By Mucky Duck (5/2016) completely recoded with new sources 8/16


User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.mdimperialstreams'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
metaset = selfAddon.getSetting('enable_meta')
metaget = metahandlers.MetaData()
show_docs = selfAddon.getSetting('enable_docs')
show_toons = selfAddon.getSetting('enable_toons')
show_tv = selfAddon.getSetting('enable_shows')
show_mov = selfAddon.getSetting('enable_movies')
show_anime = selfAddon.getSetting('enable_anime')
show_adult = selfAddon.getSetting('enable_adult')
baseurl = 'http://megashare.live'
baseurl2 = 'http://episodetube.com'
baseurl3 = 'http://freecartoons.co'
baseurl4 = 'http://documentarystorm.com'
baseurl5 = 'http://watchdocumentary.org'
baseurl6 = 'http://watchfreeanime.org'




############################################################################################################################
############################################################################################################################
###======================================================movies==========================================================###
############################################################################################################################
############################################################################################################################





def CAT():
        if show_docs == 'true':
                addDir('[B][COLOR white]DOCUMENTARIES[/COLOR][/B]','url',60,icon,fanart,'')
        if show_toons == 'true':
                addDir('[B][COLOR white]CARTOONS[/COLOR][/B]','url',40,icon,fanart,'')
        if show_tv == 'true':
                addDir('[B][COLOR white]TV SHOWS[/COLOR][/B]','url',20,art+'TV_SHOWS.png',fanart,'')
        if show_mov == 'true':
                addDir('[B][COLOR white]MOVIES[/COLOR][/B]','url',1,art+'MOVIES.png',fanart,'')
        if show_anime == 'true':
                addDir('[B][COLOR white]ANIME[/COLOR][/B]','url',50,icon,fanart,'')
        setView('files', 'menu-view')




def MOV():
        if show_adult == 'true':
                addDir('[B][COLOR white]Adult (18+) Movies[/COLOR][/B]',baseurl+'/watch-list/adult-18',2,art+'MOVIES.png',art+'1.jpg','')
        addDir('[B][COLOR white]Movies Just Added[/COLOR][/B]',baseurl,2,art+'MOVIES.png',art+'1.jpg','')
        addDir('[B][COLOR white]Search Movies[/COLOR][/B]','url',5,art+'SEARCH_MOVIES.png',art+'1.jpg','')
        addDir('[B][COLOR white]Box Office[/COLOR][/B]',baseurl+'/watch-list/in-theaters',2,art+'BOX_OFFICE.png',art+'1.jpg','')
        addDir('[B][COLOR white]HD Movies[/COLOR][/B]',baseurl+'/watch-quality/hd',2,art+'MOVIES.png',art+'1.jpg','')
        addDir('[B][COLOR white]Popular[/COLOR][/B]',baseurl,4,art+'MOVIES.png',art+'1.jpg','')
        addDir('[B][COLOR white]Genre[/COLOR][/B]',baseurl,3,art+'GENRE.png',art+'1.jpg','')
        setView('files', 'menu-view')




def MINDEX(url):
        link = OPEN_URL(url)
        all_videos = regex_get_all(link, 'class="afis"', '</div>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, 'title="', '"')
                name = addon.unescape(name)
                name = name.encode('ascii', 'ignore').decode('ascii')
                url = regex_from_to(a, 'href="', '"')
                thumb = regex_from_to(a, 'src="', '"')
                if metaset=='true':
                        addDir2('[B][COLOR white]%s[/COLOR][/B]' %name,url,6,thumb,items)
                else:
                        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,6,thumb,art+'1.jpg','')
        try:
                np = re.compile('<li><a href="(.*?)" >Next Page &raquo;</a></li>').findall(link)[0]
                addDir('[I][B][COLOR gold]Go To Next Page>>>[/COLOR][/B][/I]',np,2,art+'next.png',fanart,'')
        except:pass
        setView('movies', 'movie-view')




def POPULARM(url,iconimage):
        link = OPEN_URL(url)
        all_videos = regex_get_all(link, '"widget popular-posts"', '</ul>')
        match=re.compile('<a href="(.*?)" title=".*?" class="wpp-post-title" target="_self">(.*?)</a>').findall(str(all_videos))
        items = len(match)
        for url,name in match:
                name = addon.unescape(name)
                name = name.encode('ascii', 'ignore').decode('ascii')
                if metaset=='true':
                        addDir2('[B][COLOR white]%s[/COLOR][/B]' %name,url,6,iconimage,items)
                else:
                        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,6,iconimage,art+'1.jpg','')
        setView('movies', 'movie-view')




def MGENRE(url):
        link = OPEN_URL(url)
        match=re.compile('<li class="cat-item cat-item-.*?"><a href="(.*?)" >(.*?)</a>').findall(link) 
        for url,name in match:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,2,art+'GENRE.png',art+'1.jpg','')
        setView('files', 'menu-view')




def SEARCHM():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','%20')
                url = baseurl+'/?s='+search
                MINDEX(url)




def RESOLVEM(name,url,iconimage):
        referer = url
        link = OPEN_URL(url)
        request_url = re.findall(r'<iframe.*?src="(.*?)" .*?>', str(link), re.I|re.DOTALL)[0]
        if 'uptovideo' in request_url:
                headers = {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                           'Accept-Encoding':'gzip, deflate, sdch', 'Accept-Language':'en-US,en;q=0.8',
                           'Connection':'keep-alive', 'Referer':referer, 'Upgrade-Insecure-Requests':'1', 'User-Agent': User_Agent}
                link = requests.get(request_url,headers=headers).content
                if jsunpack.detect(link):
                        js_data = jsunpack.unpack(link)
                        match = re.findall('file:"([^"]+)', js_data)
                for url in match:
                        if '/v.mp4' in url:
                                liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
                                liz.setInfo(type='Video', infoLabels={"Title":name,"Plot":description})
                                liz.setProperty("IsPlayable","true")
                                liz.setPath(str(url))
                                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        else:
                url = urlresolver.resolve(request_url)
                
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={"Title":name,"Plot":description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(str(url))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)




############################################################################################################################
############################################################################################################################
###=====================================================tv-shows=========================================================###
############################################################################################################################
############################################################################################################################




def TV():
        addDir('[B][COLOR white]MOST VIEWED EPISODES[/COLOR][/B]',baseurl2+'/?display=tube&filtre=views',21,icon,art+'2.jpg','')
        addDir('[B][COLOR white]NEWLY ADDED SHOWS[/COLOR][/B]',baseurl2+'/?s=',21,art+'New_Tv_Shows.png',art+'2.jpg','')
        addDir('[B][COLOR white]LATEST EPISODES[/COLOR][/B]',baseurl2+'/category/episodes/',21,art+'LATEST_EPISODES.png',art+'2.jpg','')
        addDir('[B][COLOR white]SEARCH[/COLOR][/B]','url',26,art+'SEARCH.png',art+'2.jpg','')
        addDir('[B][COLOR white]GENRE[/COLOR][/B]',baseurl2+'/genres/',24,art+'GENRE.png',art+'2.jpg','')
        addDir('[B][COLOR white]ALL[/COLOR][/B]',baseurl2+'/a-z-series/',25,art+'TV_SHOWS.png',art+'2.jpg','')
        setView('files', 'menu-view')




def TINDEX(url):
        link = OPEN_URL(url)
        all_videos = regex_get_all(link, '<li class="border-radius-5 box-shadow', '</li')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '<span>', '</')
                name = addon.unescape(name)
                name = name.encode('ascii', 'ignore').decode('ascii')
                url = regex_from_to(a, 'href="', '"')
                thumb = regex_from_to(a, 'src="', '"')
                global tv_ep
                tv_ep = regex_from_to(a, 'src=.*?class="', '"')
                if 'attachment' in tv_ep:
                        tv_ep = 'false'
                nono = ['Tags', 'Categories', 'Contact', 'Watch Episode']
                if name not in nono:
                        if metaset=='true':
                                if tv_ep=='false':
                                        addDir3('[B][COLOR white]%s[/COLOR][/B]' %name,url,22,thumb,items,'',name)
                                else:
                                        addDir4('[B][COLOR white]%s[/COLOR][/B]' %name,url,27,thumb,items,'',name)   
                        else:
                                if tv_ep=='false':
                                        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,22,thumb,art+'2.jpg','')
                                else:
                                        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,27,thumb,art+'2.jpg','')
                        
        try:
                np = re.compile('<li><a href="(.*?)">Next &rsaquo;</a></li>').findall(link)[0]
                np.replace('&#038;','&')
                addDir('[I][B][COLOR gold]Go To Next Page>>>[/COLOR][/B][/I]',np,21,art+'next.png',art+'2.jpg','')
        except:pass
        if tv_ep=='false':
                setView('tvshows', 'show-view')
        else:
                setView('episodes', 'epi-view')




def SEA(name,url,iconimage):
        show_title = name
        link = OPEN_URL(url)
        match=re.compile('<th colspan="5".*?><i>(.*?)</i>').findall(link) 
        items = len(match)
        for name in match:
                name = name.replace('Season','[COLOR gold]Season[/COLOR]').strip()
                if metaset=='true':
                        addDir3('[B][COLOR white]%s[/COLOR][/B]' %name,url,23,iconimage,items,'',show_title)
                else:
                        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,23,iconimage,art+'2.jpg','')
        setView('files', 'menu-view')




def EP(name,url,iconimage,show_title):
        sn = name.replace('[B][COLOR white]','').replace('[/COLOR][/B]','').replace('[COLOR gold]Season[/COLOR]','Season')
        if iconimage == None:
                iconimage = icon
        link = OPEN_URL(url)
        all_links = regex_get_all(link, '<th colspan="5".*?><i> %s </i></th></tr>' % sn, '</table>')[0]
        all_links = all_links.replace('\r','').replace('\n','').replace('\t','')
        all_videos = regex_get_all(str(all_links), '<tr>', '</tr>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '<td>.*?</td>.*?</td>.*?</td><td><a.*?>', '</')
                name = addon.unescape(name)
                name = name.encode('ascii', 'ignore').decode('ascii')
                sea = regex_from_to(a, '<td>.*?</td><td.*?><a.*?>', '</')
                epi = regex_from_to(a, '<td>.*?</td>.*?</td><td><a.*?>', '</')
                show_title = regex_from_to(a, 'title="', '"')
                url = regex_from_to(a, 'href="', '"')
                if sn in sea:
                        if metaset=='true':
                                addDir4('[B][COLOR gold]%s[/COLOR] [COLOR white]%s[/COLOR][/B]' %(epi,name),url,27,iconimage,items,'',show_title)
                        else:
                                addDir('[B][COLOR gold]%s[/COLOR] [COLOR white]%s[/COLOR][/B]' %(epi,name),url,27,iconimage,art+'2.jpg','')
        setView('episodes', 'epi-view')




def TGENRE(url):
        link = OPEN_URL(url)
        all_videos = regex_get_all(link, '<li class="border-radius-5 box-shadow', '</li')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '<span>', '</')
                url = regex_from_to(a, 'href="', '"')
                thumb = regex_from_to(a, 'src="', '"')
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,21,thumb,art+'2.jpg','')
        setView('files', 'menu-view')




def TALL(url):
        link = OPEN_URL(url)
        match=re.compile('<a href="(.*?)">(.*?)</a><br').findall(link) 
        for url,name in match:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,22,icon,art+'2.jpg','')
        setView('files', 'menu-view')




def SEARCHT():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = baseurl2+'/?s='+search
                TINDEX(url)



def TRESOLVE(name,url,iconimage):
        link = OPEN_URL(url)
        RequestURL = re.findall(r'<script type="text/javascript" src="(.*?)".*?>', str(link), re.I|re.DOTALL)[0]
        RequestURL = RequestURL.replace('validatehash.php?hashkey=','view.php?ref=')
        headers = {'Referer': url, 'User-Agent': User_Agent}
        link = requests.get(RequestURL, headers=headers, allow_redirects=False).content
        if jsunpack.detect(link):
                js_data = jsunpack.unpack(link)
                url = re.search('"src"\s*,\s*"([^"]+)', js_data)
        host =  url.group(1).replace('http://','').replace('https://','').partition('/')[0]
        headers = {'Host': host, 'Origin': 'http://videomega.tv', 'Referer': RequestURL, 'User-Agent': User_Agent}
        url = url.group(1) + '|' + urllib.urlencode(headers)
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={"Title":name,"Plot":description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(str(url))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)




############################################################################################################################
############################################################################################################################
###=====================================================CARTOONS=========================================================###
############################################################################################################################
############################################################################################################################




def TOONS():
        addDir('[B][COLOR white]REQUESTED[/COLOR][/B]',baseurl3+'/category/list-cartoons-request/',41,icon,art+'3.jpg','')
        addDir('[B][COLOR white]LATEST[/COLOR][/B]',baseurl3,41,icon,art+'3.jpg','')
        addDir('[B][COLOR white]DISNEY[/COLOR][/B]',baseurl3+'/category/disney/',41,icon,art+'3.jpg','')
        addDir('[B][COLOR white]SERIES[/COLOR][/B]',baseurl3+'/tag/series/',41,icon,art+'3.jpg','')
        addDir('[B][COLOR white]MOVIES[/COLOR][/B]',baseurl3+'/category/movie/',41,icon,art+'3.jpg','')
        addDir('[B][COLOR white]SEARCH[/COLOR][/B]','url',45,art+'SEARCH.png',art+'3.jpg','')
        addDir('[B][COLOR white]GENRE[/COLOR][/B]',baseurl3,43,art+'GENRE.png',art+'3.jpg','')
        addDir('[B][COLOR white]YEARS[/COLOR][/B]',baseurl3+'/search-cartoons-movie-by-years/',44,icon,art+'3.jpg','')
        setView('files', 'menu-view')




def CINDEX(url):
        if baseurl3 in url:
                fanart = art+'3.jpg'
        else:
                fanart = art+'4.jpg'
        link = OPEN_URL(url)
        all_videos = regex_get_all(link, '<article', '</article')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, 'rel="bookmark">', '</')
                name = addon.unescape(name)
                name = name.encode('ascii', 'ignore').decode('ascii')
                url = regex_from_to(a, 'href="', '"')
                thumb = regex_from_to(a, 'src="', '"')
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,42,thumb,fanart,'')
        try:
                np = re.compile("<li><a rel='nofollow' href='(.*?)'.*?>(.*?)</a>").findall(link)
                for url, pn in np:
                       if '/page/' in url:
                                if 'class' not in pn:
                                        addDir('[I][B][COLOR gold]Page%s>>>[/COLOR][/B][/I]' %pn,url,41,art+'next.png',fanart,'')
        except:pass
        if baseurl3 in url:
                setView('movies', 'toon-view')
        else:
                setView('movies', 'anime-view')




def CEP(name,url,iconimage):
        if baseurl3 in url:
                fanart = art+'3.jpg'
        else:
                fanart = art+'4.jpg'
        nono = name.replace('[B][COLOR white]','').replace('[/COLOR][/B]','')
        link = OPEN_URL(url)
        all_videos = regex_get_all(link, 'Episode List:', '</ul')
        match=re.compile('<a href="(.*?)" target="_blank" class="link2">(.*?)</a>').findall(str(all_videos))
        for url, name in match:
                if nono in name:
                        name = name.replace(nono,'')
                name = addon.unescape(name)
                name = name.encode('ascii', 'ignore').decode('ascii')
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,46,iconimage,fanart,'')
        try:
                try:
                        pm = re.compile('file:"(.*?)"').findall(link)[0]
                except:
                        pm = re.findall(r'<iframe.*?src="(.*?)".*?>', str(link), re.I|re.DOTALL)[0]
                pm = pm.strip()
                if '/preview'in pm:
                        headers = {'User-Agent':User_Agent}
                        link = requests.get(pm, headers=headers,allow_redirects=False, verify=False).text
                        match=re.compile('"url_encoded_fmt_stream_map","itag\\\u003d.*?\\\u0026url\\\u003d(.*?)%3B').findall(link)[0]
                        pm = urllib.unquote(match)
                        pm = pm.replace('\\u003d','=').replace('\\u0026','&')
                        if 'video/x-flv' in pm:
                                pm = pm.partition('url=')[2]
                if 'google' or 'blogspot' in pm:
                        addDir('[I][B][COLOR gold]Play Movie[/COLOR][/B][/I]',str(pm),100,iconimage,fanart,'')
        except:pass
        if baseurl3 in url:
                setView('movies', 'toon-view')
        else:
                setView('movies', 'anime-view')




def CGENRE(url):
        link = OPEN_URL(url)
        match=re.compile('<li id="menu-item-.*?" class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="(.*?)">(.*?)</a>').findall(link) 
        for url,name in match:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,41,art+'GENRE.png',art+'3.jpg','')
        setView('files', 'menu-view')




def CYEARS(url):
        link = OPEN_URL(url)
        match=re.compile('<a href="(.*?)" title="View all post filed under .*?".*?>(.*?)</a>').findall(link) 
        for url,name in match:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,41,icon,art+'3.jpg','')
        setView('files', 'menu-view')




def SEARCHC():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = baseurl3+'/?s='+search
                CINDEX(url)




def CRESOLVE(name,url,iconimage):
        link = OPEN_URL(url)
        try:
                url = re.compile('file:"(.*?)"').findall(link)[0]
        except:
                url = re.findall(r'<iframe.*?src="(.*?)".*?>', str(link), re.I|re.DOTALL)[0]
        url = url.replace(' ','').replace('\t','').replace('\r','').replace('\n','')
        if '/preview' in url:
                headers = {'User-Agent':User_Agent}
                link = requests.get(url, headers=headers,allow_redirects=False, verify=False).text
                match=re.compile('"url_encoded_fmt_stream_map","itag\\\u003d.*?\\\u0026url\\\u003d(.*?)%3B').findall(link)[0]
                url = urllib.unquote(match)
                url = url.replace('\\u003d','=').replace('\\u0026','&')#.replace('video/x-flv','video/mp4')
                if 'video/x-flv' in url:
                        url = url.partition('url=')[2]
        if 'google' or 'blogspot' in url:
                liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
                liz.setInfo(type='Video', infoLabels={"Title":name,"Plot":description})
                liz.setProperty("IsPlayable","true")
                liz.setPath(str(url))
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)



############################################################################################################################
############################################################################################################################
###======================================================ANIME=======================================================###
############################################################################################################################
############################################################################################################################




def ANIME():
        addDir('[B][COLOR white]ENGLISH SUBBED[/COLOR][/B]',baseurl6+'/category/english-subbed/',41,icon,art+'4.jpg','')
        addDir('[B][COLOR white]ENGLISH DUBBED[/COLOR][/B]',baseurl6+'/english-dubbed/',41,icon,art+'4.jpg','')
        addDir('[B][COLOR white]LATEST ADDED[/COLOR][/B]',baseurl6,41,icon,art+'4.jpg','')
        addDir('[B][COLOR white]SERIES[/COLOR][/B]',baseurl6+'/category/anime-shows/',41,icon,art+'4.jpg','')
        addDir('[B][COLOR white]MOVIES[/COLOR][/B]',baseurl6+'/category/anime-movies/',41,icon,art+'4.jpg','')
        addDir('[B][COLOR white]SEARCH[/COLOR][/B]','url',52,art+'SEARCH.png',art+'4.jpg','')
        addDir('[B][COLOR white]GENRE[/COLOR][/B]',baseurl6,51,art+'GENRE.png',art+'4.jpg','')
        setView('files', 'menu-view')




def AGENRE(url):
        link = OPEN_URL(url)
        match=re.compile('<option class="level-0" value=".*?">(.*?)</option>').findall(link) 
        for name in match:
                g_id = name.partition('&')[0].lower().replace(' ','-')
                name = name.replace('&nbsp;','').upper()
                url = baseurl6 + '/category/%s' %g_id
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,41,art+'GENRE.png',art+'4.jpg','')
        setView('files', 'menu-view')




def SEARCHA():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = baseurl6+'/?s='+search
                CINDEX(url)





############################################################################################################################
############################################################################################################################
###==================================================DOCUMENTARIES=======================================================###
############################################################################################################################
############################################################################################################################




def DOCS():
        addDir('[B][COLOR white]TRENDING DOCUMENTARIES[/COLOR][/B]',baseurl4,62,icon,art+'5.png','')
        addDir('[B][COLOR white]TOP 100 DOCUMENTARIES[/COLOR][/B]',baseurl4+'/top-100-documentary-films/',61,icon,art+'5.png','')
        addDir('[B][COLOR white]NEW ARRIVALS[/COLOR][/B]',baseurl4+'/new-arrivals/',61,icon,art+'5.png','')
        addDir('[B][COLOR white]"SURPRISE ME!"[/COLOR][/B]',baseurl4+'/?random',66,icon,art+'5.png','')
        addDir('[B][COLOR white]RANDOM PICKS[/COLOR][/B]',baseurl4,62,icon,art+'5.png','')
        addDir('[B][COLOR white]TOP RATED[/COLOR][/B]',baseurl4,62,icon,art+'5.png','')
        addDir('[B][COLOR white]SEARCH[/COLOR][/B]','url',65,art+'SEARCH.png',art+'5.png','')
        addDir('[B][COLOR white]GENRE[/COLOR][/B]',baseurl4,63,art+'GENRE.png',art+'5.png','')
        addDir('[B][COLOR white]A/Z[/COLOR][/B]',baseurl4+'/full-documentary-list/',64,icon,art+'5.png','')
        setView('files', 'menu-view')
        



def DINDEX(url):
        link = OPEN_URL(url)
        all_videos = regex_get_all(link, 'class="tile', 'btn-primary btn-block')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '<h1><a href=.*?>', '</')
                name = addon.unescape(name)
                name = name.encode('ascii', 'ignore').decode('ascii')
                url = regex_from_to(a, 'href="', '"')
                thumb = regex_from_to(a, 'src="', '"')
                dis = regex_from_to(a, '<p>', '</p>')
                dis = addon.unescape(dis)
                dis = dis.encode('ascii', 'ignore').decode('ascii')
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,66,thumb,art+'5.png',dis)
        try:
                pn=re.compile("<span class='pages'>(.*?)</span>").findall(link)[0]
                addLink('[COLOR gold]%s[/COLOR]' %pn,'url','',icon,art+'5.png','')
        except: pass
        try:
                np = re.compile('<a class="nextpostslink" rel="next" href="(.*?)">').findall(link)[0]
                addDir('[I][B][COLOR gold]Go To Next Page>>>[/COLOR][/B][/I]',np,61,art+'next.png',art+'5.png','')
        except:pass
        setView('movies', 'doc-view')




def DINDEX2(name,url):
        name = name.replace('[B][COLOR white]','').replace('[/COLOR][/B]','')
        link = OPEN_URL(url)
        link = link.replace('\r','').replace('\n','')
        all_links = regex_get_all(link, '<h1 class="video-row-heading">%s' %name, '</div></div>')
        all_videos = regex_get_all(str(all_links), '"item"', 'btn-primary btn-block')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '<h1><a href=.*?>', '</')
                name = addon.unescape(name)
                name = name.encode('ascii', 'ignore').decode('ascii')
                url = regex_from_to(a, 'href="', '"')
                thumb = regex_from_to(a, 'src="', '"')
                dis = regex_from_to(a, '<p>', '</p>')
                dis = addon.unescape(dis)
                dis = dis.encode('ascii', 'ignore').decode('ascii')
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,66,thumb,art+'5.png',dis)
        try:
                np = re.compile('<div class="siguiente"><a href="(.*?)" >Next').findall(link)[0]
                addDir('[I][B][COLOR gold]Go To Next Page>>>[/COLOR][/B][/I]',np,62,art+'next.png',art+'5.png','')
        except:pass
        setView('movies', 'doc-view')




def DGENRE(url):
        link = OPEN_URL(url)
        match=re.compile('<li class="cat-item cat-item-.*?"><a href="(.*?)" title=".*?">(.*?)</a>').findall(link) 
        for url,name in match:
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,61,art+'GENRE.png',art+'5.png','')
        setView('files', 'menu-view')




def DAZ(url):
        link = OPEN_URL(url)
        match=re.compile('<div class="col-sm-10"><a href="(.*?)" rel="bookmark" title=".*?" class="list-item-title">(.*?)</a></div>').findall(link) 
        for url,name in match:
                name = addon.unescape(name)
                name = name.encode('ascii', 'ignore').decode('ascii')
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,66,icon,art+'5.png','')
        setView('files', 'menu-view')




def SEARCHD():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = baseurl4+'/?s='+search
                DINDEX(url)




def RESOLVED(name,url,iconimage):
        referer = url
        link = OPEN_URL(url)
        request_url = re.findall(r'<iframe.*?src="(.*?)" .*?>', str(link), re.I|re.DOTALL)[0]
        #request_url = 'http://www.snagfilms.com/embed/player?filmId=00000150-ab06-d007-a1d1-af773efc0026'
        #request_url = 'http://www.youtube.com/embed/videoseries?list=PL47058A7AB8DCC0F8'
        #request_url = 'https://www.youtube.com/embed/6qpudAhYhpc'
        request_url = request_url.replace('https:','http:')
        if 'http:' not in request_url:
                request_url = 'http:' + request_url
        if 'uptovideo' in request_url:
                headers = {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                           'Accept-Encoding':'gzip, deflate, sdch', 'Accept-Language':'en-US,en;q=0.8',
                           'Connection':'keep-alive', 'Referer':referer, 'Upgrade-Insecure-Requests':'1', 'User-Agent': User_Agent}
                link = requests.get(request_url,headers=headers).content
                if jsunpack.detect(link):
                        js_data = jsunpack.unpack(link)
                        match = re.findall('file:"([^"]+)', js_data)
                for url in match:
                        if '/v.mp4' in url:
                                liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
                                liz.setInfo(type='Video', infoLabels={"Title":name,"Plot":description})
                                liz.setProperty("IsPlayable","true")
                                liz.setPath(str(url))
                                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        elif 'rtd.rt.com' in request_url:
                link = OPEN_URL(request_url)
                match = re.findall(r"file: '(.*?)'}", str(link), re.I|re.DOTALL)[0]
                if 'https://rtd.rt.com' not in match:
                        match = 'https://rtd.rt.com' + match
                if "' + '" in match:
                        match = match.replace("' + '","")
                url = match
                
        elif 'youtube' in request_url:
                if 'videoseries?list' in request_url:
                        vid_id = request_url.partition('?list=')[2]
                        vid_id = vid_id.partition('?')[0]
                        url = 'plugin://plugin.video.youtube/play/?playlist_id=%s' % vid_id
                else:
                        vid_id = request_url.partition('embed/')[2]
                        vid_id = vid_id.partition('?')[0]
                        url = 'plugin://plugin.video.youtube/play/?video_id=%s' % vid_id

        elif 'snagfilms.com' in request_url:
                link = OPEN_URL(request_url)
                link = link.replace('\t','').replace('\n','').replace('\b','')
                try:
                        url = re.findall(r'file: "(.*?)",                                        label: ".*?"', str(link), re.I|re.DOTALL)[-1]
                except:
                        url = re.findall(r'file: "(.*?)",                                        label: ".*?"', str(link), re.I|re.DOTALL)[0]

        else:
                url = urlresolver.resolve(request_url)
                
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={"Title":name,"Plot":description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(str(url))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
                




############################################################################################################################
############################################################################################################################
###=======================================================END============================================================###
############################################################################################################################
############################################################################################################################





def RESOLVE(name,url,iconimage):
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={"Title":name,"Plot":description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(str(url))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)




def regex_from_to(text, from_string, to_string, excluding=True):
        if excluding:
                try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
                except: r = ''
        else:
                try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
                except: r = ''
        return r




def regex_get_all(text, start_with, end_with):
        r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
        return r




def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def PT(url):
        addon.log('Play Trailer %s' % url)
        notification( addon.get_name(), 'fetching trailer', addon.get_icon())
        xbmc.executebuiltin("PlayMedia(%s)"%url)




def notification(title, message, icon):
        addon.show_small_popup( addon.get_name(), message.title(), 5000, icon)
        return




def addDir(name,url,mode,iconimage,fanart,description):
        name = name.replace('()','')
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title":name,"Plot":description})
        liz.setProperty('fanart_image', fanart)
        if mode==27 or mode==6 or mode==46 or mode==66 or mode==100:
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok




def addDir2(name,url,mode,iconimage,itemcount):
        name = name.replace('[B][COLOR white]','').replace('[/COLOR][/B]','')
        splitName=name.partition('(')
        simplename=""
        simpleyear=""
        if len(splitName)>0:
            simplename=splitName[0]
            simpleyear=splitName[2].partition(')')
        if len(simpleyear)>0:
            simpleyear=simpleyear[0]
        meta = metaget.get_meta('movie',simplename,simpleyear)
        if meta['cover_url']=='':
            try:
                meta['cover_url']=iconimage
            except:
                meta['cover_url']=icon
        name = '[B][COLOR white]' + name + '[/COLOR][/B]'
        meta['title'] = name
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=meta['cover_url'], thumbnailImage=meta['cover_url'])
        liz.setInfo( type="Video", infoLabels= meta )
        contextMenuItems = []
        contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
        if meta['trailer']:
                contextMenuItems.append(('Play Trailer', 'XBMC.RunPlugin(%s)' % addon.build_plugin_url({'mode': 99, 'url':meta['trailer']})))
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        if not meta['backdrop_url'] == '':
                liz.setProperty('fanart_image', meta['backdrop_url'])
        else: liz.setProperty('fanart_image', art+'1.jpg')
        if mode==100 or mode==6:
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
        else:
             ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
        return ok




def addDir3(name,url,mode,iconimage,itemcount,description,show_title):
        show_title = show_title.replace('[B][COLOR white]','').replace('[/COLOR][/B]','')
        try:
                show_title = re.split(r"\(", str(show_title), re.I)[0]
        except: pass
        try:
                show_title = re.split(r" Season ", str(show_title), re.I)[0]
        except: pass
        try:
                show_title = re.split(r"[I]", str(show_title), re.I)[0]
        except: pass
        meta = metaget.get_meta('tvshow',show_title)
        if meta['cover_url']=='':
            try:
                meta['cover_url']=iconimage
            except:
                meta['cover_url']=icon
        meta['title'] = name
        infoLabels = {'rating': meta['rating'],'genre': meta['genre'],'mpaa':"rated %s"%meta['mpaa'],'plot': meta['plot'],'title': meta['title'],'cover_url': meta['cover_url'],'fanart': meta['backdrop_url'],'Episode': meta['episode'],'Aired': meta['premiered']}
        contextMenuItems = []
        contextMenuItems.append(('TV Show Info', 'XBMC.Action(Info)'))
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&show_title="+urllib.quote_plus(show_title)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=meta['cover_url'], thumbnailImage=meta['cover_url'])
        liz.setInfo( type="Video", infoLabels= meta )
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        if not meta['backdrop_url'] == '':
                liz.setProperty('fanart_image', meta['backdrop_url'])
        else:
                liz.setProperty('fanart_image', art+'2.jpg')
        if mode==100 or mode==27:
                liz.setProperty("IsPlayable","true")
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
        else:
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
        return ok




def addDir4(name,url,mode,iconimage,itemcount,description,show_title):
        show_title = show_title.replace('[B][COLOR white]','').replace('[/COLOR][/B]','')
        sea = show_title[-5:-3]
        if '0' in sea[0]:
                sea = sea[1]
        epi = show_title[-2:]
        if '0' in epi[0]:
                 epi = epi[1]
        show_title = show_title[:-6].rstrip()
        meta = metaget.get_episode_meta(show_title,'',sea,epi)
        if meta['cover_url']=='':
            try:
                meta['cover_url']=iconimage
            except:
                meta['cover_url']=icon
        meta['title'] = name
        contextMenuItems = []
        contextMenuItems.append(('TV Show Info', 'XBMC.Action(Info)'))
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&show_title="+urllib.quote_plus(show_title)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=meta['cover_url'], thumbnailImage=meta['cover_url'])
        liz.setInfo( type="Video", infoLabels= meta )
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        if not meta['backdrop_url'] == '':
                liz.setProperty('fanart_image', meta['backdrop_url'])
        else:
                liz.setProperty('fanart_image', art+'2.jpg')
        if mode==100 or mode==27:
                liz.setProperty("IsPlayable","true")
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
        else:
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
        return ok
        



def addLink(name,url,mode,iconimage,fanart,description=''):
        #u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
        #ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok




def OPEN_URL(url):
        headers = {}
        headers['User-Agent'] = User_Agent
        link = requests.get(url, headers=headers).text
        link = link.encode('ascii', 'ignore').decode('ascii')
        return link





def setView(content, viewType):
    ''' Why recode whats allready written and works well,
    Thanks go to Eldrado for it '''
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':

        print addon.get_setting(viewType)
        if addon.get_setting(viewType) == 'Info':
            VT = '504'
        elif addon.get_setting(viewType) == 'Info2':
            VT = '503'
        elif addon.get_setting(viewType) == 'Info3':
            VT = '515'
        elif addon.get_setting(viewType) == 'Fanart':
            VT = '508'
        elif addon.get_setting(viewType) == 'Poster Wrap':
            VT = '501'
        elif addon.get_setting(viewType) == 'Big List':
            VT = '51'
        elif addon.get_setting(viewType) == 'Low List':
            VT = '724'
        elif addon.get_setting(viewType) == 'List':
            VT = '50'
        elif addon.get_setting(viewType) == 'Default Menu View':
            VT = addon.get_setting('default-view1')
        elif addon.get_setting(viewType) == 'Default TV Shows View':
            VT = addon.get_setting('default-view2')
        elif addon.get_setting(viewType) == 'Default Episodes View':
            VT = addon.get_setting('default-view3')
        elif addon.get_setting(viewType) == 'Default Movies View':
            VT = addon.get_setting('default-view4')
        elif addon.get_setting(viewType) == 'Default Docs View':
            VT = addon.get_setting('default-view5')
        elif addon.get_setting(viewType) == 'Default Cartoons View':
            VT = addon.get_setting('default-view6')
        elif addon.get_setting(viewType) == 'Default Anime View':
            VT = addon.get_setting('default-view7')

        print viewType
        print VT
        
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )




params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None
show_title=None




try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:
        description=urllib.unquote_plus(params["description"])
except:
        pass

try:
        show_title=urllib.unquote_plus(params["show_title"])
except:
        pass




if mode==None or url==None or len(url)<1:
        CAT()

elif mode==1:
        MOV()

elif mode==2:
        MINDEX(url)

elif mode==3:
        MGENRE(url)

elif mode==4:
        POPULARM(url,iconimage)

elif mode==5:
        SEARCHM()

elif mode==6:
        RESOLVEM(name,url,iconimage)

elif mode==20:
        TV()

elif mode==21:
        TINDEX(url)

elif mode==22:
        SEA(name,url,iconimage)

elif mode==23:
        EP(name,url,iconimage,show_title)

elif mode==24:
        TGENRE(url)

elif mode==25:
        TALL(url)

elif mode==26:
        SEARCHT()

elif mode==27:
        TRESOLVE(name,url,iconimage)

elif mode==40:
        TOONS()

elif mode==41:
        CINDEX(url)

elif mode==42:
        CEP(name,url,iconimage)

elif mode==43:
        CGENRE(url)

elif mode==44:
        CYEARS(url)

elif mode==45:
        SEARCHC()

elif mode==46:
        CRESOLVE(name,url,iconimage)

elif mode==50:
        ANIME()

elif mode==51:
        AGENRE(url)

elif mode==52:
        SEARCHA()

elif mode==60:
        DOCS()

elif mode==61:
        DINDEX(url)

elif mode==62:
        DINDEX2(name,url)

elif mode==63:
        DGENRE(url)

elif mode==64:
        DAZ(url)

elif mode==65:
        SEARCHD()

elif mode==66:
        RESOLVED(name,url,iconimage)

elif mode==99:
        PT(url)

elif mode==100:
        RESOLVE(name,url,iconimage)
xbmcplugin.endOfDirectory(int(sys.argv[1]))




























































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































