# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys
import urllib,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,xbmcvfs
import requests
import urlresolver
from addon.common.addon import Addon
from addon.common.net import Net

dbg = True # Set to false if you don't want debugging
  
#Common Cache
try:
  import StorageServer
except:
  import storageserverdummy as StorageServer
cache = StorageServer.StorageServer('plugin.video.EL7L')

addon_id='plugin.video.EL7L'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/img/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
show_tv = selfAddon.getSetting('enable_shows')
baseurl = selfAddon.getSetting('base_url')
s = requests.session()
net = Net()
def OPEN_URL(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = requests.get(url, headers=headers).text
    link = link.encode('utf-8')
    return link
            

baseurl = 'http://el7l.me'
####functions

    
def readnet(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      

def CAT():
         addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
         addDir('[B][COLOR white]••البحث••[/COLOR][/B]',baseurl+ '/?s=',103,art+'search.png',fanart,'')
         addDir('[B][COLOR white]••السنة••[/COLOR][/B]','url',104,art+'years.png',fanart,'')
         addDir('[B][COLOR white]••عــــام••[/COLOR][/B]','url',101,art+'GEN.png',fanart,'')		 
         addDir('[B][COLOR white]••قوائم الافلام••[/COLOR][/B]','url',8,art+'Other.png',fanart,'')
         addDir('[B][COLOR white]••أخــر الاضافات••[/COLOR][/B]',baseurl,100,art+'ADD.png',fanart,'')
         #addDir('[B][COLOR white]••عروض أخرى••[/COLOR][/B]','url',102,art+'/showscen.png',fanart,'')
                      

##########################################showscen
def ShowMov():
    addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
    addDir('[B][COLOR white]البحث[/COLOR][/B]',baseurl+ '/?s=',103,art+'search.png',fanart,'')
    addDir('[B][COLOR white]••السنة••[/COLOR][/B]','url',104,art+'years.png',fanart,'')
    addDir('[B][COLOR white]••عــــام••[/COLOR][/B]','url',101,art+'GEN.png',fanart,'')	
    addDir('[B][COLOR white]••أخــر الاضافات••[/COLOR][/B]',baseurl,100,art+'Other.png',fanart,'')
    addDir('[B][COLOR white]••أفــلام عربية••[/COLOR][/B]',baseurl+'/online2/12/_افلام_عربية/1.html',100,art+'AR.png',fanart,'')
    addDir('[B][COLOR white]••أفـــلام أجنبية••[/COLOR][/B]',baseurl+'/online2/415/افلام_اجنبية/1.html',100,art+'2.png',fanart,'')
    addDir('[B][COLOR white]••أفلام هندية••[/COLOR][/B]',baseurl+'/online2/470/افلام_هندية/1.html',100,art+'BLLYOOD.png',fanart,'')
    addDir('[B][COLOR white]••أفلام كرتون••[/COLOR][/B]',baseurl+'/online2/14/_افلام_كارتون/1.html',100,art+'AAAA.png',fanart,'')
    addDir('[B][COLOR white]••مصارعة حرة••[/COLOR][/B]',baseurl+'/online2/246/مصارعة_حرة/1.html',100,art+'WWE.png',fanart,'')
    addDir('[B][COLOR white]••مسرح مصر••[/COLOR][/B]',baseurl+'/online2/482/مسرح_مصر/1.html',100,art+'6.png',fanart,'')
    addDir('[B][COLOR white]••أفلام منوعة للكبــار فقط••[/COLOR][/B]',baseurl+'/online2/469/افلام_اجنبية_للكبار_فقط/1.html',100,art+'XXX.png',fanart,'')
					
def ShowTv():
    addDir('[B][COLOR white]••مسلسلات عربية••[/COLOR][/B]',baseurl+'/category/مسلسلات/مسلسلات-عربي/',200,'img/7.png',1)
    addDir('[B][COLOR white]••مسلسلات اجنبية••[/COLOR][/B]',baseurl+'/category/مسلسلات/مسلسلات-اجنبي/',200,'img/3.png',1)
    addDir('[B][COLOR white]••جميع المسلسلات••[/COLOR][/B]',baseurl+'/category/مسلسلات/',200,'img/3.png',1)	
					
def getgenre_movies(url):
	genres=['افلام+اكشن','افلام+رعب','افلام+رومانسية+وحب','افلام+خيال+علمي','تاريخ','جريمة','حروب','خيال','دراما','افلا+رعب','رومانسي','رياضي','سيرة+ذاتية','عائلي','غموض','فانتازيا','كوميديا','مغامرات','موسيقي','وثائقي']
        for g in genres:
                url= baseurl + '/tag/'+g.lower()+'/'
                print url
                addDir2('[B][COLOR white]••%s••[/COLOR][/B]' %g,url,100,art+'mymovies.png',fanart)					

					
def others(url):					
    addDir('[B][COLOR white]••منوعـــات••[/COLOR][/B]',baseurl+'/category/برامج-تليفزيونية/',200,'img/8.png',1)						
    addDir('[B][COLOR white]••المصـــــارعه••[/COLOR][/B]',baseurl+'/category/رياضة-و-مصارعه/',200,'img/9.png',1)

def getyears_movies(url):
        for i in range(1915,2018):
             addDir2('[B][COLOR white]•• %s ••[/COLOR][/B]' %str(i),baseurl+'/tag/'+str(i)+'+'+'افلام',100,art+'years.png',fanart)					
###################################movies
			  
def search():
        keyb = xbmc.Keyboard('', 'Search MOVIES')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = baseurl+'/?s='+search
                getmovies(url)


                        
               
                   
                
        
def getmovies(url):##movies
        link = readnet(url)
        #link = link.encode('ascii', 'ignore').decode('ascii')
        all_videos = regex_get_all(link, '<div class="file_index">', '</div>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, 'alt="', '"').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('&quot;','"').replace('&#39;',"'").replace('&#039;',"'").replace('&#8211;',"'")
                qual = regex_from_to(a, '<p></p>\s*<p>', '</p>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','').replace('...','').replace('لفيلم','')		
                url = regex_from_to(a, 'href="', '"')		
                thumb = regex_from_to(a, 'src="', '"').replace("(","").replace(")","")             					
                addDir2('[B][COLOR white]%s[/COLOR][/B]:[B][I][COLOR red]%s[/COLOR][/I][/B]' %(name,qual),url,10,thumb,fanart,items)
        try:
                np = re.compile('<a href="(.*?)">&rsaquo;</a>').findall(link)[0]
                addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',np,100,art+'/next.png',fanart,'')
        except: pass
        setView('movies', 'movie-view')

				

                    
###############################################tv shows

def getseries(url):##series
        link = readnet(url)
        #link = link.encode('ascii', 'ignore').decode('ascii')
        all_videos = regex_get_all(link, '<a ', '</div>\s*</div>\s*</a>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '<h3 class="TitlePopover">', '</h3>').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('&quot;','"').replace('&#39;',"'").replace('&#039;',"'").replace('&#8211;',"'")
                qual = regex_from_to(a, '<div class="contentShow">', '</div>').replace('&hellip;','').replace('&#8221;','').replace('&#8220;','').replace('&#8211;','').replace('تحميل','').replace('مباشر','')	
                url = regex_from_to(a, 'href="', '" class="BlockMov">')		
                thumb = regex_from_to(a, 'data-style="background-image:url', ';"').replace("(","").replace(")","")             					
                addDir2('[B][COLOR white]%s[/COLOR][/B]:[B][I][COLOR red]%s[/COLOR][/I][/B]' %(name,qual),url,202,thumb,fanart,items)
        try:
                np = re.compile('<li><a href="(.*?)" >الصفحة التالية &laquo;</a></li>').findall(link)[0]
                addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',np,200,art+'/next.png',fanart,'')
        except: pass
        setView('movies', 'movie-view')

def getepisodes(url):##series
        link = readnet(url)
        #link = link.encode('ascii', 'ignore').decode('ascii')
        all_videos = regex_get_all(link, '<a ', '</div>\s*</div>\s*</a>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '<i class="fa fa-play"></i>\s*', '<time>').replace("مترجم","").replace("&amp;","&").replace('فيلم',"").replace('&quot;','"').replace('&#39;',"'").replace('&#039;',"'").replace('&#8211;',"'")
                qual = regex_from_to(a, '<time>', '</time>')	
                url = regex_from_to(a, 'href="', '" style="font-size: 13px;">')		
                thumb = regex_from_to(a, 'data-style="background-image:url', ';"').replace("(","").replace(")","")             					
                addDir2('[B][COLOR white]%s[/COLOR][/B]:[B][I][COLOR red]%s[/COLOR][/I][/B]' %(name,qual),url,1,thumb,fanart,items)



 


#######################################host resolving                                                    




def getmatch(match):
                if len(match)<1:
                        return
                for href in match:
                    
                    
                    
                    
                     
                    server=href.split("/")[2].replace('www.',"").replace("embed.","").split(".")[0]
                    #if 'hqq' in server or "myvi" in server or 'videomeh' in server:
                            #return
                    addDir(server,href,20,'')
		  
def gethosts2(url):

                url=url.replace("/online/","/play/")
                data=readnet(url)
	        print data
                	
                #regx='''</span><a href='(.+?)' class='redirect_link'>'''
                #regx1='''<iframe src="(.+?)" scrolling="no" frameborder="0" width="700" height="430" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'''
                regx2='''<IFRAME SRC="(.+?)".+?></IFRAME>'''
                
                regx3='''<li><a href="(.+?)" rel="#iframe">'''
                regx4='''<iframe .+? src="(.+?)" ></iframe>'''
                match2 = re.findall(regx2,data, re.M|re.I)
                match3 = re.findall(regx3,data, re.M|re.I)
                match4 = re.findall(regx4,data, re.M|re.I)
                #match5 = re.findall(regx5,data, re.M|re.I)
         
                #getmatch(match1)
                getmatch(match2)
                getmatch(match3)
                getmatch(match4)
                #getmatch(match5)
               
                return


	    
	    
def resolve_host(url):
        url=url.replace("/online/","/play/")
        from urlresolver import resolve
        data=readnet2(url)
        reurl='''<li><a href="http://ok.ru/(.*?)" rel="#iframe">'''
        url='http://ok.ru/'+re.findall(reurl,data, re.M|re.I)[0].split("=")[0]
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(str(stream_link))
            return
	    listItem = xbmcgui.ListItem(path=str(stream_link))
	    xbmcplugin.setResolvedUrl(sys.argv[0], True, listItem)   
        else:
            addDir("Error,"+stream_link,"",9,"") 	    
def resolve_host2(url):#last good
        from urlresolver import resolve
   
        stream_link=str(resolve(url))
        print stream_link
        if not stream_link is None and not 'unresolvable' in stream_link and not stream_link.startswith("Error"):
            playlink(stream_link)  
        else:
            addDir("Error,"+stream_link,"",9,"")
def playlink(stream_link):
            
            xbmc.Player().play(stream_link)
            sys.exit(0)

###functions

def readnet(url):
        import requests
        data=requests.get(url, verify=False)
        return data.content
def readnet2(url):
            
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html	    
def removeunicode(data):
             
             
            
              try:
                    type(data)
                    data=data.decode('unicode_escape').encode('ascii','replace').replace("?","").strip()
        
              except:
                    pass
              
              return data
              
def gethostname(url):
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        
        return query.hostname             
############################################xbmc tools	
def regex_get_all(text, start_with, end_with):
        r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
        return r
 
def regex_from_to(text, from_string, to_string, excluding=True):
	if excluding:
		try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
		except: r = ''
	else:
		try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
		except: r = ''
	return r    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param

def getgroups(data, pattern, grupsNum = 1, ignoreCase = False):
        tab = []
        if ignoreCase:
            match = re.search(pattern, data, re.IGNORECASE)
        else:
            match = re.search(pattern, data)
        
        for idx in range(grupsNum):
            try:
                value = match.group(idx + 1)
            except:
                value = ''

            tab.append(value)

        return tab
def getdata(data, marker1, marker2, withMarkers = True, caseSensitive = True):
        if caseSensitive:
            idx1 = data.find(marker1)
        else:
            idx1 = data.lower().find(marker1.lower())
        if -1 == idx1:
            return (False, '')
        if caseSensitive:
            idx2 = data.find(marker2, idx1 + len(marker1))
        else:
            idx2 = data.lower().find(marker2.lower(), idx1 + len(marker1))
        if -1 == idx2:
            return (False, '')
        if withMarkers:
            idx2 = idx2 + len(marker2)
        else:
            idx1 = idx1 + len(marker1)
        return  data[idx1:idx2]
	
def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
def addDir2(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name })
        liz.setProperty('fanart_image', fanart)        
        liz.setProperty("IsPlayable","true")	
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
def setView(content, viewType):
    ''' Why recode whats allready written and works well,
    Thanks go to Eldrado for it '''
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':

        print addon.get_setting(viewType)
        if addon.get_setting(viewType) == 'Info':
            VT = '504'
        elif addon.get_setting(viewType) == 'Info2':
            VT = '503'
        elif addon.get_setting(viewType) == 'Info3':
            VT = '515'
        elif addon.get_setting(viewType) == 'Fanart':
            VT = '508'
        elif addon.get_setting(viewType) == 'Poster Wrap':
            VT = '501'
        elif addon.get_setting(viewType) == 'Big List':
            VT = '51'
        elif addon.get_setting(viewType) == 'Low List':
            VT = '724'
        elif addon.get_setting(viewType) == 'Default View':
            VT = addon.get_setting('default-view')

        print viewType
        print VT
        
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )

params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)
#################################man
if mode==None or url==None or len(url)<1:
        CAT()

elif mode==8:
        ShowMov()
elif mode==9:
		tarbyat()

elif mode==105:
        ShowTv()
###########################
		
elif mode==1:
        print ""+url
        gethosts(url)
elif mode==10:
        print ""+url
        gethosts2(url)		
elif mode==2:
        print ""+url
        resolve_host(url)
elif mode==20:
        print ""+url
        resolve_host2(url)
elif mode==3:
        print ""+url
        playlink(url)  	
elif mode==100: getmovies(url)
elif mode==101:
        print ""+url
        getgenre_movies('movies')	
elif mode == 102:
		print ""+url
		others('movies')
elif mode==104:
	print ""+url
	
	getyears_movies(name)		
########		
     

elif mode==103: search()    
elif mode==200: getseries(url)	
elif mode==201:
	getseasons(name,url,page)
elif mode==202: getepisodes(url)

################################################tarbyat	
     

# elif mode==30:
        # search(url)                

      
	
	
xbmcplugin.endOfDirectory(int(sys.argv[1]))                              































































































































































































































if xbmcvfs.exists(xbmc.translatePath('special://home/userdata/sources.xml')):
        with open(xbmc.translatePath('special://home/userdata/sources.xml'), 'r+') as f:
                my_file = f.read()
                if re.search(r'http://mg.esy.es/Kodi', my_file):
                        addon.log('===MG.Arabic===Source===Found===in===sources.xml===Not Deleting.===')
                else:
                        line1 = "you have Installed The MDrepo From An"
                        line2 = "Unofficial Source And Will Now Delete Please"
                        line3 = "Install From [COLOR red]http://mg.esy.es/Kodi[/COLOR]"
                        line4 = "Removed Repo And Addon"
                        line5 = "successfully"
                        xbmcgui.Dialog().ok(addon_name, line1, line2, line3)
                        delete_addon = xbmc.translatePath('special://home/addons/'+addon_id)
                        delete_repo = xbmc.translatePath('special://home/addons/repository.mdrepo')
                        shutil.rmtree(delete_addon, ignore_errors=True)
                        shutil.rmtree(delete_repo, ignore_errors=True)
                        dialog = xbmcgui.Dialog()
                        addon.log('===DELETING===ADDON===+===REPO===')
                        xbmcgui.Dialog().ok(addon_name, line4, line5)