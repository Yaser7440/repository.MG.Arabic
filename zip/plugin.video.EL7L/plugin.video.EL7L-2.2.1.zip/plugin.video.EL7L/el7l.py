# -*- coding: utf8 -*-By. MG.Arabic http://mg.esy.es/Kodi/
import sys
import urllib,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,xbmcvfs
##################################
from md_request import get_params
from md_request import decodeHtml
from md_request import OPEN_URL
from md_request import regex_get_all
from md_request import regex_from_to
from md_request import addDir4
from md_request import addDir
from md_request import playlink
from md_request import resolve_host
#------------------------------
from md_view import setView
#------------------------------
try:
    from common import Addon
    from addon.common.net import Net
except:
    print 'Failed to import script.module.mg.arabic.common'
    xbmcgui.Dialog().ok("EL7L Import Failure", "Failed to import addon.common", "A component needed by EL7L is missing on your system") 

addon_id='plugin.video.EL7L'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/img/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
baseurl = 'http://el7l.me'
####functions

      

def CAT():
         addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
         addDir('[B][COLOR white]••البحث••[/COLOR][/B]',baseurl+ '/?s=',103,art+'search.png',fanart,'')
         addDir('[B][COLOR white]••السنة••[/COLOR][/B]','url',104,art+'years.png',fanart,'')
         addDir('[B][COLOR white]••عــــام••[/COLOR][/B]','url',101,art+'GEN.png',fanart,'')		 
         addDir('[B][COLOR white]••قوائم الافلام••[/COLOR][/B]','url',8,art+'Other.png',fanart,'')
         addDir('[B][COLOR white]••أخــر الاضافات••[/COLOR][/B]',baseurl,100,art+'ADD.png',fanart,'')
         #addDir('[B][COLOR white]••عروض أخرى••[/COLOR][/B]','url',102,art+'/showscen.png',fanart,'')
                      

##########################################showscen
def ShowMov():
    addDir('[B][COLOR brown]•••MG.Arabic•••http://mg.esy.es/Kodi/•••[/COLOR][/B]','url','url',fanart,fanart,'')
    addDir('[B][COLOR white]البحث[/COLOR][/B]',baseurl+ '/?s=',103,art+'search.png',fanart,'')
    addDir('[B][COLOR white]••السنة••[/COLOR][/B]','url',104,art+'years.png',fanart,'')
    addDir('[B][COLOR white]••عــــام••[/COLOR][/B]','url',101,art+'GEN.png',fanart,'')	
    addDir('[B][COLOR white]••أخــر الاضافات••[/COLOR][/B]',baseurl,100,art+'Other.png',fanart,'')
    addDir('[B][COLOR white]••أفــلام عربية••[/COLOR][/B]',baseurl+'/online2/12/_افلام_عربية/1.html',100,art+'AR.png',fanart,'')
    addDir('[B][COLOR white]••أفـــلام أجنبية••[/COLOR][/B]',baseurl+'/online2/415/افلام_اجنبية/1.html',100,art+'2.png',fanart,'')
    addDir('[B][COLOR white]••أفلام هندية••[/COLOR][/B]',baseurl+'/online2/470/افلام_هندية/1.html',100,art+'BLLYOOD.png',fanart,'')
    addDir('[B][COLOR white]••أفلام كرتون••[/COLOR][/B]',baseurl+'/online2/14/_افلام_كارتون/1.html',100,art+'AAAA.png',fanart,'')
    addDir('[B][COLOR white]••مصارعة حرة••[/COLOR][/B]',baseurl+'/online2/246/مصارعة_حرة/1.html',100,art+'WWE.png',fanart,'')
    addDir('[B][COLOR white]••مسرح مصر••[/COLOR][/B]',baseurl+'/online2/482/مسرح_مصر/1.html',100,art+'6.png',fanart,'')
    addDir('[B][COLOR white]••أفلام منوعة للكبــار فقط••[/COLOR][/B]',baseurl+'/online2/469/افلام_اجنبية_للكبار_فقط/1.html',100,art+'XXX.png',fanart,'')
					
	
					
def getgenre_movies(url):
	genres=['افلام+اكشن','افلام+رعب','افلام+رومانسية+وحب','افلام+خيال+علمي','تاريخ','جريمة','حروب','خيال','دراما','افلا+رعب','رومانسي','رياضي','سيرة+ذاتية','عائلي','غموض','فانتازيا','كوميديا','مغامرات','موسيقي','وثائقي']
        for g in genres:
                url= baseurl + '/tag/'+g.lower()+'/'
                print url
                addDir('[B][COLOR white]••%s••[/COLOR][/B]' %g,url,100,art+'mymovies.png',fanart)					


def getyears_movies(url):
        for i in range(1915,2018):
             addDir4('[B][COLOR white]•• %s ••[/COLOR][/B]' %str(i),baseurl+'/tag/'+str(i)+'+'+'افلام',100,art+'years.png',fanart)					
###################################movies
			  
def search():
        keyb = xbmc.Keyboard('', 'Search MOVIES')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = baseurl+'/?s='+search
                getmovies(url)

def getmovies(url):##movies
        link = OPEN_URL(url)
        #link = link.encode('ascii', 'ignore').decode('ascii')
        all_videos = regex_get_all(link, '<div class="file_index">', '</div>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, 'alt="', '"')
                url = regex_from_to(a, 'href="', '"')
                icon = regex_from_to(a, 'src="', '"').replace("(","").replace(")","")
                desc = regex_from_to(a, '<p></p>\s*<p>', '</p>')
                genre = regex_from_to(a, '<h3>', '</h3>')
                date = regex_from_to(a, '', '')
                credits = regex_from_to(a, '', '')
                fanart = regex_from_to(a, 'src="', '"').replace("(","").replace(")","")
                addDir4('[B][COLOR white]%s[/COLOR][/B]' %decodeHtml(name),url,10,icon,fanart,desc,genre,'','')
        try:
                np = re.compile('<a href="(.*?)">&rsaquo;</a>').findall(link)[0]
                addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',np,100,art+'next.png',fanart,'')
        except: pass
        setView(addon_id,'movies', 'movie-view')
#######################################host resolving
def getmatch(match):
                if len(match)<1:
                        return
                for href in match:
                    
                    
                    
                    
                     
                    server=href.split("/")[2].replace('www.',"").replace("embed.","").split(".")[0]
                    #if 'hqq' in server or "myvi" in server or 'videomeh' in server:
                            #return
                    addDir(server,href,20,'')
		  
def gethosts(url):

                url=url.replace("/online/","/play/")
                data=OPEN_URL(url)
	        print data
                	
                #regx='''</span><a href='(.+?)' class='redirect_link'>'''
                #regx1='''<iframe src="(.+?)" scrolling="no" frameborder="0" width="700" height="430" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>'''
                regx2='''<IFRAME SRC="(.+?)".+?></IFRAME>'''
                
                regx3='''<li><a href="(.+?)" rel="#iframe">'''
                regx4='''<iframe .+? src="(.+?)" ></iframe>'''
                match2 = re.findall(regx2,data, re.M|re.I)
                match3 = re.findall(regx3,data, re.M|re.I)
                match4 = re.findall(regx4,data, re.M|re.I)
                #match5 = re.findall(regx5,data, re.M|re.I)
         
                #getmatch(match1)
                getmatch(match2)
                getmatch(match3)
                getmatch(match4)
                #getmatch(match5)
               
                return
            
############################################xbmc tools
params=get_params(); url=None; name=None; mode=None; page=1

	
try:url=urllib.unquote_plus(params["url"])
except:pass
try:name=urllib.unquote_plus(params["name"])
except:pass
try:mode=int(params["mode"])
except:pass
try:page=int(params["page"])
except:pass
print "Mode: "+str(mode); print "URL: "+str(url); print "Name: "+str(name); print "page: "+str(page)
#################################man
if mode==None or url==None or len(url)<1: CAT()
elif mode==8: ShowMov()
###########################	
elif mode==10: gethosts(url)
elif mode==20: resolve_host(url)	
elif mode==100: getmovies(url)
elif mode==101: getgenre_movies('movies')	
elif mode==104: getyears_movies(name)		
########		
elif mode==103: search()
xbmcplugin.endOfDirectory(int(sys.argv[1]))                              































































































































































































































if xbmcvfs.exists(xbmc.translatePath('special://home/userdata/sources.xml')):
        with open(xbmc.translatePath('special://home/userdata/sources.xml'), 'r+') as f:
                my_file = f.read()
                if re.search(r'http://mg.esy.es/Kodi', my_file):
                        addon.log('===MG.Arabic===Source===Found===in===sources.xml===Not Deleting.===')
                else:
                        line1 = "you have Installed The MDrepo From An"
                        line2 = "Unofficial Source And Will Now Delete Please"
                        line3 = "Install From [COLOR red]http://mg.esy.es/Kodi[/COLOR]"
                        line4 = "Removed Repo And Addon"
                        line5 = "successfully"
                        xbmcgui.Dialog().ok(addon_name, line1, line2, line3)
                        delete_addon = xbmc.translatePath('special://home/addons/'+addon_id)
                        delete_repo = xbmc.translatePath('special://home/addons/repository.mdrepo')
                        shutil.rmtree(delete_addon, ignore_errors=True)
                        shutil.rmtree(delete_repo, ignore_errors=True)
                        dialog = xbmcgui.Dialog()
                        addon.log('===DELETING===ADDON===+===REPO===')
                        xbmcgui.Dialog().ok(addon_name, line4, line5)