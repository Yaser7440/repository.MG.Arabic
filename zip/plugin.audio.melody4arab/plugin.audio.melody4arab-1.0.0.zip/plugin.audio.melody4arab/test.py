list1=[('mahmoud','59'),('ali','9')]
list2=['mahmoud','ali']

match=[(u'http://www.melody4arab.com/songs/view_songs_2669.htm', u'\u0641\u0649 \u0627\u0644\u0644\u064a\u0644 \u0644\u0645\u0627 \u062e\u0644\u0649')]
print match[0][1]
