# -*- coding: utf8 -*-

import sys
import urllib,urllib2,re,os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re



############################################

####functions

    
def readnet(url):
            from addon.common.net import Net
            net=Net()
            USER_AGENT='Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
            MAX_TRIES=3
            


            
            headers = {
                'User-Agent': USER_AGENT,
                'Referer': url
            }

            html = net.http_GET(url).content
            return html
      

              

##########################################parsing tools
def showmenu():

                list1=[('http://www.melody4arab.com/', 'المطربون'), ('http://www.arabmelody.net/cat/lebanese_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x84\xd8\xa8\xd9\x86\xd8\xa7\xd9\x86\xd9\x8a\xd9\x87'), ('http://www.arabmelody.net/cat/kuwaiti_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x83\xd9\x88\xd9\x8a\xd8\xaa\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/saudi_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb3\xd8\xb9\xd9\x88\xd8\xaf\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/sudanese_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb3\xd9\x88\xd8\xaf\xd8\xa7\xd9\x86\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/yemeni_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x8a\xd9\x85\xd9\x86\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/emirati_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xa7\xd9\x85\xd8\xa7\xd8\xb1\xd8\xa7\xd8\xaa\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/iraqi_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb9\xd8\xb1\xd8\xa7\xd9\x82\xd9\x8a\xd9\x87'), ('http://www.arabmelody.net/cat/syrian_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb3\xd9\x88\xd8\xb1\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/bahraini_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xa8\xd8\xad\xd8\xb1\xd9\x8a\xd9\x86\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/omani_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xb9\xd9\x85\xd8\xa7\xd9\x86\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/jordanian_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xa7\xd8\xb1\xd8\xaf\xd9\x86\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/qatari_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x82\xd8\xb7\xd8\xb1\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/moroccan_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x85\xd8\xba\xd8\xb1\xd8\xa8\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/algerian_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xac\xd8\xb2\xd8\xa7\xd8\xa6\xd8\xb1\xd9\x8a\xd8\xa9'), ('http://www.arabmelody.net/cat/tunisian_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd8\xaa\xd9\x88\xd9\x86\xd8\xb3\xd9\x8a\xd9\x87'), ('http://www.arabmelody.net/cat/libyan_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x84\xd9\x8a\xd8\xa8\xd9\x8a\xd9\x87'), ('http://www.arabmelody.net/cat/palestinian_songs', '\xd8\xa7\xd8\xba\xd8\xa7\xd9\x86\xd9\x8a \xd9\x81\xd9\x84\xd8\xb3\xd8\xb7\xd9\x8a\xd9\x86\xd9\x8a\xd9\x87')]
                for item in list1:
                    #menuitems.append((item[1].encode("utf-8"),item[1],102,'img/music.png','',1))
                    try:title=item[1].encode("utf-8")
                    except:title=str(item[1])
                    addDir(title,item[0],102,'','',1)
                    break

   
                    


def getA_Z(url):
                match=[('http://www.melody4arab.com/view_artist.php?type=alpha&id=a2', '\xd9\x8a'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=a1', '\xd9\x88'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=z', '\xd9\x87'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=y', '\xd9\x86'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=x', '\xd9\x85'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=w', '\xd9\x84'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=v', '\xd9\x83'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=u', '\xd9\x82'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=t', '\xd9\x81'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=s', '\xd8\xba'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=r', '\xd8\xb9'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=q', '\xd8\xb8'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=p', '\xd8\xb7'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=o', '\xd8\xb6'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=n', '\xd8\xb5'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=m', '\xd8\xb4'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=l', '\xd8\xb3'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=k', '\xd8\xb2'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=j', '\xd8\xb1'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=i', '\xd8\xb0'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=h', '\xd8\xaf'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=g', '\xd8\xae'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=f', '\xd8\xad'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=e', '\xd8\xac'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=d', '\xd8\xab'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=c', '\xd8\xaa'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=b', '\xd8\xa8'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=a', '\xd8\xa3'), ('http://www.melody4arab.com/view_artist.php?type=alpha&id=0-9', '0-9')]
                match.reverse()
                for item in match:
                  
                   href=item[0]
                   try:letter=item[1].encode("utf-8")
                   except:letter=str(item[1])
                   
                   addDir(letter,href,100,'','',1)
                




                
			

                   
                
        
def getartists(name,urlmain,page):##movies
                print "page",page
               
               
                data=readnet(urlmain)
               
                
               
                if data is None:
                    return
               
                regx='''<a title=".*?" href="(.*?)">(.*?)</a></div>'''
                regx='''<div align="center"><a href="(.*?)" title="(.*?)"><img src="(.*?)" alt='''

                match=re.findall(regx,data, re.M|re.I)
                print "match",match
                

                for href,title,img in match:
                   
                   try:artist=title.encode("utf-8")
                   except:artist=str(title)
                   addDir(artist,href,1000,img,'',1)
                

def getalbums(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  #http://www.arabmelody.net/audios/a9109/
                  
                  url_page=urlmain+"/page"+str(page)

                 
                  
                else:
                
                      url_page=urlmain
                
                
                data=readnet(url_page)
                
                data=data.split('<span class="header_brown">')[1]
                
                
                if data is None:
                    return
                
                blocks=data.split('<tr onMouseover=')
                i=0
                print "url_page",url_page
               
                
                
                print "blocks",len(blocks)
               
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                   
                    
                    regx='''<td.*?itemprop="album"><a href="(.*?)"/>(.*?)</a></div></td>'''
                    
                    match=re.findall(regx,block, re.M|re.I)
                    print "match",match
                    
                    name=match[0][1]
                    href=match[0][0]
                    img=''

                   
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:addDir(name,href,300,img,'',1)
                    except:continue
                    
               
                   
                
               
                #addDir("next page",urlmain,200,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                
                    

def getsongs(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  #http://www.arabmelody.net/audios/a9109/
                  
                  url_page=urlmain+"/page"+str(page)

                 
                  
                else:
                
                      url_page=urlmain
                
                
                data=readnet(url_page)
                
                #data=data.split('<span class="header_brown"')[2]
                
                
                if data is None:
                    return
                
                blocks=data.split('div itemprop="track"')
                i=0
                print "url_page",url_page
               
                
                
                print "blocks",len(blocks)
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                   
                    regx='''<div align="center"><a href="(.*?)"> <img alt="(.*?)" src="(.*?)" height="14" width="14" border="0"></a></div>'''
                    
                    match=re.findall(regx,block, re.M|re.I)

                    name=match[0][1]
                    href=match[0][0]
                    img=match[0][2].replace("..",'http://www.melody4arab.com/')

                   
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:addDir(name,href,3,img,'',1)
                    except:continue
                    
               
                   
                
               
                #addDir("next page",urlmain,200,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))
                
                                        
def getalbumsongs(name,urlmain,page):##series
                print "page",page
               
                if page>1:
                  #http://www.arabmelody.net/audios/a9109/
                  
                  url_page=urlmain+"/page"+str(page)

                 
                  
                else:
                
                      url_page=urlmain
                
                
                data=readnet(url_page)
                
                #data=data.split('<span class="header_brown"')[2]
                
                
                if data is None:
                    return
                
                blocks=data.split('itemprop="track"')
                i=0
                print "url_page",url_page
               
                
                
                print "blocks",len(blocks)
                for block in blocks:
                    i=i+1
                    if i==1:
                            continue
                   
                   
                    regx='''<div align="center"><a href="(.*?)"> <img alt="(.*?)" src="(.*?)" height="14" width="14" border="0"></a></div>'''
                    regx='''song="(.*?)">'''
                    
                    href=re.findall(regx,block, re.M|re.I)[0]
                    print "href",href
                    regx='''<img src=".*?" alt="(.*?)".*?></a></div></td>'''
                    name=re.findall(regx,block, re.M|re.I)[0]
                    
                    
                    
                    img=''

                   
                                                
                               
                    
                    try:name=name.encode("utf-8")
                    except:name=str(name)
                    try:addDir(name,href,31,img,'',1)
                    except:continue
                    
               
                   
                
               
                #addDir("next page",urlmain,200,'http://www.tachyonpunch.com/comics/images/next_icon.png','',str(page+1))                    


def playlink(url):
            data=readnet(url)
            regx='''href="(.*?)" download='''
            url=re.findall(regx,data, re.M|re.I)[0]
            xbmc.Player().play(url)
            sys.exit(0)
def playlink2(url):
           
            xbmc.Player().play(url)
            sys.exit(0)               
############################################xbmc tools	    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        print "input,output",paramstring,param
        return param



def addLink(name,url,mode,iconimage):
        
    u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true");
    
    ok=xbmcplugin.addDirectoryItem(handle=_thisPlugin,url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir(name,url,mode,iconimage,extra='',page=0):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

params=get_params()
url=None
name=None
mode=None
page=1

	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "page: "+str(page)

if mode==None or url==None or len(url)<1:
        print ""
        showmenu()
elif mode==1:
        print ""+url
        gethosts(name,url)
elif mode==2:
        print ""+url
        resolve_host(url)        
elif mode==3:
        print ""+url
        playlink(url)
     
elif mode==31:
        print ""+url
        playlink2(url)        
elif mode==100:
        print ""+url
        getartists(name,url,page)
elif mode==1000:
        print ""+url
        getalbums(name,url,page)        
elif mode==101:
        print ""+url
        getgenre('movies')	

elif mode==102:
	print ""+url
	getA_Z(url)
	
elif mode==103:
	print ""+url
        search(url)    
       


elif mode==200:

	getsongs(name,url,page)
elif mode==300:

	getalbumsongs(name,url,page)	
elif mode==201:
        print "mfaraj"+url
	getseasons(name,url,page)
	#getvideopage(url,page)	
elif mode==202:
	getepisodes(name,url,page)


xbmcplugin.endOfDirectory(int(sys.argv[1]))                              
