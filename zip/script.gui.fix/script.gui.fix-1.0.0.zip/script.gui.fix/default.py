import os
import sys
import xbmc
import xbmcaddon
import xbmcgui
import time


xbmcaddon.Addon(id='script.gui.fix').openSettings()

xbmcaddon.Addon(id='script.gui.fix').getSetting('select_skin')
