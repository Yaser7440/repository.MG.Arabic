import os
import sys
import xbmc
import xbmcaddon

skin = xbmc.getSkinDir()
skinname = xbmcaddon.Addon(id=skin).getAddonInfo('name')
xbmcaddon.Addon(id='script.gui.fix').setSetting('select_skin',skin)
xbmcaddon.Addon(id='script.gui.fix').setSetting('skin_name',skinname)
