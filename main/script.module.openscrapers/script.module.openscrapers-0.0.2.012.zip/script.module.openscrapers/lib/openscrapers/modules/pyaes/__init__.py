# The MIT License (MIT)
#
# Copyright (c) 2014 Richard Moore
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribpcr/NIT Li,twar/or selo deuseiesopy
# in the Sof,twarhts
p#
# to any pshts
whom
# in the Softirighfurn puerhts
do thibpcrjecthts
# infollownclucondiimits:Moore