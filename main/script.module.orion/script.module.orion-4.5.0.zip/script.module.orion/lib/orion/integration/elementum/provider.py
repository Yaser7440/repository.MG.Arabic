from providers.orionoid import Orionoid
if provider == Orionoid.Id:
    return Orionoid.streams(filtering)
